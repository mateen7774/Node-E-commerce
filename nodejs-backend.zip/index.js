const express = require("express");
const app = express();
var morgan = require("morgan");
var bodyParser = require("body-parser");
const cors = require("cors");
app.use(cors());
const dotenv = require("dotenv");
dotenv.config({
  path: "./src/config.env",
});

app.use(bodyParser.json());
app.use(
  bodyParser.urlencoded({
    extended: true,
  })
);
app.use(express.json());
// const fileUpload = require('express-fileupload')
// app.use(fileUpload())
let path = require("path");
app.use("/public", express.static(path.join(__dirname, "public")));

app.use((req, res, next) => {
  res.header("Access-Control-Allow-Origin", "*");
  res.header(
    "Access-Control-Allow-Headers",
    "Origin, X-Requested-With, Content-Type, Accept, Authorization"
  );
  if (req.method === "OPTIONS") {
    res.header("Access-Control-Allow-Methods", "PUT, POST, PATCH, DELETE, GET");
    return res.status(200).json({});
  }
  next();
});

bodyParser.urlencoded({
  extended: false,
});

const Routes = {
  userRouter: require("./src/routes/users/users.routes"),
  adminRouter: require("./src/routes/admin/admin.routes"),
  newsLetterRouter: require("./src/routes/newsletter/newLetter.routes"),
  storeManagementRouter: require("./src/routes/store/storeManagement.routes"),
  locationRouter: require("./src/routes/location/location.routes"),
  productManagementRouter: require("./src/routes/product/productManagement.routes"),
  productRouter: require("./src/routes/department/department.routes"),
  categoryRouter: require("./src/routes/category/category.routes"),
  paymentRouter: require("./src/routes/payment/payment.routes"),
  landingPageRouter: require("./src/routes/landingPage/landingPage.routes"),
  wishListRouter: require("./src/routes/userWishList&Cart/userWishList&Cart.routes"),
  sslCommerzRouter: require("./src/routes/sslCommerz/sslCommerz.routes"),
  autorizeNetRouter: require("./src/routes/authorizeNet/authorizeNet.routes"),
  deliveryDriverRouter: require("./src/routes/deliveryDriver/deliveryDriver.routes"),
  pathaoRouter: require("./src/routes/pathao/pathao.routes"),
  uspsRouter: require("./src/routes/usps/usps.routes"),
  aramexRouter: require("./src/routes/aramex/aramex.routes"),
  stripeRouter: require("./src/routes/stripe/stripe.routes"),
  currencyRouter: require("./src/routes/currency/currency.routes"),
  courierRouter: require("./src/routes/courier/courier.routes"),
  dhlRouter: require("./src/routes/dhl/dhl.routes"),
};

app.use(express.static("public"));
app.use(morgan("dev"));

// API Routes
app.use("/api/user", Routes.userRouter);
app.use("/api/admin", Routes.adminRouter);
app.use("/api/news-letter", Routes.newsLetterRouter);
app.use("/api/store-management", Routes.storeManagementRouter);
app.use("/api/location", Routes.locationRouter);
app.use("/api/product", Routes.productManagementRouter);
app.use("/api/department", Routes.productRouter);
app.use("/api/category", Routes.categoryRouter);
app.use("/api/payment", Routes.paymentRouter);
app.use("/api/landing-page", Routes.landingPageRouter);
app.use("/api/wish-list", Routes.wishListRouter);
app.use("/api/sslCommerz", Routes.sslCommerzRouter);
app.use("/api/autorizeNet", Routes.autorizeNetRouter);
app.use("/api/deliveryDriver", Routes.deliveryDriverRouter);
app.use("/api/pathao", Routes.pathaoRouter);
app.use("/api/usps", Routes.uspsRouter);
app.use("/api/aramex", Routes.aramexRouter);
app.use("/api/stripe", Routes.stripeRouter);
app.use("/api/currency", Routes.currencyRouter);
app.use("/api/courier", Routes.courierRouter);
app.use("/api/dhl", Routes.dhlRouter);

// Calling crons
require("./src/controllers/crons/store.cron");
//require('./src/controllers/crons/currency.cron');
//require('./src/controllers/crons/payment.cron.js');

const port = process.env.PORT || 3001;
let server = app.listen(port, () =>
  console.log(`App listening on port ${port}`)
);
process.on("uncaughtException", (err) => {
  console.error("There was an uncaught error", err);
  process.exit(1); //mandatory (as per the Node.js docs)
});
