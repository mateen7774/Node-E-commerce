const connection = require("../../db/db.connection");
//var crypto = require('crypto');
const {
  QueryTypes
} = require("sequelize");
//!Landing Page Api's
exports.createLandingPageProductsView = async (req, res, next) => {
  try {
    /*   
          `CREATE VIEW ProductView
                 AS SELECT p.*,c.ProductID,c.Clicks, r.Rating,r.Review
                 FROM productclicks c, productreviewrating r,product p,category c
                 WHERE c.ProductID=r.ProductID
                 WHERE p.ProductID=r.ProductID
                 WHERE c.ProductID=r.ProductID;`;*/
    let createProductViewsQuery = ` CREATE VIEW recentlyviewed
                AS SELECT c.CategoryID,c.Category,s.SubCategory,p.* ,g.Small,g.Medium,g.large
                FROM (((((((product p
                LEFT JOIN subcategory s ON s.SubCategoryID = p.SubCategoryID)
                LEFT JOIN category c ON c.CategoryID = s.CategoryID)
                LEFT JOIN productvariantoption o ON o.ProductID IN (p.ProductID))
                LEFT JOIN productvariantoptionvalue v ON v.OptionID IN(o.OptionID))
                LEFT JOIN productimage i ON i.OptionValueID IN(v.OptionValueID))
                LEFT JOIN imagegallery g ON g.ImageGalleryID IN(i.ImageGalleryID))
                LEFT JOIN productclicks k ON k.ProductID IN (p.ProductID))
                WHERE i.MainImage = 'Y'
                Order BY  p.LastUpdate DESC
                LIMIT 10;  `;
    let createProductViews = await connection.query(createProductViewsQuery);
    if (createProductViews && createProductViews.length > 0) {
      res.status(200).json({
        status: true,
        message: "Product View successfully created",
      });
    } else {
      res.status(200).json({
        status: false,
        message: "Error while creating Product View",
      });
    }
  } catch (err) {
    next(err);
    res.status(200).json({
      status: false,
      Department: {},
      error: err.message,
    });
  }
};
exports.getRecentlyViewedProducts = async (req, res, next) => {
  try {
    let Region = req.region;
    const currencyRate = req.currency_rate;
    let {
      limit,
      offset,
      UserID
    } = req.body;
    limit = parseInt(limit);
    offset = parseInt(offset);
    offset = limit * offset;
    let productsCount = await connection.query(
      `SELECT COUNT(ProductID) as total_records FROM recentlyviewed WHERE UserID="${UserID}" `, {
      type: QueryTypes.SELECT,
    }
    );
    if (productsCount && productsCount.length > 0) {
      let viewRecentlyViewedProductsQuery =
        ` SELECT * FROM recentlyviewed WHERE UserID="${UserID}"  limit ` +
        limit +
        " offset " +
        offset;
      let viewRecentlyViewedProducts = await connection.query(
        viewRecentlyViewedProductsQuery, {
        type: QueryTypes.SELECT,
      }
      );
      if (viewRecentlyViewedProducts && viewRecentlyViewedProducts.length > 0) {
        //!cuurency conversion
        if (Region == "Bangladesh") {
          for (let i = 0; i < viewRecentlyViewedProducts.length; i++) {
            let Price = viewRecentlyViewedProducts[i].Price;
            if (viewRecentlyViewedProducts[i].Currency == "USD") {
              viewRecentlyViewedProducts[i]["Currency"] = "BDT";
              viewRecentlyViewedProducts[i]["Price"] = parseFloat(
                currencyRate * Price
              ).toFixed(2);
            }
          }
        } else if (Region == "USA") {
          for (let i = 0; i < viewRecentlyViewedProducts.length; i++) {
            let Price = viewRecentlyViewedProducts[i].Price;
            if (viewRecentlyViewedProducts[i].Currency == "BDT") {
              viewRecentlyViewedProducts[i]["Currency"] = "USD";
              viewRecentlyViewedProducts[i]["Price"] = parseFloat(
                currencyRate * Price
              ).toFixed(2);
            }
          }
        } else {
          for (let i = 0; i < viewRecentlyViewedProducts.length; i++) {
            let Price = viewRecentlyViewedProducts[i].Price;
            viewRecentlyViewedProducts[i]["Currency"] = "USD";
            viewRecentlyViewedProducts[i]["Price"] = parseFloat(
              currencyRate * Price
            ).toFixed(2);
          }
        }

        res.status(200).json({
          status: true,
          total_records: productsCount[0].total_records,
          recentlyViewedProducts: viewRecentlyViewedProducts,
        });
      } else {
        res.status(200).json({
          status: true,
          total_records: productsCount[0].total_records,
          recentlyViewedProducts: [],
        });
      }
    }
  } catch (err) {
    next(err);
    res.status(200).json({
      status: false,
      recentlyViewedProducts: {},
      error: err.message,
    });
    console.log(err.message);
  }
};
exports.trendingForyouProducts = async (req, res, next) => {
  try {
    let Region = req.region;
    const getCurrencyRates = req.getCurrencyRates;
    let currencyRate;
    let {
      limit,
      offset,
      Country,
      search,
      sort
    } = req.body;
    let CountryID;
    limit = parseInt(limit);
    offset = parseInt(offset);
    offset = limit * offset;
    if (Region == "Bangladesh") {
      CountryID = "16";
    } else {
      CountryID = "226";
    }
    let productsCount = await connection.query(
      `SELECT COUNT(ProductID) as total_records FROM trendingforyouviewmore WHERE CountryID="${CountryID}" `, {
      type: QueryTypes.SELECT,
    }
    );
    if (productsCount[0].total_records && productsCount[0].total_records > 0) {
      let viewTrendingForYouProductsQuery =
        `  SELECT * from trendingforyouviewmore WHERE CountryID="${CountryID}" AND Title LIKE "%${search}%" 
                order by ProductID ${sort} 
                 limit ` +
        limit +
        " offset " +
        offset;
      let viewTrendingForYouProducts = await connection.query(
        viewTrendingForYouProductsQuery, {
        type: QueryTypes.SELECT,
      }
      );
      if (viewTrendingForYouProducts && viewTrendingForYouProducts.length > 0) {
        //!cuurency conversion
        let newArray;
        for (let i = 0; i < viewTrendingForYouProducts.length; i++) {
          const fromCurrency = viewTrendingForYouProducts[i].Currency;
          const selectCurrency = getCurrencyRates.filter(item => item.FromCurrency === fromCurrency);
          currencyRate = selectCurrency.length ? selectCurrency[0].Rate : null;
          if (selectCurrency.length > 0) {
            newArray = getCurrencyRates.filter(item => item.FromCurrency === fromCurrency)
            const convertedCurrency = newArray[0].ToCurrency;
            let Price = viewTrendingForYouProducts[i].Price;
            viewTrendingForYouProducts[i]["Currency"] = convertedCurrency;
            viewTrendingForYouProducts[i]["Price"] = parseFloat(
              currencyRate * Price
            ).toFixed(2);
          }
        }
        res.status(200).json({
          status: true,
          total_records: productsCount[0].total_records,
          trendingForYouProducts: viewTrendingForYouProducts,
        });
      } else {
        res.status(200).json({
          status: true,
          total_records: productsCount[0].total_records,
          trendingForYouProducts: [],
        });
      }
    } else {
      res.status(200).json({
        status: true,
        total_records: productsCount[0].total_records,
        trendingForYouProducts: [],
      });
    }
  } catch (err) {
    console.loog(err)
    res.status(200).json({
      status: false,
      trendingForYouProducts: {},
      error: err.message,
    });
    console.log(err.message);
  }
};
exports.topRatedProducts = async (req, res, next) => {
  try {
    let Region = req.region;
    const getCurrencyRates = req.getCurrencyRates;
    let currencyRate;

    console.log("getCurrencyRates", getCurrencyRates)
    console.log("Region", Region)

    let {
      limit,
      offset,
      search,
      sort
    } = req.body;
    limit = parseInt(limit);
    offset = parseInt(offset);
    offset = limit * offset;
    let CountryID;
    if (Region == "Bangladesh") {
      CountryID = "16";
    } else {
      CountryID = "226";
    }
    let productsCount = await connection.query(
      `SELECT COUNT(ProductID) as total_records FROM topratedviewmore WHERE CountryID="${CountryID}"`, {
      type: QueryTypes.SELECT,
    }
    );
    if (productsCount[0].total_records && productsCount[0].total_records > 0) {
      let viewTopRatedProductsQuery =
        ` SELECT * FROM topratedviewmore WHERE Title  LIKE "%${search}%" AND CountryID="${CountryID}"
                order by ProductID ${sort}
             limit ` +
        limit +
        " offset " +
        offset;
      let viewTopRatedProducts = await connection.query(
        viewTopRatedProductsQuery, {
        type: QueryTypes.SELECT,
      }
      );
      if (viewTopRatedProducts && viewTopRatedProducts.length > 0) {
        //!cuurency conversion
        let newArray;
        for (let i = 0; i < viewTopRatedProducts.length; i++) {
          const fromCurrency = viewTopRatedProducts[i].Currency;
          const selectCurrency = getCurrencyRates.filter(item => item.FromCurrency === fromCurrency);
          currencyRate = selectCurrency.length ? selectCurrency[0].Rate : null;
          if (selectCurrency.length > 0) {
            newArray = getCurrencyRates.filter(item => item.FromCurrency === fromCurrency)
            const convertedCurrency = newArray[0].ToCurrency;
            let Price = viewTopRatedProducts[i].Price;
            viewTopRatedProducts[i]["Currency"] = convertedCurrency;
            viewTopRatedProducts[i]["Price"] = parseFloat(
              currencyRate * Price
            ).toFixed(2);
          }
        }
        res.status(200).json({
          status: true,
          total_records: productsCount[0].total_records,
          viewTopRatedProducts: viewTopRatedProducts,
        });
      } else {
        res.status(200).json({
          status: true,
          total_records: productsCount[0].total_records,
          viewTopRatedProducts: [],
        });
      }
    } else {
      res.status(200).json({
        status: true,
        total_records: productsCount[0].total_records,
        viewTopRatedProducts: [],
      });
    }
  } catch (err) {
    next(err);
    res.status(200).json({
      status: false,
      viewTopRatedProducts: {},
      error: err.message,
    });
    console.log(err.message);
  }
};
exports.deleteRecentlyViewedProducts = async (req, res, next) => {
  try {
    let {
      ProductID,
      UserID
    } = req.body;
    let checkIfProductsExists = await connection.query(
      `
            select * from recentlyviewed where ProductID = "${ProductID}" AND UserID = "${UserID}"
            `, {
      type: QueryTypes.SELECT,
    }
    );
    if (checkIfProductsExists && checkIfProductsExists.length > 0) {
      let updateRcenltyViewed = await connection.query(
        ` UPDATE productclicks SET RemoveStatus="Y" WHERE ProductID = "${ProductID}" AND UserID = "${UserID}" `
      );
      if (updateRcenltyViewed) {
        res.status(200).json({
          status: true,
          message: `Recently Viewed Product removed successfully `,
        });
      } else {
        res.status(200).json({
          status: false,
          message: `Error while updating Status `,
        });
      }
    } else {
      res.status(200).json({
        status: false,
        message: `Product does not exist `,
      });
    }
  } catch (err) {
    next(err);
    res.status(200).json({
      status: false,
      recentlyViewedProducts: {},
      message: err.message,
    });
    console.log(err.message);
  }
};
exports.test = async (req, res, next) => {
  let transaction;
  try {
    transaction = await connection.transaction();
    const data = req.body;
    const sslcz = new SSLCommerzPayment(store_id, store_passwd, is_live);
    console.log(data);
    //process the response that got from sslcommerz
    // https://developer.sslcommerz.com/doc/v4/#order-validation-api
    //res.status(200).json(data);
    let OrderLength = data.value_a.split(",");
    if (OrderLength.length == 1) {
      let updatePaymentSuccessResponse = await connection.query(
        `UPDATE processpayment SET PaymentStatus='Paid', PaymentSuccessResponse='${JSON.stringify(
          data
        )}' WHERE OrderNumber='${data.value_a}' `, {
        transaction,
      }
      );
      if (updatePaymentSuccessResponse) {
        let getInventoryCount = await connection.query(
          `SELECT OrderNumber,ProductVariantCombinationDetail,Quantity,UserID,ProductID from processorder WHERE  OrderNumber='${data.value_a}' `, {
          type: QueryTypes.SELECT,
          transaction,
        }
        );
        console.log(getInventoryCount, "getInventoryCount");
        let updateInventory;
        let saveProductVariantCombinationID = [];
        let ProductID = [];
        const UserID = getInventoryCount[0].UserID;
        for (let i = 0; i < getInventoryCount.length; i++) {
          let array = [];
          let Quantity = getInventoryCount[i].Quantity;
          array.push(getInventoryCount[i].ProductVariantCombinationDetail);
          ProductVariantCombinationIDs = `(${array.join(",")})`;
          let quantityCount = -Math.abs(Quantity);
          updateInventory = await connection.query(
            `UPDATE productinventory SET Inventory=Inventory+${quantityCount} WHERE ProductVariantCombinationID IN ${ProductVariantCombinationIDs} `, {
            transaction,
          }
          );
          saveProductVariantCombinationID.push(array);
          ProductID.push(getInventoryCount[i].ProductID);
        }
        if (updateInventory) {
          //below this
          ProductID = `(${ProductID.join(",")})`;
          saveProductVariantCombinationID = `(${saveProductVariantCombinationID.join(
            ","
          )})`;
          let checkIfProductExists = await connection.query(
            ` select * from shoppingcart where ProductID IN ${ProductID} AND ProductVariantCombinationDetail IN ${saveProductVariantCombinationID} AND UserID = "${UserID}"
                            `, {
            type: QueryTypes.SELECT,
            transaction,
          }
          );
          if (checkIfProductExists && checkIfProductExists.length > 0) {
            let deleteShoppingCartList = await connection.query(
              ` DELETE FROM shoppingcart WHERE ProductID IN ${ProductID} AND ProductVariantCombinationDetail IN ${saveProductVariantCombinationID} AND UserID = "${UserID}"`, {
              transaction,
            }
            );
            //above this
            if (deleteShoppingCartList) {
              const OrderNumber = data.value_a;
              let TypeID = "6";
              let CreaterID = "1";
              let Body = {
                OrderNumber: OrderNumber,
                body: "Your order is placed",
              };
              let Message = `You Order # ${Body.OrderNumber} is placed `;
              let getDeviceIDQuery = ` SELECT DeviceID,EmailAddress
                    FROM profile 
                    WHERE UserID=${UserID}`;
              let getDeviceID = await connection.query(getDeviceIDQuery, {
                type: QueryTypes.SELECT,
                transaction,
              });
              let DeviceID = getDeviceID[0].DeviceID;
              let EmailAddress = getDeviceID[0].EmailAddress;
              console.log(DeviceID);
              if (
                DeviceID == null ||
                DeviceID == "NULL" ||
                DeviceID == "null"
              ) {
                console.log("NULL CONDITION -----------------");
                sendEmail(EmailAddress, Message, TypeID);
                console.log(
                  " 1st EMAIL METHOD ------------------------------------"
                ); //! Email Method
                if (transaction) await transaction.commit(); //!final commit
                res.redirect(`${CLIENT_IP}/payment-checkout?status=success`);
              } else if (DeviceID && DeviceID.length > 0) {
                console.log("DEVICE ID EXIST CONDITION -----------------");
                let ReceiverID = UserID;
                console.log(
                  " 2nd EMAIL METHOD ------------------------------------"
                ); //! Email Method
                let sendNotification = await Notification(
                  TypeID,
                  Body,
                  CreaterID,
                  ReceiverID,
                  transaction
                );
                console.log(sendNotification, "sendNotification");
                if (sendNotification) {
                  sendEmail(EmailAddress, Message, TypeID);
                  if (transaction) await transaction.commit(); //!final commit
                  res.redirect(`${CLIENT_IP}/payment-checkout?status=success`);
                } else {
                  if (transaction) await transaction.rollback();
                  res.redirect(
                    `${CLIENT_IP}/payment-checkout?status=failed?failure_message=Error while sending user notification`
                  );
                }
              }
            } else {
              if (transaction) await transaction.rollback();
              res.redirect(
                `${CLIENT_IP}/payment-checkout?status=failed?failure_message=Error while deleting from cart`
              );
            }
          } else {
            if (transaction) await transaction.rollback();
            res.redirect(
              `${CLIENT_IP}/payment-checkout?status=failed?failure_message=Product does not exist in Shopping Cart`
            );
          }
        } else {
          if (transaction) await transaction.rollback();
          res.redirect(
            `${CLIENT_IP}/payment-checkout?status=failed?failure_message=Error while updating inventory count`
          );
        }
      } else {
        if (transaction) await transaction.rollback();
        res.redirect(
          `${CLIENT_IP}/payment-checkout?status=failed?failure_message=Error while updating payment response`
        );
      }
    } else {
      for (let i = 0; i < 2; i++) {
        let updatePaymentSuccessResponse = await connection.query(
          `UPDATE processpayment SET PaymentStatus='Paid', PaymentSuccessResponse='${JSON.stringify(
            data
          )}' WHERE OrderNumber='${OrderLength[i]}' `, {
          transaction,
        }
        );
        if (updatePaymentSuccessResponse) {
          let getInventoryCount = await connection.query(
            `SELECT OrderNumber,ProductVariantCombinationDetail,Quantity,UserID,ProductID from processorder WHERE  OrderNumber='${OrderLength[i]}' `, {
            type: QueryTypes.SELECT,
            transaction,
          }
          );
          console.log(getInventoryCount, "getInventoryCount");
          let updateInventory;
          let saveProductVariantCombinationID = [];
          let ProductID = [];
          const UserID = getInventoryCount[0].UserID;
          for (let i = 0; i < getInventoryCount.length; i++) {
            let array = [];
            let Quantity = getInventoryCount[i].Quantity;
            array.push(getInventoryCount[i].ProductVariantCombinationDetail);
            ProductVariantCombinationIDs = `(${array.join(",")})`;
            let quantityCount = -Math.abs(Quantity);
            updateInventory = await connection.query(
              `UPDATE productinventory SET Inventory=Inventory+${quantityCount} WHERE ProductVariantCombinationID IN ${ProductVariantCombinationIDs} `, {
              transaction,
            }
            );
            saveProductVariantCombinationID.push(array);
            ProductID.push(getInventoryCount[i].ProductID);
          }
          if (updateInventory) {
            //below this
            ProductID = `(${ProductID.join(",")})`;
            saveProductVariantCombinationID = `(${saveProductVariantCombinationID.join(
              ","
            )})`;
            let checkIfProductExists = await connection.query(
              ` select * from shoppingcart where ProductID IN ${ProductID} AND ProductVariantCombinationDetail IN ${saveProductVariantCombinationID} AND UserID = "${UserID}"
                                `, {
              type: QueryTypes.SELECT,
              transaction,
            }
            );
            if (checkIfProductExists && checkIfProductExists.length > 0) {
              let deleteShoppingCartList = await connection.query(
                ` DELETE FROM shoppingcart WHERE ProductID IN ${ProductID} AND ProductVariantCombinationDetail IN ${saveProductVariantCombinationID} AND UserID = "${UserID}"`, {
                transaction,
              }
              );
              //above this
              if (deleteShoppingCartList) {
                if (i === 0) {
                  continue;
                } else {
                  const OrderNumber = `${OrderLength[0]}, ${OrderLength[1]}`;
                  let TypeID = "6";
                  let CreaterID = "1";
                  let Body = {
                    OrderNumber: OrderNumber,
                    body: "Your order is placed",
                  };
                  let Message = `You Order # ${Body.OrderNumber} is placed `;
                  let getDeviceIDQuery = ` SELECT DeviceID,EmailAddress
                                        FROM profile 
                                       WHERE UserID=${UserID}`;
                  let getDeviceID = await connection.query(getDeviceIDQuery, {
                    type: QueryTypes.SELECT,
                    transaction,
                  });
                  let DeviceID = getDeviceID[0].DeviceID;
                  let EmailAddress = getDeviceID[0].EmailAddress;
                  console.log(DeviceID);
                  if (
                    DeviceID == null ||
                    DeviceID == "NULL" ||
                    DeviceID == "null"
                  ) {
                    console.log("NULL CONDITION -----------------");
                    sendEmail(EmailAddress, Message, TypeID);
                    console.log(
                      " 1st EMAIL METHOD ------------------------------------"
                    ); //! Email Method
                    if (transaction) await transaction.commit(); //!final commit
                    res.redirect(
                      `${CLIENT_IP}/payment-checkout?status=success`
                    );
                  } else if (DeviceID && DeviceID.length > 0) {
                    console.log("DEVICE ID EXIST CONDITION -----------------");
                    let ReceiverID = UserID;
                    console.log(
                      " 2nd EMAIL METHOD ------------------------------------"
                    ); //! Email Method
                    let sendNotification = await Notification(
                      TypeID,
                      Body,
                      CreaterID,
                      ReceiverID,
                      transaction
                    );
                    console.log(sendNotification, "sendNotification");
                    if (sendNotification) {
                      sendEmail(EmailAddress, Message, TypeID);
                      if (transaction) await transaction.commit(); //!final commit
                      res.redirect(
                        `${CLIENT_IP}/payment-checkout?status=success`
                      );
                    } else {
                      if (transaction) await transaction.rollback();
                      res.redirect(
                        `${CLIENT_IP}/payment-checkout?status=failed?failure_message=Error while sending user notification`
                      );
                    }
                  }
                }
              } else {
                if (transaction) await transaction.rollback();
                res.redirect(
                  `${CLIENT_IP}/payment-checkout?status=failed?failure_message=Error while deleting from cart`
                );
              }
            } else {
              if (transaction) await transaction.rollback();
              res.redirect(
                `${CLIENT_IP}/payment-checkout?status=failed?failure_message=Product does not exist in Shopping Cart`
              );
            }
          } else {
            if (transaction) await transaction.rollback();
            res.redirect(
              `${CLIENT_IP}/payment-checkout?status=failed?failure_message=Error while updating inventory count`
            );
          }
        } else {
          if (transaction) await transaction.rollback();
          res.redirect(
            `${CLIENT_IP}/payment-checkout?status=failed?failure_message=Error while updating payment response`
          );
        }
      }
    }
  } catch (err) {
    if (transaction) await transaction.rollback();
    console.log(err.message);
    next(err);
    res.status(200).json({
      status: false,
      message: err.message,
    });
  }
};
exports.viewLandingPageProductsView = async (req, res, next) => {
  try {
    const Region = req.region;
    const getCurrencyRates = req.getCurrencyRates;

    console.log("Region------->", Region)
    console.log("getCurrencyRates------->", getCurrencyRates)

    let currencyRate;

    let {
      Country,
      UserID
    } = req.body;
    let mostPopularProducts = [];
    let topRatedProducts = [];
    let bestSellerVendor = [];
    let newArrivalProducts = [];
    let trendingForYouProducts = [];
    let CountryID;
    if (Region == "Bangladesh") {
      CountryID = "16";
    } else {
      CountryID = "226";
    }

    console.log(Region, "Region")

    let mostPopularProductsQuery = `Select * from mostpopular WHERE CountryID="${CountryID}"`;
    let storemostPopularProducts = await connection.query(
      mostPopularProductsQuery, {
      type: QueryTypes.SELECT,
    }
    );
    if (storemostPopularProducts && storemostPopularProducts.length > 0) {
      mostPopularProducts = storemostPopularProducts;
    } else {
      mostPopularProducts = [];
    }
    let topRatedProductsQuery = `Select * from toprated WHERE CountryID="${CountryID}" `;
    let storeTopRatedProducts = await connection.query(topRatedProductsQuery, {
      type: QueryTypes.SELECT,
    });
    if (storeTopRatedProducts && storeTopRatedProducts.length > 0) {
      topRatedProducts = storeTopRatedProducts;
    } else {
      topRatedProducts = [];
    }
    let bestSellerVendorQuery = `Select * from bestsellers WHERE CountryID="${CountryID}"`;
    let storeBestSellerVendor = await connection.query(bestSellerVendorQuery, {
      type: QueryTypes.SELECT,
    });
    if (storeBestSellerVendor && storeBestSellerVendor.length > 0) {
      bestSellerVendor = storeBestSellerVendor;
    } else {
      bestSellerVendor = [];
    }
    let newArrivalProductsQuery = `Select * from newarrivals WHERE CountryID="${CountryID}"`;
    let storeNewArrivalProducts = await connection.query(
      newArrivalProductsQuery, {
      type: QueryTypes.SELECT,
    }
    );
    if (storeNewArrivalProducts && storeNewArrivalProducts.length > 0) {
      newArrivalProducts = storeNewArrivalProducts;
    } else {
      newArrivalProducts = [];
    }

    let trendingForYouProductsQuery = `Select * from trendingforyou WHERE CountryID="${CountryID}"`;
    let storeTrendingForYouProducts = await connection.query(
      trendingForYouProductsQuery, {
      type: QueryTypes.SELECT,
    }
    );
    if (storeTrendingForYouProducts && storeTrendingForYouProducts.length > 0) {
      trendingForYouProducts = storeTrendingForYouProducts;
    } else {
      trendingForYouProducts = [];
    }
    let recentlyViewedProducts = [];
    if (UserID) {
      let recentlyViewedProductsQuery = `Select * from recentlyviewed WHERE UserID="${UserID}" LIMIT 10 `;
      recentlyViewedProducts = await connection.query(
        recentlyViewedProductsQuery, {
        type: QueryTypes.SELECT,
      }
      );
    } else if (UserID == null || UserID == "") {
      recentlyViewedProducts = [];
    }
    if (recentlyViewedProducts && recentlyViewedProducts.length > 0) {
      let newArray;
      console.log("recentlyViewedProducts---------------------->", recentlyViewedProducts)

      for (let i = 0; i < recentlyViewedProducts.length; i++) {

        const fromCurrency = recentlyViewedProducts[i].Currency;

        console.log("fromCurrency", fromCurrency)
        const selectCurrency = getCurrencyRates.filter(item => item.FromCurrency === fromCurrency);
        currencyRate = selectCurrency.length ? selectCurrency[0].Rate : null;

        console.log("getCurrencyRates", getCurrencyRates)
        console.log("selectCurrency", selectCurrency)

        if (selectCurrency.length > 0) {

          console.log("currencyRate-------------------", currencyRate);

          newArray = getCurrencyRates.filter(item => item.FromCurrency === fromCurrency)

          console.log(newArray, "newArray")
          const convertedCurrency = newArray[0].ToCurrency;
          console.log(convertedCurrency, "at index", i)
          console.log(recentlyViewedProducts[i]["Currency"])
          let Price = recentlyViewedProducts[i].Price;

          console.log("Price", Price)
          recentlyViewedProducts[i]["Currency"] = convertedCurrency;
          recentlyViewedProducts[i]["Price"] = parseFloat(
            currencyRate * Price
          ).toFixed(2);

        }
        console.log(newArray, "newArray")
      }

    }
    if (mostPopularProducts && mostPopularProducts.length > 0) {

      console.log("inside mostpopulare products------------>")
      let newArray;
      let selectCurrency;
      for (let i = 0; i < mostPopularProducts.length; i++) {

        const fromCurrency = mostPopularProducts[i].Currency;
        console.log("fromCurrency", fromCurrency)

        const selectCurrency = getCurrencyRates.filter(item => item.FromCurrency === fromCurrency);
        currencyRate = selectCurrency.length ? selectCurrency[0].Rate : null;
        console.log("currencyRate-------------------", currencyRate);

        if (selectCurrency.length > 0) {
          newArray = getCurrencyRates.filter(item => item.FromCurrency === fromCurrency)
          const convertedCurrency = newArray[0].ToCurrency;
          console.log(convertedCurrency, "at index", i)
          console.log(mostPopularProducts[i]["Currency"])

          let Price = mostPopularProducts[i].Price;
          mostPopularProducts[i]["Currency"] = convertedCurrency;
          mostPopularProducts[i]["Price"] = parseFloat(
            currencyRate * Price
          ).toFixed(2);
        }

      }
    }
    if (topRatedProducts && topRatedProducts.length > 0) {
      console.log("inside toprate__________________________________________________")
      let newArray;

      for (let i = 0; i < topRatedProducts.length; i++) {

        const fromCurrency = topRatedProducts[i].Currency;
        console.log("fromCurrency", fromCurrency)

        const selectCurrency = getCurrencyRates.filter(item => item.FromCurrency === fromCurrency);
        currencyRate = selectCurrency.length ? selectCurrency[0].Rate : null;
        console.log("currencyRate-------------------", currencyRate);


        if (selectCurrency.length > 0) {
          newArray = getCurrencyRates.filter(item => item.FromCurrency === fromCurrency)
          const convertedCurrency = newArray[0].ToCurrency;
          console.log(convertedCurrency, "at index", i)
          console.log(topRatedProducts[i]["Currency"])

          let Price = topRatedProducts[i].Price;
          topRatedProducts[i]["Currency"] = convertedCurrency;
          topRatedProducts[i]["Price"] = parseFloat(
            currencyRate * Price
          ).toFixed(2);
        }
      }

    }
    if (newArrivalProducts && newArrivalProducts.length > 0) {
      let newArray;
      for (let i = 0; i < newArrivalProducts.length; i++) {

        const fromCurrency = newArrivalProducts[i].Currency;
        console.log("fromCurrency", fromCurrency)

        const selectCurrency = getCurrencyRates.filter(item => item.FromCurrency === fromCurrency);
        currencyRate = selectCurrency.length ? selectCurrency[0].Rate : null;
        console.log("currencyRate-------------------", currencyRate);

        if (selectCurrency.length > 0) {
          newArray = getCurrencyRates.filter(item => item.FromCurrency === fromCurrency)
          const convertedCurrency = newArray[0].ToCurrency;
          console.log(convertedCurrency, "at index", i)
          console.log(newArrivalProducts[i]["Currency"])

          let Price = newArrivalProducts[i].Price;
          newArrivalProducts[i]["Currency"] = convertedCurrency;
          newArrivalProducts[i]["Price"] = parseFloat(
            currencyRate * Price
          ).toFixed(2);
        }
      }
    }
    if (bestSellerVendor && bestSellerVendor.length > 0) {
      if (Region == "Bangladesh") {
        for (let i = 0; i < bestSellerVendor.length; i++) {
          let Price = bestSellerVendor[i].Price;
          if (bestSellerVendor[i].Currency == "USD") {
            bestSellerVendor[i]["Currency"] = "BDT";
            bestSellerVendor[i]["Price"] = parseFloat(
              currencyRate * Price
            ).toFixed(2);
          }
        }
      } else {
        for (let i = 0; i < bestSellerVendor.length; i++) {
          let Price = bestSellerVendor[i].Price;
          if (bestSellerVendor[i].Currency == "BDT") {
            bestSellerVendor[i]["Currency"] = "USD";
            bestSellerVendor[i]["Price"] = parseFloat(
              currencyRate * Price
            ).toFixed(2);
          }
        }
      }
    }
    if (trendingForYouProducts && trendingForYouProducts.length > 0) {

      let newArray;

      for (let i = 0; i < trendingForYouProducts.length; i++) {

        const fromCurrency = trendingForYouProducts[i].Currency;
        console.log("fromCurrency", fromCurrency)

        const selectCurrency = getCurrencyRates.filter(item => item.FromCurrency === fromCurrency);
        currencyRate = selectCurrency.length ? selectCurrency[0].Rate : null;
        console.log("currencyRate-------------------", currencyRate);

        if (selectCurrency.length > 0) {
          newArray = getCurrencyRates.filter(item => item.FromCurrency === fromCurrency)
          const convertedCurrency = newArray[0].ToCurrency;
          console.log(convertedCurrency, "at index", i)
          console.log(trendingForYouProducts[i]["Currency"])

          let Price = trendingForYouProducts[i].Price;
          trendingForYouProducts[i]["Currency"] = convertedCurrency;
          trendingForYouProducts[i]["Price"] = parseFloat(
            currencyRate * Price
          ).toFixed(2);
        }
      }

    }
    res.status(200).json({
      status: true,
      recentlyViewedProducts,
      mostPopularProducts,
      topRatedProducts,
      newArrivalProducts,
      bestSellerVendor,
      trendingForYouProducts,
    });
  } catch (err) {
    console.log(err);
    res.status(200).json({
      status: false,
      message: err.message,
    });
  }
};

exports.getCountryCurrencyData = async (req, res, next) => {
  try {
    let currencyList = await connection.query(
      `SELECT c.CountryID, c.IOSCountryCode,c.Country, c.ISO2 ,c.CurrencyCode
      FROM country c
      INNER JOIN currencyrate cr ON cr.ToCurrency = c.CurrencyCode WHERE c.AllowDelivery = 'Y'
      GROUP BY c.Country
      `, {
      type: QueryTypes.SELECT,
    }
    );
    //  console.log("currencyList_________", currencyList)
    if (currencyList.length > 0) {
      res.status(200).json({
        status: true,
        message: "success",
        // mateenobj: obj,
        currencyList: currencyList
      })
    } else {
      res.status(400).json({
        status: false,
        message: "no data found!"
      })
    }
  } catch (error) {
    res.status(500).json({
      status: false,
      message: error
    })
  }
}