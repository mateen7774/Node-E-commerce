const connection = require("../../db/db.connection");
const { QueryTypes } = require("sequelize");
const { Notification } = require("../usersControllers/users.controller");
const { sendEmail } = require("../../utils/notificationsMail");
/* var CryptoJS = require("crypto-js");
let key = "001";
    var data = CryptoJS.AES.encrypt(CourierName, key);
    data = data.toString();
    console.log(data); */
exports.addCourierService = async (req, res, next) => {
  try {
    let {
      CourierName,
      Account,
      ClientID,
      ClientSecret,
      EndPoint,
      DeliveryTrackURL,
      BusinessEmail,
      BusinessPhone,
      BusinessURL,
      APIAvailable,
      Active,
      AdminNote,
    } = req.body;
    let checkCourierName = await connection.query(
      `SELECT * FROM courier WHERE CourierName="${CourierName}" `,
      { type: QueryTypes.SELECT }
    );
    if (checkCourierName && checkCourierName.length > 0) {
      res.status(200).json({
        status: false,
        message: "Courier Service with this name already exists",
      });
    } else {
      let insertCourierServiceQuery = `INSERT INTO courier( CourierName ,
            Account,ClientID,ClientSecret,EndPoint,DeliveryTrackURL,BusinessEmail,BusinessPhone,BusinessURL,
            APIAvailable,Active,AdminNote) values(?,?,?,?,?,?,?,?,?,?,?,?)`;
      let insertCourierService = await connection.query(
        insertCourierServiceQuery,
        {
          replacements: [
            CourierName,
            Account,
            ClientID,
            ClientSecret,
            EndPoint,
            DeliveryTrackURL,
            BusinessEmail,
            BusinessPhone,
            BusinessURL,
            APIAvailable,
            Active,
            AdminNote,
          ],
        }
      );
      if (insertCourierService) {
        res.status(200).json({
          status: true,
          message: "Successfully added courier service",
        });
      } else {
        res.status(200).json({
          status: false,
          message: "Error while adding courier service ",
        });
      }
    }
  } catch (err) {
    next(err);
    res.status(200).json({
      status: false,
      message: err.message,
    });
  }
};
exports.getCourierService = async (req, res, next) => {
  try {
    let getCourierService = await connection.query(
      `SELECT * FROM courier WHERE Active="Y" `,
      { type: QueryTypes.SELECT }
    );
    if (getCourierService) {
      res.status(200).json({
        status: true,
        getCourierService,
      });
    } else {
      res.status(200).json({
        status: false,
        getCourierService: [],
      });
    }
  } catch (err) {
    next(err);
    res.status(200).json({
      status: false,
      getCourierService: [],
    });
  }
};
exports.deleteCourierService = async (req, res, next) => {
  try {
    let { CourierID } = req.body;
    let deleteCourierServiceQuery = ` UPDATE courier SET Active="N" WHERE CourierID = "${CourierID}" `;
    let deleteCourierService = await connection.query(
      deleteCourierServiceQuery
    );
    if (deleteCourierService) {
      res.status(200).json({
        status: true,
        message: "Successfully deleted courier service",
      });
    } else {
      res.status(200).json({
        status: false,
        message: "Error while deleting courier service",
      });
    }
  } catch (err) {
    next(err);
    res.status(200).json({
      status: false,
      message: err.message,
    });
  }
};
exports.updateCourierService = async (req, res, next) => {
  try {
    let {
      CourierID,
      Account,
      ClientID,
      ClientSecret,
      EndPoint,
      DeliveryTrackURL,
      BusinessEmail,
      BusinessPhone,
      BusinessURL,
      APIAvailable,
      Active,
      AdminNote,
    } = req.body;
    let LastUpdate = new Date().toISOString().slice(0, 19).replace("T", " ");
    let updateCourierServiceQuery = `UPDATE courier SET  Account = '${Account}', ClientID = '${ClientID}', 
      ClientSecret = '${ClientSecret}', EndPoint = '${EndPoint}', DeliveryTrackURL = '${DeliveryTrackURL}', BusinessEmail = '${BusinessEmail}',BusinessPhone = '${BusinessPhone}'
            , BusinessURL = '${BusinessURL}', APIAvailable = '${APIAvailable}',Active = '${Active}',LastUpdate='${LastUpdate}', AdminNote = '${AdminNote}'
            WHERE CourierID = "${CourierID}" `;

    let updateCourierService = await connection.query(
      updateCourierServiceQuery
    );
    if (updateCourierService) {
      res.status(200).json({
        status: true,
        message: "Successfully updated courier service",
      });
    } else {
      res.status(200).json({
        status: false,
        message: "Error while updating courier service ",
      });
    }
  } catch (err) {
    next(err);
    res.status(200).json({
      status: false,
      message: err.message,
    });
  }
};
//! update Order detail with tracking number
exports.updateOrderDetailByOrderId = async (req, res, next) => {
  let transaction;
  try {
    transaction = await connection.transaction();
    let { CourierID, TrackingNumber, OrderNumber, CourierName } = req.body;
    let currentdateAndTime = [];
    let LastUpdate = new Date().toISOString().slice(0, 19).replace("T", " ");
    currentdateAndTime[0] = LastUpdate;
    currentdateAndTime[1] = LastUpdate;
    currentdateAndTime[2] = LastUpdate;
    let StatusHistory = JSON.stringify(currentdateAndTime);
    let updateOrderQuery = ` UPDATE processorder SET ProcessStatus="On the Way",StatusHistory='${StatusHistory}',CourierID="${CourierID}",TrackingNumber = "${TrackingNumber}",LastUpdate="${LastUpdate}" WHERE OrderNumber="${OrderNumber}" `;
    let updateOrder = await connection.query(updateOrderQuery, { transaction });
    if (updateOrder) {
      //-------------------------------------------------------------------------------
      let TypeID = "6";
      let CreaterID = "1";
      let Body = {
        OrderNumber: OrderNumber,
        body: `Your Order ${OrderNumber} is assigned to ${CourierName} Courier Service with following TrackingNumber ${TrackingNumber} `,
      };
      let Message = `You Order # ${Body.OrderNumber} is assigned to ${CourierName} Courier Service with folowing TrackingNumber ${TrackingNumber}`;
      let getDeviceIDQuery = ` SELECT DeviceID,EmailAddress,UserID
                       FROM profile 
                       WHERE UserID IN (SELECT UserID from processorder WHERE OrderNumber="${OrderNumber}" )`;
      let getDeviceID = await connection.query(getDeviceIDQuery, {
        type: QueryTypes.SELECT,
        transaction,
      });
      if (getDeviceID && getDeviceID.length > 0) {
        let DeviceID = getDeviceID[0].DeviceID;
        let EmailAddress = getDeviceID[0].EmailAddress;
        console.log(DeviceID);
        let ReceiverID = getDeviceID[0].UserID;

        sendEmail(EmailAddress, Message, TypeID);
        let sendNotification = await Notification(
          TypeID,
          Body,
          CreaterID,
          ReceiverID,
          transaction
        );
        console.log(sendNotification, "sendNotification");
        if (sendNotification) {
          if (transaction) await transaction.commit();
          res.status(200).json({
            status: true,
            message: `Your Order ${OrderNumber} is assigned to ${CourierName} Courier Service with folowing TrackingNumber ${TrackingNumber} `,
          });
        } else {
          if (transaction) await transaction.rollback();
          res.status(200).json({
            status: false,
            message: "Error while sending Notification to User ",
          });
        }
      } else {
        res.status(200).json({
          status: false,
          message: " Error while getting user details from Database ",
        });
      }
    } else {
      res.status(200).json({
        status: false,
        message: "Error while updating order details",
      });
    }
  } catch (err) {
    next(err);
    res.status(200).json({
      status: false,
      message: err.message,
    });
  }
};
exports.sendUserVendorContactNo = async (req, res, next) => {
  let transaction;
  try {
    transaction = await connection.transaction();
    let { OrderNumber, ContactNo } = req.body;
    let currentdateAndTime = [];
    let LastUpdate = new Date().toISOString().slice(0, 19).replace("T", " ");
    currentdateAndTime[0] = LastUpdate;
    currentdateAndTime[1] = LastUpdate;
    currentdateAndTime[2] = LastUpdate;
    let StatusHistory = JSON.stringify(currentdateAndTime);
    let updateOrderQuery = ` UPDATE processorder SET ProcessStatus="On the Way",StatusHistory='${StatusHistory}',LastUpdate="${LastUpdate}"  WHERE OrderNumber="${OrderNumber}" `;
    let updateOrder = await connection.query(updateOrderQuery, { transaction });
    if (updateOrder) {
      //-------------------------------------------------------------------------------
      let TypeID = "6";
      let CreaterID = "1";
      let Body = {
        OrderNumber: OrderNumber,
        body: `Your Order ${OrderNumber} is assigned to Vendor Delivery Person with Contact No  ${ContactNo} `,
      };
      let Message = `You Order # ${Body.OrderNumber}  is assigned to Vendor Delivery Person with Contact No  ${ContactNo}`;
      let getDeviceIDQuery = ` SELECT DeviceID,EmailAddress,UserID
                       FROM profile 
                       WHERE UserID IN (SELECT UserID from processorder WHERE OrderNumber="${OrderNumber}" )`;
      let getDeviceID = await connection.query(getDeviceIDQuery, {
        type: QueryTypes.SELECT,
        transaction,
      });
      if (getDeviceID && getDeviceID.length > 0) {
        console.log(getDeviceID);
        let DeviceID = getDeviceID[0].DeviceID;
        let EmailAddress = getDeviceID[0].EmailAddress;
        console.log(DeviceID);
        let ReceiverID = getDeviceID[0].UserID;
        sendEmail(EmailAddress, Message, TypeID);
        let sendNotification = await Notification(
          TypeID,
          Body,
          CreaterID,
          ReceiverID,
          transaction
        );
        console.log(sendNotification, "sendNotification");
        if (sendNotification) {
          if (transaction) await transaction.commit();
          res.status(200).json({
            status: true,
            message: `Your Order ${OrderNumber} is assigned to Vendor Delivery Person with Contact No  ${ContactNo} `,
          });
        } else {
          if (transaction) await transaction.rollback();
          res.status(200).json({
            status: false,
            message: "Error while sending Notification to User ",
          });
        }
      } else {
        res.status(200).json({
          status: false,
          message: " Error while getting user details from Database ",
        });
      }
    } else {
      res.status(200).json({
        status: false,
        message: "Error while updating order status ",
      });
    }
  } catch (err) {
    next(err);
    res.status(200).json({
      status: false,
      message: err.message,
    });
  }
};
//! update vendor shipping status
exports.changeVendorShippingOrderStatus = async (req, res, next) => {
  let transaction;
  try {
    const { status, OrderNumber } = req.body;
    let body;
    transaction = await connection.transaction();
    let changeOrderStatus;
    let LastUpdate = new Date().toISOString().slice(0, 19).replace("T", " ");
    let StatusHistory = [];
    let orderStatus;
    let parsePreviousStatusHistory = [];
    let getOrderDetail = await connection.query(
      `SELECT * from processorder  WHERE  OrderNumber="${OrderNumber}" AND DeliveryStatus="VS" `,
      {
        type: QueryTypes.SELECT,
        transaction,
      }
    );

    if (getOrderDetail && getOrderDetail.length > 0) {
      let ReceiverID = getOrderDetail[0].UserID;
      if (status == "Delivered") {
        body = `Your order ${OrderNumber} is Delivered`;
        orderStatus = "Delivered";
        let DeliveryConfirmationPic;
        if (req.file && Object.keys(req.file).length > 0) {
          if (req.file.path && req.file.path.length > 0) {
            DeliveryConfirmationPic = req.file.path;
          } else {
            DeliveryConfirmationPic = null;
          }
        } else {
          DeliveryConfirmationPic = null;
        }
        console.log(getOrderDetail[0].StatusHistory);
        parsePreviousStatusHistory = JSON.parse(
          getOrderDetail[0].StatusHistory
        );
        parsePreviousStatusHistory.push(LastUpdate);
        changeOrderStatus = await connection.query(
          `UPDATE processorder SET ProcessStatus="${status}",StatusHistory='${JSON.stringify(
            parsePreviousStatusHistory
          )}',LastUpdate="${LastUpdate}",DeliveryConfirmationPic="${DeliveryConfirmationPic}",DeliveryDate="${LastUpdate}" WHERE OrderNumber="${OrderNumber}"`,
          {
            transaction,
          }
        );
      }
      if (changeOrderStatus) {
        let TypeID = "6";
        let CreaterID = "1";
        let Body = {
          OrderNumber: OrderNumber,
          body,
        };
        let Message = `You Order # ${Body.OrderNumber} is ${orderStatus} `;
        let getDeviceIDQuery = ` SELECT DeviceID,EmailAddress,UserID
              FROM profile 
              WHERE UserID=${ReceiverID}`;
        let getDeviceID = await connection.query(getDeviceIDQuery, {
          type: QueryTypes.SELECT,
          transaction,
        });
        if (getDeviceID && getDeviceID.length > 0) {
          let DeviceID = getDeviceID[0].DeviceID;
          let EmailAddress = getDeviceID[0].EmailAddress;
          let ReceiverID = getDeviceID[0].UserID;
          console.log(DeviceID);
          sendEmail(EmailAddress, Message, TypeID);
          let sendNotification = await Notification(
            TypeID,
            Body,
            CreaterID,
            ReceiverID,
            transaction
          );
          console.log(sendNotification, "sendNotification");
          if (sendNotification) {
            if (transaction) await transaction.commit(); //!final commit
            res.status(200).json({
              status: true,
              message: "Order Status Updated Sucessfully ",
            });
          } else {
            if (transaction) await transaction.rollback();
            res.status(200).json({
              status: false,
              message: "Error while sending Notification to User ",
            });
          }
        }
      } else {
        if (transaction) await transaction.rollback();
        res.status(200).json({
          status: false,
          message: "Error while updating order status ",
        });
      }
    } else {
      if (transaction) await transaction.rollback();
      res.status(200).json({
        status: false,
        message: "No record found to update against this data ",
      });
    }
  } catch (err) {
    if (transaction) await transaction.rollback();
    next(err);
    res.status(200).json({
      status: false,
      error: err.message,
    });
  }
};
exports.updatePickupOrderStatus = async (req, res, next) => {
  let transaction;
  try {
    const { OrderNumber } = req.body;
    let body;
    transaction = await connection.transaction();
    let changeOrderStatus;
    let StatusHistory = [];
    let getOrderDetail = await connection.query(
      `SELECT * from processorder  WHERE  OrderNumber="${OrderNumber}"  `,
      {
        type: QueryTypes.SELECT,
        transaction,
      }
    );

    if (getOrderDetail && getOrderDetail.length > 0) {
      let ReceiverID = getOrderDetail[0].UserID;
      body = `Your order ${OrderNumber} is Assigned and Ready to Pickup from Vendor Store`;
      console.log(getOrderDetail[0].StatusHistory);
      let currentdateAndTime = [];
      let LastUpdate = new Date().toISOString().slice(0, 19).replace("T", " ");
      currentdateAndTime[0] = LastUpdate;
      let StatusHistory = JSON.stringify(currentdateAndTime);
      changeOrderStatus = await connection.query(
        `UPDATE processorder SET ProcessStatus="Assigned",ReadyPickupForAdmin= "N",ReadyPickupForUser="Y",StatusHistory='${StatusHistory}',LastUpdate="${LastUpdate}" WHERE OrderNumber="${OrderNumber}"`,
        {
          transaction,
        }
      );
      if (changeOrderStatus) {
        let TypeID = "6";
        let CreaterID = "1";
        let Body = {
          OrderNumber: OrderNumber,
          body,
        };
        let Message = `You Order # ${Body.OrderNumber} is Assigned and Ready to Pickup `;
        let getDeviceIDQuery = ` SELECT DeviceID,EmailAddress,UserID
              FROM profile 
              WHERE UserID=${ReceiverID}`;
        let getDeviceID = await connection.query(getDeviceIDQuery, {
          type: QueryTypes.SELECT,
          transaction,
        });
        if (getDeviceID && getDeviceID.length > 0) {
          let DeviceID = getDeviceID[0].DeviceID;
          let EmailAddress = getDeviceID[0].EmailAddress;
          let ReceiverID = getDeviceID[0].UserID;
          console.log(DeviceID);
          sendEmail(EmailAddress, Message, TypeID);
          let sendNotification = await Notification(
            TypeID,
            Body,
            CreaterID,
            ReceiverID,
            transaction
          );
          console.log(sendNotification, "sendNotification");
          if (sendNotification) {
            if (transaction) await transaction.commit(); //!final commit
            res.status(200).json({
              status: true,
              message: "Order Assigned Status Updated Sucessfully ",
            });
          } else {
            if (transaction) await transaction.rollback();
            res.status(200).json({
              status: false,
              message: "Error while sending Notification to User ",
            });
          }
        } else {
          if (transaction) await transaction.rollback();
          res.status(200).json({
            status: false,
            message: "Error while getting user data from Database",
          });
        }
      } else {
        if (transaction) await transaction.rollback();
        res.status(200).json({
          status: false,
          message: "Error while updating order status ",
        });
      }
    } else {
      if (transaction) await transaction.rollback();
      res.status(200).json({
        status: false,
        message: "No record found to update against this data ",
      });
    }
  } catch (err) {
    if (transaction) await transaction.rollback();
    next(err);
    res.status(200).json({
      status: false,
      error: err.message,
    });
  }
};
exports.deliveredPickupOrderStatus = async (req, res, next) => {
  let transaction;
  try {
    const { status, OrderNumber } = req.body;
    let body;
    transaction = await connection.transaction();
    let changeOrderStatus;
    let LastUpdate = new Date().toISOString().slice(0, 19).replace("T", " ");
    let StatusHistory = [];
    let orderStatus;
    let parsePreviousStatusHistory = [];
    let getOrderDetail = await connection.query(
      `SELECT * from processorder  WHERE  OrderNumber="${OrderNumber}"  `,
      {
        type: QueryTypes.SELECT,
        transaction,
      }
    );
    console.log(getOrderDetail, "getOrderDetail");
    if (getOrderDetail && getOrderDetail.length > 0) {
      let ReceiverID = getOrderDetail[0].UserID;
      if (status == "Delivered") {
        body = `Your order ${OrderNumber} is Delivered`;
        orderStatus = "Delivered";
        let DeliveryConfirmationPic;
        if (req.file && Object.keys(req.file).length > 0) {
          if (req.file.path && req.file.path.length > 0) {
            DeliveryConfirmationPic = req.file.path;
          } else {
            DeliveryConfirmationPic = null;
          }
        } else {
          DeliveryConfirmationPic = null;
        }
        console.log(getOrderDetail[0].StatusHistory);
        parsePreviousStatusHistory = JSON.parse(
          getOrderDetail[0].StatusHistory
        );
        parsePreviousStatusHistory.push(LastUpdate);
        parsePreviousStatusHistory.push(LastUpdate);
        parsePreviousStatusHistory.push(LastUpdate);
        //parsePreviousStatusHistory(1).fill(LastUpdate);
        changeOrderStatus = await connection.query(
          `UPDATE processorder SET ProcessStatus="${status}",StatusHistory='${JSON.stringify(
            parsePreviousStatusHistory
          )}',LastUpdate="${LastUpdate}",DeliveryConfirmationPic="${DeliveryConfirmationPic}",DeliveryDate="${LastUpdate}" WHERE OrderNumber="${OrderNumber}"`,
          {
            transaction,
          }
        );
      }
      if (changeOrderStatus) {
        let TypeID = "6";
        let CreaterID = "1";
        let Body = {
          OrderNumber: OrderNumber,
          body,
        };
        let Message = `You Order # ${Body.OrderNumber} is ${orderStatus} `;
        let getDeviceIDQuery = ` SELECT DeviceID,EmailAddress,UserID
              FROM profile 
              WHERE UserID=${ReceiverID}`;
        let getDeviceID = await connection.query(getDeviceIDQuery, {
          type: QueryTypes.SELECT,
          transaction,
        });
        if (getDeviceID && getDeviceID.length > 0) {
          let DeviceID = getDeviceID[0].DeviceID;
          let EmailAddress = getDeviceID[0].EmailAddress;
          let ReceiverID = getDeviceID[0].UserID;
          console.log(DeviceID);
          sendEmail(EmailAddress, Message, TypeID);
          let sendNotification = await Notification(
            TypeID,
            Body,
            CreaterID,
            ReceiverID,
            transaction
          );
          console.log(sendNotification, "sendNotification");
          if (sendNotification) {
            if (transaction) await transaction.commit(); //!final commit
            res.status(200).json({
              status: true,
              message: "Order Delivered Status Updated Sucessfully ",
            });
          } else {
            if (transaction) await transaction.rollback();
            res.status(200).json({
              status: false,
              message: "Error while sending Notification to User ",
            });
          }
        }
      } else {
        if (transaction) await transaction.rollback();
        res.status(200).json({
          status: false,
          message: "Error while updating order status ",
        });
      }
    } else {
      if (transaction) await transaction.rollback();
      res.status(200).json({
        status: false,
        message: "No record found to update against this data ",
      });
    }
  } catch (err) {
    if (transaction) await transaction.rollback();
    next(err);
    res.status(200).json({
      status: false,
      error: err.message,
    });
  }
};
