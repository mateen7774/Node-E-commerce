const CC = require("currency-converter-lt");
var cron = require("node-cron");
const connection = require("../../db/db.connection");
//This will run job at 12:00 am every day
cron.schedule("*/1 * * * * ", async (req, res, next) => {
  console.log(
    "Currency CRON JOB IS IN PROGRESS __________________________________________________________________________"
  );
  try {
    let currencyConverter = new CC({
      from: "BDT",
      to: "USD",
      isDecimalComma: false,
    });
    let response = await currencyConverter.convert();
    let currencyConverter1 = new CC({
      from: "USD",
      to: "BDT",
      isDecimalComma: false,
    });
    let response1 = await currencyConverter1.convert();
    let Rate = [response, response1];
    let FromCurrency = ["BDT", "USD"];
    let ToCurrency = ["USD", "BDT"];
    let LastUpdate = new Date().toISOString().slice(0, 19).replace("T", " ");

    let updaetCurrencyRate =
      await connection.query(`UPDATE currencyrate SET LastUpdate="${LastUpdate}",Rate = CASE ID
         WHEN 1 THEN ${response}
         ELSE Rate 
         END, 
         Rate = CASE ID
         WHEN 2 THEN ${response1}
         ELSE Rate 
         END
         WHERE ID IN (1, 2)`);
    if (updaetCurrencyRate) {
      let insertAuditCurrencyRateQuery = `INSERT INTO auditcurrencyrate(RecordDate,FromCurrency,ToCurrency, Rate, LastUpdate) VALUES `;
      for (let i = 0; i < Rate.length; i++) {
        if (i == Rate.length - 1) {
          insertAuditCurrencyRateQuery += `( "${LastUpdate}","${FromCurrency[i]}","${ToCurrency[i]}","${Rate[i]}","${LastUpdate}")`;
        } else {
          insertAuditCurrencyRateQuery += `( "${LastUpdate}","${FromCurrency[i]}","${ToCurrency[i]}","${Rate[i]}","${LastUpdate}"),`;
        }
      }
      let insertAuditCurrencyRate = await connection.query(
        insertAuditCurrencyRateQuery
      );
      if (insertAuditCurrencyRate) {
        console.log("true");
        return true;
      } else {
        console.log("Error while inerting currency rate audit");
        return false;
      }
    } else {
      console.log("Error while updating rate");
      return false;
    }
  } catch (err) {
    console.log(err.message);
    return false;
  }
});
