var cron = require("node-cron");
const connection = require("../../db/db.connection");
const SSLCommerzPayment = require("sslcommerz-lts");
const { QueryTypes } = require("sequelize");
const { sendEmail } = require("../../utils/notificationsMail");
const {
  Notification,
} = require("../../controllers/usersControllers/users.controller");
const CLIENT_IP =
  process.env.SSL_LIVE === "true"
    ? "https://banglabazar.com"
    : "http://localhost:3001";
const store_id =
  process.env.SSL_LIVE_CRED === "true"
    ? "banglabazaarlive"
    : "bangl61c06810b2370";
const store_passwd =
  process.env.SSL_LIVE_CRED === "true"
    ? "603761BEBA54F89776"
    : "bangl61c06810b2370@ssl";
const is_live = process.env.SSL_LIVE_CRED === "true" ? true : false; //true for live, false for sandbox
const SERVER_IP =
  process.env.SSL_LIVE === "true"
    ? "https://api.banglabazar.com"
    : "http://192.168.100.57:3001";
//This will run job at 12:00 am every day
cron.schedule("*/1 * * * *", async (req, res, next) => {
  console.log(
    "UPDATE PAYMENT STATUS CRON JOB IS IN PROGRESS __________________________________________________________________________"
  );
  try {
    let getOrdersDetails = await connection.query(
      `SELECT OrderNumber,TransactionID,UserID FROM processpayment WHERE OrderDate >  (NOW() - INTERVAL 15 MINUTE) AND PaymentStatus="Pending" `,
      {
        type: QueryTypes.SELECT,
      }
    );
    console.log(getOrdersDetails);
    const promises = getOrdersDetails.map(async (item, i) => {
      const TransactionID = getOrdersDetails[i].TransactionID;
      const OrderNumber = getOrdersDetails[i].OrderNumber;
      const data = {
        tran_id: TransactionID,
      };
      const sslcz = new SSLCommerzPayment(store_id, store_passwd, is_live);
      let apiResponse = await sslcz.transactionQueryByTransactionId(data);
      console.log(apiResponse);
      if (
        apiResponse.element &&
        apiResponse.element.length > 0 &&
        apiResponse.element[0].status != "INVALID"
      ) {
        let updatePayentStatus = await connection.query(
          `UPDATE processpayment SET PaymentStatus="Paid" WHERE OrderNumber="${OrderNumber}" AND TransactionID="${TransactionID}" `
        );
        if (updatePayentStatus) {
          const UserID = getOrdersDetails[i].UserID;
          let TypeID = "6";
          let CreaterID = "1";
          let Body = {
            OrderNumber: OrderNumber,
            body: "Your order is placed",
          };
          let Message = `You Order # ${Body.OrderNumber} is placed `;
          let getDeviceIDQuery = ` SELECT DeviceID,EmailAddress
                FROM profile 
                WHERE UserID=${UserID}`;
          let getDeviceID = await connection.query(getDeviceIDQuery, {
            type: QueryTypes.SELECT,
          });
          let DeviceID = getDeviceID[0].DeviceID;
          let EmailAddress = getDeviceID[0].EmailAddress;
          console.log(DeviceID);
          if (DeviceID == null || DeviceID == "NULL" || DeviceID == "null") {
            console.log("NULL CONDITION -----------------");
            sendEmail(EmailAddress, Message, TypeID);
            console.log(
              " 1st EMAIL METHOD ------------------------------------"
            ); //! Email Method
          } else if (DeviceID && DeviceID.length > 0) {
            console.log("DEVICE ID EXIST CONDITION -----------------");
            console.log(
              " 2nd EMAIL METHOD ------------------------------------"
            ); //! Email Method
            let sendNotification = await Notification(
              TypeID,
              Body,
              CreaterID,
              ReceiverID
            );
            console.log(sendNotification, "sendNotification");
            if (sendNotification) {
              sendEmail(EmailAddress, Message, TypeID);
            }
          }
        } else {
          console.log("Error while updating payment status");
        }
      }
    });
    await Promise.all(promises);
  } catch (err) {
    console.log(err.message);
  }
});
