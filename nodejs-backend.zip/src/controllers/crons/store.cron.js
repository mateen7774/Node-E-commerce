var cron = require("node-cron");
const { QueryTypes } = require("sequelize");
const { createStore } = require("../pathao/pathao.controller");
const {
  Notification,
} = require("../../controllers/usersControllers/users.controller");
const connection = require("../../db/db.connection");
var pathao_base_url =
  process.env.IS_LIVE === "true"
    ? "api-hermes.pathaointernal.com"
    : "hermes-api.p-stageenv.xyz";
var pathao_credentials =
  process.env.IS_LIVE === "true"
    ? {
      username: "usazia@gmail.com",
      password: "BanglaBazar@2015",
      client_id: "1154",
      client_secret: "l23Uvqg5bPu5ojxjDuQNBZkdyBdUw0o1qZeOC0Do",
      grant_type: "password",
    }
    : {
      username: "nawaze.info@gmail.com",
      password: "lovePathao",
      client_id: "15",
      client_secret: "kcNpxS9oUXotQiuQLTyUOhppLiKE5GLV4vd2OHO2",
      grant_type: "password",
    };
const axios = require("axios");
cron.schedule("0 */30 * * * *", async (req, res, next) => {
  //The 0 at the beginning means to run at the 0th minute. (If it were an *, the script would run every minute during every second hour.)
  console.log(
    "CRON JOB IS IN PROGRESS __________________________________________________________________________"
  );
  let transaction;
  try {
    transaction = await connection.transaction();
    let body = pathao_credentials;
    let accessToken = await axios.post(
      `https://${pathao_base_url}/aladdin/api/v1/issue-token`,
      body,
      {}
    );
    if (accessToken) {
      let pathaoToken = accessToken.data.access_token;
      let response = await axios.get(
        `https://${pathao_base_url}/aladdin/api/v1/stores`,
        {
          headers: {
            Authorization: `Bearer ${pathaoToken}`,
          },
        }
      );
      if (response) {
        let getPendingStoreRequestsQuery = `
                 select * from vendorstore where ApprovalStatus = "Pending"
          `;
        let getPendingStoreRequests = await connection.query(
          getPendingStoreRequestsQuery,
          {
            type: QueryTypes.SELECT,
            transaction,
          }
        );
        if (getPendingStoreRequests && getPendingStoreRequests.length > 0) {
          console.log(
            "Pending REQUESTS QUERY EXISTS CASE-----------------------------------------------------------------------"
          );
          let storeName = [];
          let storeID = [];
          let VendorID = [];
          let pathaoStores = response.data.data.data;

          for (let i = 0; i < getPendingStoreRequests.length; i++) {
            let currentName = getPendingStoreRequests[i].StoreName;
            for (let j = 0; j < pathaoStores.length; j++) {
              if (currentName === pathaoStores[j].store_name) {
                VendorID.push(getPendingStoreRequests[i].VendorID);
                storeName.push(pathaoStores[j].store_name);
                storeID.push(pathaoStores[j].store_id);
              }
            }
          }

          console.log("VendorID.length", VendorID.length);
          console.log(VendorID, "--------------------------VendorID");
          if (VendorID.length == 0) {
            updateApprovalStatus = true;
          } else {
            for (let i = 0; i < VendorID.length; i++) {
              try {
                updateApprovalStatus = await connection.query(
                  `UPDATE vendorstore SET ApprovalStatus = "Approved",PthaoStoreResponse="Store created successfully",
                  PthaoStoreRequest = "NULL",PthaoStoreID="${storeID[i]}" WHERE StoreName="${storeName[i]}" `,
                  {
                    transaction,
                  }
                );
                updateApprovalStatus = true;
                console.log("updateApprovalStatus true");
              } catch (e) {
                updateApprovalStatus = false;
                console.log("updateApprovalStatus false");
                console.log(e);
                if (transaction) await transaction.rollback();
              }

              //above this
            }
          }
          console.log(updateApprovalStatus, "updateApprovalStatus");
          if (updateApprovalStatus) {
            let getPendingStoreRequest = await connection.query(
              `SELECT v.*, p.PathaoCityID
                        FROM vendorstore v
                        INNER JOIN pathaocities p on p.DBCityID=v.CityID
                        WHERE v.PthaoStoreRequest="In Queue" `,
              {
                type: QueryTypes.SELECT,
                transaction,
              }
            );
            if (getPendingStoreRequest && getPendingStoreRequest.length > 0) {
              console.log("getPendingStoreRequest Length");
              console.log("getPendingStoreRequest");
              let StoreName;
              let StorePhone;
              let Address1;
              let city_id;
              let zone_id;
              let area_id;
              let response;

              StoreName = getPendingStoreRequest[0].StoreName;
              StorePhone = getPendingStoreRequest[0].StorePhone;
              Address1 = getPendingStoreRequest[0].Address1;
              city_id = getPendingStoreRequest[0].PathaoCityID;
              zone_id = getPendingStoreRequest[0].zone_id;
              area_id = getPendingStoreRequest[0].area_id;
              try {
                console.log("inside create store loop");
                response = await createStore(
                  StoreName,
                  StorePhone,
                  Address1,
                  city_id,
                  zone_id,
                  area_id,
                  pathaoToken
                );
              } catch (e) {
                console.log(e);
                console.log("catch block of create store inside loop");
                if (transaction) await transaction.rollback();
              }

              if (
                response.data.message ===
                "You already have a almost same pending store request."
              ) {
                console.log("Everything Okay Relax Please 1");
                if (transaction) await transaction.commit(); //!final commit
              } else if (
                response.data.message ===
                "Store created successfully, Please wait one hour for approval."
              ) {
                updateQueueStatus = await connection.query(
                  `UPDATE vendorstore SET PthaoStoreRequest = "NULL",PthaoStoreResponse="Store created successfully" WHERE StoreName = "${StoreName}" `,
                  {
                    transaction,
                  }
                );
                if (updateQueueStatus) {
                  console.log("Everything Okay Relax Please 2");
                  if (transaction) await transaction.commit(); //!final commit
                } else {
                  console.log("Error while changing Queue Status to Pending ");
                  if (transaction) await transaction.rollback();
                }
              } else if (
                response.data.errors.name[0] === "Unique store name required"
              ) {
                let rand_Number = Math.floor(Math.random() * 90000) + 10000;
                let updatedStoreName = StoreName + rand_Number;
                console.log(updatedStoreName, "updatedStoreName 1");
                response = await createStore(
                  updatedStoreName,
                  StorePhone,
                  Address1,
                  city_id,
                  zone_id,
                  area_id,
                  pathaoToken
                );
                if (
                  response.data.message ===
                  "You already have a almost same pending store request."
                ) {
                  console.log("Everything Okay Relax Please 1");
                  if (transaction) await transaction.commit(); //!final commit
                } else if (
                  response.data.message ===
                  "Store created successfully, Please wait one hour for approval."
                ) {
                  let updateQueueStatus = await connection.query(
                    `UPDATE vendorstore SET PthaoStoreResponse="Store created successfully",PthaoStoreRequest = "NULL" WHERE StoreName = "${StoreName}" `,
                    {
                      transaction,
                    }
                  );
                  if (updateQueueStatus) {
                    console.log("Everything Okay Relax Please 2");
                    if (transaction) await transaction.commit(); //!final commit
                  } else {
                    console.log(
                      "Error while changing Queue Status to Pending "
                    );
                    if (transaction) await transaction.rollback();
                  }
                } else {
                  console.log(response.data.errors.name, "------------ issue<");
                  console.log("Error while creating pathao store");
                  if (transaction) await transaction.rollback();
                }
              } else {
                console.log(response.data.errors.name, "------------ issue>");
                console.log("Error while creating pathao store");
                if (transaction) await transaction.rollback();
              }
            } else {
              console.log("NO IN Queue Requests found ");
              if (transaction) await transaction.commit(); //! commit
            }
          } else {
            console.log("Error while updating Pthao ID & Status");
            if (transaction) await transaction.rollback();
          }
        } else {
          console.log(
            "ELSE PART OF Pending REQUESTS QUERY -------------------------------------------------------"
          );
          let getPendingStoreRequest = await connection.query(
            ` SELECT v.*, p.PathaoCityID
                    FROM vendorstore v
                    INNER JOIN pathaocities p on p.DBCityID=v.CityID
                    WHERE v.PthaoStoreRequest="In Queue" 
                    ORDER BY v.VendorStoreID ASC`,
            {
              type: QueryTypes.SELECT,
              transaction,
            }
          );
          if (getPendingStoreRequest && getPendingStoreRequest.length > 0) {
            let StoreName;
            let StorePhone;
            let Address1;
            let city_id;
            let zone_id;
            let area_id;
            let response;

            console.log("Inside loop");
            StoreName = getPendingStoreRequest[0].StoreName;
            StorePhone = getPendingStoreRequest[0].StorePhone;
            Address1 = getPendingStoreRequest[0].Address1;
            city_id = getPendingStoreRequest[0].PathaoCityID;
            zone_id = getPendingStoreRequest[0].zone_id;
            area_id = getPendingStoreRequest[0].area_id;
            try {
              response = await createStore(
                StoreName,
                StorePhone,
                Address1,
                city_id,
                zone_id,
                area_id,
                pathaoToken
              );
            } catch (e) {
              console.log(e);
              console.log("catch block of create store inside loop");
              if (transaction) await transaction.rollback();
            }
            if (
              response.data.message ===
              "You already have a almost same pending store request."
            ) {
              console.log("Everything Okay Relax Please 1");
              if (transaction) await transaction.commit(); //!final commit
            } else if (
              response.data.message ===
              "Store created successfully, Please wait one hour for approval."
            ) {
              let updateQueueStatus;
              updateQueueStatus = await connection.query(
                `UPDATE vendorstore SET PthaoStoreRequest = "NULL" WHERE StoreName ="${StoreName}" `,
                {
                  transaction,
                }
              );
              if (updateQueueStatus) {
                console.log("Everything Okay Relax Please 2");
                if (transaction) await transaction.commit(); //!final commit
              } else {
                console.log("Error while changing Queue Status to Pending ");
                if (transaction) await transaction.rollback();
              }
            } else if (
              response.data.errors.name[0] === "Unique store name required"
            ) {
              let rand_Number = Math.floor(Math.random() * 90000) + 10000;
              let updatedStoreName = StoreName + rand_Number;
              console.log(updatedStoreName, "updatedStoreName 2");
              response = await createStore(
                updatedStoreName,
                StorePhone,
                Address1,
                city_id,
                zone_id,
                area_id,
                pathaoToken
              );
              if (
                response.data.message ===
                "You already have a almost same pending store request."
              ) {
                console.log("Everything Okay Relax Please 1");
                if (transaction) await transaction.commit(); //!final commit
              } else if (
                response.data.message ===
                "Store created successfully, Please wait one hour for approval."
              ) {
                let updateQueueStatus = await connection.query(
                  `UPDATE vendorstore SET PthaoStoreRequest = "NULL" WHERE StoreName = "${StoreName}" `,
                  {
                    transaction,
                  }
                );
                if (updateQueueStatus) {
                  console.log("Everything Okay Relax Please 2");
                  if (transaction) await transaction.commit(); //!final commit
                } else {
                  console.log("Error while changing Queue Status to Pending ");
                  if (transaction) await transaction.rollback();
                }
              } else {
                console.log(
                  "Error while creating pathao store inside name condition"
                );
                if (transaction) await transaction.rollback();
              }
            } else {
              console.log("Error while creating pathao store");
              if (transaction) await transaction.rollback();
            }
          } else {
            console.log("NO IN Queue Requests found ");
            if (transaction) await transaction.commit(); //! commit
          }
        }
      } else {
        console.log("Error while getting pathao Stores");
        if (transaction) await transaction.rollback();
      }
    } else {
      console.log("Error while getting Pathao Access Token");
      if (transaction) await transaction.rollback();
    }
  } catch (err) {
    console.log("Catch Error is ", err.message);
    if (transaction) await transaction.rollback();
  }
});
