const axios = require("axios");
const { QueryTypes } = require("sequelize");
const connection = require("../../db/db.connection");
const { sendEmail } = require("../../utils/notificationsMail");
const {
  Notification,
} = require("../../controllers/usersControllers/users.controller");

const dhl_username =
  process.env.DHL_LIVE_CRED === "true" ? "true" : "apI7vQ4oG4vU2z";
const dhl_password =
  process.env.DHL_LIVE_CRED === "true" ? "false" : "Z@5bR@5tH$7jS^1g";
let dhl_url =
  process.env.DHL_LIVE === "true"
    ? "https://express.api.dhl.com/mydhlapi"
    : "https://express.api.dhl.com/mydhlapi/test";

exports.onePieceShipmentRates = async (req, res, next) => {
  let Region = req.region;
  // const currencyRate = req.currency_rate;
  const getCurrencyRates = req.getCurrencyRates;
  console.log("getCurrencyRates", getCurrencyRates)
  try {
    let { ProductIDs, destinationCityName, plannedShippingDate, countryID } =
      req.body;

    const Product_ID = ProductIDs[0]
    console.log("Product_ID", Product_ID)

    let productCurrency = await connection.query(
      `SELECT Currency FROM product WHERE ProductID="${Product_ID}"`, {
      type: QueryTypes.SELECT,
    });

    const fromCurrency = productCurrency[0]['Currency']

    if (!("plannedShippingDate" in req.body)) {
      const currentDate = new Date();

      // Add 5 days to the current date
      const fiveDaysLater = new Date(
        currentDate.getTime() + 10 * 24 * 60 * 60 * 1000
      );

      // Format the date string in the desired format (YYYY-MM-DD)
      plannedShippingDate = fiveDaysLater.toISOString().slice(0, 10);
    }
    console.log(plannedShippingDate, "plannedShippingDate");
    let saveResponse = [];
    let saveResponse1 = [];
    const idsWrappedInQuotes = ProductIDs.map(
      (ProductIDs) => `'${ProductIDs}'`
    );
    let tempProductID = `(${idsWrappedInQuotes.join(",")})`;

    let getProductShippingStatus = await connection.query(
      `SELECT ProductID,ShippingByAdmin from product WHERE ProductID IN ${tempProductID} `,
      {
        type: QueryTypes.SELECT,
      }
    );
    const BanglaBazarProducts = getProductShippingStatus.filter((obj) => {
      return obj.ShippingByAdmin === "Y";
    });
    const VendorProducts = getProductShippingStatus.filter((obj) => {
      return obj.ShippingByAdmin === "N";
    });
    console.log(BanglaBazarProducts, "BanglaBazarProducts");
    console.log(VendorProducts, "VendorProducts");

    if (BanglaBazarProducts && BanglaBazarProducts.length > 0) {
      let getUniqueCityNames = await connection.query(
        `SELECT p.ProductID,p.StoreName,pc.CityID,c.City
        FROM product p
        INNER JOIN productcity pc ON pc.ProductID=p.ProductID
        INNER JOIN city c ON c.CityID=pc.CityID
        WHERE p.ProductID IN ${tempProductID} AND p.ShippingByVendor = "N"
           `,
        {
          type: QueryTypes.SELECT,
        }
      );
      console.log(getUniqueCityNames);
      const uniqueCityProducts = Array.from(
        new Set(getUniqueCityNames.map((s) => s.City))
      ).map((lab) => {
        return {
          City: lab,
          data: getUniqueCityNames
            .filter((s) => s.City === lab)
            .map((edition) => edition.ProductID),
        };
      });

      console.log(uniqueCityProducts);
      const getCountryCode = await connection.query(
        `SELECT Country,ISO2 FROM country WHERE CountryID="${countryID}"`,
        { type: QueryTypes.SELECT }
      );
      let CountryCode = getCountryCode[0].ISO2;

      const promises = uniqueCityProducts.map(async (item, i) => {
        const ProductIds = item.data;
        const City = item.City;
        const idsWrappedInQuotes = ProductIds.map(
          (ProductIds) => `'${ProductIds}'`
        );
        let tempProductIDs = `(${idsWrappedInQuotes.join(",")})`;
        console.log(tempProductIDs, "ProductID at index ", i);
        let getProductsCities = await connection.query(
          `SELECT p.ProductID, SUM(p.Weight)AS Weight, SUM(p.Length)AS Length, SUM(p.Width)AS Width, SUM(p.Height)AS Height
                FROM product p
                WHERE p.ProductID IN ${tempProductIDs} AND p.ShippingByVendor = "N"  `,
          {
            type: QueryTypes.SELECT,
          }
        );

        let cityName = City;
        let Weight = getProductsCities[0].Weight;
        let Length = getProductsCities[0].Length;
        let Width = getProductsCities[0].Width;
        let Height = getProductsCities[0].Height;
        console.log("========================>", cityName, CountryCode, destinationCityName, Weight, Length, Width, Height, plannedShippingDate.toString());


        const response = await axios.get(`${dhl_url}/rates`, {
          params: {
            accountNumber: "525078203",
            originCountryCode: "BD",
            originCityName: cityName,
            destinationCountryCode: CountryCode,
            destinationCityName: destinationCityName,
            weight: Weight,
            length: Length,
            width: Width,
            height: Height,
            plannedShippingDate: plannedShippingDate.toString(),
            isCustomsDeclarable: true, // true or false ---> true (dutiable) and false (non-dutiable)
            unitOfMeasurement: "metric",
          },
          headers: {
            Authorization:
              "Basic " +
              Buffer.from(`${dhl_username}:${dhl_password}`).toString("base64"),
          },
        });

        let tempPrice = response.data.products[0].totalPrice[1].price;
        console.log(tempPrice, "tempPrice");
        for (let i = 0; i < ProductIds.length; i++) {
          let tempPrice = response.data.products[0].totalPrice[1].price;
          let tempLength = ProductIds.length;
          Price = tempPrice / tempLength;
          let obj = {
            message: "Price",
            type: "success",
            code: 200,
            data: {
              price: Price,
              discount: 0,
              promo_discount: 0,
              plan_id: 0,
              cod_enabled: 1,
              additional_charge: 0,
              ProductID: ProductIds[i],
            },
          };
          saveResponse.push(obj);
        }
      });
      await Promise.all(promises);
    }
    if (VendorProducts && VendorProducts.length > 0) {
      console.log(
        "Vendor case------------------------------------------------------------------------------------------"
      );
      for (let i = 0; i < VendorProducts.length; i++) {
        const ProductID = VendorProducts[i].ProductID;
        console.log(ProductID, "ProductID");
        let getShippingCost = await connection.query(
          `SELECT p.ProductID AS PRODUCTID,p.Price,p.Weight,p.ShippingByVendor,s.ShippingCostVendorInternational AS BaseShippingCost,s.ShippingCostKiloVendorInternational AS DeliveryRateKilo,IF(p.Weight>1,(SELECT DeliveryRateKilo)*Weight ,0) AS PerKgShippingCost,(SELECT BaseShippingCost)+(SELECT PerKgShippingCost) AS VendorShippingCost
            FROM product p
            LEFT JOIN shippingcostvendorcountry s ON s.ProductID=p.ProductID
            WHERE p.ProductID= "${ProductID}" AND p.ShippingByVendor="Y"
        `,
          {
            type: QueryTypes.SELECT,
          }
        );
        console.log(getShippingCost[0], "getShippingCost at index", i);
        if (getShippingCost && getShippingCost.length > 0) {
          let obj = {
            message: "Price",
            type: "success",
            code: 200,
            data: {
              price: getShippingCost[0].VendorShippingCost,
              discount: 0,
              promo_discount: 0,
              plan_id: 0,
              cod_enabled: 1,
              additional_charge: 0,
              ProductID: ProductID,
            },
          };
          saveResponse1.push(obj);
        }
      }
    }

    Array.prototype.push.apply(saveResponse, saveResponse1); //merge arrays
    // console.log(saveResponse)
    const sortByObject = ProductIDs.reduce((obj, item, index) => {
      return {
        ...obj,
        [item]: index,
      };
    }, {});

    const customSort = saveResponse.sort(
      (a, b) => sortByObject[a.data.ProductID] - sortByObject[b.data.ProductID]
    ); //sort according to input order
    if (customSort && customSort.length > 0) {
      let currencyRate;
      if (Region !== "Bangladesh") {
        for (let i = 0; i < customSort.length; i++) {
          let Price = customSort[i].data.price;
          // console.log(Price, "at index", i)

          const selectCurrency = getCurrencyRates.filter(item => item.FromCurrency === fromCurrency);
          currencyRate = selectCurrency.length ? selectCurrency[0].Rate : null;

          currencyRate = Number(currencyRate)


          if (selectCurrency.length > 0) {
            let additional_charge = customSort[i].data.additional_charge;
            customSort[i].data["additional_charge"] = parseFloat(
              currencyRate * additional_charge
            ).toFixed(2);

            customSort[i].data["additional_charge"] = Number(customSort[i].data["additional_charge"])

            customSort[i].data["price"] = parseFloat(
              currencyRate * Price
            ).toFixed(2);

            customSort[i].data["price"] = Number(customSort[i].data["price"])
          }
        }
      }

      res.status(200).send({
        status: true,
        saveResponse: customSort,
      });
    } else {
      res.status(200).send({
        status: false,
        saveResponse: [],
      });
    }
  } catch (err) {
    console.log(err);
    res.status(200).json({
      status: false,
      message: err,
    });
  }
};
exports.multiplePiecesShipmentRates = async (req, res, next) => {
  let Region = req.region;
  //const currencyRate = req.currency_rate;
  const getCurrencyRates = req.getCurrencyRates;
  try {
    //! logic is to send axios request by vendor not city coz it requires vendor store address
    const username = "apI7vQ4oG4vU2z";
    const password = "Z@5bR@5tH$7jS^1g";
    let {
      ProductIDs,
      destinationCityName,
      plannedShippingDate,
      postalCode,
      address1,
      address2,
      countryID,
    } = req.body;

    const Product_ID = ProductIDs[0]
    console.log("Product_ID", Product_ID)

    let productCurrency = await connection.query(
      `SELECT Currency FROM product WHERE ProductID="${Product_ID}"`, {
      type: QueryTypes.SELECT,
    });

    const fromCurrency = productCurrency[0]['Currency']

    if (!("plannedShippingDate" in req.body)) {
      let today = new Date();
      plannedShippingDate = new Date(
        today.getFullYear(),
        today.getMonth(),
        today.getDate() + 10
      );
    }
    console.log(plannedShippingDate, "plannedShippingDate");
    let saveResponse = [];
    let saveResponse1 = [];

    const idsWrappedInQuotes = ProductIDs.map(
      (ProductIDs) => `'${ProductIDs}'`
    );
    let tempProductID = `(${idsWrappedInQuotes.join(",")})`;

    let getProductShippingStatus = await connection.query(
      `SELECT ProductID,ShippingByAdmin,StoreName from product WHERE ProductID IN ${tempProductID} `,
      {
        type: QueryTypes.SELECT,
      }
    );
    const BanglaBazarProducts = getProductShippingStatus.filter((obj) => {
      return obj.ShippingByAdmin === "Y";
    });
    const VendorProducts = getProductShippingStatus.filter((obj) => {
      return obj.ShippingByAdmin === "N";
    });

    if (BanglaBazarProducts && BanglaBazarProducts.length > 0) {
      const getCountryCode = await connection.query(
        `SELECT Country,ISO2 FROM country WHERE CountryID="${countryID}"`,
        { type: QueryTypes.SELECT }
      );
      let countyName = getCountryCode[0].Country;
      let countryCode = getCountryCode[0].ISO2;

      const uniqueStoreProducts = Array.from(
        new Set(BanglaBazarProducts.map((s) => s.StoreName))
      ).map((lab) => {
        return {
          StoreName: lab,
          data: BanglaBazarProducts.filter((s) => s.StoreName === lab).map(
            (edition) => edition.ProductID
          ),
        };
      });

      console.log(uniqueStoreProducts, "uniqueStoreProducts");

      const promises = uniqueStoreProducts.map(async (item, i) => {
        const ProductIds = item.data;
        const idsWrappedInQuotes = ProductIds.map(
          (ProductIds) => `'${ProductIds}'`
        );
        let tempProductIDs = `(${idsWrappedInQuotes.join(",")})`;
        console.log(tempProductIDs, "ProductID at index ", i);
        let getProductsCities = await connection.query(
          `SELECT p.ProductID, SUM(p.Weight)AS Weight, SUM(p.Length)AS Length, SUM(p.Width)AS Width, SUM(p.Height)AS Height,vs.ZipCode,vs.City,vs.Address1,vs.Address2
                FROM product p
                INNER JOIN vendorstore vs ON p.StoreName=vs.StoreName
                WHERE p.ProductID IN ${tempProductIDs} AND p.ShippingByVendor = "N" 
                GROUP BY vs.StoreName `,
          {
            type: QueryTypes.SELECT,
          }
        );
        console.log(getProductsCities, "getProductsCities");
        let storeZipCode = getProductsCities[0].ZipCode;
        let storeCity = getProductsCities[0].City;
        let storeAddress1 = getProductsCities[0].Address1;
        let storeAddress2 = getProductsCities[0].Address2;
        let Weight = getProductsCities[0].Weight;
        let Length = getProductsCities[0].Length;
        let Width = getProductsCities[0].Width;
        let Height = getProductsCities[0].Height;
        //here
        let data = {
          customerDetails: {
            shipperDetails: {
              postalCode: storeZipCode,
              cityName: storeCity,
              countryCode: "BD",
              addressLine1: storeAddress1,
              addressLine2: storeAddress2,
              countyName: "Bangladesh",
            },
            receiverDetails: {
              postalCode: postalCode,
              cityName: destinationCityName,
              countryCode: countryCode,
              addressLine1: address1,
              addressLine2: address2,
              countyName: countyName,
            },
          },
          accounts: [{ typeCode: "shipper", number: "525078203" }],
          plannedShippingDateAndTime: plannedShippingDate,
          unitOfMeasurement: "metric",
          isCustomsDeclarable: true,
          packages: [
            {
              weight: parseFloat(Weight),
              dimensions: {
                length: parseFloat(Length),
                width: parseFloat(Width),
                height: parseFloat(Height),
              },
            },
          ],
        };
        const response = await axios.post(`${dhl_url}/rates`, data, {
          auth: {
            username: dhl_username,
            password: dhl_password,
          },
        });
        let tempPrice = response.data.products[0].totalPrice[1].price;
        console.log(tempPrice, "tempPrice");
        for (let i = 0; i < ProductIds.length; i++) {
          let tempPrice = response.data.products[0].totalPrice[1].price;
          let tempLength = ProductIds.length;
          Price = tempPrice / tempLength;
          let obj = {
            message: "Price",
            type: "success",
            code: 200,
            data: {
              price: Price,
              discount: 0,
              promo_discount: 0,
              plan_id: 0,
              cod_enabled: 1,
              additional_charge: 0,
              ProductID: ProductIds[i],
            },
          };
          saveResponse.push(obj);
        }
      });
      await Promise.all(promises);
    }
    if (VendorProducts && VendorProducts.length > 0) {
      console.log(
        "Vendor case------------------------------------------------------------------------------------------"
      );
      for (let i = 0; i < VendorProducts.length; i++) {
        const ProductID = VendorProducts[i].ProductID;
        console.log(ProductID, "ProductID");
        let getShippingCost = await connection.query(
          `SELECT p.ProductID AS PRODUCTID,p.Price,p.Weight,p.ShippingByVendor,s.ShippingCostVendorInternational AS BaseShippingCost,s.ShippingCostKiloVendorInternational AS DeliveryRateKilo,IF(p.Weight>1,(SELECT DeliveryRateKilo)*Weight ,0) AS PerKgShippingCost,(SELECT BaseShippingCost)+(SELECT PerKgShippingCost) AS VendorShippingCost
            FROM product p
            LEFT JOIN shippingcostvendorcountry s ON s.ProductID=p.ProductID
            WHERE p.ProductID= "${ProductID}" AND p.ShippingByVendor="Y"
        `,
          {
            type: QueryTypes.SELECT,
          }
        );
        console.log(getShippingCost[0], "getShippingCost at index", i);
        if (getShippingCost && getShippingCost.length > 0) {
          let obj = {
            message: "Price",
            type: "success",
            code: 200,
            data: {
              price: getShippingCost[0].VendorShippingCost,
              discount: 0,
              promo_discount: 0,
              plan_id: 0,
              cod_enabled: 1,
              additional_charge: 0,
              ProductID: ProductID,
            },
          };
          saveResponse1.push(obj);
        }
      }
    }

    Array.prototype.push.apply(saveResponse, saveResponse1);
    const sortByObject = ProductIDs.reduce((obj, item, index) => {
      return {
        ...obj,
        [item]: index,
      };
    }, {});

    const customSort = saveResponse.sort(
      (a, b) => sortByObject[a.data.ProductID] - sortByObject[b.data.ProductID]
    ); //sort according to input order

    if (customSort && customSort.length > 0) {
      let currencyRate;
      if (Region !== "Bangladesh") {
        for (let i = 0; i < customSort.length; i++) {
          let Price = customSort[i].data.price;
          // console.log(Price, "at index", i)
          const selectCurrency = getCurrencyRates.filter(item => item.FromCurrency === fromCurrency);
          currencyRate = selectCurrency.length ? selectCurrency[0].Rate : null;
          if (selectCurrency.lenght > 0) {
            let additional_charge = customSort[i].data.additional_charge;
            customSort[i].data["additional_charge"] = parseFloat(
              currencyRate * additional_charge
            ).toFixed(2);

            customSort[i].data["additional_charge"] = Number(customSort[i].data["additional_charge"] )

            customSort[i].data["price"] = parseFloat(
              currencyRate * Price
            ).toFixed(2);

            customSort[i].data["price"] = Number(customSort[i].data["price"])
          }
        }
      }
      res.status(200).send({
        status: true,
        saveResponse: customSort,
      });
    } else {
      res.status(200).send({
        status: false,
        saveResponse: [],
      });
    }
  } catch (err) {
    console.log(err);
    res.status(200).json({
      status: false,
      message: err.message,
    });
  }
};
exports.createShippment = async (req, res, next) => {
  let transaction;
  try {
    const username = "apI7vQ4oG4vU2z";
    const password = "Z@5bR@5tH$7jS^1g";
    transaction = await connection.transaction();
    const { OrderNumber } = req.body;
    const getUserAndStoreDetails = await connection.query(
      `SELECT vs.*,pf.EmailAddress AS UserEmail,v.CompanyName,od.ZipCode AS PostalCode,od.PhoneNumber,od.City AS DeliveryCity,od.Address1 AS  userAddress1,od.Address2 AS userAddress2,od.Name AS UserName,SUM(p.Weight) AS totalWeight,SUM(p.Height) AS totalHeight,SUM(p.Length) AS totalLength,SUM(p.Width) AS totalWidth,po.UserID,od.CountryCode,od.CountryName
      FROM processorder po
      INNER JOIN vendorstore vs ON vs.VendorStoreID=po.VendorStoreID
      INNER JOIN profile pf ON pf.UserID=po.UserID
      INNER JOIN vendor v ON v.VendorID=vs.VendorID
      INNER JOIN orderdeliveryaddress od ON od.OrderNumber=po.OrderNumber
      INNER JOIN product p ON p.ProductID=po.ProductID
      WHERE po.OrderNumber="${OrderNumber}"
      GROUP BY p.StoreName
     `,
      {
        type: QueryTypes.SELECT,
        transaction,
      }
    );
    console.log(getUserAndStoreDetails, "getUserAndStoreDetails");
    if (getUserAndStoreDetails && getUserAndStoreDetails.length > 0) {
      let storePostalCode = getUserAndStoreDetails[0].ZipCode;
      let storeCityName = getUserAndStoreDetails[0].City;
      let storeAddress1 = getUserAndStoreDetails[0].Address1;
      let storeAddress2 = getUserAndStoreDetails[0].Address2;
      let storeEmail = getUserAndStoreDetails[0].StoreEmail;
      let storePhone = getUserAndStoreDetails[0].StorePhone;
      let storeName = getUserAndStoreDetails[0].StoreName;
      let companyName = getUserAndStoreDetails[0].CompanyName;
      let userPostalCode = getUserAndStoreDetails[0].PostalCode;
      let userAddress1 = getUserAndStoreDetails[0].userAddress1;
      let userAddress2 = getUserAndStoreDetails[0].userAddress2;
      let userPhone = getUserAndStoreDetails[0].PhoneNumber;
      let deliveryCity = getUserAndStoreDetails[0].DeliveryCity;
      let userName = getUserAndStoreDetails[0].UserName;
      let EmailAddress = getUserAndStoreDetails[0].UserEmail;
      let UserID = getUserAndStoreDetails[0].UserID;
      let deliveryCountryCode = getUserAndStoreDetails[0].CountryCode;
      let deliveryCountryName = getUserAndStoreDetails[0].CountryName;
      let totalWeight = getUserAndStoreDetails[0].totalWeight;
      let totalLength = getUserAndStoreDetails[0].totalLength;
      let totalWidth = getUserAndStoreDetails[0].totalWidth;
      let totalHeight = getUserAndStoreDetails[0].totalHeight;

      var data = {
        plannedShippingDateAndTime: "2023-02-18T14:00:31GMT+01:00", //YYYY-MM-DD;
        pickup: {
          isRequested: false,
        },
        // pickup: {
        //   isRequested: true,
        //   pickupDetails: {
        //     postalAddress: {
        //       postalCode: storePostalCode.toString(),
        //       cityName: storeCityName,
        //       countryCode: "BD",
        //       addressLine1: storeAddress1,
        //       addressLine2: storeAddress2,
        //     },
        //     contactInformation: {
        //       email: String(storeEmail),
        //       phone: String(storePhone),
        //       companyName: companyName,
        //       fullName: storeName,
        //     },
        //   },
        //   pickupRequestorDetails: {
        //     postalAddress: {
        //       postalCode: storePostalCode.toString(),
        //       cityName: storeCityName,
        //       countryCode: "BD",
        //       addressLine1: storeAddress1,
        //       addressLine2: storeAddress2,
        //     },
        //     contactInformation: {
        //       email: String(storeEmail),
        //       phone: String(storePhone),
        //       companyName: companyName,
        //       fullName: storeName,
        //     },
        //   },
        // },
        productCode: "D", //Please enter DHL Express Global Product code max:6
        accounts: [{ typeCode: "shipper", number: "525078203" }],
        customerDetails: {
          shipperDetails: {
            postalAddress: {
              postalCode: storePostalCode.toString(),
              cityName: storeCityName,
              countryCode: "BD",
              addressLine1: storeAddress1,
              addressLine2: storeAddress2,
            },
            contactInformation: {
              email: String(storeEmail),
              phone: String(storePhone),
              companyName: companyName,
              fullName: storeName,
            },
          },
          receiverDetails: {
            postalAddress: {
              postalCode: userPostalCode.toString(),
              cityName: deliveryCity,
              countryCode: deliveryCountryCode,
              addressLine1: userAddress1,
              addressLine2: userAddress2,
              countryName: deliveryCountryName,
            },
            contactInformation: {
              phone: userPhone,
              companyName: userName,
              fullName: userName,
            },
          },
        },
        content: {
          packages: [
            {
              weight: parseFloat(totalWeight),
              dimensions: {
                length: parseFloat(totalLength),
                width: parseFloat(totalWidth),
                height: parseFloat(totalHeight),
              },
              customerReferences: [
                {
                  value: "Customer reference", //req
                },
              ],
            },
          ],
          isCustomsDeclarable: false, //req
          // declaredValue:"",
          // declaredValueCurrency:"",
          description: "shipment description", //req
          incoterm: "DAP", //req
          unitOfMeasurement: "metric", //req
        },
        shipmentNotification: [
          {
            typeCode: "email", //req
            receiverId: EmailAddress, //req
            // bespokeMessage: "Your order is assigned to DHL courier service",
          },
        ],
      };

      const response = await axios.post(`${dhl_url}/shipments`, data, {
        auth: {
          username: username,
          password: password,
        },
      });
      console.log(response, "response");

      if (response.data) {
        let DhlTrackingNumber = response.data.shipmentTrackingNumber;
        let DhlTrackingUrl = response.data.trackingUrl;

        let currentdateAndTime = [];
        let LastUpdate = new Date()
          .toISOString()
          .slice(0, 19)
          .replace("T", " ");
        currentdateAndTime[0] = LastUpdate;
        let StatusHistory = JSON.stringify(currentdateAndTime);
        assignOrderToDHL = await connection.query(
          `UPDATE processorder SET  ProcessStatus="Assigned",DhlTrackingNumber="${DhlTrackingNumber}",DhlTrackingUrl="${DhlTrackingUrl}",
            StatusHistory='${StatusHistory}',LastUpdate="${LastUpdate}" WHERE OrderNumber="${OrderNumber}" `,
          {
            transaction,
          }
        );
        if (assignOrderToDHL) {
          let TypeID = "6";
          let CreaterID = "1";
          let Body = {
            OrderNumber: OrderNumber,
            body: `Your Order ${OrderNumber} is Assigned to DHL `,
          };
          let Message = `You Order # ${Body.OrderNumber} is Assigned to DHL`;

          sendEmail(EmailAddress, Message, TypeID);

          let sendNotification = await Notification(
            TypeID,
            Body,
            CreaterID,
            UserID,
            transaction
          );
          console.log(sendNotification, "sendNotification");

          if (sendNotification) {
            if (transaction) await transaction.commit();
            return res.status(200).json({
              status: true,
              message: " Order is Assigned to DHL Successfully",
            });
          } else {
            if (transaction) await transaction.rollback();
            res.status(200).json({
              status: false,
              message: "Error while sending Notification to User ",
            });
          }
        } else {
          if (transaction) await transaction.rollback();
          res.status(200).json({
            status: false,
            message: "Error While assigning DHL the given Order  ",
          });
        }
      } else {
        if (transaction) await transaction.rollback();
        res.status(200).json({
          status: false,
          message: "Error while getting DHL api response",
        });
      }
    } else {
      if (transaction) await transaction.rollback();
      res.status(200).json({
        status: false,
        message: "Error while getting user and store details from db",
      });
    }
  } catch (err) {
    console.log(err.response.data);
    if (transaction) await transaction.rollback();
    res.status(200).json({
      status: false,
      message: err.message,
    });
  }
};
exports.retrieveAvailableProducts = async (req, res, next) => {
  try {
    const { ProductIDs, destinationCityName, plannedShippingDate, token } =
      req.body;
    let saveResponse = [];

    const promises = ProductIDs.map(async (item, i) => {
      const ProductID = item;
      console.log(ProductID, "ProductID at index ", i);
      getProductsCities = await connection.query(
        `SELECT ,p.ProductID,v.City,p.Weight,p.Length,p.Width,p.Height
                FROM product p
                LEFT JOIN vendorstore v ON v.StoreName=p.StoreName
                WHERE p.ProductID= "${ProductID}" AND p.ShippingByVendor="N" `,
        {
          type: QueryTypes.SELECT,
        }
      );
      console.log(
        getProductsCities,
        "getProductsCities----------------------------"
      );
      let cityName = getProductsCities[0].City;
      let Weight = getProductsCities[0].Weight;
      let Length = getProductsCities[0].Length;
      let Width = getProductsCities[0].Width;
      let Height = getProductsCities[0].Height;
      //here
      var options = {
        url: `${dhl_url}//products`,
        params: {
          accountNumber: "SOME_STRING_VALUE",
          originCountryCode: "BGD",
          originCityName: cityName,
          destinationCountryCode: "USA",
          destinationCityName: destinationCityName,
          weight: parseInt(Weight),
          length: parseInt(Length),
          width: parseInt(Width),
          height: parseInt(Height),
          plannedShippingDate: plannedShippingDate.toString(),
          isCustomsDeclarable: false, //true or false ---> true (dutiable) and false (non-dutiable)
          unitOfMeasurement: "metric",
        },
        headers: {
          Authorization: "Basic REPLACE_BASIC_AUTH",
        },
      };
      const response = await axios.get(options);
      saveResponse.push(response);
    });
    await Promise.all(promises);
    res.status(200).json({
      status: true,
      saveResponse,
    });
  } catch (err) {
    console.log(err.message);
    res.status(200).json({
      status: false,
      message: err.message,
    });
  }
};
exports.dutyAndTaxCalculator = async (req, res, next) => {
  try {
    const { ProductIDs, destinationCityName, plannedShippingDate, token } =
      req.body;
    let saveResponse = [];
    const ProductID = item;
    console.log(ProductID, "ProductID at index ", i);
    getProductsCities = await connection.query(
      `SELECT ,p.ProductID,v.City,p.Weight,p.Length,p.Width,p.Height
                FROM product p
                LEFT JOIN vendorstore v ON v.StoreName=p.StoreName
                WHERE p.ProductID= "${ProductID}" AND p.ShippingByVendor="N" `,
      {
        type: QueryTypes.SELECT,
      }
    );
    console.log(
      getProductsCities,
      "getProductsCities----------------------------"
    );
    let cityName = getProductsCities[0].City;
    let Weight = getProductsCities[0].Weight;
    let Length = getProductsCities[0].Length;
    let Width = getProductsCities[0].Width;
    let Height = getProductsCities[0].Height;
    const options = {
      //https://api.dhl.com/dtc/v1/quotes
      url: `${dhl_url}/quotes`,
      headers: {
        Authorization: "Bearer REPLACE_BEARER_TOKEN",
      },
      data: {
        pickupAccount: "0005316279",
        itemSeller: Test.com,
        pricingStrategy: AVERAGE,
        consigneeAddress: {
          country: AU,
        },
        senderAddress: {
          country: IN,
        },
        packageDetails: {
          freightCharge: {
            value: 0,
            currency: AUD,
          },
          endUse: GIFTS,
          insuranceCharge: {
            value: 0,
            currency: AUD,
          },
          tax: {
            included: true,
            percent: 10,
            return: true,
          },
          outputCurrency: AUD,
          clearanceMode: POST,
          transportMode: AIR,
        },
        customsDetails: [
          {
            itemId: "NV{{$timestamp}}",
            hsCode: "1507.90.00.13",
            itemDescription: " Of sizes not exceeding 81 cm chest measurement",
            itemShortDescription:
              "Of sizes not exceeding 81 cm chest measurement",
            gender: MALE,
            skuNumber: sku - 54321 - 01,
            condition: NEW,
            qualifiesForPreferentialTariffs: true,
            countryOfOrigin: IN,
            composition: [],
            ageGroup: ADULT,
            productCategory: "Sporting goods",
            style: Oversized,
            size: L,
            color: BLACK,
            productIdentifiers: {
              jan: "0000000000000",
              upc: "000000000000",
              brand: Wilson,
              mpn: "0000000",
              ean: "00000000",
              isbn: "00 00000000",
            },
            itemValue: {
              value: 10000,
              currency: AUD,
            },
            itemInsurance: {
              value: 0,
              currency: AUD,
            },
            itemFreight: {
              value: 0,
              currency: AUD,
            },
            width: {
              value: 30,
              unit: IN,
            },
            area: {
              value: 10,
              unit: M2,
            },
            itemQuantity: {
              value: 1,
              unit: PC,
            },
            height: {
              value: 10,
              unit: IN,
            },
            length: {
              value: 20,
              unit: IN,
            },
            weight: {
              value: 1,
              unit: KG,
            },
            tax: {
              included: true,
              percent: 10,
              return: false,
            },
          },
        ],
      },
    };
    const response = await axios.post(options);
    saveResponse.push(response);
    res.status(200).json({
      status: true,
      saveResponse,
    });
  } catch (err) {
    console.log(err.message);
    res.status(200).json({
      status: false,
      message: err.message,
    });
  }
};
exports.trackSingleShipment = async (req, res, next) => {
  try {
    let OrderNumber = req.params.id;

    let getOrderTrackingNumber = await connection.query(
      `SELECT * FROM processorder WHERE OrderNumber="${OrderNumber}" `,
      { type: QueryTypes.SELECT }
    );

    if (getOrderTrackingNumber) {
      let DhlTrackingNumber = getOrderTrackingNumber[0].DhlTrackingNumber;

      const response = await axios.get(
        `${dhl_url}/shipments/${DhlTrackingNumber}/tracking`,
        {
          auth: {
            username: dhl_username,
            password: dhl_password,
          },
        }
      );
      console.log(response, "response");
      if (response) {
        res.status(200).json({
          status: true,
          response: response.data,
        });
      }
    } else {
      res.status(200).json({
        status: false,
        message: "Error while getting tracking number from db",
      });
    }
  } catch (err) {
    console.log(err.message);
    res.status(200).json({
      status: false,
      message: err.message,
    });
  }
};
exports.trackMultipleShipment = async (req, res, next) => {
  try {
    let OrderNumber = req.params.id;

    let getOrderTrackingNumber = await connection.query(
      `SELECT * FROM processorder WHERE OrderNumber="${OrderNumber}" `,
      { type: QueryTypes.SELECT }
    );

    if (getOrderTrackingNumber) {
      let DhlTrackingNumber = getOrderTrackingNumber[0].DhlTrackingNumber;

      const response = await axios.get(`${dhl_url}/tracking`, {
        params: {
          shipmentTrackingNumber: DhlTrackingNumber,
        },
        auth: {
          username: dhl_username,
          password: dhl_password,
        },
      });

      if (response.data) {
        res.status(200).json({
          status: true,
          response: response.data,
        });
      } else {
        res.status(200).json({
          status: false,
          message: "Error while getting tracking number from db",
        });
      }
    }
  } catch (err) {
    console.log(err.response.data);
    res.status(200).json({
      status: false,
      message: err,
    });
  }
};
exports.addressValidation = async (req, res, next) => {
  let response = null;
  try {
    const { countryID, postalCode, deliveryCityName } = req.body;
    console.log(req.body);
    const getCountryCode = await connection.query(
      `SELECT Country,ISO2 FROM country WHERE CountryID="${countryID}"`,
      { type: QueryTypes.SELECT }
    );
    let countryCode = getCountryCode[0].ISO2;
    let error = false;
    try {
      response = await axios.get(`${dhl_url}/address-validate`, {
        params: {
          type: "delivery",
          cityName: deliveryCityName,
          countryCode: countryCode.toString(),
          postalCode: postalCode,
        },
        auth: {
          username: dhl_username,
          password: dhl_password,
        },
      });
    } catch (e) {
      console.log("inside catch block inner==============================================================>", e);
      error = true;
      response = { status: false, response: e.response.data.detail };
    }
    if (!error) {
      console.log("inside success block general");
      res.status(200).json({
        status: true,
        response: response.data,
      });
    } else {

      res.status(200).json({
        status: false,
        response: response,
      });
    }
  } catch (err) {
    console.log("inside catch block outer_______________________________________________________", err);
    console.log(err);
    res.status(200).json({
      status: false,
      response: err.message,
    });
  }
};
exports.dhlStatusUpdateWebhook = async (req, res, next) => {
  let transaction;
  try {
    const DhlTrackingNumber = req.params.id;
    const status = req.params.status;
    let body;
    transaction = await connection.transaction();
    let changeOrderStatus = null;
    let LastUpdate = new Date().toISOString().slice(0, 19).replace("T", " ");
    let StatusHistory = [];
    let parsePreviousStatusHistory = [];
    let getOrderDetail = await connection.query(
      `SELECT UserID,OrderNumber,StatusHistory from processorder  WHERE  DhlTrackingNumber="${DhlTrackingNumber}" `,
      {
        type: QueryTypes.SELECT,
        transaction,
      }
    );

    if (getOrderDetail && getOrderDetail.length > 0) {
      let ReceiverID = getOrderDetail[0].UserID;
      const OrderNumber = getOrderDetail[0].OrderNumber;
      body = `Your order ${OrderNumber} is ${status}`;

      console.log(getOrderDetail[0].StatusHistory);
      parsePreviousStatusHistory = JSON.parse(getOrderDetail[0].StatusHistory);
      parsePreviousStatusHistory.push(LastUpdate);
      changeOrderStatus = await connection.query(
        `UPDATE processorder SET ProcessStatus="Delivered",StatusHistory='${JSON.stringify(
          parsePreviousStatusHistory
        )}',LastUpdate="${LastUpdate}",DeliveryDate="${LastUpdate}" WHERE OrderNumber="${OrderNumber}" AND DeliveryStatus="dhl" `,
        {
          transaction,
        }
      );

      if (changeOrderStatus) {
        let getDeviceIDQuery = ` SELECT DeviceID,UserID,EmailAddress
                FROM profile 
                WHERE UserID=${ReceiverID}`;
        let getDeviceID = await connection.query(getDeviceIDQuery, {
          type: QueryTypes.SELECT,
          transaction,
        });
        if (getDeviceID && getDeviceID.length > 0) {
          let DeviceID = getDeviceID[0].DeviceID;
          let EmailAddress = getDeviceID[0].EmailAddress;
          console.log(DeviceID);
          let TypeID = "6";
          let CreaterID = "1";
          let Body = {
            OrderNumber: OrderNumber,
            body,
          };
          let Message = `You Order # ${OrderNumber} is ${status} `;
          sendEmail(EmailAddress, Message, TypeID);

          let sendNotification = await Notification(
            TypeID,
            Body,
            CreaterID,
            ReceiverID,
            transaction
          );
          console.log(sendNotification, "sendNotification");
          if (sendNotification) {
            if (transaction) await transaction.commit(); //!final commit
            res.status(200).json({
              status: true,
              message: "Order Status Updated Sucessfully ",
            });
          } else {
            if (transaction) await transaction.rollback();
            res.status(200).json({
              status: false,
              message: "Error while sending Notification to User ",
            });
          }
        } else {
          if (transaction) await transaction.rollback();
          res.status(200).json({
            status: false,
            message: "Error while getting user data from Database ",
          });
        }
      } else {
        if (transaction) await transaction.rollback();
        res.status(200).json({
          status: false,
          message: "Error while updating order status ",
        });
      }
    } else {
      if (transaction) await transaction.rollback();
      res.status(200).json({
        status: false,
        message: "No record found to update against this data ",
      });
    }
  } catch (err) {
    if (transaction) await transaction.rollback();
    next(err);
    res.status(200).json({
      status: false,
      message: err.message,
    });
  }
};
