const {
    QueryTypes
} = require("sequelize");

const connection = require("../../db/db.connection");

exports.aramexShipment = async (req, res, next) => {
    try {
        
    } catch (err) {
        next(err);
        res.status(200).json({
            status: false,
            error: err.message,
        });
    }
};