const connection = require("../../db/db.connection");
const { QueryTypes } = require("sequelize");
const csvtojson = require("csvtojson");
//!Department CRUD
exports.addDepartment = async (req, res, next) => {
  try {
    const { Department, Description, DigitalProduct, ShippingGlobal, Active } =
      req.body;
    DepartmentPic = req.file.path;
    console.log(DepartmentPic);
    // let LastUpdate = new Date().toISOString().slice(0, 19).replace('T', ' ')
    let checkIfDeptNameExists = await departmentNameCheck(Department);
    console.log(checkIfDeptNameExists);
    if (checkIfDeptNameExists && checkIfDeptNameExists == "0") {
      let insertDepartment = `insert into department ( Department ,Description,DepartmentPic,DigitalProduct,ShippingGlobal,Active) values (?,?,?,?,?,?)`;
      let addDepartment = await connection.query(insertDepartment, {
        replacements: [
          Department,
          Description,
          DepartmentPic,
          DigitalProduct,
          ShippingGlobal,
          Active,
        ],
      });
      if (addDepartment && addDepartment.length > 0) {
        res.status(200).json({
          status: true,
          message: "Department created successfully",
        });
      } else {
        res.status(200).json({
          status: false,
          message: "Error while creating Department",
        });
      }
    } else if (checkIfDeptNameExists && checkIfDeptNameExists == "1") {
      res.status(200).json({
        status: false,
        message: "Department Name already exists,Choose another",
        Department: [],
      });
    }
  } catch (err) {
    console.log(err)
    res.status(200).json({
      status: false,
      Department: {},
      error: err.message,
    });
  }
};
let departmentNameCheck = async (Department) => {
  try {
    let department = await connection.query(
      `select * from department where Department = '${Department}'`,
      { type: QueryTypes.SELECT }
    );
    if (department && department.length > 0) {
      return "1";
    } else {
      return "0";
    }
  } catch (err) {
    console.log(err.message);
    return null;
  }
};
exports.viewDepartment = async (req, res, next) => {
  try {
    let { limit, offset } = req.body;
    limit = parseInt(limit);
    offset = parseInt(offset);
    offset = limit * offset;
    let departmentCount = await connection.query(
      `SELECT COUNT(DepartmentID) as total_records FROM department  `,
      { type: QueryTypes.SELECT }
    );
    if (departmentCount && departmentCount.length > 0) {
      let data =
        "SELECT *  FROM department order by DepartmentID desc limit " +
        limit +
        " offset " +
        offset;
      let allDepartments = await connection.query(data, {
        type: QueryTypes.SELECT,
      });
      if (allDepartments && allDepartments.length > 0) {
        res.status(200).json({
          status: true,
          total_records: departmentCount[0].total_records,
          Department: allDepartments,
        });
      } else {
        res.status(200).json({
          status: true,
          total_records: departmentCount[0].total_records,
          Department: [],
        });
      }
    }
  } catch (err) {
    next(err);
    res.status(200).json({
      status: false,
      profile: {},
      error: err.message,
    });
    console.log(err.message);
  }
};
exports.viewAllDepartment = async (req, res, next) => {
  try {
    let viewAlldepartment = await connection.query(
      `SELECT * FROM  department  `,
      { type: QueryTypes.SELECT }
    );
    if (viewAlldepartment && viewAlldepartment.length > 0) {
      res.status(200).json({
        status: true,
        ALLDepartments: viewAlldepartment,
      });
    } else {
      res.status(200).json({
        status: false,
        message: "Error while displaying Departments",
      });
    }
  } catch (err) {
    next(err);
    res.status(200).json({
      status: false,
      profile: {},
      error: err.message,
    });
    console.log(err.message);
  }
};
exports.deleteDepartmentById = async (req, res, next) => {
  try {
    const id = req.params.id;
    console.log(id);

    let checkDepartment = await connection.query(
      `select * from department where DepartmentID = "${id}" `,
      { type: QueryTypes.SELECT }
    );
    if (checkDepartment && checkDepartment.length > 0) {
      let checkIfDepartmentExistsInCategory =
        await checkDepartmentIDExistsInCategory(id);
      if (
        checkIfDepartmentExistsInCategory &&
        checkIfDepartmentExistsInCategory == "0"
      ) {
        console.log(checkIfDepartmentExistsInCategory);
        let deleteDepartment = await connection.query(
          `DELETE FROM department WHERE DepartmentID="${id}" `,
          { type: QueryTypes.DELETE }
        );
        res.status(200).json({
          status: true,
          message: `Department deleted successfully`,
        });
      } else if (
        checkIfDepartmentExistsInCategory &&
        checkIfDepartmentExistsInCategory == "1"
      ) {
        res.status(200).json({
          status: false,
          message: `Category exists in this department it cannot be deleted`,
        });
      }
    } else {
      console.log("--------------");
      res.status(200).json({
        status: false,
        message: `Department does not exist`,
      });
    }
  } catch (err) {
    next(err);
    res.status(200).json({
      status: false,
      data: {},
      error: err.message,
    });
    console.log(err.message);
  }
};
exports.updateDepartmentById = async (req, res, next) => {
  try {
    const id = req.params.id;
    console.log(id);
    const { Department, Description, DigitalProduct, ShippingGlobal, Active } =
      req.body;

    let LastUpdate = new Date().toISOString().slice(0, 19).replace("T", " ");

    let checkDepartment = await connection.query(
      `select * from department where DepartmentID = '${id}' `,
      { type: QueryTypes.SELECT }
    );
    if (checkDepartment && checkDepartment.length > 0) {
      console.log(req.file);
      if (req.file && Object.keys(req.file).length > 0) {
        if (req.file.path && req.file.path.length > 0) {
          DepartmentPic = req.file.path;
        } else {
          DepartmentPic = checkDepartment[0].DepartmentPic;
        }
      } else {
        DepartmentPic = checkDepartment[0].DepartmentPic;
      }

      //console.log(user);
      console.log(Department);
      console.log(checkDepartment[0].Department);
      if (Department == checkDepartment[0].Department) {
        let updateDepartment = `UPDATE department SET Department = ?, Description = ?,DepartmentPic=?,  DigitalProduct = ?,ShippingGlobal = ?,  Active = ?,LastUpdate=? WHERE DepartmentID = "${id}"   `;
        let updateDepartmentQuery = await connection.query(updateDepartment, {
          replacements: [
            Department,
            Description,
            DepartmentPic,
            DigitalProduct,
            ShippingGlobal,
            Active,
            LastUpdate,
          ],
        });
        if (updateDepartmentQuery) {
          res.status(200).json({
            status: true,
            message: `Department updated successfully`,
          });
        } else {
          res.status(200).json({
            status: false,
            message: `Error while updating Department`,
          });
        }
      } else {
        let checkIFDepartmentNameAlreadyExists = await connection.query(
          `select * from department where Department = '${Department}' `,
          { type: QueryTypes.SELECT }
        );
        console.log(checkIFDepartmentNameAlreadyExists);
        if (
          checkIFDepartmentNameAlreadyExists &&
          checkIFDepartmentNameAlreadyExists.length > 0
        ) {
          res.status(200).json({
            status: false,
            profile: {},
            message: `Department Name already taken, please select another one`,
          });
        } else {
          let updateDepartment = `UPDATE department SET Department = ?, Description = ?,DepartmentPic=?,  DigitalProduct = ?,ShippingGlobal = ?,  Active = ?,LastUpdate=? WHERE DepartmentID = "${id}"   `;
          let updateDepartmentQuery = await connection.query(updateDepartment, {
            replacements: [
              Department,
              Description,
              DepartmentPic,
              DigitalProduct,
              ShippingGlobal,
              Active,
              LastUpdate,
            ],
          });
          if (updateDepartmentQuery && updateDepartmentQuery.length > 0) {
            res.status(200).json({
              status: true,
              message: `department  updated successfully`,
            });
          } else {
            res.status(200).json({
              status: false,
              message: `Error while updating department`,
            });
          }
        }
      }
    } else {
      res.status(200).json({
        status: false,
        message: `Department does not exist`,
        Department: [],
      });
    }
  } catch (err) {
    next(err);
    console.log(err.message);
    res.status(200).json({
      status: false,
      profile: {},
      error: err.message,
    });
  }
};
let checkDepartmentIDExistsInCategory = async (DepartmentID) => {
  try {
    let department = await connection.query(
      `select * from category where DepartmentID = '${DepartmentID}'`,
      { type: QueryTypes.SELECT }
    );
    if (department && department.length > 0) {
      return "1";
    } else {
      return "0";
    }
  } catch (err) {
    console.log(err.message);
    return null;
  }
};
//!INSERT Department list by CSV file APi's
exports.insertDepartmentsListByCsv = async (req, res, next) => {
  try {
    // CSV file name
    const fileName = "AllDepartment.csv";

    csvtojson()
      .fromFile(fileName)
      .then(async (source) => {
        // Fetching the data from each row
        // and inserting to the table "sample"
        console.log(source.length);
        for (var i = 0; i < source.length; i++) {
          (Department = source[i]["Department"]),
            (Description = source[i]["Description"]),
            (DepartmentPic = source[i]["DepartmentPic"]),
            (DigitalProduct = source[i]["DigitalProduct"]),
            (ShippingGlobal = source[i]["ShippingGlobal"]),
            (Active = source[i]["Active"]),
            (LastUpdate = source[i]["LastUpdate"]);

          // Inserting data of current row
          // into database
          var insertDepartmentTableQuery = `INSERT INTO department( Department, Description, DepartmentPic,DigitalProduct,ShippingGlobal,Active,LastUpdate) values(?,?, ?, ?,?,?,?)`;
          let insertDepartmentTable = await connection.query(
            insertDepartmentTableQuery,
            {
              replacements: [
                Department,
                Description,
                DepartmentPic,
                DigitalProduct,
                ShippingGlobal,
                Active,
                LastUpdate,
              ],
            }
          );
          if (insertDepartmentTable) {
            console.log("All items stored into database successfully");
          } else {
            console.log("Unable to insert item at row ", i + 1);
          }
        }
      });
    res.status(200).json({
      status: true,
      message: "successfully upload data in Department table",
    });
  } catch (err) {
    next(err);
    res.status(200).json({
      status: false,
      Department: {},
      error: err.message,
    });
  }
};
