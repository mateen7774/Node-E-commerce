const { QueryTypes } = require("sequelize");
const connection = require("../../db/db.connection");
const { sendMessage } = require("../../utils/notify");

exports.adduserEmailToNewsLetter = async (req, res, next) => {
  try {
    let { email_address } = req.body;

    if (email_address && email_address.length > 0) {
      let checkEmailStatusQuery = ` SELECT EmailAddress
               FROM newsletter 
               WHERE EmailAddress="${email_address}"`;
      let checkEmailStatus = await connection.query(checkEmailStatusQuery, {
        type: QueryTypes.SELECT,
      });
      console.log(checkEmailStatus.length, "checkEmailStatus");

      if (checkEmailStatus && checkEmailStatus.length > 0) {
        res.status(200).json({
          status: false,
          message:
            "It looks like you've already subscribed to our newsletter with this email address ",
        });
      } else {
        let insertNewsLetterEmailQuery = `insert into newsletter (EmailAddress) values ('${email_address}')`;

        let insertNewsLetterEmail = await connection.query(
          insertNewsLetterEmailQuery
        );
        if (insertNewsLetterEmail) {
          //sendMessage(email_address);

          res.status(200).json({
            status: true,
            message: "Email saved successfully and message send to mail",
          });
        } else {
          res.status(200).json({
            status: false,
            message: "Error while saving user email",
            error: err.message,
          });
        }
      }
    } else {
      res.status(200).json({
        status: false,
        message: "Empty Email entered ,Please provide an Email ",
      });
    }
  } catch (err) {
    res.status(200).json({
      status: false,
      message: "Error while saving user email",
      error: err.message,
    });
  }
};
