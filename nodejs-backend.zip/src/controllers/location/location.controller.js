const connection = require("../../db/db.connection");
const csvtojson = require("csvtojson");
const { QueryTypes } = require("sequelize");
//!Country CRUD
exports.addCountry = async (req, res, next) => {
  try {
    const {
      GatewayID,
      Country,
      IOSCountryCode,
      CurrencyCode,
      CountryPhoneCode,
      GMTtime,
      AllowUser,
      AllowDelivery,
      AllowVendor,
      VATTaxRate,
      FlatDeliveryRate,
      FlatDeliveryRateKilo,
      Active,
      AdminNote,
      ISO2,
    } = req.body;
    let checkIFCountryNameExists = await CountryNameCheck(Country);
    if (checkIFCountryNameExists && checkIFCountryNameExists == "0") {
      let insertCountryQuery = `insert into country (
                    GatewayID,
                    Country,
                    IOSCountryCode,
                    CurrencyCode,
                    CountryPhoneCode,
                    GMTtime,
                    AllowUser,
                    AllowDelivery,
                    AllowVendor,
                    VATTaxRate,
                    FlatDeliveryRate,
                    FlatDeliveryRateKilo,
                    Active,
                    AdminNote,
                    ISO2) values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`;
      let insertCountry = await connection.query(insertCountryQuery, {
        replacements: [
          GatewayID,
          Country,
          IOSCountryCode,
          CurrencyCode,
          CountryPhoneCode,
          GMTtime,
          AllowUser,
          AllowDelivery,
          AllowVendor,
          VATTaxRate,
          FlatDeliveryRate,
          FlatDeliveryRateKilo,
          Active,
          AdminNote,
          ISO2,
        ],
      });
      if (insertCountry) {
        res.status(200).json({
          status: true,
          message: "Country details added successfully",
        });
      } else {
        res.status(200).json({
          status: false,
          message: "Error while adding Country Details",
        });
      }
    } else if (checkIFCountryNameExists && checkIFCountryNameExists == "1") {
      res.status(200).json({
        status: false,
        message: "Country already exists",
        Country: [],
      });
    }
  } catch (err) {
    next(err);
    res.status(200).json({
      status: false,
      Category: {},
      error: err.message,
    });
  }
};
let CountryNameCheck = async (Country) => {
  try {
    let checkCountryNameExists = await connection.query(
      `select * from country where Country = '${Country}'`,
      { type: QueryTypes.SELECT }
    );
    if (checkCountryNameExists && checkCountryNameExists.length > 0) {
      return "1";
    } else {
      return "0";
    }
  } catch (err) {
    console.log(err.message);
    return null;
  }
};
exports.getCountry = async (req, res, next) => {
  try {
    let { limit, offset } = req.body;
    limit = parseInt(limit);
    offset = parseInt(offset);
    let countryCount = await connection.query(
      `SELECT COUNT(CountryID) as total_records FROM country `,
      { type: QueryTypes.SELECT }
    );
    console.log(countryCount, "countryCount");
    if (countryCount && countryCount.length > 0) {
      let viewCountry =
        "SELECT * FROM  country order by CountryID ASC limit " +
        limit +
        " offset " +
        offset;
      let allCountry = await connection.query(viewCountry, {
        type: QueryTypes.SELECT,
      });
      if (allCountry && allCountry.length > 0) {
        res.status(200).json({
          status: true,
          total_records: countryCount[0].total_records,
          Country: allCountry,
        });
      } else {
        res.status(200).json({
          status: true,
          total_records: countryCount[0].total_records,
          Country: [],
        });
      }
    } else {
      res.status(200).json({
        status: true,
        total_records: countryCount[0].total_records,
        Country: [],
      });
    }
  } catch (err) {
    next(err);
    res.status(200).json({
      status: false,
      Country: [],
      error: err.message,
    });
    console.log(err.message);
  }
};
exports.getAllCountry = async (req, res, next) => {
  try {
    let viewAllCountry = await connection.query(`SELECT * FROM country `, {
      type: QueryTypes.SELECT,
    });
    if (viewAllCountry) {
      res.status(200).json({
        status: true,
        Countries: viewAllCountry,
      });
    } else {
      res.status(200).json({
        status: false,
        message: "Error while showing Coutry Details",
      });
    }
  } catch (err) {
    next(err);
    res.status(200).json({
      status: false,
      profile: {},
      error: err.message,
    });
    console.log(err.message);
  }
};
exports.getCountryByName = async (req, res, next) => {
  try {
    let { limit, offset, Country } = req.body;
    limit = parseInt(limit);
    offset = parseInt(offset);
    console.log(req.body);
    let countryCount = await connection.query(
      `SELECT COUNT(CountryID) as total_records FROM country WHERE Country LIKE "%${Country}%" `,
      { type: QueryTypes.SELECT }
    );
    console.log(countryCount, "countryCount");
    if (countryCount && countryCount.length > 0) {
      let viewCountry =
        `SELECT * FROM  country WHERE Country LIKE "%${Country}%" order by CountryID ASC limit ` +
        limit +
        " offset " +
        offset;
      let allCountry = await connection.query(viewCountry, {
        type: QueryTypes.SELECT,
      });
      if (allCountry && allCountry.length > 0) {
        res.status(200).json({
          status: true,
          total_records: countryCount[0].total_records,
          Country: allCountry,
        });
      } else {
        res.status(200).json({
          status: true,
          total_records: countryCount[0].total_records,
          Country: [],
        });
      }
    } else {
      res.status(200).json({
        status: true,
        total_records: countryCount[0].total_records,
        Country: [],
      });
    }
  } catch (err) {
    console.log(err);
    res.status(200).json({
      status: false,
      Country: [],
      error: err.message,
    });
  }
};
exports.getVendorAllowedCountries = async (req, res, next) => {
  try {
    let getVednorAllowedCountries = await connection.query(
      `SELECT * FROM country WHERE AllowVendor="Y" `,
      {
        type: QueryTypes.SELECT,
      }
    );
    if (getVednorAllowedCountries && getVednorAllowedCountries.length > 0) {
      res.status(200).json({
        status: true,
        Countries: getVednorAllowedCountries,
      });
    } else {
      res.status(200).json({
        status: false,
        message: "No Country Detail Found",
        Countries: [],
      });
    }
  } catch (err) {
    console.log(err);
    res.status(200).json({
      status: false,
      Countries: {},
      error: err.message,
    });
  }
};
exports.getDeliveryAllowedCountries = async (req, res, next) => {
  try {
    let getDeliveryAllowedCountries = await connection.query(
      `SELECT * FROM country WHERE AllowDelivery="Y" `,
      {
        type: QueryTypes.SELECT,
      }
    );
    if (getDeliveryAllowedCountries && getDeliveryAllowedCountries.length > 0) {
      res.status(200).json({
        status: true,
        Countries: getDeliveryAllowedCountries,
      });
    } else {
      res.status(200).json({
        status: false,
        message: "No Country Detail Found",
        Countries: [],
      });
    }
  } catch (err) {
    console.log(err);
    res.status(200).json({
      status: false,
      Countries: {},
      error: err.message,
    });
    console.log(err.message);
  }
};
exports.getUserAllowedCountries = async (req, res, next) => {
  try {
    let getUserAllowedCountries = await connection.query(
      `SELECT * FROM country WHERE AllowUser="Y" `,
      {
        type: QueryTypes.SELECT,
      }
    );
    if (getUserAllowedCountries && getUserAllowedCountries.length > 0) {
      res.status(200).json({
        status: true,
        Countries: getUserAllowedCountries,
      });
    } else {
      res.status(200).json({
        status: false,
        message: "No Country Detail Found",
        Countries: [],
      });
    }
  } catch (err) {
    console.log(err);
    res.status(200).json({
      status: false,
      Countries: {},
      error: err.message,
    });
    console.log(err.message);
  }
};
exports.updateCountryById = async (req, res, next) => {
  try {
    const {
      GatewayID,
      Country,
      IOSCountryCode,
      CurrencyCode,
      CountryPhoneCode,
      GMTtime,
      AllowUser,
      AllowDelivery,
      AllowVendor,
      VATTaxRate,
      FlatDeliveryRate,
      FlatDeliveryRateKilo,
      Active,
      AdminNote,
      ISO2,
    } = req.body;
    let LastUpdate = new Date().toISOString().slice(0, 19).replace("T", " ");
    let checkifCountry = await connection.query(
      `SELECT * FROM country WHERE CountryID="${req.params.id}"`,
      { type: QueryTypes.SELECT }
    );
    if (checkifCountry && checkifCountry.length > 0) {
      //check for unique Country Name
      console.log(Country);
      console.log(checkifCountry[0].Country);
      if (Country == checkifCountry[0].Country) {
        let updateCountryQuery = `UPDATE country SET
                      GatewayID=?,
                      Country=?,
                      IOSCountryCode=?,
                      CurrencyCode=?,
                      CountryPhoneCode=?,
                      GMTtime=?,
                      AllowUser=?,
                      AllowDelivery=?,
                      AllowVendor=?,
                      VATTaxRate=?,
                      FlatDeliveryRate=?,
                      FlatDeliveryRateKilo=?,
                      Active=?,
                      LastUpdate=?,
                      AdminNote=?,
                      ISO2=? WHERE CountryID  = "${req.params.id}"`;
        let updateCountry = await connection.query(updateCountryQuery, {
          replacements: [
            GatewayID,
            Country,
            IOSCountryCode,
            CurrencyCode,
            CountryPhoneCode,
            GMTtime,
            AllowUser,
            AllowDelivery,
            AllowVendor,
            VATTaxRate,
            FlatDeliveryRate,
            FlatDeliveryRateKilo,
            Active,
            LastUpdate,
            AdminNote,
            ISO2,
          ],
        });
        if (updateCountry) {
          res.status(200).json({
            status: true,
            message: "Country details updated successfully",
          });
        } else {
          res.status(200).json({
            status: false,
            message: "Error while updated Country Details",
          });
        }
      } else {
        let checkIFCountryNameAlreadyExist = await connection.query(
          `select * from country  where Country  = "${Country}"   `,
          { type: QueryTypes.SELECT }
        );
        console.log(checkIFCountryNameAlreadyExist);
        if (
          checkIFCountryNameAlreadyExist &&
          checkIFCountryNameAlreadyExist.length > 0
        ) {
          res.status(200).json({
            status: false,
            Country: {},
            message: `Country Name already registered`,
          });
        } else {
          let updateCountryQuery = `UPDATE country SET
      GatewayID=?,
      Country=?,
      IOSCountryCode=?,
      CurrencyCode=?,
      CountryPhoneCode=?,
      GMTtime=?,
      AllowUser=?,
      AllowDelivery=?,
      AllowVendor=?,
      VATTaxRate=?,
      FlatDeliveryRate=?,
      FlatDeliveryRateKilo=?,
      Active=?,
      LastUpdate=?,
      AdminNote=?,
      ISO2=? WHERE CountryID  = "${req.params.id}"`;
          let updateCountry = await connection.query(updateCountryQuery, {
            replacements: [
              GatewayID,
              Country,
              IOSCountryCode,
              CurrencyCode,
              CountryPhoneCode,
              GMTtime,
              AllowUser,
              AllowDelivery,
              AllowVendor,
              VATTaxRate,
              FlatDeliveryRate,
              FlatDeliveryRateKilo,
              Active,
              LastUpdate,
              AdminNote,
              ISO2,
            ],
          });
          if (updateCountry) {
            res.status(200).json({
              status: true,
              message: "Country details updated successfully",
            });
          } else {
            res.status(200).json({
              status: false,
              message: "Error while updated Country Details",
            });
          }
        }
      }
    } else {
      res.status(200).json({
        status: false,
        message: "Country does not exist",
      });
    }
  } catch (err) {
    console.log(err.message);
    res.status(200).json({
      status: false,
      Category: {},
      error: err.message,
    });
  }
};
exports.deleteCountryById = async (req, res, next) => {
  try {
    const id = req.params.id;
    console.log(id);

    let checkCountry = await connection.query(
      `select * from country where CountryID = "${id}" `,
      { type: QueryTypes.SELECT }
    );
    if (checkCountry && checkCountry.length > 0) {
      let checkIfCountryIDExistsinState = await checkCountryExistsInState(id); //!see if country has states
      console.log(checkIfCountryIDExistsinState);
      if (
        checkIfCountryIDExistsinState &&
        checkIfCountryIDExistsinState == "0"
      ) {
        let checkIfCountryIDExistsinCity = await checkCountryExistsInCity(id); //!see if country has cities
        console.log(checkIfCountryIDExistsinCity);
        if (
          checkIfCountryIDExistsinCity &&
          checkIfCountryIDExistsinCity == "0"
        ) {
          let deleteCountry = await connection.query(
            `DELETE FROM country WHERE CountryID="${id}" `,
            { type: QueryTypes.DELETE }
          );
          res.status(200).json({
            status: true,
            message: `Country deleted successfully`,
          });
        } else if (
          checkIfCountryIDExistsinCity &&
          checkIfCountryIDExistsinCity == "1"
        ) {
          console.log("*********");
          res.status(200).json({
            status: false,
            message: `Country has cities it cannot be deleted`,
          });
        }
      } else if (
        checkIfCountryIDExistsinState &&
        checkIfCountryIDExistsinState == "1"
      ) {
        console.log("*********");
        res.status(200).json({
          status: false,
          message: `Country has states it cannot be deleted`,
        });
      }
    } else {
      console.log("*********");
      res.status(200).json({
        status: false,
        message: `Country does not exist`,
      });
    }
  } catch (err) {
    next(err);
    res.status(200).json({
      status: false,
      data: {},
      error: err.message,
    });
    console.log(err.message);
  }
};
let checkCountryExistsInState = async (CountryID) => {
  try {
    let countryCheck = await connection.query(
      `select * from state where CountryID  = '${CountryID}'`,
      { type: QueryTypes.SELECT }
    );
    if (countryCheck && countryCheck.length > 0) {
      return "1";
    } else {
      return "0";
    }
  } catch (err) {
    console.log(err.message);
    return null;
  }
};
let checkCountryExistsInCity = async (CountryID) => {
  try {
    let countryCheck = await connection.query(
      `select * from city where CountryID  = '${CountryID}'`,
      { type: QueryTypes.SELECT }
    );
    if (countryCheck && countryCheck.length > 0) {
      return "1";
    } else {
      return "0";
    }
  } catch (err) {
    console.log(err.message);
    return null;
  }
};
//!States Crud
exports.addState = async (req, res, next) => {
  try {
    const {
      CountryID,
      State,
      Native,
      StateCode,
      VATTaxRate,
      FlatDeliveryRate,
      FlatDeliveryRateKilo,
      Active,
      AdminNote,
    } = req.body;
    let checkIFCountryExists = await CountryIDCheck(CountryID); //!check if country exists or not (i.e enter Country ID is valid or inavlid)
    console.log(checkIFCountryExists);
    if (checkIFCountryExists && checkIFCountryExists == "1") {
      let checkIFStateNameExists = await StateNameCheck(State);
      if (checkIFStateNameExists && checkIFStateNameExists == "0") {
        //!check if city already exists
        let insertStateQuery = `insert into state (
            CountryID,
            State,
            Native,
            StateCode,
            VATTaxRate,
            FlatDeliveryRate,
            FlatDeliveryRateKilo,
            Active,
            AdminNote) values (?,?,?,?,?,?,?,?,?)`;
        let insertState = await connection.query(insertStateQuery, {
          replacements: [
            CountryID,
            State,
            Native,
            StateCode,
            VATTaxRate,
            FlatDeliveryRate,
            FlatDeliveryRateKilo,
            Active,
            AdminNote,
          ],
        });
        if (insertState) {
          res.status(200).json({
            status: true,
            message: "State details added successfully",
          });
        } else {
          res.status(200).json({
            status: false,
            message: "Error while adding State Details",
          });
        }
      } else if (checkIFStateNameExists && checkIFStateNameExists == "1") {
        res.status(200).json({
          status: false,
          message: "State already exists",
          State: [],
        });
      }
    } else if (checkIFCountryExists && checkIFCountryExists == "0") {
      res.status(200).json({
        status: false,
        message: "Country does not exists",
        Country: [],
      });
    }
  } catch (err) {
    next(err);
    res.status(200).json({
      status: false,
      Category: {},
      error: err.message,
    });
  }
};
let StateNameCheck = async (State) => {
  try {
    let checkStateNameExists = await connection.query(
      `select * from state where State = '${State}'`,
      { type: QueryTypes.SELECT }
    );
    if (checkStateNameExists && checkStateNameExists.length > 0) {
      return "1";
    } else {
      return "0";
    }
  } catch (err) {
    console.log(err.message);
    return null;
  }
};
exports.getState = async (req, res, next) => {
  try {
    let { limit, offset, CountryID,sort } = req.body;
    limit = parseInt(limit);
    offset = parseInt(offset);
    offset = limit * offset;
    let stateCount = await connection.query(
      `SELECT COUNT(CountryID) as total_records FROM state WHERE CountryID="${CountryID}" `,
      { type: QueryTypes.SELECT }
    );
    if (stateCount && stateCount.length > 0) {
      let viewState =
        `SELECT  s.*,c.Country FROM ( state s INNER JOIN  country c ON s.CountryID = c.CountryID) WHERE s.CountryID="${CountryID}" order by s.State ${sort} limit ` +
        limit +
        " offset " +
        offset;
      let allState = await connection.query(viewState, {
        type: QueryTypes.SELECT,
      });
	    console.log(allState)
      if (allState && allState.length > 0) {
        res.status(200).json({
          status: true,
          total_records: stateCount[0].total_records,
          State: allState,
        });
      } else {
        res.status(200).json({
          status: true,
          total_records: stateCount[0].total_records,
          State: [],
        });
      }
    }
  } catch (err) {
    //next(err);
    res.status(200).json({
      status: false,
      profile: {},
      error: err.message,
    });
    console.log(err.message);
  }
};
exports.getAllState = async (req, res, next) => {
  try {
    let allStateQuery = `SELECT  StateID AS value,State AS label FROM state `;
    let allState = await connection.query(allStateQuery, {
      type: QueryTypes.SELECT,
    });
    if (allState && allState.length > 0) {
      res.status(200).json({
        status: true,
        States: allState,
      });
    } else {
      res.status(200).json({
        status: true,
        message: "Something went wrong cannot show State list",
      });
    }
  } catch (err) {
    next(err);
    res.status(200).json({
      status: false,
      State: {},
      error: err.message,
    });
    console.log(err.message);
  }
};
exports.getStateByName = async (req, res, next) => {
  try {
    let { limit, offset, State, CountryID, sort } = req.body;
    limit = parseInt(limit);
    offset = parseInt(offset)
    offset = limit * offset;
    console.log(req.body);
    let stateCount = await connection.query(
      `SELECT COUNT(StateID) as total_records FROM state WHERE State LIKE "%${State}%" AND CountryID="${CountryID}"`,
      { type: QueryTypes.SELECT }
    );
    console.log(stateCount, "stateCount");
    if (stateCount && stateCount.length > 0) {
      let viewCountry =
        `SELECT * FROM  state WHERE State LIKE "%${State}%" AND CountryID="${CountryID}" order by State ${sort} limit ` +
        limit +
        " offset " +
        offset;
      let getStatesByName = await connection.query(viewCountry, {
        type: QueryTypes.SELECT,
      });
      if (getStatesByName && getStatesByName.length > 0) {
        res.status(200).json({
          status: true,
          total_records: stateCount[0].total_records,
          State: getStatesByName,
        });
      } else {
        res.status(200).json({
          status: true,
          total_records: stateCount[0].total_records,
          State: [],
        });
      }
    } else {
      res.status(200).json({
        status: true,
        total_records: stateCount[0].total_records,
        State: [],
      });
    }
  } catch (err) {
    console.log(err);
    res.status(200).json({
      status: false,
      State: [],
      error: err.message,
    });
  }
};
exports.getVednorAllowedStates = async (req, res, next) => {
  try {
    const { CountryID } = req.body;
    let getVednorAllowedStates = await connection.query(
      `SELECT * FROM state WHERE CountryID="${CountryID}" ORDER BY State ASC`,
      {
        type: QueryTypes.SELECT,
      }
    );
    if (getVednorAllowedStates && getVednorAllowedStates.length > 0) {
      res.status(200).json({
        status: true,
        States: getVednorAllowedStates,
      });
    } else {
      res.status(200).json({
        status: false,
        message: "No State found",
        States: [],
      });
    }
  } catch (err) {
    next(err);
    res.status(200).json({
      status: false,
      States: {},
      error: err.message,
    });
    console.log(err.message);
  }
};
exports.updateStateById = async (req, res, next) => {
  try {
    const {
      State,
      Native,
      StateCode,
      VATTaxRate,
      FlatDeliveryRate,
      FlatDeliveryRateKilo,
      Active,
      AdminNote,
    } = req.body;
    let LastUpdate = new Date().toISOString().slice(0, 19).replace("T", " ");
    let checkifStateExists = await connection.query(
      `SELECT * FROM state WHERE StateID="${req.params.id}"`,
      { type: QueryTypes.SELECT }
    );
    if (checkifStateExists && checkifStateExists.length > 0) {
      //check for unique State Name
      console.log(State);
      console.log(checkifStateExists[0].State);
      if (State == checkifStateExists[0].State) {
        let updateStateQuery = `UPDATE state SET
        State=?,
        Native=?,
        StateCode=?,
        VATTaxRate=?,
        FlatDeliveryRate=?,
        FlatDeliveryRateKilo=?,
        Active=?,
        LastUpdate=?,
        AdminNote=? WHERE StateID  = "${req.params.id}"`;
        let updateState = await connection.query(updateStateQuery, {
          replacements: [
            State,
            Native,
            StateCode,
            VATTaxRate,
            FlatDeliveryRate,
            FlatDeliveryRateKilo,
            Active,
            LastUpdate,
            AdminNote,
          ],
        });
        if (updateState) {
          res.status(200).json({
            status: true,
            message: "State details updated successfully",
          });
        } else {
          res.status(200).json({
            status: false,
            message: "Error while updated State Details",
          });
        }
      } else {
        let checkIFStateNameAlreadyExist = await connection.query(
          `select * from state  where State = "${State}"   `,
          { type: QueryTypes.SELECT }
        );
        console.log(checkIFStateNameAlreadyExist);
        if (
          checkIFStateNameAlreadyExist &&
          checkIFStateNameAlreadyExist.length > 0
        ) {
          res.status(200).json({
            status: false,
            Country: {},
            message: `State Name already registered`,
          });
        } else {
          let updateStateQuery = `UPDATE state SET
          State=?,
          Native=?,
          StateCode=?,
          VATTaxRate=?,
          FlatDeliveryRate=?,
          FlatDeliveryRateKilo=?,
          Active=?,
          LastUpdate=?,
          AdminNote=? WHERE StateID  = "${req.params.id}"`;
          let updateState = await connection.query(updateStateQuery, {
            replacements: [
              State,
              Native,
              StateCode,
              VATTaxRate,
              FlatDeliveryRate,
              FlatDeliveryRateKilo,
              Active,
              LastUpdate,
              AdminNote,
            ],
          });
          if (updateState) {
            res.status(200).json({
              status: true,
              message: "State details updated successfully",
            });
          } else {
            res.status(200).json({
              status: false,
              message: "Error while updated State Details",
            });
          }
        }
      }
    } else {
      res.status(200).json({
        status: false,
        message: "State does not exist",
      });
    }
  } catch (err) {
    next(err);
    res.status(200).json({
      status: false,
      Category: {},
      error: err.message,
    });
  }
};
//!Cities Crud
exports.addCity = async (req, res, next) => {
  try {
    const {
      CountryID,
      StateID,
      City,
      Native,
      VATTaxRate,
      FlatDeliveryRate,
      FlatDeliveryRateKilo,
      DeliveryPersonAvailable,
      Active,
      AdminNote,
    } = req.body;
    let checkIFCountryExists = await CountryIDCheck(CountryID); //!check if country exists or not (i.e enter Country ID is valid or inavlid)
    console.log(checkIFCountryExists);
    if (checkIFCountryExists && checkIFCountryExists == "1") {
      let checkIFStateExists = await StateIDCheck(StateID);
      if (checkIFStateExists && checkIFStateExists == "1") {
        //!check state exists or not
        let checkIFCityNameExists = await CityNameCheck(City);
        if (checkIFCityNameExists && checkIFCityNameExists == "0") {
          //!check if city already exists
          let insertCityQuery = `insert into city (
        CountryID,
        StateID,
        City,
        Native,
        VATTaxRate,
        FlatDeliveryRate,
        FlatDeliveryRateKilo,
        DeliveryPersonAvailable,
        Active,
        AdminNote) values (?,?,?,?,?,?,?,?,?,?)`;
          let insertCity = await connection.query(insertCityQuery, {
            replacements: [
              CountryID,
              StateID,
              City,
              Native,
              VATTaxRate,
              FlatDeliveryRate,
              FlatDeliveryRateKilo,
              DeliveryPersonAvailable,
              Active,
              AdminNote,
            ],
          });
          if (insertCity) {
            res.status(200).json({
              status: true,
              message: "City details added successfully",
            });
          } else {
            res.status(200).json({
              status: false,
              message: "Error while adding City Details",
            });
          }
        } else if (checkIFCityNameExists && checkIFCityNameExists == "1") {
          res.status(200).json({
            status: false,
            message: "City already exists",
            City: [],
          });
        }
      } else if (checkIFStateExists && checkIFStateExists == "0") {
        res.status(200).json({
          status: false,
          message: "State does not exists",
          State: [],
        });
      }
    } else if (checkIFCountryExists && checkIFCountryExists == "0") {
      res.status(200).json({
        status: false,
        message: "Country does not exists",
        Country: [],
      });
    }
  } catch (err) {
    next(err);
    res.status(200).json({
      status: false,
      Category: {},
      error: err.message,
    });
  }
};
let CountryIDCheck = async (CountryID) => {
  try {
    let checkCountryExists = await connection.query(
      `select * from country where CountryID = '${CountryID}'`,
      { type: QueryTypes.SELECT }
    );
    if (checkCountryExists && checkCountryExists.length > 0) {
      return "1";
    } else {
      return "0";
    }
  } catch (err) {
    console.log(err.message);
    return null;
  }
};
let StateIDCheck = async (StateID) => {
  try {
    let checkifStateExists = await connection.query(
      `select * from state where StateID = '${StateID}'`,
      { type: QueryTypes.SELECT }
    );
    if (checkifStateExists && checkifStateExists.length > 0) {
      return "1";
    } else {
      return "0";
    }
  } catch (err) {
    console.log(err.message);
    return null;
  }
};
let CityNameCheck = async (City) => {
  try {
    let checkCityNameExists = await connection.query(
      `select * from city where City = '${City}'`,
      { type: QueryTypes.SELECT }
    );
    if (checkCityNameExists && checkCityNameExists.length > 0) {
      return "1";
    } else {
      return "0";
    }
  } catch (err) {
    console.log(err.message);
    return null;
  }
};


exports.getCity = async (req, res, next) => {
  try {
    let { limit, offset, StateID, searchTerm } = req.body;
    limit = parseInt(limit);
    offset = parseInt(offset);
    offset = limit * offset;

    let searchQuery = '';
    if (searchTerm) {
      // If searchTerm is provided, construct the search query
      searchQuery = ` AND c.City LIKE '%${searchTerm}%'`;
    }

    let cityCount = await connection.query(
      `SELECT COUNT(StateID) as total_records FROM city WHERE StateID="${StateID}" `,
      { type: QueryTypes.SELECT }
    );
    if (cityCount && cityCount.length > 0) {
      let viewCity =
        `SELECT c.*, s.State, t.Country FROM ((city c INNER JOIN country t ON c.CountryID = t.CountryID) INNER JOIN state s ON c.StateID = s.StateID) WHERE c.StateID="${StateID}"${searchQuery} ORDER BY StateID DESC LIMIT ` +
        limit +
        ' OFFSET ' +
        offset;
      let allCity = await connection.query(viewCity, {
        type: QueryTypes.SELECT,
      });
      if (allCity && allCity.length > 0) {
        res.status(200).json({
          status: true,
          total_records: cityCount[0].total_records,
          City: allCity,
        });
      } else {
        res.status(200).json({
          status: true,
          total_records: cityCount[0].total_records,
          City: [],
        });
      }
    }
  } catch (err) {
    next(err);
    res.status(200).json({
      status: false,
      profile: {},
      error: err.message,
    });
    console.log(err.message);
  }
};
exports.adOldgetCity = async (req, res, next) => {
  try {
    let { limit, offset, StateID } = req.body;
    limit = parseInt(limit);
    offset = parseInt(offset);
    offset = limit * offset;
    let cityCount = await connection.query(
      `SELECT COUNT(StateID) as total_records FROM city WHERE StateID="${StateID}" `,
      { type: QueryTypes.SELECT }
    );
//	      console.log("______________+++++++++++++++", cityCount);

    if (cityCount && cityCount.length > 0) {
      let viewCity =
        `SELECT  c.*,s.State,t.Country FROM (( city c INNER JOIN  country t ON c.CountryID = t.CountryID) INNER JOIN  state s  ON c.StateID = s.StateID) WHERE c.StateID="${StateID}" order by StateID desc limit ` +
        limit +
        " offset " +
        offset;
      let allCity = await connection.query(viewCity, {
        type: QueryTypes.SELECT,
      });
      if (allCity && allCity.length > 0) {
        res.status(200).json({
          status: true,
          total_records: cityCount[0].total_records,
          City: allCity,
        });
      } else {
        res.status(200).json({
          status: true,
          total_records: cityCount[0].total_records,
          City: [],
        });
      }
    }
  } catch (err) {
    next(err);
    res.status(200).json({
      status: false,
      profile: {},
      error: err.message,
    });
    console.log(err.message);
  }
};
exports.getAllCity = async (req, res, next) => {
  try {
    let allCityQuery = `SELECT  CityID AS value,City AS label FROM city `;
    let allCity = await connection.query(allCityQuery, {
      type: QueryTypes.SELECT,
    });
    if (allCity && allCity.length > 0) {
      res.status(200).json({
        status: true,
        Cities: allCity,
      });
    } else {
      res.status(200).json({
        status: true,
        message: "Something went wrong cannot show Cities list",
        Cities: [],
      });
    }
  } catch (err) {
    next(err);
    res.status(200).json({
      status: false,
      City: {},
      error: err.message,
    });
    console.log(err.message);
  }
};
exports.getAllCityByState = async (req, res, next) => {
  try {
    let allCityByStateQuery = `SELECT * FROM city WHERE StateID="${req.params.id}" ORDER BY City ASC `;
    let allCityByState = await connection.query(allCityByStateQuery, {
      type: QueryTypes.SELECT,
    });
    if (allCityByState && allCityByState.length > 0) {
      res.status(200).json({
        status: true,
        Cities: allCityByState,
      });
    } else {
      res.status(200).json({
        status: true,
        Cities: [],
      });
    }
  } catch (err) {
    next(err);
    res.status(200).json({
      status: false,
      City: {},
      error: err.message,
    });
    console.log(err.message);
  }
};
exports.getAllCityByCountry = async (req, res, next) => {
  try {
    let allCityByCountryQuery = `SELECT * FROM city WHERE CountryID="${req.params.id}" `;
    let allCityByCountry = await connection.query(allCityByCountryQuery, {
      type: QueryTypes.SELECT,
    });
    if (allCityByCountry && allCityByCountry.length > 0) {
      res.status(200).json({
        status: true,
        Cities: allCityByCountry,
      });
    } else {
      res.status(200).json({
        status: true,
        Cities: [],
      });
    }
  } catch (err) {
    console.log(err);
    res.status(200).json({
      status: false,
      Cities: {},
      error: err.message,
    });
    console.log(err.message);
  }
};
exports.getVednorAllowedCities = async (req, res, next) => {
  try {
    const { CountryID } = req.body;
    let getVednorAllowedCities = await connection.query(
      `SELECT * FROM city WHERE CountryID="${CountryID}" ORDER BY City ASC `,
      {
        type: QueryTypes.SELECT,
      }
    );
    if (getVednorAllowedCities && getVednorAllowedCities.length > 0) {
      res.status(200).json({
        status: true,
        Cities: getVednorAllowedCities,
      });
    } else {
      res.status(200).json({
        status: false,
        message: "No City detail found",
        Cities: [],
      });
    }
  } catch (err) {
    next(err);
    res.status(200).json({
      status: false,
      Cities: {},
      error: err.message,
    });
    console.log(err.message);
  }
};
exports.updateCityById = async (req, res, next) => {
  try {
    const {
      City,
      Native,
      VATTaxRate,
      FlatDeliveryRate,
      FlatDeliveryRateKilo,
      DeliveryPersonAvailable,
      Active,
      AdminNote,
    } = req.body;
    let LastUpdate = new Date().toISOString().slice(0, 19).replace("T", " ");
    let checkifCityExists = await connection.query(
      `SELECT * FROM city WHERE CityID="${req.params.id}"`,
      { type: QueryTypes.SELECT }
    );
    if (checkifCityExists && checkifCityExists.length > 0) {
      //check for unique City Name
      console.log(City);
      console.log(checkifCityExists[0].City);
      if (City == checkifCityExists[0].City) {
        let updateCityQuery = `UPDATE city SET
        City=?,
        Native=?,
        VATTaxRate=?,
        FlatDeliveryRate=?,
        FlatDeliveryRateKilo=?,
        DeliveryPersonAvailable=?,
        Active=?,
        LastUpdate=?,
        AdminNote=? WHERE CityID  = "${req.params.id}"`;
        let updateCity = await connection.query(updateCityQuery, {
          replacements: [
            City,
            Native,
            VATTaxRate,
            FlatDeliveryRate,
            FlatDeliveryRateKilo,
            DeliveryPersonAvailable,
            Active,
            LastUpdate,
            AdminNote,
          ],
        });
	      console.log("========",updateCity,City,
            Native,
            VATTaxRate,
            FlatDeliveryRate,
            FlatDeliveryRateKilo,
            DeliveryPersonAvailable,
            Active,
            LastUpdate,
            AdminNote)
        if (updateCity) {
          res.status(200).json({
            status: true,
            message: "City details updated successfully",
          });
        } else {
          res.status(200).json({
            status: false,
            message: "Error while updated City Details",
          });
        }
      } else {
        let checkIFCityNameAlreadyExist = await connection.query(
         `select * from city  where City = "${City}"   `,
         { type: QueryTypes.SELECT }
      );
      console.log(checkIFCityNameAlreadyExist);
        if (
         checkIFCityNameAlreadyExist &&
         checkIFCityNameAlreadyExist.length > 0
       ) {
         res.status(200).json({
            status: false,
           Country: {},
          message: `City Name already registered`,
        });
      } else {
	      console.log("_______________________",City,
              Native,
              VATTaxRate,
              FlatDeliveryRate,
              FlatDeliveryRateKilo,
              DeliveryPersonAvailable,
              Active,
              LastUpdate,
              AdminNote,)

          let updateCityQuery = `UPDATE city SET
          City=?,
          Native=?,
          VATTaxRate=?,
          FlatDeliveryRate=?,
          FlatDeliveryRateKilo=?,
          DeliveryPersonAvailable=?,
          Active=?,
          LastUpdate=?,
          AdminNote=? WHERE CityID  = "${req.params.id}"`;
          let updateCity = await connection.query(updateCityQuery, {
            replacements: [
              City,
              Native,
              VATTaxRate,
              FlatDeliveryRate,
              FlatDeliveryRateKilo,
              DeliveryPersonAvailable,
              Active,
              LastUpdate,
              AdminNote,
            ],
          });
	      console.log("=====================================================================",updateCity,City,
              Native,
              VATTaxRate,
              FlatDeliveryRate,
              FlatDeliveryRateKilo,
              DeliveryPersonAvailable,
              Active,
              LastUpdate,
              AdminNote)
          if (updateCity) {
            res.status(200).json({
              status: true,
              message: "City details Updated successfully",
            });
          } else {
            res.status(200).json({
              status: false,
              message: "Error while updated City Details",
            });
          }
        }
      }
    } else {
      res.status(200).json({
        status: false,
        message: "City does not exist",
      });
    }
  } catch (err) {
    next(err);
    res.status(200).json({
      status: false,
      Category: {},
      error: err.message,
    });
  }
};
/* exports.deleteCityById = async (req, res, next) => {
  try {
    const id = req.params.id;
    console.log(id);

    let checkCity = await connection.query(
      `select * from City where CityID = "${id}" `,
      { type: QueryTypes.SELECT }
    );
    if (checkCity && checkCity.length > 0) {
        let checkIfCityIDExistsInVendor = await checkCityExistsInVendor(id); //!see if city exists in vendor table
        console.log(checkIfCityIDExistsInVendor);
        if (
          checkIfCityIDExistsInVendor &&
          checkIfCityIDExistsInVendor == "0"
        ) {
          let deleteCity = await connection.query(
            `DELETE FROM city WHERE CityID="${id}" `,
            { type: QueryTypes.DELETE }
          );
          res.status(200).json({
            status: true,
            message: `Country deleted successfully`,
          });
        } else if (
          checkIfCityIDExistsInVendor &&
          checkIfCityIDExistsInVendor == "1"
        ) {
          res.status(200).json({
            status: false,
            message: `City is being used in Vendor Table it cannot be deleted`,
          });
        }
      
    } else {
      console.log("*********");
      res.status(200).json({
        status: false,
        message: `City does not exist`,
      });
    }
  } catch (err) {
    next(err);
    res.status(200).json({
      status: false,
      data: {},
      error: err.message,
    });
    console.log(err.message);
  }
}; */
/* let checkCityExistsInVendor = async (CityID) => {

  try {
    let countryCheck = await connection.query(
      `select * from vendor where CityID  = '${CityID}'`,
      { type: QueryTypes.SELECT }
    );
    if (countryCheck && countryCheck.length > 0) {
      return "1";
    } else {
      return "0";
    }
  } catch (err) {
    console.log(err.message);
    return null;
  }
}; */

exports.insertCountresListByCsv = async (req, res, next) => {
  try {
    // CSV file name
    const fileName = "AllCountry.csv";

    csvtojson()
      .fromFile(fileName)
      .then(async (source) => {
        // Fetching the data from each row
        // and inserting to the table "sample"
        console.log(source.length);
        for (var i = 0; i < source.length; i++) {
          (Country = source[i]["Country"]),
            (IOSCountryCode = source[i]["IOSCountryCode"]),
            (AllowUser = source[i]["AllowUser"]),
            (AllowDelivery = source[i]["AllowDelivery"]),
            (AllowVendor = source[i]["AllowVendor"]),
            (ISO2 = source[i]["ISO2"]);

          // Inserting data of current row
          // into database
          var insertCountryTable = `INSERT INTO country( Country, IOSCountryCode, AllowUser,AllowDelivery,AllowVendor,ISO2) values(?, ?, ?,?,?,?)`;
          let vendorStoreQuery = await connection.query(insertCountryTable, {
            replacements: [
              Country,
              IOSCountryCode,
              AllowUser,
              AllowDelivery,
              AllowVendor,
              ISO2,
            ],
          });
          if (vendorStoreQuery) {
            console.log("All items stored into database successfully");
          } else {
            console.log("Unable to insert item at row ", i + 1);
          }
        }
      });
    res.status(200).json({
      status: true,
      message: "successfully upload data in country table",
    });
  } catch (err) {
    next(err);
    res.status(200).json({
      status: false,
      profile: {},
      error: err.message,
    });
  }
};
exports.insertStatesListByCsv = async (req, res, next) => {
  try {
    // CSV file name
    const fileName = "AllCities1.csv";

    csvtojson()
      .fromFile(fileName)
      .then(async (source) => {
        // Fetching the data from each row
        // and inserting to the table "sample"
        console.log(source.length);
        for (var i = 0; i < source.length; i++) {
          (CountryID = source[i]["CountryID"]),
            (City = source[i]["City"]),
            (Native = source[i]["Native"]);

          // Inserting data of current row
          // into database
          var insertStateTableQuery = `INSERT INTO city(CountryID, City,Native) values(?,?,?)`;
          let insertStateTable = await connection.query(insertStateTableQuery, {
            replacements: [CountryID, City, Native],
          });
          if (insertStateTable) {
            console.log("All items stored into database successfully");
          } else {
            console.log("Unable to insert item at row ", i + 1);
          }
        }
      });
    res.status(200).json({
      status: true,
      message: "successfully upload data in state table",
    });
  } catch (err) {
    next(err);
    res.status(200).json({
      status: false,
      state: {},
      error: err.message,
    });
  }
};
exports.insertCitiesListByCsv = async (req, res, next) => {
  try {
    // CSV file name
    const fileName = "CityNative.csv";

    csvtojson()
      .fromFile(fileName)
      .then(async (source) => {
        // Fetching the data from each row
        // and inserting to the table "sample"
        console.log(source.length);
        for (var i = 0; i < source.length; i++) {
          /*  ( CityID = source[i]["CityID"]),
            (CountryID = source[i]["CountryID"]),
            (StateID = source[i]["StateID"]),
            (City = source[i]["City"]),  */
          Native = source[i]["Native"];
          /* (VATTaxRate = source[i]["VATTaxRate"]),
            (FlatDeliveryRate = source[i]["FlatDeliveryRate"]),
            (FlatDeliveryRateKilo = source[i]["FlatDeliveryRateKilo"]),
            (DeliveryPersonAvailable = source[i]["DeliveryPersonAvailable"]),
            (Active = source[i]["Active"]),
            (LastUpdate = source[i]["LastUpdate"]),
            (AdminNote = source[i]["AdminNote"]); */

          // Inserting data of current row
          // into database
          var insertCityTableQuery = `UPDATE city SET Native=? WHERE CityID="${
            i + 1
          }"`;
          let insertCityTable = await connection.query(insertCityTableQuery, {
            replacements: [
              /*  CityID,
              CountryID,
              StateID,
              City, */
              Native,
              /* VATTaxRate,
              FlatDeliveryRate,
              FlatDeliveryRateKilo,
              DeliveryPersonAvailable,
              Active,
              LastUpdate,
              AdminNote, */
            ],
          });
          if (insertCityTable) {
            console.log("All items stored into database successfully");
          } else {
            console.log("Unable to insert item at row ", i + 1);
          }
        }
      });
    res.status(200).json({
      status: true,
      message: "successfully upload data in city table",
    });
  } catch (err) {
    next(err);
    res.status(200).json({
      status: false,
      City: {},
      error: err.message,
    });
  }
};
exports.addNewStateByUser = async (req, res, next) => {
  try {
    let { CountryID, StateName } = req.body;
    let insertStatequeryString = `insert into state (CountryID,State)`;
    insertStatequeryString += ` values ("${CountryID}","${StateName}") `;
    let insertState = await connection.query(insertStatequeryString, {
      type: QueryTypes.INSERT,
    });
    if (insertState) {
      res.status(200).json({
        status: true,
        message: "State added Successfully",
        StateID: insertState[0],
      });
    } else {
      res.status(200).json({
        status: false,
        message: "something went wrong cannot add state",
      });
    }
  } catch (err) {
    next(err);
    res.status(200).json({
      status: false,
      profile: {},
      error: err.message,
    });
  }
};
exports.addNewCityByUser = async (req, res, next) => {
  try {
    let { CountryID, StateID, City } = req.body;
    let insertCityQueryString = `insert into city (CountryID,StateID,City )`;
    insertCityQueryString += ` values ("${CountryID}","${StateID}","${City}") `;
    let insertCity = await connection.query(insertCityQueryString, {
      type: QueryTypes.INSERT,
    });
    if (insertCity) {
      res.status(200).json({
        status: true,
        message: "City added Successfully",
        CityID: insertCity[0],
      });
    } else {
      res.status(200).json({
        status: false,
        message: "something went wrong cannot add state",
      });
    }
  } catch (err) {
    next(err);
    res.status(200).json({
      status: false,
      profile: {},
      error: err.message,
    });
  }
};
