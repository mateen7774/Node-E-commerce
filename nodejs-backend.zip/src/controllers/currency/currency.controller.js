const connection = require("../../db/db.connection");
const {
    QueryTypes,
} = require("sequelize");

exports.getAuditCurrency = async (req, res, next) => {
    try {
        let {
            limit,
            offset,
            sort
        } = req.body;
        limit = parseInt(limit);
        offset = parseInt(offset);
        offset = limit * offset;
        let getAuditCurrencyQuery = `SELECT * from auditcurrencyrate ORDER BY RecordDate ${sort} limit  ` +
            limit +
            " offset " +
            offset;
        let getAuditCurrencyRate = await connection.query(getAuditCurrencyQuery, {
            type: QueryTypes.SELECT
        });
        if (getAuditCurrencyRate) {
            res.status(200).json({
                status: true,
                getAuditCurrencyRate,
            });
        } else {
            res.status(200).json({
                status: false,
                message: "Error while agetting currency rate ",
            });
        }
    } catch (err) {
        next(err);
        res.status(200).json({
            status: false,
            message: err.message,
        });
    }
};