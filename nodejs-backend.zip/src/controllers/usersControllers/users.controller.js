const connection = require("../../db/db.connection");
const {
  sendMail
} = require("../../utils/email");
const bcrypt = require("bcrypt");
const {
  sendPath
} = require("../../utils/path");
//const accessToken = require("../../middleware/assignToke.mid");
const {
  QueryTypes
} = require("sequelize");
const getAccessToken = require("../../middleware/assignToke.mid");
const {
  admin
} = require("../../utils/firebaseConfig.js");
exports.registerUser = async (req, res, next) => {
  try {
    let {
      UserName,
      EmailAddress,
      Password,
      IPAddress
    } = req.body;
    let checkEmail = await connection.query(
      `SELECT * FROM profile where EmailAddress = '${EmailAddress}'`, {
        type: QueryTypes.SELECT,
      }
    );
    console.log(checkEmail);
    if (checkEmail && checkEmail.length > 0) {
      res.status(200).json({
        status: false,
        message: "USER already existed",
        user: [],
      });
    } else {
      const salt = await bcrypt.genSalt(10);
      let hashPassword = await bcrypt.hash(Password, salt);
      var otp = Math.floor(Math.random() * 90000) + 10000;
      otp.toString();
      let addUserProfileQuery = `insert into profile (UserName,EmailAddress, Password, Customer,AccessCodeEmail , Active, PhoneVerified,IPAddress,CreatedDate)  `;
      addUserProfileQuery += ` values ("${UserName}","${EmailAddress}", "${hashPassword}", "Y","${otp.toString()}", "Y", "N","${IPAddress}","${new Date()
        .toISOString()
        .slice(0, 19)
        .replace("T", " ")}") `;
      let addUserProfile = await connection.query(addUserProfileQuery);
      if (addUserProfile) {
        const UserID = addUserProfile[0];
        const TypeID = "1";
        let LastUpdate = new Date()
          .toISOString()
          .slice(0, 19)
          .replace("T", " ");
        let addNewUserNotificationQuery = `insert into notification (TypeID,Body,CreaterID,ReceiverID,LastUpdate)  `;
        addNewUserNotificationQuery += ` values ("${TypeID}","New User ${UserName} has joined","${UserID}","1","${LastUpdate}") `;

        let addNewUserNotification = await connection.query(
          addNewUserNotificationQuery
        );
        if (addNewUserNotification) {
          sendMail(EmailAddress, otp);
          res.status(200).json({
            status: true,
            message: `OTP send and user added successfully`,
          });
        } else {
          res.status(200).json({
            status: false,
            message: `error while adding notification into database`,
          });
        }
      } else {
        res.status(200).json({
          status: false,
          message: `Something went wrong, please try again later`,
          error: err.message,
        });
      }
    }
  } catch (err) {
    next(err);
    res.status(200).json({
      status: false,
      user: [],
      error: err.message,
    });
  }
};
exports.verifyOTP = async (req, res, next) => {
  try {
    let {
      email,
      otp
    } = req.body;

    let queryString = `select * from profile where EmailAddress = '${email}' and AccessCodeEmail= '${otp}' `;
    let user = await connection.query(queryString, {
      type: QueryTypes.SELECT,
    });
    if (user && user.length > 0) {
      let updateEmailVerificationQuery = `update profile Set EmailVerified = 'Y' where UserID='${user[0].UserID}'`;
      let updateUser = await connection.query(updateEmailVerificationQuery);
      if (updateUser) {
        res.status(200).json({
          status: true,
          message: `Email verification successful`,
        });
      } else {
        res.status(200).json({
          status: false,
          message: `Error while verifying Email Address`,
        });
      }
    } else {
      res.status(200).json({
        status: false,
        message: `Invalid OTP`,
      });
    }
  } catch (err) {
    next(err);
    res.status(200).json({
      status: false,
      profile: {},
      error: err.message,
    });
  }
};
exports.resendOTP = async (req, res, next) => {
  try {
    let {
      email
    } = req.body;
    console.log(email, "email");
    if (email) {
      let queryString = `select * from profile where EmailAddress ="${email}" `;
      let user = await connection.query(queryString, {
        type: QueryTypes.SELECT,
      });
      if (user && user.length > 0) {
        var otp = Math.floor(Math.random() * 90000) + 10000;
        otp.toString();
        let queryString = `UPDATE profile SET AccessCodeEmail='${otp}' WHERE EmailAddress="${email}" `;
        let resendOTP_ = await connection.query(queryString);
        if (resendOTP_) {
          sendMail(email, otp);
          res.status(200).json({
            status: true,
            message: `OTP is resend to the EmailAddress`,
          });
        } else {
          res.status(200).json({
            status: false,
            message: `Error while sending OTP`,
          });
        }
      } else {
        res.status(200).json({
          status: false,
          message: `Please enter an email to get OTP `,
        });
      }
    } else {
      res.status(200).json({
        status: false,
        message: `Please provide an email address`,
      });
    }
  } catch (err) {
    next(err);
    res.status(200).json({
      status: false,
      profile: {},
      error: err.message,
    });
  }
};


exports.login = async (req, res, next) => {
  try {
    let {
      EmailAddress,
      Password,
      deviceID,
      hashPassword,
      signIn,
      SessionID,
      IPAddress,
    } = req.body;
    let validPassword;
    let getUserData = await connection.query(
      `select * from profile
      where EmailAddress = '${EmailAddress}' 
      `,
      {
        type: QueryTypes.SELECT,
      }
    );
    if (getUserData && getUserData.length > 0) {
      let storedHashPassword = getUserData[0].Password;
      if (signIn == "Y") {
        if (storedHashPassword === hashPassword) {
          validPassword = true;
        } else {
          validPassword = false;
        }
      } else {
        validPassword = await bcrypt.compare(Password, storedHashPassword);
      }
      if (validPassword) {
        const path = "http://banglabazar.com/verify-email/" + EmailAddress; //changes here
        if (getUserData[0].Active == "Y") {
          if (getUserData[0].EmailVerified == "N") {
            sendPath(EmailAddress, path);
            console.log(path);
            res.status(200).json({
              status: false,
              message:
                "Your account is not verified !! A verification Link resent to the Email Address",
              user: [],
            });
          } else {
            let token = await getAccessToken(getUserData[0]);
            let updateUserDeviceIDQuery = false;
            if (deviceID == null) {
              updateUserDeviceIDQuery = true;
            } else {
              try {
                updateUserDeviceID = await connection.query(
                  `UPDATE profile SET DeviceID="${deviceID}" WHERE UserID="${getUserData[0].UserID}"
             `
                );
                updateUserDeviceIDQuery = true;
              } catch (e) {
                updateUserDeviceIDQuery = false;
              }
            }
            if (updateUserDeviceIDQuery == true) {
              //below this
              let LastLogin = new Date()
                .toISOString()
                .slice(0, 19)
                .replace("T", " ");
              let addUserLoginDetailsQuery = `insert into login (SessionID,IPAddress,Active ,UserID,LastLogin)`;
              addUserLoginDetailsQuery += ` values ("${token}","${IPAddress}","Y","${getUserData[0].UserID}","${LastLogin}") `;
              addUserLoginDetailsQuery += ` ON DUPLICATE KEY UPDATE LastLogin=VALUES(LastLogin)`;
              let addUserLoginDetails = await connection.query(
                addUserLoginDetailsQuery
              );
              //above this
              if (addUserLoginDetails) {
                let getDeliverDriverDetails = await connection.query(
                  `SELECT d.*
              FROM profile p
              INNER JOIN deliverydriver d ON d.DeliveryDriverID = p.UserID
              WHERE d.DeliveryDriverID="${getUserData[0].UserID}" 
             `,
                  {
                    type: QueryTypes.SELECT,
                  }
                );

                let deliveryDriverDetails = getDeliverDriverDetails[0] ? getDeliverDriverDetails[0]["ReviewedByAdmin"] == "Y" ? getDeliverDriverDetails[0] : null : null;
                let deliveryDriverStatus = getDeliverDriverDetails[0] ? getDeliverDriverDetails[0]["ReviewedByAdmin"] == "Y" ? "Y" : "P" : "N";

                res.status(200).json({
                  status: true,
                  message: "Logged in successfully",
                  user: getUserData[0],
                  deliveryDriverDetails: deliveryDriverDetails,
                  deliveryDriverStatus,
                  token,
                });

              } else {
                res.status(200).json({
                  status: false,
                  message: "Error while adding user login history",
                  user: [],
                });
              }
            } else {
              res.status(200).json({
                status: false,
                message: "Error while updating User deviceID",
                user: [],
              });
            }
          }
        } else {
          res.status(200).json({
            status: false,
            message: "Sorry your account has been deactivated",
            user: [],
          });
        }
      } else {
        res.status(200).json({
          status: false,
          message: "Enterted Password does not matched",
          user: [],
        });
      }
    } else {
      res.status(200).json({
        status: false,
        message: "The email address you entered isn't connected to an account.",
        user: [],
      });
    }
  } catch (error) {
    res.status(200).json({
      status: false,
      message: "Error while loggin in",
      error: error.message,
    });
  }
};


exports.checkedliveryguystatus = async (req, res, next) => {
  try {
    // const { userId } = req.body
    const userId = req.UserID;
    let getDeliverDriverDetails = await connection.query(
      `SELECT d.*
              FROM profile p
              INNER JOIN deliverydriver d ON d.DeliveryDriverID = p.UserID
              WHERE d.DeliveryDriverID="${userId}"
             `,
      {
        type: QueryTypes.SELECT,
      }
    );

    let deliveryDriverStatus = getDeliverDriverDetails[0] ? getDeliverDriverDetails[0]["ReviewedByAdmin"] == "Y" ? "Y" : "P" : "N";

    res.status(200).json({
      status: true,
      deliveryDriverStatus
    });
  } catch (error) {
    res.status(200).json({
      status: false,
      message: "internal server error",
      error: error.message,
    });
  }
};



exports.adOldlogin = async (req, res, next) => {
	
  try {
    let {
      EmailAddress,
      Password,
      deviceID,
      hashPassword,
      signIn,
      SessionID,
      IPAddress,
    } = req.body;
    let validPassword;
    let getUserData = await connection.query(
      `select * from profile
      where EmailAddress = '${EmailAddress}' 
      `, {
        type: QueryTypes.SELECT,
      }
    );
    if (getUserData && getUserData.length > 0) {
      let storedHashPassword = getUserData[0].Password;
      if (signIn == "Y") {
        if (storedHashPassword === hashPassword) {
          validPassword = true;
        } else {
          validPassword = false;
        }
      } else {
        validPassword = await bcrypt.compare(Password, storedHashPassword);
      }
      if (validPassword) {
        const path = "http://banglabazar.com/verify-email/" + EmailAddress; //changes here
        if (getUserData[0].Active == "Y") {
          if (getUserData[0].EmailVerified == "N") {
            sendPath(EmailAddress, path);
            console.log(path);
            res.status(200).json({
              status: false,
              message: "Your account is not verified !! A verification Link resent to the Email Address",
              user: [],
            });
          } else {
            let token = await getAccessToken(getUserData[0]);
            let updateUserDeviceIDQuery = false;
            if (deviceID == null) {
              updateUserDeviceIDQuery = true;
            } else {
              try {
                updateUserDeviceID = await connection.query(
                  `UPDATE profile SET DeviceID="${deviceID}" WHERE UserID="${getUserData[0].UserID}"
             `
                );
                updateUserDeviceIDQuery = true;
              } catch (e) {
                updateUserDeviceIDQuery = false;
              }
            }
            if (updateUserDeviceIDQuery == true) {
              //below this
              let LastLogin = new Date()
                .toISOString()
                .slice(0, 19)
                .replace("T", " ");
              let addUserLoginDetailsQuery = `insert into login (SessionID,IPAddress,Active ,UserID,LastLogin)`;
              addUserLoginDetailsQuery += ` values ("${token}","${IPAddress}","Y","${getUserData[0].UserID}","${LastLogin}") `;
              addUserLoginDetailsQuery += ` ON DUPLICATE KEY UPDATE LastLogin=VALUES(LastLogin)`;
              let addUserLoginDetails = await connection.query(
                addUserLoginDetailsQuery
              );
              //above this
              if (addUserLoginDetails) {
                let getDeliverDriverDetails = await connection.query(
                  `SELECT d.*
              FROM profile p
              INNER JOIN deliverydriver d ON d.DeliveryDriverID = p.UserID
              WHERE d.DeliveryDriverID="${getUserData[0].UserID}" AND d.ReviewedByAdmin="Y"
             `, {
                    type: QueryTypes.SELECT,
                  }
                )
		      

                let DeliveryApproveStatus = await connection.query(
                  `SELECT d.*
              FROM profile p
              INNER JOIN deliverydriver d ON d.DeliveryDriverID = p.UserID
              WHERE d.DeliveryDriverID = "${getUserData[0].UserID}"
              AND (d.ReviewedByAdmin IS NULL OR d.ReviewedByAdmin = "N")
             `,
                  {
                    type: QueryTypes.SELECT,
                  }
                );

                console.log("______________________________________________DeliveryApproveStatus", DeliveryApproveStatus);
                if (
                  getDeliverDriverDetails &&
                  getDeliverDriverDetails.length > 0
                ) {
                  res.status(200).json({
                    status: true,
                    message: "Logged in successfully",
                    user: getUserData[0],
		    DeliveryApproveStatus,
                    deliveryDriverDetails: getDeliverDriverDetails[0],
                    token,
                  });
                } else {
                  res.status(200).json({
                    status: true,
                    message: "Logged in successfully",
                    user: getUserData[0],
                    deliveryDriverDetails: null,
		    DeliveryApproveStatus,
                    token,
                  });
                }
              } else {
                res.status(200).json({
                  status: false,
                  message: "Error while adding user login history",
                  user: [],
                });
              }
            } else {
              res.status(200).json({
                status: false,
                message: "Error while updating User deviceID",
                user: [],
              });
            }
          }
        } else {
          res.status(200).json({
            status: false,
            message: "Sorry your account has been deactivated",
            user: [],
          });
        }
      } else {
        res.status(200).json({
          status: false,
          message: "Enterted Password does not matched",
          user: [],
        });
      }
    } else {
      res.status(200).json({
        status: false,
        message: "The email address you entered isn't connected to an account.",
        user: [],
      });
    }
  } catch (error) {
    res.status(200).json({
      status: false,
      message: "Error while loggin in",
      error: error.message,
    });
  }
};
exports.updateUserById = async (req, res, next) => {
  try {
    const id = req.params.id
    console.log(id);
	  console.log(req.params.id)
    let {
      UserName,
      EmailAddress,
      Birthday,
      Gender,
      PhoneNumber,
      EmailVerified,
      PhoneVerified,
    } = req.body;
    console.log(req.body);
    if (PhoneNumber.startsWith("+")) {
      PhoneNumber = PhoneNumber.replace(/^\+/, "");
    }
    let LastUpdate = new Date().toISOString().slice(0, 19).replace("T", " ");
    // edit functionality
    let user = await connection.query(
      `select * from profile where UserID = '${id}' `, {
        type: QueryTypes.SELECT,
      }
    );
    if (user && user.length > 0) {
      let queryString;
      if (Birthday && Birthday != undefined && Birthday != "Invalid date") {
        console.log(Birthday, "Birthday");
        queryString = `UPDATE profile SET UserName = '${UserName}', EmailAddress = '${EmailAddress}', Birthday = '${Birthday}', 
                Gender = '${Gender}', PhoneNumber = '${PhoneNumber}', EmailVerified = '${EmailVerified}', PhoneVerified = '${PhoneVerified}',LastUpdate = '${LastUpdate}'
             WHERE UserID = "${id}"  `;
      } else {
        queryString = `UPDATE profile SET UserName = '${UserName}', EmailAddress = '${EmailAddress}', 
                Gender = '${Gender}', PhoneNumber = '${PhoneNumber}', EmailVerified = '${EmailVerified}', PhoneVerified = '${PhoneVerified}',LastUpdate = '${LastUpdate}'
             WHERE UserID = "${id}"  `;
      }

      let updateUser = await connection.query(queryString, {
        replacements: [req.body],
      });
      if (updateUser) {
        res.status(200).json({
          status: true,
          message: `User details updated successfully`,
        });
      } else {
        res.status(200).json({
          status: false,
          message: `Error while updating user details`,
        });
      }
    } else {
      res.status(200).json({
        status: false,
        message: `User not found with given ID`,
      });
    }
  } catch (err) {
    next(err);
    res.status(200).json({
      status: false,
      data: {},
      error: err.message,
    });
    console.log(err.message);
  }
};
exports.deleteUserById = async (req, res, next) => {
  try {
    const id = req.params.id;
    console.log(id);

    connection.query(
      `select * from profile where UserID = "${id}" `,
      async (err, rows, fields) => {
        if (err) {
          res.status(200).json({
            status: false,
            message: "Error while deleting",
            error: err.message,
          });
        } else {
          if (rows.length > 0) {
            console.log("--------------");
            let queryString = ` DELETE FROM profile WHERE UserID="${id}"  `;
            connection.query(queryString, [req.body], (err, rows, fields) => {
              if (err) {
                res.status(200).json({
                  status: false,
                  profile: {},
                  message: `Something went wrong, please try again later`,
                  error: err.message,
                });
              } else {
                res.status(200).json({
                  status: true,
                  message: `User deleted successfully`,
                });
              }
            });
          } else {
            console.log("--------------");
            res.status(200).json({
              status: false,
              message: `User not found with given ID`,
            });
          }
        }
      }
    );
  } catch (error) {
    next(err);
    res.status(200).json({
      status: false,
      data: {},
      error: err.message,
    });
    console.log(err.message);
  }
};
exports.uploadImage = async (req, res, next) => {
  try {
    const UserID = req.UserID;
    let profileImage = req.file.path;
    // let queryString = `insert into profile (UserName,Birthday,Gender ,EmailAddress, PhoneNumber, Password,Customer,Active,EmailVerified,PhoneVerified,CreatedDate)`;
    // queryString += ` values ("${username}","${Birthday}","${Gender}","${email}", "${phone_number}","1122" ,"${Customer}","${Active}","Y","Y","${new Date()
    //   .toISOString()
    //   .slice(0, 19)
    //   .replace("T", " ")}") `;

    // let addUser = await connection.query(queryString);
    let user = await connection.query(
      `select * from profile where UserID = "${UserID}" `, {
        type: QueryTypes.SELECT,
      }
    );
    if (user && user.length > 0) {
      let queryString = `UPDATE profile SET ProfilePic= ? WHERE UserID = "${UserID}" `;
      let updateQuery = await connection.query(queryString, {
        replacements: [profileImage],
      });
      if (updateQuery) {
        res.status(200).json({
          status: true,
          message: ` Profile Picture is updated `,
          Path: profileImage,
        });
      } else {
        res.status(200).json({
          status: false,
          message: "Error while uploading profile",
          error: err.message,
        });
      }
    } else {
      res.status(200).json({
        status: false,
        message: `User not found with given ID`,
      });
    }
  } catch (err) {
    res.status(200).json({
      status: false,
      error: err.message,
    });
    console.log(err.message);
  }
};
exports.makeUsername = async (req, res, next) => {
  try {
    let queryString = `Select * from profile `;
    console.log(queryString);
    connection.query(queryString, async (err, rows) => {
      if (err) {
        res.status(200).json({
          status: false,
          message: "Error ",
          error: err.message,
        });
      } else {
        let queryString = `SELECT CONCAT(FirstName, ' ', LastName) AS UserName, UserID FROM profile `;
        connection.query(queryString, async (err, rows) => {
          if (err) {
            res.status(200).json({
              status: false,
              message: "Error ",
              error: err.message,
            });
          } else {
            if (rows && rows.length > 0) {
              for (let i = 0; i < rows.length; i++) {
                console.log(rows[i].UserID, rows[i].UserName);
                let userNameUpdateQuery = `UPDATE profile SET FirstName="${rows[i].UserName}" WHERE UserID = "${rows[i].UserID}"`;
                connection.query(userNameUpdateQuery, (err, rows) => {
                  if (err) {
                    res.status(200).json({
                      status: false,
                      message: "Error ",
                      error: err.message,
                    });
                  }
                });
              }
              res.status(200).json({
                status: true,
                message: "Username created ",
              });
            }
          }
        });
      }
    });
  } catch (error) {
    res.status(200).json({
      status: false,
      data: {},
      error: error.message,
    });
    console.log(error.message);
  }
};
exports.notifcationTypeTable = async (req, res, next) => {
  try {
    let queryString = `CREATE TABLE notificationtype (
              TypeID int NOT NULL PRIMARY KEY AUTO_INCREMENT,
              TypeName varchar(255)
          ); `;
    console.log(queryString);
    connection.query(queryString, (err, rows, fields) => {
      if (err) {
        res.status(200).json({
          status: false,
          profile: {},
          message: `Something went wrong, please try again later`,
          error: err.message,
        });
      } else {
        res.status(200).json({
          status: true,
          message: `notification type table created successfully`,
        });
      }
    });
  } catch (err) {
    next(err);
    res.status(200).json({
      status: false,
      profile: {},
      error: err.message,
    });
  }
};
// exports.notifcationTable = async (req, res, next) => {
//   try {
//     let queryString = ` CREATE TABLE notification ( NotificationID int NOT NULL PRIMARY KEY AUTO_INCREMENT,
//             TypeID int NOT NULL, Body Text,
//             CreaterID int NOT NULL,
//             ReceiverID int NOT NULL,
//             CONSTRAINT FK_NotificationType FOREIGN KEY (TypeID)
//             REFERENCES notificationtype(TypeID),
//             CONSTRAINT FK_NotificationType1 FOREIGN KEY (CreaterID) REFERENCES profile(UserID),
//             CONSTRAINT FK_NotificationType2 FOREIGN KEY (ReceiverID) REFERENCES profile(UserID) )`;
//     console.log(queryString);
//     connection.query(queryString, (err, rows, fields) => {
//       if (err) {
//         res.status(200).json({
//           status: false,
//           profile: {},
//           message: `Something went wrong, please try again later`,
//           error: err.message,
//         });
//       } else {
//         res.status(200).json({
//           status: true,
//           message: `Notification table created successfully`,
//         });
//       }
//     });
//   } catch (err) {
//     next(err);
//     res.status(200).json({
//       status: false,
//       profile: {},
//       error: err.message,
//     });
//   }
// };
exports.notesTable = async (req, res, next) => {
  try {
    let queryString = ` CREATE TABLE notes ( NoteID int NOT NULL PRIMARY KEY AUTO_INCREMENT,
            Note  text NOT NULL,
            CreatedDate  datetime NOT NULL,
            LastUpdate   datetime NOT NULL,
            CreaterID int NOT NULL,
            UserID int NOT NULL,
            CONSTRAINT FK_NotesType1 FOREIGN KEY (CreaterID) REFERENCES profile(UserID),
            CONSTRAINT FK_NotesType2 FOREIGN KEY (UserID) REFERENCES profile(UserID) )`;
    let createTable = await connection.query(queryString);
    if (createTable) {
      res.status(200).json({
        status: true,
        message: `Notes table created successfully`,
      });
    } else {
      res.status(200).json({
        status: false,
        message: `Error while creating table`,
      });
    }
  } catch (err) {
    next(err);
    res.status(200).json({
      status: false,
      profile: {},
      error: err.message,
    });
  }
};
exports.forgotPassword = async (req, res, next) => {
  try {
    let {
      email_address
    } = req.body;
    let checkUserEmail = await connection.query(
      `select * from profile where EmailAddress = '${email_address}'`, {
        type: QueryTypes.SELECT,
      }
    );
    if (checkUserEmail && checkUserEmail.length > 0) {
      var otp = Math.floor(Math.random() * 90000) + 10000;
      let queryString = `UPDATE profile SET AccessCodeEmail='${otp.toString()}' WHERE EmailAddress="${email_address}" `;
      let update = await connection.query(queryString);
      if (update) {
        let result = await sendMail(email_address, otp.toString());
        console.log(result, "--------------------------");
        res.status(200).json({
          status: true,
          message: "OTP send successfully",
        });
      } else {
        res.status(200).json({
          status: false,
          message: "Error while sending OTP",
        });
      }
    } else {
      res.status(200).json({
        status: false,
        message: "Email Address does not exist",
      });
    }
  } catch (err) {
    console.log(err);
    res.status(200).json({
      status: false,
      error: err.message,
    });
  }
};
exports.verifyOTPResetPassword = async (req, res, next) => {
  try {
    let {
      email_address,
      OTP
    } = req.body;

    let queryString = `select * from profile where EmailAddress = '${email_address}' and AccessCodeEmail= '${OTP}' `;
    let user = await connection.query(queryString, {
      type: QueryTypes.SELECT,
    });
    if (user && user.length > 0) {
      let updateEmailVerificationQuery = `update profile Set EmailVerified = 'Y' where UserID='${user[0].UserID}'`;
      let updateUser = await connection.query(updateEmailVerificationQuery);
      if (updateUser) {
        res.status(200).json({
          status: true,
          message: `Email verification successful`,
        });
      } else {
        res.status(200).json({
          status: false,
          message: `Error while verifying Email Address`,
        });
      }
    } else {
      res.status(200).json({
        status: false,
        message: `Invalid OTP`,
      });
    }
  } catch (err) {
    res.status(200).json({
      status: false,
      error: err.message,
    });
  }
};
exports.updatePassword = async (req, res, next) => {
  try {
    let {
      email_address,
      password
    } = req.body;
    const salt = await bcrypt.genSalt(10);
    let hashPassword = await bcrypt.hash(password, salt);
    let queryString = `update profile Set Password =  "${hashPassword}" WHERE EmailAddress="${email_address}"`;
    let updatePassword = await connection.query(queryString);
    if (updatePassword) {
      res.status(200).json({
        status: true,
        message: "Password updated successfully",
      });
    } else {
      res.status(200).json({
        status: false,
        message: "Error while updating password",
      });
    }
  } catch (err) {
    res.status(200).json({
      status: false,
      error: err.message,
    });
  }
};
exports.updatePhoneNumber = async (req, res, next) => {
  try {
   // const UserID = req.UserID;
	     
    const {
	    UserID,
      phoneNumber
    } = req.body;
    console.log(req.body, "-----------------------------");

    console.log(phoneNumber, "phoneNumber");
    let checkUserID = await connection.query(
      `select * from profile where UserID = "${UserID}" `, {
        type: QueryTypes.SELECT,
      }
    );
    console.log(checkUserID);
    if (checkUserID && checkUserID.length > 0) {
      console.log("******");
      let queryString = ` UPDATE profile SET PhoneNumber="${phoneNumber}", PhoneVerified= 'Y' WHERE UserID = "${UserID}"  `;
      let updatePhoneNumber = await connection.query(queryString);
      if (updatePhoneNumber) {
        res.status(200).json({
          status: true,
          message: `Phone Number updated successfully`,
        });
      } else {
        res.status(200).json({
          status: false,
          profile: {},
          message: `Something went wrong, please try again later`,
          error: err.message,
        });
      }
    } else {
      console.log("--------------");
      res.status(200).json({
        status: false,
        message: `User not found with given ID`,
      });
    }
  } catch (err) {
    next(err);
    res.status(200).json({
      status: false,
      data: {},
      error: err.message,
    });
    console.log(err.message);
  }
};
exports.updateEmail = async (req, res, next) => {
  try {
    const {
      EmailAddress
    } = req.body;
    let checkUserID = await connection.query(
      `select * from profile where EmailAddress = "${EmailAddress}" `, {
        type: QueryTypes.SELECT,
      }
    );
    console.log(checkUserID);
    if (checkUserID && checkUserID.length > 0) {
      console.log("******");
      let queryString = ` UPDATE profile SET EmailAddress="${EmailAddress}", EmailVerified= 'Y' WHERE UserID = "${checkUserID[0].UserID}"  `;
      let updateEmailAddress = await connection.query(queryString);
      if (updateEmailAddress) {
        res.status(200).json({
          status: true,
          message: `EmailAddress updated successfully`,
        });
      } else {
        res.status(200).json({
          status: false,
          profile: {},
          message: `Something went wrong, please try again later`,
          error: err.message,
        });
      }
    } else {
      console.log("--------------");
      res.status(200).json({
        status: false,
        message: `Email Address does not exist`,
      });
    }
  } catch (err) {
    next(err);
    res.status(200).json({
      status: false,
      data: {},
      error: err.message,
    });
    console.log(err.message);
  }
};
exports.viewUserDetailsByPhoneFilter = async (req, res, next) => {
  try {
    let {
      limit,
      offset,
      search,
      sort
    } = req.body;
    limit = parseInt(limit);
    offset = parseInt(offset);
    offset = limit * offset;
    search = search.trim();
    let usersCount = await connection.query(
      `SELECT COUNT(UserID ) as total_records FROM profile WHERE  PhoneNumber  LIKE "%${search}%"`, {
        type: QueryTypes.SELECT,
      }
    );
    if (usersCount && usersCount.length > 0) {
      let viewUsersDetailQuery =
        `SELECT *  FROM profile WHERE  PhoneNumber  LIKE "%${search}%" order by UserID ${sort} limit ` +
        limit +
        " offset " +
        offset;
      let viewUsersDetail = await connection.query(viewUsersDetailQuery, {
        type: QueryTypes.SELECT,
      });
      if (viewUsersDetail && viewUsersDetail.length > 0) {
        res.status(200).json({
          status: true,
          total_records: usersCount[0].total_records,
          Users: viewUsersDetail,
        });
      } else {
        res.status(200).json({
          status: true,
          total_records: usersCount[0].total_records,
          Users: [],
        });
      }
    }
  } catch (err) {
    next(err);
    res.status(200).json({
      status: false,
      users: {},
      error: err.message,
    });
    console.log(err.message);
  }
};
exports.viewUserDetailsByEmailFilter = async (req, res, next) => {
  try {
    let {
      limit,
      offset,
      search,
      sort
    } = req.body;
    limit = parseInt(limit);
    offset = parseInt(offset);
    offset = limit * offset;
    search = search.trim();

    let usersCount = await connection.query(
      `SELECT COUNT(UserID) as total_records FROM profile WHERE  EmailAddress  LIKE "%${search}%"   `, {
        type: QueryTypes.SELECT,
      }
    );
    if (usersCount && usersCount.length > 0) {
      let viewUsersDetailQuery =
        `SELECT *  FROM profile WHERE  EmailAddress  LIKE "%${search}%" order by UserID ${sort} limit ` +
        limit +
        " offset " +
        offset;
      let viewUsersDetail = await connection.query(viewUsersDetailQuery, {
        type: QueryTypes.SELECT,
      });
      if (viewUsersDetail && viewUsersDetail.length > 0) {
        res.status(200).json({
          status: true,
          total_records: usersCount[0].total_records,
          Users: viewUsersDetail,
        });
      } else {
        res.status(200).json({
          status: true,
          total_records: usersCount[0].total_records,
          Users: [],
        });
      }
    }
  } catch (err) {
    next(err);
    res.status(200).json({
      status: false,
      users: {},
      error: err.message,
    });
    console.log(err.message);
  }
};
exports.viewUserDetailsByNameFilter = async (req, res, next) => {
  try {
    let {
      limit,
      offset,
      search,
      sort
    } = req.body;
    limit = parseInt(limit);
    offset = parseInt(offset);
    offset = limit * offset;
    console.log(req.body);
    search = search.trim();

    let usersCount = await connection.query(
      `SELECT COUNT(UserID ) as total_records FROM profile WHERE  UserName  LIKE "%${search}%" `, {
        type: QueryTypes.SELECT,
      }
    );
    if (usersCount && usersCount.length > 0) {
      let viewUsersDetailQuery =
        `SELECT *  FROM profile WHERE  UserName  LIKE "%${search}%" order by UserID ${sort} limit ` +
        limit +
        " offset " +
        offset;
      let viewUsersDetail = await connection.query(viewUsersDetailQuery, {
        type: QueryTypes.SELECT,
      });
      if (viewUsersDetail && viewUsersDetail.length > 0) {
        res.status(200).json({
          status: true,
          total_records: usersCount[0].total_records,
          Users: viewUsersDetail,
        });
      } else {
        res.status(200).json({
          status: true,
          total_records: usersCount[0].total_records,
          Users: [],
        });
      }
    }
  } catch (err) {
    next(err);
    res.status(200).json({
      status: false,
      users: {},
      error: err.message,
    });
    console.log(err.message);
  }
};
exports.getOrdersDetailsByOrderID = async (req, res, next) => {
  try {
    let OrderNumber = req.params.id;
    let productCombinationPriceDetail = [];
    let getProcessOrderDetails = await connection.query(
      `SELECT * from processorder WHERE OrderNumber="${OrderNumber}" 
     `, {
        type: QueryTypes.SELECT,
      }
    );
    let viewOrderListQuery = `SELECT p.ProductID,p.Title,m.TransactionID,s.OrderNumber,s.AllowStorePickup,s.AllowAdminPickup,s.ReadyPickupForUser,s.ReadyPickupForAdmin,s.OrderDate,m.PaymentStatus,p.Price AS BasePrice,s.Quantity,p.Currency,s.UserID,g.Small,g.Medium,g.Large,i.MainImage,s.StatusHistory,s.ProcessStatus,
      (SELECT COUNT(t.ProductID)
      from productreviewrating t WHERE t.ProductID = p.ProductID) AS REVIEW_COUNT,
      (SELECT AVG(t.Rating) from productreviewrating t WHERE t.ProductID = p.ProductID) AS  AVG_Rating
          FROM ((((((( product p      
          LEFT JOIN productvariantoption o ON o.ProductID IN( p.ProductID))
          LEFT JOIN productvariantoptionvalue v  ON  v.OptionID IN (o.OptionID))  
          LEFT JOIN productimage i  ON  i.OptionValueID IN (v.OptionValueID))
          LEFT JOIN imagegallery g  ON  g.ImageGalleryID IN (i.ImageGalleryID))
          LEFT JOIN productvariantcombination c  ON  c.OptionValueID IN (v.OptionValueID))
          INNER JOIN processorder s ON s.ProductID IN(c.ProductID))
          LEFT JOIN processpayment m ON m.OrderNumber IN(s.OrderNumber))
          WHERE i.MainImage='Y' AND s.OrderNumber="${OrderNumber}"
          GROUP BY s.ProcessOrderID `;
    let viewOrderList = await connection.query(viewOrderListQuery, {
      type: QueryTypes.SELECT,
    });

    let productCombinationDetail;
    if (viewOrderList && viewOrderList.length > 0) {
      for (let i = 0; i < getProcessOrderDetails.length; i++) {
        let ProductVariantCombinationDetail = [];
        ProductVariantCombinationDetail.push(
          getProcessOrderDetails[i].ProductVariantCombinationDetail
        );
        ProductVariantCombinationDetail = `(${ProductVariantCombinationDetail.join(
          ","
        )})`;
        productCombinationDetail = await connection.query(
          `SELECT p.ProductID,c.ProductVariantCombinationID,c.VendorStoreID,c.Price AS ProductCombinationPrice,c.AvailableInventory,o.OptionID,o.OptionName,v.OptionValue,v.OptionValueID
              FROM ((((product p
              LEFT JOIN productvariantoption o ON o.ProductID IN( p.ProductID))
              LEFT JOIN productvariantoptionvalue v  ON  v.OptionID IN (o.OptionID)) 
              LEFT JOIN productvariantcombination c  ON  c.OptionValueID IN (v.OptionValueID))
              LEFT JOIN processorder s ON s.ProductID IN(c.ProductID))
              WHERE  c.ProductVariantCombinationID IN ${ProductVariantCombinationDetail}
              GROUP BY c.OptionValueID
             `, {
            type: QueryTypes.SELECT,
          }
        );
        productCombinationPriceDetail.push(productCombinationDetail);
      }
      let orderName = [];
      let orderDate = [];
      let paymentStatus = [];
      let transactionID = [];
      let tempPC = productCombinationPriceDetail;
      let tempProd = viewOrderList;
      let tempArray = [];
      let allowStorePickup = [];
      let readyPickupForUser = [];
      let readyPickupForAdmin = [];
      let allowAdminPickup = [];
      let statusHistory = [];
      let processStatus = [];
      var arr = [];
      let tempAOrderDetails = [];
      for (let i = 0; i < tempProd.length; i++) {
        var obj = {
          ...tempProd[i],
        };
        obj["ProductCombinations"] = tempPC[i];
        tempArray.push(obj);
      }
      for (let i = 0; i < tempArray.length; i++) {
        if (!orderName.includes(tempArray[i].OrderNumber)) {
          orderName.push(tempArray[i].OrderNumber);
          orderDate.push(tempArray[i].OrderDate);
          paymentStatus.push(tempArray[i].PaymentStatus);
          transactionID.push(tempArray[i].TransactionID);
          allowStorePickup.push(tempArray[i].AllowStorePickup);
          readyPickupForUser.push(tempArray[i].ReadyPickupForUser);
          readyPickupForAdmin.push(tempArray[i].ReadyPickupForAdmin);
          allowAdminPickup.push(tempArray[i].AllowAdminPickup);
          statusHistory.push(tempArray[i].StatusHistory);
          processStatus.push(tempArray[i].ProcessStatus);
        }
      }
      for (let i = 0; i < orderName.length; i++) {
        var obj = {
          OrderNumber: orderName[i],
          OrderDate: orderDate[i],
          PaymentStatus: paymentStatus[i],
          TransactionID: transactionID[i],
          AllowStorePickup: allowStorePickup[i],
          ReadyPickupForUser: readyPickupForUser[i],
          ReadyPickupForAdmin: readyPickupForAdmin[i],
          AllowAdminPickup: allowAdminPickup[i],
          StatusHistory: statusHistory[i],
          ProcessStatus: processStatus[i],
          ProductDetail: [],
        };
        for (let j = 0; j < tempArray.length; j++) {
          if (orderName[i] === tempArray[j].OrderNumber) {
            obj.ProductDetail.push(tempArray[j]);
          }
        }
        tempAOrderDetails.push(obj);
      }
      if (productCombinationDetail && productCombinationDetail.length > 0) {
        orderShippingDetail = await connection.query(
          `SELECT o.ID AS DeliveryAddressID,o.OrderNumber,o.Name AS DeliveryName,o.PhoneNumber AS DeliveryPhoneNumber,o.Address1 AS DeliveryAddress1,o.Address2 AS DeliveryAddress2,o.City AS DeliveryCity,o.State AS DeliveryState,o.CountryID AS DeliveryCountryID,c.Country AS DeliveryCountry,o.ZipCode AS DeliveryZipCode,o.DesireDate,o.UserNote AS DeliveryUserNote
          FROM processorder p 
          INNER JOIN orderdeliveryaddress o ON o.OrderNumber = p.OrderNumber
          INNER JOIN country c ON c.CountryID = o.CountryID
          WHERE  p.OrderNumber = "${OrderNumber}" 
         `, {
            type: QueryTypes.SELECT,
          }
        );
        if (orderShippingDetail && orderShippingDetail.length > 0) {
          let deliveryDriverDetails = await connection.query(
            `SELECT d.*,p.*
            FROM processorder o
            INNER JOIN deliverydriver d ON d.DeliveryDriverID = o.DeliveryDriverID
            INNER JOIN profile p ON p.UserID = d.DeliveryDriverID
            WHERE o.OrderNumber = "${OrderNumber}"
           `, {
              type: QueryTypes.SELECT,
            }
          );
          if (deliveryDriverDetails && deliveryDriverDetails.length > 0) {
            res.status(200).json({
              status: true,
              orderDetails: tempAOrderDetails[0],
              orderShippingDetail: orderShippingDetail[0],
              deliveryDriverDetails: deliveryDriverDetails[0],
            });
          } else {
            res.status(200).json({
              status: true,
              orderDetails: tempAOrderDetails[0],
              orderShippingDetail: orderShippingDetail[0],
              deliveryDriverDetails: null,
            });
          }
        } else {
          res.status(200).json({
            status: true,
            orderDetails: tempAOrderDetails[0],
            orderShippingDetail: null,
            deliveryDriverDetails: null,
          });
        }
      } else {
        res.status(200).json({
          status: false,
          orderDetails: null,
          orderShippingDetail: null,
          deliveryDriverDetails: null,
        });
      }
    } else {
      res.status(200).json({
        status: false,
        orderDetails: null,
        orderShippingDetail: null,
        deliveryDriverDetails: null,
      });
    }
  } catch (err) {
    console.log(err.message);
    next(err);
    res.status(200).json({
      status: false,
      orderDetails: null,
      orderShippingDetail: null,
      deliveryDriverDetails: null,
    });
  }
};
exports.getUserCatdDetails = async (req, res, next) => {
  try {
    let UserID = req.UserID;
    getUserCardDetails = await connection.query(
      `SELECT u.*,c.Country
      FROM profile p
      INNER JOIN userpayment u ON u.UserID = p.UserID
      INNER JOIN country c ON c.CountryID = u.CountryID
      WHERE u.UserID="${UserID}"
      ORDER BY u.LastUpdate DESC
     `, {
        type: QueryTypes.SELECT,
      }
    );
    if (getUserCardDetails && getUserCardDetails.length > 0) {
      res.status(200).json({
        status: true,
        getUserCardDetails,
      });
    } else {
      res.status(200).json({
        status: false,
        getUserCardDetails: null,
      });
    }
  } catch {
    console.log(err.message);
    next(err);
    res.status(200).json({
      status: false,
      getUserCardDetails: null,
    });
  }
};
exports.Notification = async (
  TypeID,
  Body,
  CreaterID,
  ReceiverID,
  transaction
) => {
  try {
    let LastUpdate = new Date().toISOString().slice(0, 19).replace("T", " ");
    let id;
    let insertNotifications;
    /*  const UserID = req.UserID;
     let Body = null;
     let Notification = null;
     let Time = null;
     let TypeName = null; */
    let saveBody = JSON.stringify(Body);
    /* if (TypeID == "3") {
      insertNotifications = true
    } else { */
    //try {
    let insertNotificationsQuery = `insert into notification (TypeID,Body,CreaterID,ReceiverID,LastUpdate ) `;
    insertNotificationsQuery += ` values ("${TypeID}",'${saveBody}',"${CreaterID}","${ReceiverID}","${LastUpdate}") `;

    insertNotifications = await connection.query(insertNotificationsQuery, {
      transaction,
    });
    //insertNotifications = true
    /* } catch (e) {
      console.log(e)
      insertNotifications = false
    } */
    // }
    if (TypeID == "3") {
      id = "null";
    }
    if (TypeID == "4") {
      id = "null";
    }
    if (TypeID == "6") {
      id = Body.OrderNumber;
    }
    if (TypeID == "7") {
      id = Body.OrderNumber;
    }
    if (TypeID == "8") {
      id = Body.OrderNumber;
    }
    if (TypeID == "5") {
      if (Body.DeliveryDriverID && Body.DeliveryDriverID.length > 0) {
        id = Body.DeliveryDriverID;
      } else if (Body.ProductID && Body.ProductID.length > 0) {
        id = Body.ProductID;
      } else {
        id = "null";
      }
    }
    let body = Body.body;

    if (insertNotifications) {
      //This query will check if device id exists then send firebase notification to user otherwise send true means only above query runs i.e save into db and returs true
      let getDeviceIDQuery = ` SELECT DeviceID
    FROM profile 
    WHERE UserID=${ReceiverID}`;
      let getDeviceID = await connection.query(getDeviceIDQuery, {
        type: QueryTypes.SELECT,
        transaction,
      });
      console.log(
        getDeviceID[0].DeviceID,
        "getDeviceIDQuery------------------------------"
      );
      if (
        getDeviceID[0].DeviceID &&
        getDeviceID[0].DeviceID !== "NULL" &&
        getDeviceID[0].DeviceID !== "null" &&
        getDeviceID[0].DeviceID !== null &&
        getDeviceID[0].DeviceID !== undefined
      ) {
        let getTypeIDQuery = `SELECT TypeName,TypeID
      FROM notificationtype 
      WHERE TypeID="${TypeID}" `;
        let getTypeID = await connection.query(getTypeIDQuery, {
          type: QueryTypes.SELECT,
          transaction,
        });
        if (getTypeID && getTypeID.length > 0) {
          let token = getDeviceID[0].DeviceID;
          let TypeName = getTypeID[0].TypeName;
          let TypeID = getTypeID[0].TypeID.toString();

          let result;
          let message = {
            notification: {
              title: TypeName,
              body: body,
            },
            data: {
              TypeID,
              id,
              time: LastUpdate,
              channel_id: "default_notification_channel_id",
            },
            token: token,
          };
          console.log(message);
          admin
            .messaging()
            .send(message)
            .then((result = await
              function (response) {}))
            .catch(function (error) {
              console.log(error);
              return error;
            });
          return result;
        } else {
          console.log("error");
          return;
        }
      } else {
        console.log(
          "else true case ----------------------------------------------------"
        );
        return true;
      }
    } else {
      console.log("error");
    }
  } catch (err) {
    console.log(err);
  }
  /* let getUserNotificationsQuery = ` SELECT t.*,n.*
                FROM notification n
                INNER JOIN notificationtype t ON t.TypeID=n.TypeID
                WHERE n.ReceiverID=${UserID}`;
    let getUserNotifications = await connection.query(getUserNotificationsQuery, {
      type: QueryTypes.SELECT,
    });
 */

  /*  if (getUserNotifications && getUserNotifications.length > 0) {
     Body = getUserNotifications[0].Body
     Notification = getUserNotifications[0].NotificationStatus
     Time = getUserNotifications[0].LastUpdate
     TypeName = getUserNotifications[0].TypeName
   }
   console.log(Body) */
  /* const bodyValues = JSON.parse(Body);
  const OrderNumber = bodyValues.OrderNumber
  const body = bodyValues.Body
  console.log(OrderNumber) */

  //let threadId = "null"
  // console.log(token)
  /* const payload = {
    
      "message":{
        "token":"bk3RNwTe3H0:CI2k_HHwgIpoDKCIZvvDMExUdFQ3P1...",
        "notification":{
          "title":"Portugal vs. Denmark",
          "body":"great match!"
        }
      }
  };
  console.log(payload)
  var options = {
    priority: "high",
    timeToLive: 60 * 60 * 24
  }; */
  /* INNER JOIN notification n ON n.ReceiverID=p.UserID
  INNER JOIN notificationtype t ON t.TypeID=n.TypeID */
};
exports.getUserReviewStatus = async (req, res, next) => {
  try {
    const {
      ProductID
    } = req.body;
    const UserID = req.UserID;
    console.log(UserID, "UserID");
    let checkProductBoughtStatus = await connection.query(
      `SELECT 
    CASE
        WHEN EXISTS (
            SELECT * FROM processorder 
            WHERE UserID = "${UserID}" AND ProductID = "${ProductID}"
        ) 
        AND NOT EXISTS (
            SELECT * FROM productreviewrating 
            WHERE UserID = "${UserID}" AND ProductID =  "${ProductID}"
        ) THEN 'true'
        ELSE 'false'
    END AS result;
 `, {
        type: QueryTypes.SELECT
      }
    );
    console.log(
      checkProductBoughtStatus,
      "checkProductBoughtStatus------------------->"
    );
    if (checkProductBoughtStatus) {
      res.status(200).json({
        status: true,
        productStatus: checkProductBoughtStatus[0].result === "false" ? false : true,
      });
    } else {
      res.status(200).json({
        status: false,
        message: "Error while getting user product review status",
      });
    }
  } catch (e) {
    console.log(e.message);
    res.status(200).json({
      status: false,
      message: e.message,
    });
  }
};
exports.logout = async (req, res, next) => {
  try {
    const {
      SessionID
    } = req.body;
    let changeActiveStatus = await connection.query(
      `UPDATE login SET Active="N" WHERE SessionID="${SessionID}" `
    );
    if (changeActiveStatus) {
      res.status(200).json({
        status: true,
        message: "Successfully updated Active status",
      });
    } else {
      res.status(200).json({
        status: false,
        message: "Error while changing Active status",
      });
    }
  } catch (e) {
    console.log(e.message);
    res.status(200).json({
      status: false,
      message: e.message,
    });
  }
};
