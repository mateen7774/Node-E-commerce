const connection = require("../../db/db.connection");
const { QueryTypes } = require("sequelize");
const {
  Notification,
} = require("../../controllers/usersControllers/users.controller");
const { sendEmail, } = require("../../utils/notificationsMail");
const { sendContactUsEmail, } = require("../../utils/notify");
const { sendContactAdminMail } = require("../../utils/contactEmail");

exports.addUser = async (req, res, next) => {
  try {
    let {
      username,
      email,
      Birthday,
      Gender,
      phone_number,
      Customer,
      Active,
      EmailVerified,
      PhoneVerified,
    } = req.body;

    let checkIfUserExists = await userByEmailCheck(email);

    if (checkIfUserExists && checkIfUserExists == "0") {
      let queryString = `insert into profile (UserName,Birthday,Gender ,EmailAddress, PhoneNumber, Password,Customer,Active,EmailVerified,PhoneVerified,CreatedDate)`;
      queryString += ` values ("${username}","${Birthday}","${Gender}","${email}", "${phone_number}","1122" ,"${Customer}","${Active}","Y","Y","${new Date()
        .toISOString()
        .slice(0, 19)
        .replace("T", " ")}") `;

      let addUser = await connection.query(queryString);
      if (addUser) {
        res.status(200).json({
          status: true,
          message: "User created successfully",
        });
      } else {
        res.status(200).json({
          status: false,
          message: "Error while adding User",
        });
      }
    } else if (checkIfUserExists && checkIfUserExists == "1") {
      res.status(200).json({
        status: false,
        message: "USER already exists",
        user: [],
      });
    }
  } catch (err) {
    next(err);
    res.status(200).json({
      status: false,
      profile: {},
      error: err.message,
    });
  }
};
let userByEmailCheck = async (EmailAddress) => {
  try {
    let user = await connection.query(
      `select * from profile where EmailAddress = '${EmailAddress}'`,
      {
        type: QueryTypes.SELECT,
      }
    );
    if (user && user.length > 0) {
      return "1";
    } else {
      return "0";
    }
  } catch (err) {
    console.log(err.message);
    return null;
  }
};
exports.viewUsers = async (req, res, next) => {
  try {
    let { limit, offset } = req.body;
    limit = parseInt(limit);
    offset = parseInt(offset);
    offset = limit * offset;
    let usersCount = await connection.query(
      `SELECT COUNT(UserID) as total_records FROM profile `,
      {
        type: QueryTypes.SELECT,
      }
    );
    if (usersCount && usersCount.length > 0) {
      let data =
        "SELECT *  FROM profile order by UserID desc limit " +
        limit +
        " offset " +
        offset;
      let allUsers = await connection.query(data, {
        type: QueryTypes.SELECT,
      });
      if (allUsers && allUsers.length > 0) {
        res.status(200).json({
          status: true,
          total_records: usersCount[0].total_records,
          data: allUsers,
        });
      } else {
        res.status(200).json({
          status: true,
          total_records: usersCount[0].total_records,
          data: [],
        });
      }
    }
  } catch (err) {
    next(err);
    res.status(200).json({
      status: false,
      profile: {},
      error: err.message,
    });
    console.log(err.message);
  }
};
exports.viewUserById = async (req, res, next) => {
  try {
    let user = await connection.query(
      `select * from profile WHERE UserID='${req.params.id}' `,
      {
        type: QueryTypes.SELECT,
      }
    );
    // console.log(user)
    if (user && user.length > 0) {
      res.status(200).json({
        status: true,
        profile: user[0] ? user[0] : [],
      });
    } else {
      res.status(200).json({
        status: false,
        message: "User not found with given ID",
      });
    }
  } catch (err) {
    next(err);
    res.status(200).json({
      status: false,
      profiles: [],
      error: err.message,
    });
    console.log(err.message);
  }
};
exports.updateUsersDetailsByID = async (req, res, next) => {
  try {
    const id = req.params.id;
    let { UserName, EmailAddress, Birthday, Gender, PhoneNumber } = req.body;
    let LastUpdate = new Date().toISOString().slice(0, 19).replace("T", " ");
    // edit functionality
    let user = await connection.query(
      `select * from profile where UserID = '${id}' `,
      {
        type: QueryTypes.SELECT,
      }
    );
    if (user && user.length > 0) {
      let queryString;
      if (Birthday && Birthday != undefined && Birthday != "Invalid date") {
        queryString = `UPDATE profile SET UserName = '${UserName}', EmailAddress = '${EmailAddress}', Birthday = '${Birthday}', 
                Gender = '${Gender}', PhoneNumber = '${PhoneNumber}' ,LastUpdate = '${LastUpdate}'
             WHERE UserID = "${id}"  `;
      } else {
        queryString = `UPDATE profile SET UserName = '${UserName}', EmailAddress = '${EmailAddress}', 
                Gender = '${Gender}', PhoneNumber = '${PhoneNumber}' ,LastUpdate = '${LastUpdate}'
             WHERE UserID = "${id}"  `;
      }

      let updateUser = await connection.query(queryString, {
        replacements: [req.body],
      });
      if (updateUser) {
        res.status(200).json({
          status: true,
          message: `User details updated successfully`,
        });
      } else {
        res.status(200).json({
          status: false,
          message: `Error while updating user details`,
        });
      }
    } else {
      res.status(200).json({
        status: false,
        message: `User not found with given ID`,
      });
    }
  } catch (error) {
    next(err);
    res.status(200).json({
      status: false,
      data: {},
      error: err.message,
    });
    console.log(err.message);
  }
};

exports.deleteUserById = async (req, res, next) => {
  try {
    const id = req.params.id;

    connection.query(
      `select * from profile where UserID = "${id}" `,
      async (err, rows, fields) => {
        if (err) {
          res.status(200).json({
            status: false,
            message: "Error while deleting",
            error: err.message,
          });
        } else {
          if (rows.length > 0) {
            let queryString = ` DELETE FROM profile WHERE UserID="${id}"  `;
            connection.query(queryString, [req.body], (err, rows, fields) => {
              if (err) {
                res.status(200).json({
                  status: false,
                  profile: {},
                  message: `Something went wrong, please try again later`,
                  error: err.message,
                });
              } else {
                res.status(200).json({
                  status: true,
                  message: `User deleted successfully`,
                });
              }
            });
          } else {
            res.status(200).json({
              status: false,
              message: `User not found with given ID`,
            });
          }
        }
      }
    );
  } catch (error) {
    next(err);
    res.status(200).json({
      status: false,
      data: {},
      error: err.message,
    });
    console.log(err.message);
  }
};

exports.updateRoles = async (req, res, next) => {
  try {
    let { UserID, Customer, DeliveryPerson, Vendor, Admin } = req.body;
    let checkIfUserExists = await connection.query(
      `select * from profile where UserID = "${UserID}" `,
      {
        type: QueryTypes.SELECT,
      }
    );
    if (checkIfUserExists && checkIfUserExists.length > 0) {
      let queryString = ` UPDATE profile SET Customer = '${Customer}', DeliveryPerson = '${DeliveryPerson}' , 
            Vendor = '${Vendor}', Admin = '${Admin}' WHERE UserID = "${UserID}" `;
      let updateRole = await connection.query(queryString);
      if (updateRole) {
        res.status(200).json({
          status: true,
          message: `User Role Updated Successfully`,
        });
      } else {
        res.status(200).json({
          status: false,
          message: `Error while updating role`,
        });
      }
    } else {
      res.status(200).json({
        status: false,
        message: `User not found with given ID`,
      });
    }
  } catch (err) {
    next(err);
    res.status(200).json({
      status: false,
      error: err.message,
    });
    console.log(err.message);
  }
};

exports.showNote = async (req, res, next) => {
  try {
    const id = req.params.id;
    // get by id functionality
    let queryString = "select * from profile WHERE UserID=? ";
    let user = await connection.query(queryString, {
      replacements: [req.params.id],
      type: QueryTypes.SELECT,
    });
    let queryString_ = ` SELECT n.*,p.UserName AS CreaterName,p.EmailAddress
                    FROM notes n
                    JOIN profile p ON n.CreaterID=p.UserID
                    WHERE n.UserID=${id}`;
    let notes = await connection.query(queryString_, {
      type: QueryTypes.SELECT,
    });
    if (notes && notes.length > 0) {
      res.status(200).json({
        status: true,
        message: `Admin Notes`,
        Note: notes,
      });
    } else {
      res.status(200).json({
        status: true,
        message: `Admin Notes`,
        Note: [],
      });
    }
  } catch (error) {
    next(err);
    res.status(200).json({
      status: false,
      profile: {},
      error: err.message,
    });
    console.log(err.message);
  }
};

exports.createNote = async (req, res, next) => {
  try {
    let { CreaterID, UserID, Note, CreatedDate, LastUpdate } = req.body;
    let queryString = `insert into notes (Note,CreaterID ,UserID)  `;
    queryString += ` values ("${Note}", "${CreaterID}","${UserID}") `;
    let newNote = await connection.query(queryString);
    if (newNote) {
      res.status(200).json({
        status: true,
        message: "Note Inserted successfully",
      });
    } else {
      res.status(200).json({
        status: false,
        message: "Error while adding note",
      });
    }
  } catch (err) {
    res.status(200).json({
      status: false,
      error: err.message,
    });
  }
};

exports.updateNote = async (req, res, next) => {
  try {
    const { NoteID } = req.body;
    let { Note, CreaterID, UserID, LastUpdate } = req.body;
    let queryString = `UPDATE notes SET Note='${Note}',CreaterID='${CreaterID}',UserID='${UserID}',LastUpdate='${new Date()
      .toISOString()
      .slice(0, 19)
      .replace("T", " ")}' WHERE NoteID = "${NoteID}"  `;
    console.log(queryString);
    connection.query(queryString, (err, rows, fields) => {
      if (err) {
        res.status(200).json({
          status: false,
          data: {},
          message: "error something went wrong",
          error: err.message,
        });
      } else {
        res.status(200).json({
          status: true,
          message: "Note updated successfully",
        });
      }
    });
  } catch (err) {
    res.status(200).json({
      status: false,
      error: err.message,
    });
  }
};

exports.getInAppNotifications = async (req, res, next) => {
  try {
    const receiverID = req.UserID;
    let getInAppNotificationsQuery = ` SELECT t.*,n.Body,n.NotificationID,n.LastUpdate,n.NotificationStatus,p.UserID,p.UserName,p.EmailAddress,p.ProfilePic
                FROM notification n
                JOIN profile p ON p.UserID = n.CreaterID
                LEFT JOIN notificationtype t ON t.TypeID = n.TypeID
                WHERE n.ReceiverID=${receiverID}
                ORDER BY n.NotificationID DESC`;
    let getInAppNotifications = await connection.query(
      getInAppNotificationsQuery,
      {
        type: QueryTypes.SELECT,
      }
    );
    if (getInAppNotifications && getInAppNotifications.length > 0) {
      res.status(200).json({
        status: true,
        notifications: getInAppNotifications,
      });
    } else {
      res.status(200).json({
        status: true,
        notifications: [],
      });
    }
  } catch (err) {
    next(err);
    res.status(200).json({
      status: false,
      notifications: [],
      error: err.message,
    });
  }
};

exports.updateInAppNotifications = async (req, res, next) => {
  try {
    const NotificationID = req.params.id;
    let updateInAppNotificationsQuery = ` UPDATE notification SET NotificationStatus="read" WHERE NotificationID="${NotificationID}" `;
    let updateInAppNotifications = await connection.query(
      updateInAppNotificationsQuery
    );
    if (updateInAppNotifications) {
      res.status(200).json({
        status: true,
        message: "Successfully changed status to read",
      });
    } else {
      res.status(200).json({
        status: false,
        message: "unable to change the status ",
      });
    }
  } catch (err) {
    next(err);
    res.status(200).json({
      status: false,
      message: err.message,
    });
  }
};

exports.setStatus = async (req, res, next) => {
  try {
    let { UserID, Active } = req.body;
    let checkIfUserExists = await connection.query(
      `select * from profile where UserID = "${UserID}" `,
      {
        type: QueryTypes.SELECT,
      }
    );
    if (checkIfUserExists && checkIfUserExists.length > 0) {
      let queryString = ` UPDATE profile SET Active = '${Active}' WHERE UserID = "${UserID}" `;
      let updateRole = await connection.query(queryString);
      if (updateRole) {
        res.status(200).json({
          status: true,
          message: `User status updated`,
        });
      } else {
        res.status(200).json({
          status: false,
          message: `Error while updating status`,
        });
      }
    } else {
      res.status(200).json({
        status: false,
        message: `User not found with given ID`,
      });
    }
  } catch (error) {
    next(err);
    res.status(200).json({
      status: false,
      data: {},
      error: err.message,
    });
    console.log(err.message);
  }
};

exports.checkEmail = async (req, res, next) => {
  try {
    let { EmailAddress } = req.body;
    let user = await connection.query(
      `select * from profile where EmailAddress = "${EmailAddress}" `,
      {
        type: QueryTypes.SELECT,
      }
    );
    if (user && user.length > 0) {
      res.status(200).json({
        status: false,
        message: `Email already used by another user`,
      });
    } else {
      res.status(200).json({
        status: true,
        message: `Email does not exist `,
      });
    }
  } catch (error) {
    next(err);
    res.status(200).json({
      status: false,
      data: {},
      error: err.message,
    });
    console.log(err.message);
  }
};

exports.checkNumber = async (req, res, next) => {
  try {
    let { PhoneNumber } = req.body;

    let user = await connection.query(
      `select * from profile where PhoneNumber = "${PhoneNumber}" `,
      {
        type: QueryTypes.SELECT,
      }
    );
    if (user && user.length > 0) {
      res.status(200).json({
        status: false,
        message: `PhoneNumber already exists`,
      });
    } else {
      res.status(200).json({
        status: true,
        message: `PhoneNumber does not exist `,
      });
    }
  } catch (error) {
    next(err);
    res.status(200).json({
      status: false,
      data: {},
      error: err.message,
    });
    console.log(err.message);
  }
};

exports.updateIP = async (req, res, next) => {
  try {
    let { IPAddress, UserID } = req.body;
    let updateIP = await connection.query(
      `update profile Set IPAddress=  "${IPAddress}" WHERE UserID="${UserID}"`,
      {
        type: QueryTypes.UPDATE,
      }
    );

    if (updateIP && updateIP.length > 0) {
      res.status(200).json({
        status: true,
        message: "IP Address updated successfully",
      });
    } else {
      res.status(200).json({
        status: false,
        data: {},
        message: "error something went wrong",
        error: err.message,
      });
    }
  } catch (err) {
    res.status(200).json({
      status: false,
      error: err.message,
    });
  }
};

exports.showType = async (req, res, next) => {
  try {
    let queryString = await connection.query(
      `select * from notificationtype `,
      {
        type: QueryTypes.SELECT,
      }
    );
    if (queryString) {
      res.status(200).json({
        status: true,
        Type: queryString,
      });
    } else {
      res.status(200).json({
        status: false,
        message: "something went wrong cannot show type",
      });
    }
  } catch (err) {
    next(err);
    res.status(200).json({
      status: false,
      profile: {},
      error: err.message,
    });
  }
};

exports.viewRecordsReviewByAdmin = async (req, res, next) => {
  try {
    let getVendorBusinessQuery = `SELECT * FROM vendor WHERE ReviewedByAdmin="N" ORDER BY VendorID DESC LIMIT 50 `;
    let getVendorBusiness = await connection.query(getVendorBusinessQuery, {
      type: QueryTypes.SELECT,
    });
    if (getVendorBusiness && getVendorBusiness.length > 0) {
      res.status(200).json({
        status: true,
        VendorBusinessRecords: getVendorBusiness,
      });
    } else {
      res.status(200).json({
        status: false,
        message: "NO Vendor Business Records found",
        VendorBusinessRecords: [],
      });
    }
  } catch (err) {
    next(err);
    res.status(200).json({
      status: false,
      profile: {},
      error: err.message,
    });
  }
};

exports.updateVendorAdminStatusById = async (req, res, next) => {
  try {
    let checkIfVendorExists = await connection.query(
      `select * from vendor WHERE VendorID="${req.params.id}" `,
      {
        type: QueryTypes.SELECT,
      }
    );
    if (checkIfVendorExists && checkIfVendorExists.length > 0) {
      let updateVendorStatusQuery = `UPDATE vendor SET ReviewedByAdmin="Y" WHERE VendorID ="${req.params.id}" `;
      let updateVendorStatus = await connection.query(updateVendorStatusQuery, {
        type: QueryTypes.UPDATE,
      });
      if (updateVendorStatus) {
        res.status(200).json({
          status: true,
          message: "Vendor Status Reviewed By Admin Updated Successfully",
        });
      } else {
        res.status(200).json({
          status: false,
          message: "error while updating vendor status",
          VendorBusiness: [],
        });
      }
    } else {
      res.status(200).json({
        status: false,
        message: "NO Vendor Business found",
        VendorBusiness: [],
      });
    }
  } catch (err) {
    next(err);
    res.status(200).json({
      status: false,
      profile: {},
      error: err.message,
    });
  }
};

exports.viewRecordsReviewBySuperAdmin = async (req, res, next) => {
  try {
    let getVendorBusinessQuery = `SELECT * FROM vendor WHERE ReviewedBySuperAdmin="N" LIMIT 50 `;
    let getVendorBusiness = await connection.query(getVendorBusinessQuery, {
      type: QueryTypes.SELECT,
    });
    if (getVendorBusiness && getVendorBusiness.length > 0) {
      res.status(200).json({
        status: true,
        VendorBusinessRecords: getVendorBusiness,
      });
    } else {
      res.status(200).json({
        status: false,
        message: "NO Vendor Business Records found",
        VendorBusinessRecords: [],
      });
    }
  } catch (err) {
    next(err);
    res.status(200).json({
      status: false,
      profile: {},
      error: err.message,
    });
  }
};
exports.updateVendorSuperAdminStatusById = async (req, res, next) => {
  let transaction;
  try {
    const {
      CommissionRate,
      EffectiveStartDate,
      EffectiveEndDate,
      AdminNote,
      SubCategoryNote,
      SubCategoryID,
    } = req.body;
    transaction = await connection.transaction();
    console.log(req.params.id);
    let checkIfVendorExists = await connection.query(
      `select * from vendor WHERE VendorID="${req.params.id}" `,
      {
        type: QueryTypes.SELECT,
        transaction,
      }
    );
    if (checkIfVendorExists && checkIfVendorExists.length > 0) {
      //!below this
      const VendorID = req.params.id;
      let LastUpdate = new Date().toISOString().slice(0, 19).replace("T", " ");
      let addVendorComissionRateQuery = `insert into vendorcommissionrate (VendorID,CommissionRate,EffectiveStartDate ,EffectiveEndDate, LastUpdate, AdminNote)`;
      addVendorComissionRateQuery += ` values (?,?,?,?,?,?) `;
      addVendorComissionRateQuery += ` ON DUPLICATE KEY UPDATE CommissionRate="${CommissionRate}",LastUpdate=VALUES(LastUpdate)`;
      let addVendorComissionRate = await connection.query(
        addVendorComissionRateQuery,
        {
          replacements: [
            VendorID,
            CommissionRate,
            EffectiveStartDate,
            EffectiveEndDate,
            LastUpdate,
            AdminNote,
          ],
          transaction,
        }
      );
      if (addVendorComissionRate) {
        let addVendorSubCategoryQuery = `insert into vendorsubcategory (VendorID,SubCategoryID,LastUpdate ,AdminNote) VALUES`;
        for (let i = 0; i < SubCategoryID.length; i++) {
          if (i == SubCategoryID.length - 1) {
            addVendorSubCategoryQuery += `('${VendorID}', '${SubCategoryID[i]}','${LastUpdate}','${SubCategoryNote}')`;
          } else {
            addVendorSubCategoryQuery += `('${VendorID}', '${SubCategoryID[i]}','${LastUpdate}','${SubCategoryNote}'),`;
          }
        }
        addVendorSubCategoryQuery += ` ON DUPLICATE KEY UPDATE LastUpdate=VALUES(LastUpdate),AdminNote=VALUES(AdminNote)`;
        let addVendorSubCategory = await connection.query(
          addVendorSubCategoryQuery
        );
        if (addVendorSubCategory) {
          let updateVendroRoleQuery = await connection.query(
            `UPDATE profile Set Vendor="Y" WHERE UserID="${req.params.id}"`,
            {
              transaction,
            }
          );
          if (updateVendroRoleQuery) {
            let updateVendorStatusQuery = `UPDATE vendor SET ReviewedBySuperAdmin="Y" WHERE VendorID ="${req.params.id}" `;
            let updateVendorStatus = await connection.query(
              updateVendorStatusQuery,
              {
                transaction,
              }
            );
            let ReceiverID = req.params.id;
            if (updateVendorStatus) {
              let TypeID = "5";
              let CreaterID = "1";
              let Body = {
                body: "Your Buisness is Approved by Admin and Registered Successfully",
              };
              let Message = Body.body;
              let getDeviceIDQuery = ` SELECT DeviceID
        FROM profile 
        WHERE UserID=${ReceiverID}`;
              let getDeviceID = await connection.query(getDeviceIDQuery, {
                type: QueryTypes.SELECT,
                transaction,
              });

              if (getDeviceID && getDeviceID.length > 0) {
                let EmailAddress = getDeviceID[0].EmailAddress;
                sendEmail(EmailAddress, Message, TypeID);
                let sendNotification = await Notification(
                  TypeID,
                  Body,
                  CreaterID,
                  ReceiverID,
                  transaction
                );
                if (sendNotification) {
                  if (transaction) await transaction.commit(); //!final commit
                  res.status(200).json({
                    status: true,
                    message:
                      "Vendor Status Reviewed By Super Admin Updated Successfully",
                  });
                } else {
                  if (transaction) await transaction.rollback();
                  res.status(200).json({
                    status: false,
                    message: "Error while sending Notification to User ",
                  });
                }
              } else {
                if (transaction) await transaction.rollback();
                res.status(200).json({
                  status: false,
                  message: "Error while getting data from Database",
                });
              }
            } else {
              if (transaction) await transaction.rollback();
              res.status(200).json({
                status: false,
                message: "error while updating vendor status",
              });
            }
          } else {
            if (transaction) await transaction.rollback();
            res.status(200).json({
              status: false,
              message: "Error while updating role to vendor",
            });
          }
        } else {
          if (transaction) await transaction.rollback();
          res.status(200).json({
            status: false,
            message: "Error while adding data into Vendor SubCategory Table",
          });
        }
      } else {
        if (transaction) await transaction.rollback();
        res.status(200).json({
          status: false,
          message: "Error while adding data into Vendor Commission Rate",
        });
      }
    } else {
      if (transaction) await transaction.rollback();
      res.status(200).json({
        status: false,
        message: "NO Vendor Business found",
      });
    }
  } catch (err) {
    console.log(err.message);
    if (transaction) await transaction.rollback();
    next(err);
    res.status(200).json({
      status: false,
      error: err.message,
    });
  }
};
exports.getProductsReviewedByAdmin = async (req, res, next) => {
  try {
    let producstDetails = await connection.query(
      `SELECT * FROM product  WHERE ReviewedByAdmin="N" AND Active="N" `,
      {
        type: QueryTypes.SELECT,
      }
    );
    if (producstDetails && producstDetails.length > 0) {
      res.status(200).json({
        status: true,
        Products: producstDetails,
      });
    } else {
      res.status(200).json({
        status: true,
        message: "NO Products Records found",
        Products: [],
      });
    }
  } catch (err) {
    next(err);
    res.status(200).json({
      status: false,
      users: {},
      error: err.message,
    });
    console.log(err.message);
  }
};


//!by vendore

exports.vendoreRequestsReviewBySuperAdmin = async (req, res, next) => {
  try {
    let {
      limit,
      offset
    } = req.body;
    console.log("================================================>", req.body);
    limit = parseInt(limit);
    offset = parseInt(offset);
    offset = limit * offset;

    let getVendorBusinessQuery = `SELECT * FROM vendor WHERE ReviewedBySuperAdmin="N" ORDER BY VendorID DESC LIMIT ${limit} OFFSET ${offset}`;
    let getVendorBusiness = await connection.query(getVendorBusinessQuery, {
      type: QueryTypes.SELECT,
    });
    if (getVendorBusiness && getVendorBusiness.length > 0) {
      res.status(200).json({
        status: true,
        VendorBusinessRecords: getVendorBusiness,
      });
    } else {
      res.status(200).json({
        status: false,
        message: "NO Vendor Business Records found",
        VendorBusinessRecords: [],
      });
    }
  } catch (err) {
    next(err);
    res.status(200).json({
      status: false,
      profile: {},
      error: err.message,
    });
  }
};







exports.updateProductsReviewedByAdminStatus = async (req, res, next) => {
  try {
    let checkIfProductsExists = await connection.query(
      `select * from product WHERE ProductID="${req.params.id}" `,
      {
        type: QueryTypes.SELECT,
      }
    );
    if (checkIfProductsExists && checkIfProductsExists.length > 0) {
      let updateProductStatusQuery = `UPDATE product SET ReviewedByAdmin="Y" WHERE ProductID ="${req.params.id}" `;
      let updateProductStatus = await connection.query(
        updateProductStatusQuery,
        {
          type: QueryTypes.UPDATE,
        }
      );
      if (updateProductStatus) {
        res.status(200).json({
          status: true,
          message: "Product Status Reviewed By Admin Updated Successfully",
        });
      } else {
        res.status(200).json({
          status: false,
          message: "error while updating Product status",
          Products: [],
        });
      }
    } else {
      res.status(200).json({
        status: false,
        message: "NO Products found",
        Products: [],
      });
    }
  } catch (err) {
    next(err);
    res.status(200).json({
      status: false,
      profile: {},
      error: err.message,
    });
  }
};
exports.getProductsReviewedBySuperAdmin = async (req, res, next) => {
  try {
    let producstDetails = await connection.query(
      `SELECT * FROM product  WHERE ReviewedByAdmin="N" AND Active="N" ORDER BY ProductID DESC LIMIT 50`,
      {
        type: QueryTypes.SELECT,
      }
    );
    if (producstDetails && producstDetails.length > 0) {
      res.status(200).json({
        status: true,
        Products: producstDetails,
      });
    } else {
      res.status(200).json({
        status: true,
        message: "NO Products Records found",
        Products: [],
      });
    }
  } catch (err) {
    next(err);
    res.status(200).json({
      status: false,
      users: {},
      error: err.message,
    });
    console.log(err.message);
  }
};
exports.getProductsActiveStatus = async (req, res, next) => {
  try {
    let producstDetails = await connection.query(
      `SELECT * FROM product  WHERE ReviewedByAdmin="Y" AND Active="N" `,
      {
        type: QueryTypes.SELECT,
      }
    );
    if (producstDetails && producstDetails.length > 0) {
      res.status(200).json({
        status: true,
        Products: producstDetails,
      });
    } else {
      res.status(200).json({
        status: true,
        message: "NO Products Records found",
        Products: [],
      });
    }
  } catch (err) {
    next(err);
    res.status(200).json({
      status: false,
      users: {},
      error: err.message,
    });
    console.log(err.message);
  }
};
exports.updateProductsActiveStatusById = async (req, res, next) => {
  let transaction;
  try {
    transaction = await connection.transaction();
    let checkIfProductsExists = await connection.query(
      `select * from product WHERE ProductID="${req.params.id}" `,
      {
        type: QueryTypes.SELECT,
        transaction,
      }
    );
    if (checkIfProductsExists && checkIfProductsExists.length > 0) {
      let ReceiverID = checkIfProductsExists[0].VendorID;
      let Title = checkIfProductsExists[0].Title;
      let updateProductStatusQuery = `UPDATE product SET Active="Y" WHERE ProductID ="${req.params.id}" `;
      let updateProductStatus = await connection.query(
        updateProductStatusQuery,
        {
          transaction,
        }
      );
      if (updateProductStatus) {
        let TypeID = "5";
        let CreaterID = "1";
        let Body = {
          body: `Your Product ${Title} is approved by Admin and Registered Now`,
        };
        let Message = Body.body;
        let getDeviceIDQuery = ` SELECT DeviceID,EmailAddress
        FROM profile 
        WHERE UserID=${ReceiverID}`;
        let getDeviceID = await connection.query(getDeviceIDQuery, {
          type: QueryTypes.SELECT,
          transaction,
        });
        let DeviceID = getDeviceID[0].DeviceID;
        let EmailAddress = getDeviceID[0].EmailAddress;
        console.log(DeviceID);
        if (DeviceID == null || DeviceID == "NULL" || DeviceID == "null") {
          console.log("NULL CONDITION -----------------");
          sendEmail(EmailAddress, Message, TypeID);
          if (transaction) await transaction.commit();
          res.status(200).json({
            status: true,
            message: "Product Active Status Updated Successfully",
          });
        } else if (DeviceID && DeviceID.length > 0) {
          sendEmail(EmailAddress, Message, TypeID);
          let sendNotification = await Notification(
            TypeID,
            Body,
            CreaterID,
            ReceiverID,
            transaction
          );
          if (sendNotification) {
            if (transaction) await transaction.commit();
            res.status(200).json({
              status: true,
              message: "Product Active Status Updated Successfully",
            });
          } else {
            if (transaction) await transaction.rollback();
            res.status(200).json({
              status: false,
              message: "Error while sending Notification to User ",
            });
          }
        }
      } else {
        if (transaction) await transaction.rollback();
        res.status(200).json({
          status: false,
          message: "error while updating Product status",
        });
      }
    } else {
      if (transaction) await transaction.rollback();
      res.status(200).json({
        status: false,
        message: "NO Products found",
      });
    }
  } catch (err) {
    if (transaction) await transaction.rollback();
    next(err);
    res.status(200).json({
      status: false,
      error: err.message,
    });
  }
};
exports.getVendorCount = async (req, res, next) => {
  try {
    let vendorCount = await connection.query(
      `SELECT COUNT(*) AS vendors  FROM vendor   `,
      {
        type: QueryTypes.SELECT,
      }
    );
    if (vendorCount) {
      res.status(200).json({
        status: true,
        VendorCount: vendorCount[0].vendors,
      });
    } else {
      res.status(200).json({
        status: false,
        message: "something went wrong cannot show city",
      });
    }
  } catch (err) {
    next(err);
    res.status(200).json({
      status: false,
      profile: {},
      error: err.message,
    });
  }
};
exports.getProfileCount = async (req, res, next) => {
  try {
    let userCount = await connection.query(
      `SELECT COUNT(*) AS Users FROM profile  `,
      {
        type: QueryTypes.SELECT,
      }
    );
    if (userCount) {
      res.status(200).json({
        status: true,
        UserCount: userCount[0].Users,
      });
    } else {
      res.status(200).json({
        status: false,
        message: "something went wrong cannot show city",
      });
    }
  } catch (err) {
    next(err);
    res.status(200).json({
      status: false,
      profile: {},
      error: err.message,
    });
  }
};
exports.getOrdersDetailsForAdmin = async (req, res, next) => {
  try {
    const VendorID = req.UserID;
    let ReadyPickupForAdmin;
    let ReadyPickupForUser;
    let { sort, search, limit, offset, Status } = req.body;

    limit = parseInt(limit);
    offset = parseInt(offset);
    offset = limit * offset;

    if (Status == "0") {
      ReadyPickupForUser = "N";
      ReadyPickupForAdmin = "N";
    }
    if (Status == "1") {
      ReadyPickupForUser = "N";
      ReadyPickupForAdmin = "Y";
    }
    if (Status == "2") {
      ReadyPickupForUser = "Y";
      ReadyPickupForAdmin = "N";
    }
    let productCombinationPriceDetail = [];
    let ordersCount = await connection.query(
      `SELECT o.OrderNumber,o.ProductID
       FROM product p 
       JOIN processorder o ON o.ProductID=p.ProductID
       WHERE  o.ReadyPickupForUser="${ReadyPickupForUser}" AND o.ReadyPickupForAdmin="${ReadyPickupForAdmin}" AND p.VendorID="${VendorID}"  
       GROUP BY o.OrderNumber
 `,
      {
        type: QueryTypes.SELECT,
      }
    );
    console.log(ordersCount, "ordersCount")
    if (ordersCount && ordersCount.length > 0) {
      //   let getProcessOrderDetails = await connection.query(
      //     `SELECT o.* 
      //       FROM product p 
      //      INNER JOIN processorder o ON o.ProductID=p.ProductID
      //       WHERE  o.ReadyPickupForUser="${ReadyPickupForUser}" AND o.ReadyPickupForAdmin="${ReadyPickupForAdmin}" AND p.VendorID="${VendorID}"  
      //       ORDER BY o.ProcessOrderID ${sort}
      //  `,
      //     {
      //       type: QueryTypes.SELECT,
      //     }
      //   );
      let viewOrderListQuery =
        `SELECT p.ProductID,p.Title,m.TransactionID,s.OrderNumber,s.AllowStorePickup,s.AllowAdminPickup,s.ReadyPickupForUser,s.ReadyPickupForAdmin,s.OrderDate,m.PaymentStatus,p.Price AS BasePrice,p.VendorID,p.Currency,s.UserID,g.Small,g.Medium,g.Large,i.MainImage,s.ProductVariantCombinationDetail,
        s.DeliveryStatus,
      (SELECT COUNT(t.ProductID)
      from productreviewrating t WHERE t.ProductID = p.ProductID) AS REVIEW_COUNT,
      (SELECT AVG(t.Rating) from productreviewrating t WHERE t.ProductID = p.ProductID) AS  AVG_Rating
          FROM ((((((( product p      
          LEFT JOIN productvariantoption o ON o.ProductID IN( p.ProductID))
          LEFT JOIN productvariantoptionvalue v  ON  v.OptionID IN (o.OptionID))  
          LEFT JOIN productimage i  ON  i.OptionValueID IN (v.OptionValueID))
          LEFT JOIN imagegallery g  ON  g.ImageGalleryID IN (i.ImageGalleryID))
          LEFT JOIN productvariantcombination c  ON  c.OptionValueID IN (v.OptionValueID))
          INNER JOIN processorder s ON s.ProductID IN(c.ProductID))
          LEFT JOIN processpayment m ON m.OrderNumber IN(s.OrderNumber))
          WHERE i.MainImage='Y' AND p.VendorID="${VendorID}" AND s.ProcessStatus="Processing" AND s.ReadyPickupForUser="${ReadyPickupForUser}" AND s.ReadyPickupForAdmin="${ReadyPickupForAdmin}"  AND (s.OrderNumber LIKE "%${search}%"|| s.AllowStorePickup LIKE "%${search}%"|| s.AllowAdminPickup LIKE "%${search}%") 
          GROUP BY s.ProcessOrderID
          ORDER BY s.ProcessOrderID ${sort}
         limit ` +
        limit +
        " offset " +
        offset;
      let viewOrderList = await connection.query(viewOrderListQuery, {
        type: QueryTypes.SELECT,
      });
      console.log(viewOrderList, "viewOrderList--------------------------");
      let productCombinationDetail;
      if (viewOrderList && viewOrderList.length > 0) {
        for (let i = 0; i < viewOrderList.length; i++) {
          let ProductVariantCombinationDetail = [];
          ProductVariantCombinationDetail.push(
            viewOrderList[i].ProductVariantCombinationDetail
          );
          ProductVariantCombinationDetail = `(${ProductVariantCombinationDetail.join(
            ","
          )})`;
          productCombinationDetail = await connection.query(
            `SELECT p.ProductID,c.ProductVariantCombinationID,c.VendorStoreID,c.Price AS ProductCombinationPrice,c.AvailableInventory,o.OptionID,o.OptionName,v.OptionValue,v.OptionValueID
              FROM ((((product p
              LEFT JOIN productvariantoption o ON o.ProductID IN( p.ProductID))
              LEFT JOIN productvariantoptionvalue v  ON  v.OptionID IN (o.OptionID)) 
              LEFT JOIN productvariantcombination c  ON  c.OptionValueID IN (v.OptionValueID))
              LEFT JOIN processorder s ON s.ProductID IN(c.ProductID))
              WHERE  c.ProductVariantCombinationID IN ${ProductVariantCombinationDetail} AND p.VendorID="${VendorID}"
              GROUP BY c.OptionValueID
             `,
            {
              type: QueryTypes.SELECT,
            }
          );
          productCombinationPriceDetail.push(productCombinationDetail);
        }
        let orderName = [];
        let orderDate = [];
        let paymentStatus = [];
        let transactionID = [];
        let tempPC = productCombinationPriceDetail;
        let tempProd = viewOrderList;
        let tempArray = [];
        let allowStorePickup = [];
        let readyPickupForUser = [];
        let readyPickupForAdmin = [];
        let allowAdminPickup = [];
        let deliveryStatus = [];
        var arr = [];
        let tempAOrderDetails = [];
        for (let i = 0; i < tempProd.length; i++) {
          var obj = {
            ...tempProd[i],
          };
          obj["ProductCombinations"] = tempPC[i];
          tempArray.push(obj);
        }
        for (let i = 0; i < tempArray.length; i++) {
          if (!orderName.includes(tempArray[i].OrderNumber)) {
            orderName.push(tempArray[i].OrderNumber);
            orderDate.push(tempArray[i].OrderDate);
            paymentStatus.push(tempArray[i].PaymentStatus);
            transactionID.push(tempArray[i].TransactionID);
            allowStorePickup.push(tempArray[i].AllowStorePickup);
            readyPickupForUser.push(tempArray[i].ReadyPickupForUser);
            readyPickupForAdmin.push(tempArray[i].ReadyPickupForAdmin);
            allowAdminPickup.push(tempArray[i].AllowAdminPickup);
            deliveryStatus.push(tempArray[i].DeliveryStatus);
          }
        }
        for (let i = 0; i < orderName.length; i++) {
          var obj = {
            OrderNumber: orderName[i],
            OrderDate: orderDate[i],
            PaymentStatus: paymentStatus[i],
            TransactionID: transactionID[i],
            AllowStorePickup: allowStorePickup[i],
            ReadyPickupForUser: readyPickupForUser[i],
            ReadyPickupForAdmin: readyPickupForAdmin[i],
            AllowAdminPickup: allowAdminPickup[i],
            DeliveryStatus: deliveryStatus[i],
            ProductDetail: [],
          };
          for (let j = 0; j < tempArray.length; j++) {
            if (orderName[i] === tempArray[j].OrderNumber) {
              obj.ProductDetail.push(tempArray[j]);
            }
          }
          tempAOrderDetails.push(obj);
        }
        console.log(tempAOrderDetails, "tempAOrderDetails");
        if (productCombinationDetail && productCombinationDetail.length > 0) {
          res.status(200).json({
            status: true,
            total_records: ordersCount.length,
            orderDetails: tempAOrderDetails,
          });
        } else {
          res.status(200).json({
            status: true,
            total_records: ordersCount.length,
            orderDetails: [],
          });
        }
      } else {
        res.status(200).json({
          status: true,
          total_records: ordersCount.length,
          orderDetails: [],
        });
      }
    } else {
      res.status(200).json({
        status: true,
        total_records: ordersCount.length,
        orderDetails: [],
      });
    }
  } catch (err) {
    console.log(err.message);
    next(err);
    res.status(200).json({
      status: false,
      orderDetails: [],
    });
  }
};




//! getorderFor Admin


exports.getOrdersForAdmin = async (req, res, next) => {
  try {
    const VendorID = req.UserID;
    let ReadyPickupForAdmin;
    let ReadyPickupForUser;
    let { sort, search, limit, offset, Status } = req.body;

    limit = parseInt(limit);
    offset = parseInt(offset);
    offset = limit * offset;

    if (Status == "0") {
      ReadyPickupForUser = "N";
      ReadyPickupForAdmin = "N";
    }
    if (Status == "1") {
      ReadyPickupForUser = "N";
      ReadyPickupForAdmin = "Y";
    }
    if (Status == "2") {
      ReadyPickupForUser = "Y";
      ReadyPickupForAdmin = "N";
    }
    let productCombinationPriceDetail = [];
    let ordersCount = await connection.query(
      `SELECT o.OrderNumber,o.ProductID
       FROM product p 
       JOIN processorder o ON o.ProductID=p.ProductID
       WHERE  o.ReadyPickupForUser="${ReadyPickupForUser}" AND o.ReadyPickupForAdmin="${ReadyPickupForAdmin}"
       GROUP BY o.OrderNumber
 `,
      {
        type: QueryTypes.SELECT,
      }
    );
    console.log(ordersCount, "ordersCount")
    if (ordersCount && ordersCount.length > 0) {
      ;
      let viewOrderListQuery =
        `SELECT p.ProductID,p.Title,m.TransactionID,s.OrderNumber,s.AllowStorePickup,s.AllowAdminPickup,s.ReadyPickupForUser,s.ReadyPickupForAdmin,s.OrderDate,m.PaymentStatus,p.Price AS BasePrice,p.VendorID,p.Currency,s.UserID,g.Small,g.Medium,g.Large,i.MainImage,s.ProductVariantCombinationDetail,
        s.DeliveryStatus,
      (SELECT COUNT(t.ProductID)
      from productreviewrating t WHERE t.ProductID = p.ProductID) AS REVIEW_COUNT,
      (SELECT AVG(t.Rating) from productreviewrating t WHERE t.ProductID = p.ProductID) AS  AVG_Rating
          FROM ((((((( product p      
          LEFT JOIN productvariantoption o ON o.ProductID IN( p.ProductID))
          LEFT JOIN productvariantoptionvalue v  ON  v.OptionID IN (o.OptionID))  
          LEFT JOIN productimage i  ON  i.OptionValueID IN (v.OptionValueID))
          LEFT JOIN imagegallery g  ON  g.ImageGalleryID IN (i.ImageGalleryID))
          LEFT JOIN productvariantcombination c  ON  c.OptionValueID IN (v.OptionValueID))
          INNER JOIN processorder s ON s.ProductID IN(c.ProductID))
          LEFT JOIN processpayment m ON m.OrderNumber IN(s.OrderNumber))
          WHERE i.MainImage='Y' AND s.ProcessStatus="Processing" AND s.ReadyPickupForUser="${ReadyPickupForUser}" AND s.ReadyPickupForAdmin="${ReadyPickupForAdmin}"  AND (s.OrderNumber LIKE "%${search}%"|| s.AllowStorePickup LIKE "%${search}%"|| s.AllowAdminPickup LIKE "%${search}%") 
          GROUP BY s.ProcessOrderID
          ORDER BY s.ProcessOrderID ${sort}
         limit ` +
        limit +
        " offset " +
        offset;
      let viewOrderList = await connection.query(viewOrderListQuery, {
        type: QueryTypes.SELECT,
      });
      console.log(viewOrderList.ProductDetail, "viewOrderList--------------------------");

      let productCombinationDetail;
      if (viewOrderList && viewOrderList.length > 0) {
        for (let i = 0; i < viewOrderList.length; i++) {
          let ProductVariantCombinationDetail = [];
          ProductVariantCombinationDetail.push(
            viewOrderList[i].ProductVariantCombinationDetail
          );
          ProductVariantCombinationDetail = `(${ProductVariantCombinationDetail.join(
            ","
          )})`;
          productCombinationDetail = await connection.query(
            `SELECT p.ProductID,c.ProductVariantCombinationID,c.VendorStoreID,c.Price AS ProductCombinationPrice,c.AvailableInventory,o.OptionID,o.OptionName,v.OptionValue,v.OptionValueID
              FROM ((((product p
              LEFT JOIN productvariantoption o ON o.ProductID IN( p.ProductID))
              LEFT JOIN productvariantoptionvalue v  ON  v.OptionID IN (o.OptionID)) 
              LEFT JOIN productvariantcombination c  ON  c.OptionValueID IN (v.OptionValueID))
              LEFT JOIN processorder s ON s.ProductID IN(c.ProductID))
              WHERE  c.ProductVariantCombinationID IN ${ProductVariantCombinationDetail}
              GROUP BY c.OptionValueID
             `,
            {
              type: QueryTypes.SELECT,
            }
          );
          productCombinationPriceDetail.push(productCombinationDetail);
        }
        let orderName = [];
        let orderDate = [];
        let paymentStatus = [];
        let transactionID = [];
        let tempPC = productCombinationPriceDetail;
        let tempProd = viewOrderList;
        let tempArray = [];
        let allowStorePickup = [];
        let readyPickupForUser = [];
        let readyPickupForAdmin = [];
        let allowAdminPickup = [];
        let deliveryStatus = [];
        var arr = [];
        let tempAOrderDetails = [];
        for (let i = 0; i < tempProd.length; i++) {
          var obj = {
            ...tempProd[i],
          };
          obj["ProductCombinations"] = tempPC[i];
          tempArray.push(obj);
        }
        for (let i = 0; i < tempArray.length; i++) {
          if (!orderName.includes(tempArray[i].OrderNumber)) {
            orderName.push(tempArray[i].OrderNumber);
            orderDate.push(tempArray[i].OrderDate);
            paymentStatus.push(tempArray[i].PaymentStatus);
            transactionID.push(tempArray[i].TransactionID);
            allowStorePickup.push(tempArray[i].AllowStorePickup);
            readyPickupForUser.push(tempArray[i].ReadyPickupForUser);
            readyPickupForAdmin.push(tempArray[i].ReadyPickupForAdmin);
            allowAdminPickup.push(tempArray[i].AllowAdminPickup);
            deliveryStatus.push(tempArray[i].DeliveryStatus);
          }
        }
        for (let i = 0; i < orderName.length; i++) {
          var obj = {
            OrderNumber: orderName[i],
            OrderDate: orderDate[i],
            PaymentStatus: paymentStatus[i],
            TransactionID: transactionID[i],
            AllowStorePickup: allowStorePickup[i],
            ReadyPickupForUser: readyPickupForUser[i],
            ReadyPickupForAdmin: readyPickupForAdmin[i],
            AllowAdminPickup: allowAdminPickup[i],
            DeliveryStatus: deliveryStatus[i],
            ProductDetail: [],
          };
          for (let j = 0; j < tempArray.length; j++) {
            if (orderName[i] === tempArray[j].OrderNumber) {
              obj.ProductDetail.push(tempArray[j]);
            }
          }
          tempAOrderDetails.push(obj);
        }
        console.log(tempAOrderDetails['ProductDetail'], "tempAOrderDetails");
        if (productCombinationDetail && productCombinationDetail.length > 0) {
          res.status(200).json({
            status: true,
            total_records: ordersCount.length,
            orderDetails: tempAOrderDetails,
          });
        } else {
          res.status(200).json({
            status: true,
            total_records: ordersCount.length,
            orderDetails: [],
          });
        }
      } else {
        res.status(200).json({
          status: true,
          total_records: ordersCount.length,
          orderDetails: [],
        });
      }
    } else {
      res.status(200).json({
        status: true,
        total_records: ordersCount.length,
        orderDetails: [],
      });
    }
  } catch (err) {
    console.log(err.message);
    next(err);
    res.status(200).json({
      status: false,
      orderDetails: [],
    });
  }
};





exports.changePickupStatuses = async (req, res, next) => {
  try {
    const { Status } = req.body;
    let LastUpdate = new Date().toISOString().slice(0, 19).replace("T", " ");

    let OrderNumber = req.params.id;
    let VendorID = req.UserID;
    let getUserID = await connection.query(
      `SELECT o.*
       FROM processorder o
       LEFT JOIN product p ON p.ProductID=o.ProductID
       WHERE o.OrderNumber="${OrderNumber}" AND p.VendorID="${VendorID}"  `,
      {
        type: QueryTypes.SELECT,
      }
    );
    let ReceiverID = getUserID[0].UserID;
    let VendorStoreID = getUserID[0].VendorStoreID;
    if (Status == "0") {
      let TypeID = "6";
      let CreaterID = req.UserID;
      let Body = "Your order is ready for Pickup";
      let NotificationStatus = "unread";
      const obj = {
        OrderNumber,
        Body,
      };

      if (getUserID) {
        let changePickupStatus = await connection.query(
          `UPDATE processorder SET ReadyPickupForUser="Y",LastUpdate="${LastUpdate}" 
           WHERE OrderNumber="${OrderNumber}"  AND VendorStoreID="${VendorStoreID}"`
        );
        if (changePickupStatus) {
          let addOrderNotification = await connection.query(
            `insert into notification (TypeID,Body,CreaterID,ReceiverID,LastUpdate,NotificationStatus )   values ("${TypeID}",'${JSON.stringify(
              obj
            )}',"${CreaterID}","${ReceiverID}","${LastUpdate}","${NotificationStatus}" )`
          );
          if (addOrderNotification) {
            res.status(200).json({
              status: true,
              message:
                "ReadyPickupForUser Status is updated Sucessfully && Order Notifcation is generated",
            });
          } else {
            res.status(200).json({
              status: false,
              message: "error while generating order notification",
            });
          }
        } else {
          res.status(200).json({
            status: false,
            message: "something went wrong cannot update status",
          });
        }
      } else {
        res.status(200).json({
          status: false,
          message: "something went wrong cannot get UserID ",
        });
      }
    }
    if (Status == "1") {
      let changePickupStatus = await connection.query(
        `UPDATE processorder SET ReadyPickupForAdmin="Y" WHERE OrderNumber="${OrderNumber}" AND VendorStoreID="${VendorStoreID}" `
      );
      if (changePickupStatus) {
        res.status(200).json({
          status: true,
          message: "ReadyPickupForAdmin Status is updated Sucessfully",
        });
      } else {
        res.status(200).json({
          status: false,
          message: "something went wrong cannot update status",
        });
      }
    }
  } catch (err) {
    next(err);
    res.status(200).json({
      status: false,
      error: err.message,
    });
  }
};
exports.getOrdersDetailsForSuperAdmin = async (req, res, next) => {
  try {
    const { sort, search, limit, offset } = req.body;
    let productCombinationPriceDetail = [];
    /*
    SELECT COUNT(*) AS total_records
            FROM 
            (SELECT COUNT (OrderNumber)  FROM processorder WHERE ProcessStatus="${status}" AND DeliveryDriverID="${DeliveryDriverID}"
             GROUP BY OrderNumber)total_record
    */
    let ordersCount = await connection.query(
      `SELECT COUNT(OrderNumber) as total_records FROM processorder WHERE ReadyPickupForAdmin="Y" `,
      {
        type: QueryTypes.SELECT,
      }
    );
    if (ordersCount && ordersCount.length > 0) {
      let getProcessOrderDetails = await connection.query(
        `SELECT * from processorder s WHERE  s.ReadyPickupForAdmin="Y" AND (s.OrderNumber LIKE "%${search}%"|| s.AllowStorePickup LIKE "%${search}%"|| s.AllowAdminPickup LIKE "%${search}%") 
     `,
        {
          type: QueryTypes.SELECT,
        }
      );
      let viewOrderListQuery =
        `SELECT p.ProductID,p.Title,m.TransactionID,s.OrderNumber,s.AllowStorePickup,s.AllowAdminPickup,s.ReadyPickupForUser,s.ReadyPickupForAdmin,s.OrderDate,m.PaymentStatus,p.Price AS BasePrice,p.Currency,s.UserID,g.Small,g.Medium,g.Large,i.MainImage,
      (SELECT COUNT(t.ProductID)
      from productreviewrating t WHERE t.ProductID = p.ProductID) AS REVIEW_COUNT,
      (SELECT AVG(t.Rating) from productreviewrating t WHERE t.ProductID = p.ProductID) AS  AVG_Rating
          FROM ((((((( product p      
          LEFT JOIN productvariantoption o ON o.ProductID IN( p.ProductID))
          LEFT JOIN productvariantoptionvalue v  ON  v.OptionID IN (o.OptionID))  
          LEFT JOIN productimage i  ON  i.OptionValueID IN (v.OptionValueID))
          LEFT JOIN imagegallery g  ON  g.ImageGalleryID IN (i.ImageGalleryID))
          LEFT JOIN productvariantcombination c  ON  c.OptionValueID IN (v.OptionValueID))
          INNER JOIN processorder s ON s.ProductID IN(c.ProductID))
          LEFT JOIN processpayment m ON m.OrderNumber IN(s.OrderNumber))
          WHERE i.MainImage='Y' AND s.ReadyPickupForAdmin="Y" AND (s.OrderNumber LIKE "%${search}%"|| s.AllowStorePickup LIKE "%${search}%"|| s.AllowAdminPickup LIKE "%${search}%") 
          GROUP BY s.ProcessOrderID
          ORDER by s.ProcessOrderID ${sort} limit ` +
        limit +
        " offset " +
        offset;
      let viewOrderList = await connection.query(viewOrderListQuery, {
        type: QueryTypes.SELECT,
      });

      let productCombinationDetail;
      if (viewOrderList && viewOrderList.length > 0) {
        for (let i = 0; i < getProcessOrderDetails.length; i++) {
          let ProductVariantCombinationDetail = [];
          ProductVariantCombinationDetail.push(
            getProcessOrderDetails[i].ProductVariantCombinationDetail
          );
          ProductVariantCombinationDetail = `(${ProductVariantCombinationDetail.join(
            ","
          )})`;
          productCombinationDetail = await connection.query(
            `SELECT p.ProductID,c.ProductVariantCombinationID,c.VendorStoreID,c.Price AS ProductCombinationPrice,c.AvailableInventory,o.OptionID,o.OptionName,v.OptionValue,v.OptionValueID
              FROM ((((product p
              LEFT JOIN productvariantoption o ON o.ProductID IN( p.ProductID))
              LEFT JOIN productvariantoptionvalue v  ON  v.OptionID IN (o.OptionID)) 
              LEFT JOIN productvariantcombination c  ON  c.OptionValueID IN (v.OptionValueID))
              LEFT JOIN processorder s ON s.ProductID IN(c.ProductID))
              WHERE  c.ProductVariantCombinationID IN ${ProductVariantCombinationDetail}
              GROUP BY c.OptionValueID
             `,
            {
              type: QueryTypes.SELECT,
            }
          );
          productCombinationPriceDetail.push(productCombinationDetail);
        }
        let orderName = [];
        let orderDate = [];
        let paymentStatus = [];
        let transactionID = [];
        let tempPC = productCombinationPriceDetail;
        let tempProd = viewOrderList;
        let tempArray = [];
        let allowStorePickup = [];
        let readyPickupForUser = [];
        let readyPickupForAdmin = [];
        let allowAdminPickup = [];
        var arr = [];
        let tempAOrderDetails = [];
        for (let i = 0; i < tempProd.length; i++) {
          var obj = {
            ...tempProd[i],
          };
          obj["ProductCombinations"] = tempPC[i];
          tempArray.push(obj);
        }
        for (let i = 0; i < tempArray.length; i++) {
          if (!orderName.includes(tempArray[i].OrderNumber)) {
            orderName.push(tempArray[i].OrderNumber);
            orderDate.push(tempArray[i].OrderDate);
            paymentStatus.push(tempArray[i].PaymentStatus);
            transactionID.push(tempArray[i].TransactionID);
            allowStorePickup.push(tempArray[i].AllowStorePickup);
            readyPickupForUser.push(tempArray[i].ReadyPickupForUser);
            readyPickupForAdmin.push(tempArray[i].ReadyPickupForAdmin);
            allowAdminPickup.push(tempArray[i].AllowAdminPickup);
          }
        }
        for (let i = 0; i < orderName.length; i++) {
          var obj = {
            OrderNumber: orderName[i],
            OrderDate: orderDate[i],
            PaymentStatus: paymentStatus[i],
            TransactionID: transactionID[i],
            AllowStorePickup: allowStorePickup[i],
            ReadyPickupForUser: readyPickupForUser[i],
            ReadyPickupForAdmin: readyPickupForAdmin[i],
            AllowAdminPickup: allowAdminPickup[i],
            ProductDetail: [],
          };
          for (let j = 0; j < tempArray.length; j++) {
            if (orderName[i] === tempArray[j].OrderNumber) {
              obj.ProductDetail.push(tempArray[j]);
            }
          }
          tempAOrderDetails.push(obj);
        }
        if (productCombinationDetail && productCombinationDetail.length > 0) {
          res.status(200).json({
            status: true,
            total_records: ordersCount[0].total_records,
            orderDetails: tempAOrderDetails,
          });
        } else {
          res.status(200).json({
            status: true,
            total_records: ordersCount[0].total_records,
            orderDetails: [],
          });
        }
      } else {
        res.status(200).json({
          status: true,
          total_records: ordersCount[0].total_records,
          orderDetails: [],
        });
      }
    } else {
      res.status(200).json({
        status: true,
        total_records: ordersCount[0].total_records,
        orderDetails: [],
      });
    }
  } catch (err) {
    console.log(err.message);
    next(err);
    res.status(200).json({
      status: false,
      orderDetails: [],
    });
  }
};


exports.getOrdersDetailsByOrderID = async (req, res, next) => {
  try {
  
    let OrderNumber = req.params.id;
    let productCombinationPriceDetail = [];
    let getProcessOrderDetails = await connection.query(
      `SELECT * from processorder WHERE OrderNumber="${OrderNumber}"
     `,
      {
        type: QueryTypes.SELECT,
      }
    );

    let viewOrderListQuery = `SELECT p.ProductID,p.Title,m.TransactionID,s.OrderNumber,pg.GatewayName,s.AllowStorePickup,s.AllowAdminPickup,s.ReadyPickupForUser,s.ReadyPickupForAdmin,s.OrderDate,m.PaymentStatus,p.Price AS BasePrice,s.Quantity,p.Currency,s.UserID,g.Small,g.Medium,g.Large,i.MainImage,s.StatusHistory,s.ProcessStatus,s.DeliveryDriverID,s.ConsignmentId,m.OrderTotal,m.ShippingHandling,p.FreeProductReturn,e.StoreName,e.Address1 AS StoreAddress,e.StorePhone,s.DeliveryStatus,s.TrackingNumber,s.ConsignmentId,s.ItemsPrice,s.ItemsEstimatedTax,s.ItemsShippingHandling,s.ProcessOrderID,s.DeliveryDriverID,m.GatewayID,s.VendorPaymentStatus,s.CourierID,s.PaymentType,s.VendorStoreID,s.ReturnReason,s.ReturnOrder,e.StorePhone,s.ReturnOrderStatus,if(s.ReturnOrder="Y",s.OrderNumber,0) AS isReturnOrder,s.UspsOrderStatus,s.DeliveryDate,m.Name AS PaymentName,s.RefundStatus,s.DhlTrackingUrl,s.DhlTrackingNumber,e.VendorID,m.EstimatedTax,
      (SELECT COUNT(t.ProductID)
      from productreviewrating t WHERE t.ProductID = p.ProductID) AS REVIEW_COUNT,
      (SELECT AVG(t.Rating) from productreviewrating t WHERE t.ProductID = p.ProductID) AS  AVG_Rating
          FROM ((((((((( product p      
          LEFT JOIN productvariantoption o ON o.ProductID IN( p.ProductID))
          LEFT JOIN productvariantoptionvalue v  ON  v.OptionID IN (o.OptionID))  
          LEFT JOIN productimage i  ON  i.OptionValueID IN (v.OptionValueID))
          LEFT JOIN imagegallery g  ON  g.ImageGalleryID IN (i.ImageGalleryID))
          LEFT JOIN productvariantcombination c  ON  c.OptionValueID IN (v.OptionValueID))
          INNER JOIN processorder s ON s.ProductID IN(c.ProductID))
          LEFT JOIN processpayment m ON m.OrderNumber IN(s.OrderNumber))
          LEFT JOIN paymentgateway pg ON pg.GatewayID IN(m.GatewayID))
          LEFT JOIN vendorstore e ON (e.VendorStoreID=s.VendorStoreID))
          WHERE i.MainImage='Y' AND s.OrderNumber="${OrderNumber}"
          GROUP BY s.ProcessOrderID `;
    let viewOrderList = await connection.query(viewOrderListQuery, {
      type: QueryTypes.SELECT,
    });

    let productCombinationDetail;
    if (viewOrderList && viewOrderList.length > 0) {
      for (let i = 0; i < getProcessOrderDetails.length; i++) {
        let ProductVariantCombinationDetail = [];
        ProductVariantCombinationDetail.push(
          getProcessOrderDetails[i].ProductVariantCombinationDetail
        );
        ProductVariantCombinationDetail = `(${ProductVariantCombinationDetail.join(
          ","
        )})`;
        productCombinationDetail = await connection.query(
          `SELECT p.ProductID,c.ProductVariantCombinationID,c.VendorStoreID,c.Price AS ProductCombinationPrice,c.AvailableInventory,o.OptionID,o.OptionName,v.OptionValue,v.OptionValueID,p.Currency
              FROM ((((product p
              LEFT JOIN productvariantoption o ON o.ProductID IN( p.ProductID))
              LEFT JOIN productvariantoptionvalue v  ON  v.OptionID IN (o.OptionID)) 
              LEFT JOIN productvariantcombination c  ON  c.OptionValueID IN (v.OptionValueID))
              LEFT JOIN processorder s ON s.ProductID IN(c.ProductID))
              WHERE  c.ProductVariantCombinationID IN ${ProductVariantCombinationDetail}
              GROUP BY c.OptionValueID
             `,
          {
            type: QueryTypes.SELECT,
          }
        );
        productCombinationPriceDetail.push(productCombinationDetail);
      }
      let orderName = [];
      let orderDate = [];
      let paymentStatus = [];
      let transactionID = [];
      let tempPC = productCombinationPriceDetail;
      let tempProd = viewOrderList;
      let tempArray = [];
      let allowStorePickup = [];
      let readyPickupForUser = [];
      let readyPickupForAdmin = [];
      let allowAdminPickup = [];
      let statusHistory = [];
      let processStatus = [];
      let orderTotal = [];
      let shippingHandling = [];
      let addressName = [];
      let tempAOrderDetails = [];
      let dhlTrackingUrl = [];
      let productTitle = [];
      let storeAddressDetails = [];
      let trackingNumber = [];
      let deliveryStatus = [];
      let uspsOrderStatus = [];
      let consignmentId = [];
      let paymentType = [];
      let storeName = [];
      let storePhone = [];
      let returnOrdersArray = [];
      let deliveryDate = [];
      let paymentName = [];
      let dhlTrackingNumber = [];
      let estimatedTax = [];
      for (let i = 0; i < tempProd.length; i++) {
        //!cuurency conversion
        var obj = {
          ...tempProd[i],
        };
        let variantsLength = tempPC[i].length;
        obj["ProductCombinations"] = tempPC[i];
        tempArray.push(obj);
      }
      for (let i = 0; i < tempArray.length; i++) {
        if (!orderName.includes(tempArray[i].OrderNumber)) {
          orderName.push(tempArray[i].OrderNumber);
          orderDate.push(tempArray[i].OrderDate);
          paymentStatus.push(tempArray[i].PaymentStatus);
          transactionID.push(tempArray[i].TransactionID);
          allowStorePickup.push(tempArray[i].AllowStorePickup);
          readyPickupForUser.push(tempArray[i].ReadyPickupForUser);
          readyPickupForAdmin.push(tempArray[i].ReadyPickupForAdmin);
          allowAdminPickup.push(tempArray[i].AllowAdminPickup);
          statusHistory.push(tempArray[i].StatusHistory);
          processStatus.push(tempArray[i].ProcessStatus);
          orderTotal.push(tempArray[i].OrderTotal);
          shippingHandling.push(tempArray[i].ShippingHandling);
          trackingNumber.push(tempArray[i].TrackingNumber);
          deliveryStatus.push(tempArray[i].DeliveryStatus);
          uspsOrderStatus.push(tempArray[i].UspsOrderStatus);
          consignmentId.push(tempArray[i].ConsignmentId);
          paymentType.push(tempArray[i].PaymentType);
          deliveryDate.push(tempArray[i].DeliveryDate);
          paymentName.push(tempArray[i].PaymentName);
          dhlTrackingUrl.push(tempArray[i].DhlTrackingUrl);
          dhlTrackingNumber.push(tempArray[i].DhlTrackingNumber);
          estimatedTax.push(tempArray[i].EstimatedTax);
        }
        returnOrdersArray.push(tempArray[i].isReturnOrder);
        if (!addressName.includes(tempArray[i].StoreAddress)) {
          addressName.push(tempArray[i].StoreAddress);
          storeName.push(tempArray[i].StoreName);
          storePhone.push(tempArray[i].StorePhone);
        }
      }
      //! for STOREPICKUP LOCATION ADDRESS DETAILS FOR DELIVERY DRIVER INCASE IF NEEDED IN FUTURE
      for (let i = 0; i < addressName.length; i++) {
        let obj = {
          StoreName: storeName[i],
          StorePickupAddress: addressName[i],
          StorePhoneNumber: storePhone[i],
          ProductIDs: [],
        };
        for (let j = 0; j < tempArray.length; j++) {
          console.log(tempArray[j].StoreAddress);
          console.log(addressName[i]);
          if (addressName[i] === tempArray[j].StoreAddress) {
            obj.ProductIDs.push(tempArray[j].ProductID);
          }
        }
        storeAddressDetails.push(obj);
      }
      for (let i = 0; i < orderName.length; i++) {
        if (returnOrdersArray.includes(orderName[i])) {
          var obj = {
            OrderNumber: orderName[i],
            OrderDate: orderDate[i],
            PaymentStatus: paymentStatus[i],
            TransactionID: transactionID[i],
            AllowStorePickup: allowStorePickup[i],
            ReadyPickupForUser: readyPickupForUser[i],
            ReadyPickupForAdmin: readyPickupForAdmin[i],
            AllowAdminPickup: allowAdminPickup[i],
            StatusHistory: statusHistory[i],
            ProcessStatus: processStatus[i],
            OrderTotal: orderTotal[i],
            ShippingHandling: shippingHandling[i],
            TrackingNumber: trackingNumber[i],
            DeliveryStatus: deliveryStatus[i],
            UspsOrderStatus: uspsOrderStatus[i],
            ConsignmentId: consignmentId[i],
            PaymentType: paymentType[i],
            DeliveryDate: deliveryDate[i],
            PaymentName: paymentName[i],
            DhlTrackingUrl: dhlTrackingUrl[i],
            DhlTrackingNumber: dhlTrackingNumber[i],
            EstimatedTax: estimatedTax[i],

            ReturnOrder: true,
            ProductDetail: [],
          };
        } else {
          var obj = {
            OrderNumber: orderName[i],
            OrderDate: orderDate[i],
            PaymentStatus: paymentStatus[i],
            TransactionID: transactionID[i],
            AllowStorePickup: allowStorePickup[i],
            ReadyPickupForUser: readyPickupForUser[i],
            ReadyPickupForAdmin: readyPickupForAdmin[i],
            AllowAdminPickup: allowAdminPickup[i],
            StatusHistory: statusHistory[i],
            ProcessStatus: processStatus[i],
            OrderTotal: orderTotal[i],
            ShippingHandling: shippingHandling[i],
            TrackingNumber: trackingNumber[i],
            DeliveryStatus: deliveryStatus[i],
            UspsOrderStatus: uspsOrderStatus[i],
            ConsignmentId: consignmentId[i],
            PaymentType: paymentType[i],
            DeliveryDate: deliveryDate[i],
            PaymentName: paymentName[i],
            DhlTrackingUrl: dhlTrackingUrl[i],
            DhlTrackingNumber: dhlTrackingNumber[i],
            EstimatedTax: estimatedTax[i],
            ReturnOrder: false,
            ProductDetail: [],
          };
        }
        for (let j = 0; j < tempArray.length; j++) {
          if (orderName[i] === tempArray[j].OrderNumber) {
            obj.ProductDetail.push(tempArray[j]);
          }
        }
        tempAOrderDetails.push(obj);
      }
      if (productCombinationDetail && productCombinationDetail.length > 0) {
        // orderShippingDetail = await connection.query(
        //   `SELECT o.ID AS DeliveryAddressID,o.OrderNumber,o.Name AS DeliveryName,o.PhoneNumber AS DeliveryPhoneNumber,o.Address1 AS DeliveryAddress1,o.Address2 AS DeliveryAddress2,o.City AS DeliveryCity,o.State AS DeliveryState,o.CountryID AS DeliveryCountryID,c.Country AS DeliveryCountry,o.ZipCode AS DeliveryZipCode,o.DesireDate,o.UserNote AS DeliveryUserNote
        //     FROM processorder p
        //     INNER JOIN orderdeliveryaddress o ON o.OrderNumber = p.OrderNumber
        //     INNER JOIN country c ON c.CountryID = o.CountryID
        //     WHERE  p.OrderNumber = "${OrderNumber}"
        //    `,
        //   {
        //     type: QueryTypes.SELECT,
        //   }
        // );
        let orderShippingDetail = await connection.query(
          `SELECT o.ID AS DeliveryAddressID,o.OrderNumber,o.Name AS DeliveryName,o.PhoneNumber AS DeliveryPhoneNumber,o.Address1 AS DeliveryAddress1,o.Address2 AS DeliveryAddress2,o.City AS DeliveryCity,o.State AS DeliveryState,o.CountryID AS DeliveryCountryID,c.Country AS DeliveryCountry,o.ZipCode AS DeliveryZipCode,o.DesireDate,o.UserNote AS DeliveryUserNote,s.*
            FROM processorder p 
            INNER JOIN orderdeliveryaddress o ON o.OrderNumber = p.OrderNumber
            INNER JOIN country c ON c.CountryID = o.CountryID
            LEFT JOIN vendorstore s ON s.VendorStoreID = p.VendorStoreID
            WHERE  p.OrderNumber = "${OrderNumber}" 
           `,
          {
            type: QueryTypes.SELECT,
          }
        );
        let deliveryDriverDetails = null;
        if (orderShippingDetail && orderShippingDetail.length > 0) {
          deliveryDriverDetailsQuery = await connection.query(
            `SELECT d.*,p.*
            FROM processorder o
            INNER JOIN deliverydriver d ON d.DeliveryDriverID = o.DeliveryDriverID
            INNER JOIN profile p ON p.UserID = d.DeliveryDriverID
            WHERE o.OrderNumber = "${OrderNumber}"
           `,
            {
              type: QueryTypes.SELECT,
            }
          );
          if (
            deliveryDriverDetailsQuery &&
            deliveryDriverDetailsQuery.length > 0
          ) {
            deliveryDriverDetails = deliveryDriverDetailsQuery[0];
          }
          let userDetails = await connection.query(
            `SELECT po.OrderNumber,p.UserID,p.UserName,p.ProfilePic
              FROM processorder po 
              INNER JOIN profile p ON p.UserID=po.UserID
              WHERE  po.OrderNumber = "${OrderNumber}" 
             `,
            {
              type: QueryTypes.SELECT,
            }
          );
          if (userDetails && userDetails.length > 0) {
            let getStorePickupDetails = await connection.query(
              `SELECT v.CompanyName,s.*
                 FROM processorder o
                 INNER JOIN vendorstore s ON s.VendorStoreID = o.VendorStoreID
                 INNER JOIN vendor v ON v.VendorID = s.VendorID
                 WHERE o.OrderNumber = "${OrderNumber}" AND o.AllowStorePickup="Y"
             `,
              {
                type: QueryTypes.SELECT,
              }
            );
            if (getStorePickupDetails && getStorePickupDetails.length > 0) {
              res.status(200).json({
                status: true,
                orderDetails: tempAOrderDetails[0],
                storeAddressDetails,
                orderShippingDetail: orderShippingDetail[0],
                userDetails: userDetails[0],
                deliveryDriverDetails,
                getStorePickupDetails: getStorePickupDetails[0],
              });
            } else {
              res.status(200).json({
                status: true,
                orderDetails: tempAOrderDetails[0],
                storeAddressDetails,
                orderShippingDetail: orderShippingDetail[0],
                userDetails: userDetails[0],
                deliveryDriverDetails,
                getStorePickupDetails: null,
              });
            }
          } else {
            res.status(200).json({
              status: false,
              orderDetails: tempAOrderDetails[0],
              orderShippingDetail: orderShippingDetail[0],
              deliveryDriverDetails,
              userDetails: null,
              getStorePickupDetails: null,
            });
          }
        } else {
          res.status(200).json({
            status: false,
            orderDetails: null,
            orderShippingDetail: null,
            deliveryDriverDetails: null,
            getStorePickupDetails: null,
          });
        }
      } else {
        res.status(200).json({
          status: false,
          orderDetails: null,
          orderShippingDetail: null,
          deliveryDriverDetails: null,
          getStorePickupDetails: null,
        });
      }
    } else {
      res.status(200).json({
        status: false,
        orderDetails: null,
        orderShippingDetail: null,
        deliveryDriverDetails: null,
        getStorePickupDetails: null,
      });
    }
  } catch (err) {
    console.log(err);
    next(err);
    res.status(200).json({
      status: false,
      orderDetails: null,
      orderShippingDetail: null,
      deliveryDriverDetails: null,
      getStorePickupDetails: null,
    });
  }
};

//chnaged 12/29/2023 removed region
// exports.getOrdersDetailsByOrderID = async (req, res, next) => {
//   try {
//     let Region = req.region;
//     const currencyRate = req.currency_rate;
//     let OrderNumber = req.params.id;
//     let productCombinationPriceDetail = [];
//     let getProcessOrderDetails = await connection.query(
//       `SELECT * from processorder WHERE OrderNumber="${OrderNumber}"
//      `,
//       {
//         type: QueryTypes.SELECT,
//       }
//     );

//     let viewOrderListQuery = `SELECT p.ProductID,p.Title,m.TransactionID,s.OrderNumber,pg.GatewayName,s.AllowStorePickup,s.AllowAdminPickup,s.ReadyPickupForUser,s.ReadyPickupForAdmin,s.OrderDate,m.PaymentStatus,p.Price AS BasePrice,s.Quantity,p.Currency,s.UserID,g.Small,g.Medium,g.Large,i.MainImage,s.StatusHistory,s.ProcessStatus,s.DeliveryDriverID,s.ConsignmentId,m.OrderTotal,m.ShippingHandling,p.FreeProductReturn,e.StoreName,e.Address1 AS StoreAddress,e.StorePhone,s.DeliveryStatus,s.TrackingNumber,s.ConsignmentId,s.ItemsPrice,s.ItemsEstimatedTax,s.ItemsShippingHandling,s.ProcessOrderID,s.DeliveryDriverID,m.GatewayID,s.VendorPaymentStatus,s.CourierID,s.PaymentType,s.VendorStoreID,s.ReturnReason,s.ReturnOrder,e.StorePhone,s.ReturnOrderStatus,if(s.ReturnOrder="Y",s.OrderNumber,0) AS isReturnOrder,s.UspsOrderStatus,s.DeliveryDate,m.Name AS PaymentName,s.RefundStatus,s.DhlTrackingUrl,s.DhlTrackingNumber,e.VendorID,m.EstimatedTax,
//       (SELECT COUNT(t.ProductID)
//       from productreviewrating t WHERE t.ProductID = p.ProductID) AS REVIEW_COUNT,
//       (SELECT AVG(t.Rating) from productreviewrating t WHERE t.ProductID = p.ProductID) AS  AVG_Rating
//           FROM ((((((((( product p      
//           LEFT JOIN productvariantoption o ON o.ProductID IN( p.ProductID))
//           LEFT JOIN productvariantoptionvalue v  ON  v.OptionID IN (o.OptionID))  
//           LEFT JOIN productimage i  ON  i.OptionValueID IN (v.OptionValueID))
//           LEFT JOIN imagegallery g  ON  g.ImageGalleryID IN (i.ImageGalleryID))
//           LEFT JOIN productvariantcombination c  ON  c.OptionValueID IN (v.OptionValueID))
//           INNER JOIN processorder s ON s.ProductID IN(c.ProductID))
//           LEFT JOIN processpayment m ON m.OrderNumber IN(s.OrderNumber))
//           LEFT JOIN paymentgateway pg ON pg.GatewayID IN(m.GatewayID))
//           LEFT JOIN vendorstore e ON (e.VendorStoreID=s.VendorStoreID))
//           WHERE i.MainImage='Y' AND s.OrderNumber="${OrderNumber}"
//           GROUP BY s.ProcessOrderID `;
//     let viewOrderList = await connection.query(viewOrderListQuery, {
//       type: QueryTypes.SELECT,
//     });

//     let productCombinationDetail;
//     if (viewOrderList && viewOrderList.length > 0) {
//       for (let i = 0; i < getProcessOrderDetails.length; i++) {
//         let ProductVariantCombinationDetail = [];
//         ProductVariantCombinationDetail.push(
//           getProcessOrderDetails[i].ProductVariantCombinationDetail
//         );
//         ProductVariantCombinationDetail = `(${ProductVariantCombinationDetail.join(
//           ","
//         )})`;
//         productCombinationDetail = await connection.query(
//           `SELECT p.ProductID,c.ProductVariantCombinationID,c.VendorStoreID,c.Price AS ProductCombinationPrice,c.AvailableInventory,o.OptionID,o.OptionName,v.OptionValue,v.OptionValueID,p.Currency
//               FROM ((((product p
//               LEFT JOIN productvariantoption o ON o.ProductID IN( p.ProductID))
//               LEFT JOIN productvariantoptionvalue v  ON  v.OptionID IN (o.OptionID)) 
//               LEFT JOIN productvariantcombination c  ON  c.OptionValueID IN (v.OptionValueID))
//               LEFT JOIN processorder s ON s.ProductID IN(c.ProductID))
//               WHERE  c.ProductVariantCombinationID IN ${ProductVariantCombinationDetail}
//               GROUP BY c.OptionValueID
//              `,
//           {
//             type: QueryTypes.SELECT,
//           }
//         );
//         productCombinationPriceDetail.push(productCombinationDetail);
//       }
//       let orderName = [];
//       let orderDate = [];
//       let paymentStatus = [];
//       let transactionID = [];
//       let tempPC = productCombinationPriceDetail;
//       let tempProd = viewOrderList;
//       let tempArray = [];
//       let allowStorePickup = [];
//       let readyPickupForUser = [];
//       let readyPickupForAdmin = [];
//       let allowAdminPickup = [];
//       let statusHistory = [];
//       let processStatus = [];
//       let orderTotal = [];
//       let shippingHandling = [];
//       let addressName = [];
//       let tempAOrderDetails = [];
//       let dhlTrackingUrl = [];
//       let productTitle = [];
//       let storeAddressDetails = [];
//       let trackingNumber = [];
//       let deliveryStatus = [];
//       let uspsOrderStatus = [];
//       let consignmentId = [];
//       let paymentType = [];
//       let storeName = [];
//       let storePhone = [];
//       let returnOrdersArray = [];
//       let deliveryDate = [];
//       let paymentName = [];
//       let dhlTrackingNumber = [];
//       let estimatedTax = [];
//       for (let i = 0; i < tempProd.length; i++) {
//         //!cuurency conversion
//         if (Region == "Bangladesh") {
//           let Price = tempProd[i].BasePrice;
//           if (tempProd[i].Currency == "$") {
//             tempProd[i]["Currency"] = "BDT";
//             tempProd[i]["BasePrice"] = parseFloat(currencyRate * Price).toFixed(
//               2
//             );
//           }
//         } else if (Region == "USA") {
//           let Price = tempProd[i].BasePrice;
//           if (tempProd[i].Currency == "BDT") {
//             tempProd[i]["Currency"] = "$";
//             tempProd[i]["BasePrice"] = parseFloat(currencyRate * Price).toFixed(
//               2
//             );
//           }
//         } else {
//           let Price = tempProd[i].BasePrice;
//           if (tempProd[i].Currency == "BDT") {
//             tempProd[i]["Currency"] = "$";
//             tempProd[i]["BasePrice"] = parseFloat(currencyRate * Price).toFixed(
//               2
//             );
//           }
//         }
//         var obj = {
//           ...tempProd[i],
//         };
//         let variantsLength = tempPC[i].length;
//         if (Region == "Bangladesh") {
//           for (let j = 0; j < variantsLength; j++) {
//             let Price = tempPC[i][j].ProductCombinationPrice;
//             if (tempPC[i][j].Currency == "$") {
//               tempPC[i][j]["Currency"] = "BDT";
//               tempPC[i][j]["ProductCombinationPrice"] = parseFloat(
//                 currencyRate * Price
//               ).toFixed(2);
//             }
//           }
//         } else if (Region == "USA") {
//           for (let j = 0; j < variantsLength; j++) {
//             let Price = tempPC[i][j].ProductCombinationPrice;
//             if (tempPC[i][j].Currency == "BDT") {
//               tempPC[i][j]["Currency"] = "$";
//               tempPC[i][j]["ProductCombinationPrice"] = parseFloat(
//                 currencyRate * Price
//               ).toFixed(2);
//             }
//           }
//         } else {
//           for (let j = 0; j < variantsLength; j++) {
//             let Price = tempPC[i][j].ProductCombinationPrice;
//             tempPC[i][j]["Currency"] = "$";
//             tempPC[i][j]["ProductCombinationPrice"] = parseFloat(
//               currencyRate * Price
//             ).toFixed(2);
//           }
//         }
//         obj["ProductCombinations"] = tempPC[i];
//         tempArray.push(obj);
//       }
//       for (let i = 0; i < tempArray.length; i++) {
//         if (!orderName.includes(tempArray[i].OrderNumber)) {
//           orderName.push(tempArray[i].OrderNumber);
//           orderDate.push(tempArray[i].OrderDate);
//           paymentStatus.push(tempArray[i].PaymentStatus);
//           transactionID.push(tempArray[i].TransactionID);
//           allowStorePickup.push(tempArray[i].AllowStorePickup);
//           readyPickupForUser.push(tempArray[i].ReadyPickupForUser);
//           readyPickupForAdmin.push(tempArray[i].ReadyPickupForAdmin);
//           allowAdminPickup.push(tempArray[i].AllowAdminPickup);
//           statusHistory.push(tempArray[i].StatusHistory);
//           processStatus.push(tempArray[i].ProcessStatus);
//           orderTotal.push(tempArray[i].OrderTotal);
//           shippingHandling.push(tempArray[i].ShippingHandling);
//           trackingNumber.push(tempArray[i].TrackingNumber);
//           deliveryStatus.push(tempArray[i].DeliveryStatus);
//           uspsOrderStatus.push(tempArray[i].UspsOrderStatus);
//           consignmentId.push(tempArray[i].ConsignmentId);
//           paymentType.push(tempArray[i].PaymentType);
//           deliveryDate.push(tempArray[i].DeliveryDate);
//           paymentName.push(tempArray[i].PaymentName);
//           dhlTrackingUrl.push(tempArray[i].DhlTrackingUrl);
//           dhlTrackingNumber.push(tempArray[i].DhlTrackingNumber);
//           estimatedTax.push(tempArray[i].EstimatedTax);
//         }
//         returnOrdersArray.push(tempArray[i].isReturnOrder);
//         if (!addressName.includes(tempArray[i].StoreAddress)) {
//           addressName.push(tempArray[i].StoreAddress);
//           storeName.push(tempArray[i].StoreName);
//           storePhone.push(tempArray[i].StorePhone);
//         }
//       }
//       //! for STOREPICKUP LOCATION ADDRESS DETAILS FOR DELIVERY DRIVER INCASE IF NEEDED IN FUTURE
//       for (let i = 0; i < addressName.length; i++) {
//         let obj = {
//           StoreName: storeName[i],
//           StorePickupAddress: addressName[i],
//           StorePhoneNumber: storePhone[i],
//           ProductIDs: [],
//         };
//         for (let j = 0; j < tempArray.length; j++) {
//           console.log(tempArray[j].StoreAddress);
//           console.log(addressName[i]);
//           if (addressName[i] === tempArray[j].StoreAddress) {
//             obj.ProductIDs.push(tempArray[j].ProductID);
//           }
//         }
//         storeAddressDetails.push(obj);
//       }
//       for (let i = 0; i < orderName.length; i++) {
//         if (returnOrdersArray.includes(orderName[i])) {
//           var obj = {
//             OrderNumber: orderName[i],
//             OrderDate: orderDate[i],
//             PaymentStatus: paymentStatus[i],
//             TransactionID: transactionID[i],
//             AllowStorePickup: allowStorePickup[i],
//             ReadyPickupForUser: readyPickupForUser[i],
//             ReadyPickupForAdmin: readyPickupForAdmin[i],
//             AllowAdminPickup: allowAdminPickup[i],
//             StatusHistory: statusHistory[i],
//             ProcessStatus: processStatus[i],
//             OrderTotal: orderTotal[i],
//             ShippingHandling: shippingHandling[i],
//             TrackingNumber: trackingNumber[i],
//             DeliveryStatus: deliveryStatus[i],
//             UspsOrderStatus: uspsOrderStatus[i],
//             ConsignmentId: consignmentId[i],
//             PaymentType: paymentType[i],
//             DeliveryDate: deliveryDate[i],
//             PaymentName: paymentName[i],
//             DhlTrackingUrl: dhlTrackingUrl[i],
//             DhlTrackingNumber: dhlTrackingNumber[i],
//             EstimatedTax: estimatedTax[i],

//             ReturnOrder: true,
//             ProductDetail: [],
//           };
//         } else {
//           var obj = {
//             OrderNumber: orderName[i],
//             OrderDate: orderDate[i],
//             PaymentStatus: paymentStatus[i],
//             TransactionID: transactionID[i],
//             AllowStorePickup: allowStorePickup[i],
//             ReadyPickupForUser: readyPickupForUser[i],
//             ReadyPickupForAdmin: readyPickupForAdmin[i],
//             AllowAdminPickup: allowAdminPickup[i],
//             StatusHistory: statusHistory[i],
//             ProcessStatus: processStatus[i],
//             OrderTotal: orderTotal[i],
//             ShippingHandling: shippingHandling[i],
//             TrackingNumber: trackingNumber[i],
//             DeliveryStatus: deliveryStatus[i],
//             UspsOrderStatus: uspsOrderStatus[i],
//             ConsignmentId: consignmentId[i],
//             PaymentType: paymentType[i],
//             DeliveryDate: deliveryDate[i],
//             PaymentName: paymentName[i],
//             DhlTrackingUrl: dhlTrackingUrl[i],
//             DhlTrackingNumber: dhlTrackingNumber[i],
//             EstimatedTax: estimatedTax[i],
//             ReturnOrder: false,
//             ProductDetail: [],
//           };
//         }
//         for (let j = 0; j < tempArray.length; j++) {
//           if (orderName[i] === tempArray[j].OrderNumber) {
//             obj.ProductDetail.push(tempArray[j]);
//           }
//         }
//         tempAOrderDetails.push(obj);
//       }
//       if (productCombinationDetail && productCombinationDetail.length > 0) {
//         // orderShippingDetail = await connection.query(
//         //   `SELECT o.ID AS DeliveryAddressID,o.OrderNumber,o.Name AS DeliveryName,o.PhoneNumber AS DeliveryPhoneNumber,o.Address1 AS DeliveryAddress1,o.Address2 AS DeliveryAddress2,o.City AS DeliveryCity,o.State AS DeliveryState,o.CountryID AS DeliveryCountryID,c.Country AS DeliveryCountry,o.ZipCode AS DeliveryZipCode,o.DesireDate,o.UserNote AS DeliveryUserNote
//         //     FROM processorder p
//         //     INNER JOIN orderdeliveryaddress o ON o.OrderNumber = p.OrderNumber
//         //     INNER JOIN country c ON c.CountryID = o.CountryID
//         //     WHERE  p.OrderNumber = "${OrderNumber}"
//         //    `,
//         //   {
//         //     type: QueryTypes.SELECT,
//         //   }
//         // );
//         let orderShippingDetail = await connection.query(
//           `SELECT o.ID AS DeliveryAddressID,o.OrderNumber,o.Name AS DeliveryName,o.PhoneNumber AS DeliveryPhoneNumber,o.Address1 AS DeliveryAddress1,o.Address2 AS DeliveryAddress2,o.City AS DeliveryCity,o.State AS DeliveryState,o.CountryID AS DeliveryCountryID,c.Country AS DeliveryCountry,o.ZipCode AS DeliveryZipCode,o.DesireDate,o.UserNote AS DeliveryUserNote,s.*
//             FROM processorder p 
//             INNER JOIN orderdeliveryaddress o ON o.OrderNumber = p.OrderNumber
//             INNER JOIN country c ON c.CountryID = o.CountryID
//             LEFT JOIN vendorstore s ON s.VendorStoreID = p.VendorStoreID
//             WHERE  p.OrderNumber = "${OrderNumber}" 
//            `,
//           {
//             type: QueryTypes.SELECT,
//           }
//         );
//         let deliveryDriverDetails = null;
//         if (orderShippingDetail && orderShippingDetail.length > 0) {
//           deliveryDriverDetailsQuery = await connection.query(
//             `SELECT d.*,p.*
//             FROM processorder o
//             INNER JOIN deliverydriver d ON d.DeliveryDriverID = o.DeliveryDriverID
//             INNER JOIN profile p ON p.UserID = d.DeliveryDriverID
//             WHERE o.OrderNumber = "${OrderNumber}"
//            `,
//             {
//               type: QueryTypes.SELECT,
//             }
//           );
//           if (
//             deliveryDriverDetailsQuery &&
//             deliveryDriverDetailsQuery.length > 0
//           ) {
//             deliveryDriverDetails = deliveryDriverDetailsQuery[0];
//           }
//           let userDetails = await connection.query(
//             `SELECT po.OrderNumber,p.UserID,p.UserName,p.ProfilePic
//               FROM processorder po 
//               INNER JOIN profile p ON p.UserID=po.UserID
//               WHERE  po.OrderNumber = "${OrderNumber}" 
//              `,
//             {
//               type: QueryTypes.SELECT,
//             }
//           );
//           if (userDetails && userDetails.length > 0) {
//             let getStorePickupDetails = await connection.query(
//               `SELECT v.CompanyName,s.*
//                  FROM processorder o
//                  INNER JOIN vendorstore s ON s.VendorStoreID = o.VendorStoreID
//                  INNER JOIN vendor v ON v.VendorID = s.VendorID
//                  WHERE o.OrderNumber = "${OrderNumber}" AND o.AllowStorePickup="Y"
//              `,
//               {
//                 type: QueryTypes.SELECT,
//               }
//             );
//             if (getStorePickupDetails && getStorePickupDetails.length > 0) {
//               res.status(200).json({
//                 status: true,
//                 orderDetails: tempAOrderDetails[0],
//                 storeAddressDetails,
//                 orderShippingDetail: orderShippingDetail[0],
//                 userDetails: userDetails[0],
//                 deliveryDriverDetails,
//                 getStorePickupDetails: getStorePickupDetails[0],
//               });
//             } else {
//               res.status(200).json({
//                 status: true,
//                 orderDetails: tempAOrderDetails[0],
//                 storeAddressDetails,
//                 orderShippingDetail: orderShippingDetail[0],
//                 userDetails: userDetails[0],
//                 deliveryDriverDetails,
//                 getStorePickupDetails: null,
//               });
//             }
//           } else {
//             res.status(200).json({
//               status: false,
//               orderDetails: tempAOrderDetails[0],
//               orderShippingDetail: orderShippingDetail[0],
//               deliveryDriverDetails,
//               userDetails: null,
//               getStorePickupDetails: null,
//             });
//           }
//         } else {
//           res.status(200).json({
//             status: false,
//             orderDetails: null,
//             orderShippingDetail: null,
//             deliveryDriverDetails: null,
//             getStorePickupDetails: null,
//           });
//         }
//       } else {
//         res.status(200).json({
//           status: false,
//           orderDetails: null,
//           orderShippingDetail: null,
//           deliveryDriverDetails: null,
//           getStorePickupDetails: null,
//         });
//       }
//     } else {
//       res.status(200).json({
//         status: false,
//         orderDetails: null,
//         orderShippingDetail: null,
//         deliveryDriverDetails: null,
//         getStorePickupDetails: null,
//       });
//     }
//   } catch (err) {
//     console.log(err);
//     next(err);
//     res.status(200).json({
//       status: false,
//       orderDetails: null,
//       orderShippingDetail: null,
//       deliveryDriverDetails: null,
//       getStorePickupDetails: null,
//     });
//   }
// };


exports.getOrderDetailsByVendorID = async (req, res, next) => {
  try {
    let OrderNumber = req.params.id;
    let VendorID = req.UserID

    if (req.body.UserID) {
      VendorID = req.body.UserID;
    }


    console.log("+++++++++++++++++++++++++++++++++++", req.UserID, req.body.UserID);
    let productCombinationPriceDetail = [];
    let getProcessOrderDetails = await connection.query(
      `SELECT o.*,v.CountryID AS VendorCountry
         FROM processorder o
         LEFT JOIN product p ON o.ProductID= p.ProductID
         LEFT JOIN vendor v ON v.VendorID= p.VendorID
         WHERE o.OrderNumber="${OrderNumber}" AND p.VendorID="${VendorID}"
     `,
      {
        type: QueryTypes.SELECT,
      }
    );
    let viewOrderListQuery = `SELECT p.ProductID,p.Title,m.TransactionID,s.OrderNumber,s.AllowStorePickup,s.AllowAdminPickup,s.ReadyPickupForUser,s.ReadyPickupForAdmin,s.OrderDate,m.PaymentStatus,p.Price AS BasePrice,s.Quantity,p.Currency,s.UserID,g.Small,g.Medium,g.Large,i.MainImage,s.StatusHistory,s.ProcessStatus,s.DeliveryDriverID,s.ConsignmentId,r.CountryID AS VendorCountry,s.DeliveryStatus,s.TrackingNumber,m.EstimatedTax,m.ShippingHandling,m.OrderTotal,
      (SELECT COUNT(t.ProductID)
      from productreviewrating t WHERE t.ProductID = p.ProductID) AS REVIEW_COUNT,
      (SELECT AVG(t.Rating) from productreviewrating t WHERE t.ProductID = p.ProductID) AS  AVG_Rating
          FROM (((((((( product p      
          LEFT JOIN productvariantoption o ON o.ProductID IN( p.ProductID))
          LEFT JOIN productvariantoptionvalue v  ON  v.OptionID IN (o.OptionID))  
          LEFT JOIN productimage i  ON  i.OptionValueID IN (v.OptionValueID))
          LEFT JOIN imagegallery g  ON  g.ImageGalleryID IN (i.ImageGalleryID))
          LEFT JOIN productvariantcombination c  ON  c.OptionValueID IN (v.OptionValueID))
          INNER JOIN processorder s ON s.ProductID IN(c.ProductID))
           LEFT JOIN vendor r ON (r.VendorID= p.VendorID))
          LEFT JOIN processpayment m ON m.OrderNumber IN(s.OrderNumber))
          WHERE i.MainImage='Y' AND s.OrderNumber="${OrderNumber}" AND p.VendorID="${VendorID}"
          GROUP BY s.ProcessOrderID `;
    let viewOrderList = await connection.query(viewOrderListQuery, {
      type: QueryTypes.SELECT,
    });
    let productCombinationDetail;
    if (viewOrderList && viewOrderList.length > 0) {
      for (let i = 0; i < getProcessOrderDetails.length; i++) {
        let ProductVariantCombinationDetail = [];
        ProductVariantCombinationDetail.push(
          getProcessOrderDetails[i].ProductVariantCombinationDetail
        );
        ProductVariantCombinationDetail = `(${ProductVariantCombinationDetail.join(
          ","
        )})`;
        productCombinationDetail = await connection.query(
          `SELECT p.ProductID,c.ProductVariantCombinationID,c.VendorStoreID,c.Price AS ProductCombinationPrice,c.AvailableInventory,o.OptionID,o.OptionName,v.OptionValue,v.OptionValueID,p.Currency
              FROM ((((product p
              LEFT JOIN productvariantoption o ON o.ProductID IN( p.ProductID))
              LEFT JOIN productvariantoptionvalue v  ON  v.OptionID IN (o.OptionID)) 
              LEFT JOIN productvariantcombination c  ON  c.OptionValueID IN (v.OptionValueID))
              LEFT JOIN processorder s ON s.ProductID IN(c.ProductID))
              WHERE  c.ProductVariantCombinationID IN ${ProductVariantCombinationDetail} 
              GROUP BY c.OptionValueID
             `,
          {
            type: QueryTypes.SELECT,
          }
        );
        productCombinationPriceDetail.push(productCombinationDetail);
      }
      let VendorCountry = getProcessOrderDetails[0].VendorCountry;
      let currencyRate;
      let getCurrencyRates = await connection.query(
        "SELECT * FROM currencyrate",
        {
          type: QueryTypes.SELECT,
        }
      );
      if (VendorCountry == "16") {
        currencyRate = getCurrencyRates[1].Rate;
      } else {
        currencyRate = getCurrencyRates[0].Rate;
      }
      let orderName = [];
      let orderDate = [];
      let paymentStatus = [];
      let transactionID = [];
      let tempPC = productCombinationPriceDetail;
      let tempProd = viewOrderList;
      let tempArray = [];
      let allowStorePickup = [];
      let readyPickupForUser = [];
      let readyPickupForAdmin = [];
      let allowAdminPickup = [];
      let statusHistory = [];
      let processStatus = [];
      let trackingNumber = [];
      let estimatedTax = [];
      let shippingHandling = [];
      let orderTotal = [];
      var arr = [];
      let tempAOrderDetails = [];
      let deliveryStatus = [];
      for (let i = 0; i < tempProd.length; i++) {
        //!cuurency conversion
        if (VendorCountry == "16") {
          let Price = tempProd[i].BasePrice;
          if (tempProd[i].Currency == "$") {
            tempProd[i]["Currency"] = "BDT";
            tempProd[i]["BasePrice"] = parseFloat(currencyRate * Price).toFixed(
              2
            );
          }
        } else if (VendorCountry == "226") {
          let Price = tempProd[i].BasePrice;
          if (tempProd[i].Currency == "BDT") {
            tempProd[i]["Currency"] = "$";
            tempProd[i]["BasePrice"] = parseFloat(currencyRate * Price).toFixed(
              2
            );
          }
        } else {
          let Price = tempProd[i].BasePrice;
          tempProd[i]["Currency"] = "$";
          tempProd[i]["BasePrice"] = parseFloat(currencyRate * Price).toFixed(
            2
          );
        }
        var obj = {
          ...tempProd[i],
        };
        let variantsLength = tempPC[i].length;
        if (VendorCountry == "16") {
          for (let j = 0; j < variantsLength; j++) {
            let Price = tempPC[i][j].ProductCombinationPrice;
            if (tempPC[i][j].Currency == "$") {
              tempPC[i][j]["Currency"] = "BDT";
              tempPC[i][j]["ProductCombinationPrice"] = parseFloat(
                currencyRate * Price
              ).toFixed(2);
            }
          }
        } else if (VendorCountry == "226") {
          for (let j = 0; j < variantsLength; j++) {
            let Price = tempPC[i][j].ProductCombinationPrice;
            if (tempPC[i][j].Currency == "BDT") {
              tempPC[i][j]["Currency"] = "$";
              tempPC[i][j]["ProductCombinationPrice"] = parseFloat(
                currencyRate * Price
              ).toFixed(2);
            }
          }
        } else {
          for (let j = 0; j < variantsLength; j++) {
            let Price = tempPC[i][j].ProductCombinationPrice;
            tempPC[i][j]["Currency"] = "$";
            tempPC[i][j]["ProductCombinationPrice"] = parseFloat(
              currencyRate * Price
            ).toFixed(2);
          }
        }
        obj["ProductCombinations"] = tempPC[i];
        tempArray.push(obj);
      }
      for (let i = 0; i < tempArray.length; i++) {
        if (!orderName.includes(tempArray[i].OrderNumber)) {
          orderName.push(tempArray[i].OrderNumber);
          orderDate.push(tempArray[i].OrderDate);
          paymentStatus.push(tempArray[i].PaymentStatus);
          transactionID.push(tempArray[i].TransactionID);
          allowStorePickup.push(tempArray[i].AllowStorePickup);
          readyPickupForUser.push(tempArray[i].ReadyPickupForUser);
          readyPickupForAdmin.push(tempArray[i].ReadyPickupForAdmin);
          allowAdminPickup.push(tempArray[i].AllowAdminPickup);
          statusHistory.push(tempArray[i].StatusHistory);
          processStatus.push(tempArray[i].ProcessStatus);
          deliveryStatus.push(tempArray[i].DeliveryStatus);
          trackingNumber.push(tempArray[i].TrackingNumber);
          estimatedTax.push(tempArray[i].EstimatedTax);
          shippingHandling.push(tempArray[i].ShippingHandling);
          orderTotal.push(tempArray[i].OrderTotal);
        }
      }
      for (let i = 0; i < orderName.length; i++) {
        var obj = {
          OrderNumber: orderName[i],
          OrderDate: orderDate[i],
          PaymentStatus: paymentStatus[i],
          TransactionID: transactionID[i],
          AllowStorePickup: allowStorePickup[i],
          ReadyPickupForUser: readyPickupForUser[i],
          ReadyPickupForAdmin: readyPickupForAdmin[i],
          AllowAdminPickup: allowAdminPickup[i],
          StatusHistory: statusHistory[i],
          ProcessStatus: processStatus[i],
          DeliveryStatus: deliveryStatus[i],
          TrackingNumber: trackingNumber[i],
          EstimatedTax: estimatedTax[i],
          ShippingHandling: shippingHandling[i],
          OrderTotal: orderTotal[i],
          ProductDetail: [],
        };
        for (let j = 0; j < tempArray.length; j++) {
          if (orderName[i] === tempArray[j].OrderNumber) {
            obj.ProductDetail.push(tempArray[j]);
          }
        }
        tempAOrderDetails.push(obj);
      }
      if (productCombinationDetail && productCombinationDetail.length > 0) {
        orderShippingDetail = await connection.query(
          `SELECT o.ID AS DeliveryAddressID,o.OrderNumber,o.Name AS DeliveryName,o.PhoneNumber AS DeliveryPhoneNumber,o.Address1 AS DeliveryAddress1,o.Address2 AS DeliveryAddress2,o.City AS DeliveryCity,o.State AS DeliveryState,o.CountryID AS DeliveryCountryID,c.Country AS DeliveryCountry,o.ZipCode AS DeliveryZipCode,o.DesireDate,o.UserNote AS DeliveryUserNote,s.*,v.CompanyName,v.Address1 AS VendorAddress,v.BusinessPhone
            FROM processorder p 
            INNER JOIN orderdeliveryaddress o ON o.OrderNumber = p.OrderNumber
            INNER JOIN country c ON c.CountryID = o.CountryID
            LEFT JOIN vendorstore s ON s.VendorStoreID = p.VendorStoreID
	    LEFT JOIN vendor v ON v.VendorID = s.VendorID
            WHERE  p.OrderNumber = "${OrderNumber}" AND s.VendorID="${VendorID}"
           `,
          {
            type: QueryTypes.SELECT,
          }
        );
        let deliveryDriverDetails = null;
        if (orderShippingDetail && orderShippingDetail.length > 0) {
          deliveryDriverDetailsQuery = await connection.query(
            `SELECT d.*,p.*
            FROM processorder o
            INNER JOIN deliverydriver d ON d.DeliveryDriverID = o.DeliveryDriverID
            INNER JOIN profile p ON p.UserID = d.DeliveryDriverID
            WHERE o.OrderNumber = "${OrderNumber}"
           `,
            {
              type: QueryTypes.SELECT,
            }
          );
          if (
            deliveryDriverDetailsQuery &&
            deliveryDriverDetailsQuery.length > 0
          ) {
            deliveryDriverDetails = deliveryDriverDetailsQuery[0];
          }
          let getStorePickupDetails = await connection.query(
            `SELECT v.CompanyName,s.*
               FROM processorder o
               INNER JOIN vendorstore s ON s.VendorStoreID = o.VendorStoreID
               INNER JOIN vendor v ON v.VendorID = s.VendorID
               WHERE o.OrderNumber = "${OrderNumber}" AND o.AllowStorePickup="Y"
           `,
            {
              type: QueryTypes.SELECT,
            }
          );
          if (getStorePickupDetails && getStorePickupDetails.length > 0) {
            res.status(200).json({
              status: true,
              orderDetails: tempAOrderDetails[0],
              orderShippingDetail: orderShippingDetail[0],
              deliveryDriverDetails,
              getStorePickupDetails: getStorePickupDetails[0],
            });
          } else {
            res.status(200).json({
              status: true,
              orderDetails: tempAOrderDetails[0],
              orderShippingDetail: orderShippingDetail[0],
              deliveryDriverDetails,
              getStorePickupDetails: null,
            });
          }
        } else {
          res.status(200).json({
            status: false,
            orderDetails: null,
            orderShippingDetail: null,
            deliveryDriverDetails: null,
            getStorePickupDetails: null,
          });
        }
      } else {
        res.status(200).json({
          status: false,
          orderDetails: null,
          orderShippingDetail: null,
          deliveryDriverDetails: null,
          getStorePickupDetails: null,
        });
      }
    } else {
      res.status(200).json({
        status: false,
        orderDetails: null,
        orderShippingDetail: null,
        deliveryDriverDetails: null,
        getStorePickupDetails: null,
      });
    }
  } catch (err) {
    console.log(err.message);
    next(err);
    res.status(200).json({
      status: false,
      orderDetails: null,
      orderShippingDetail: null,
      deliveryDriverDetails: null,
      getStorePickupDetails: null,
    });
  }
};


exports.getOrderDetailsForInvoice = async (req, res, next) => {
  try {
    const Region = req.region;
    let OrderNumber = req.params.id;
    let productCombinationPriceDetail = [];
    let getProcessOrderDetails = await connection.query(
      `SELECT o.*,v.CountryID AS VendorCountry
         FROM processorder o
         LEFT JOIN product p ON o.ProductID= p.ProductID
         LEFT JOIN vendor v ON v.VendorID= p.VendorID
         WHERE o.OrderNumber="${OrderNumber}" 
     `,
      {
        type: QueryTypes.SELECT,
      }
    );
    let viewOrderListQuery = `SELECT p.ProductID,p.Title,m.TransactionID,s.OrderNumber,s.AllowStorePickup,s.AllowAdminPickup,s.ReadyPickupForUser,s.ReadyPickupForAdmin,s.OrderDate,m.PaymentStatus,p.Price AS BasePrice,s.Quantity,p.Currency,s.UserID,g.Small,g.Medium,g.Large,i.MainImage,s.StatusHistory,s.ProcessStatus,s.DeliveryDriverID,s.ConsignmentId,r.CountryID AS VendorCountry,s.DeliveryStatus,s.TrackingNumber,m.OrderTotal,m.ShippingHandling,m.EstimatedTax,
      (SELECT COUNT(t.ProductID)
      from productreviewrating t WHERE t.ProductID = p.ProductID) AS REVIEW_COUNT,
      (SELECT AVG(t.Rating) from productreviewrating t WHERE t.ProductID = p.ProductID) AS  AVG_Rating
          FROM (((((((( product p      
          LEFT JOIN productvariantoption o ON o.ProductID IN( p.ProductID))
          LEFT JOIN productvariantoptionvalue v  ON  v.OptionID IN (o.OptionID))  
          LEFT JOIN productimage i  ON  i.OptionValueID IN (v.OptionValueID))
          LEFT JOIN imagegallery g  ON  g.ImageGalleryID IN (i.ImageGalleryID))
          LEFT JOIN productvariantcombination c  ON  c.OptionValueID IN (v.OptionValueID))
          INNER JOIN processorder s ON s.ProductID IN(c.ProductID))
           LEFT JOIN vendor r ON (r.VendorID= p.VendorID))
          LEFT JOIN processpayment m ON m.OrderNumber IN(s.OrderNumber))
          WHERE i.MainImage='Y' AND s.OrderNumber="${OrderNumber}" 
          GROUP BY s.ProcessOrderID `;
    let viewOrderList = await connection.query(viewOrderListQuery, {
      type: QueryTypes.SELECT,
    });
    let productCombinationDetail;
    if (viewOrderList && viewOrderList.length > 0) {
      for (let i = 0; i < getProcessOrderDetails.length; i++) {
        let ProductVariantCombinationDetail = [];
        ProductVariantCombinationDetail.push(
          getProcessOrderDetails[i].ProductVariantCombinationDetail
        );
        ProductVariantCombinationDetail = `(${ProductVariantCombinationDetail.join(
          ","
        )})`;
        productCombinationDetail = await connection.query(
          `SELECT p.ProductID,c.ProductVariantCombinationID,c.VendorStoreID,c.Price AS ProductCombinationPrice,c.AvailableInventory,o.OptionID,o.OptionName,v.OptionValue,v.OptionValueID,p.Currency
              FROM ((((product p
              LEFT JOIN productvariantoption o ON o.ProductID IN( p.ProductID))
              LEFT JOIN productvariantoptionvalue v  ON  v.OptionID IN (o.OptionID)) 
              LEFT JOIN productvariantcombination c  ON  c.OptionValueID IN (v.OptionValueID))
              LEFT JOIN processorder s ON s.ProductID IN(c.ProductID))
              WHERE  c.ProductVariantCombinationID IN ${ProductVariantCombinationDetail} 
              GROUP BY c.OptionValueID
             `,
          {
            type: QueryTypes.SELECT,
          }
        );
        productCombinationPriceDetail.push(productCombinationDetail);
      }
      let VendorCountry = getProcessOrderDetails[0].VendorCountry;
      let currencyRate;
      let getCurrencyRates = await connection.query(
        "SELECT * FROM currencyrate",
        {
          type: QueryTypes.SELECT,
        }
      );
      if (Region == "Bangladesh") {
        currencyRate = getCurrencyRates[1].Rate;
      } else {
        currencyRate = getCurrencyRates[0].Rate;
      }
      let orderName = [];
      let orderDate = [];
      let paymentStatus = [];
      let transactionID = [];
      let tempPC = productCombinationPriceDetail;
      let tempProd = viewOrderList;
      let tempArray = [];
      let allowStorePickup = [];
      let readyPickupForUser = [];
      let readyPickupForAdmin = [];
      let allowAdminPickup = [];
      let statusHistory = [];
      let processStatus = [];
      let trackingNumber = [];
      var arr = [];
      let tempAOrderDetails = [];
      let deliveryStatus = [];
      let orderTotal = [];
      let shippingHandling = [];
      let estimatedTax = [];
      console.log(currencyRate, "currencyRate---===========================")
      for (let i = 0; i < tempProd.length; i++) {

        let tempTotal = parseFloat(currencyRate * tempProd[i].OrderTotal).toFixed(2);

        console.log(tempProd, "")
        //!cuurency conversion
        //!  new 
        if (Region == "Bangladesh") {
          console.log("THERE===============>", tempProd[i]);
          if (tempProd[i].Currency == "USD") {
            let Price = tempProd[i].BasePrice;
            let EstimatedTax = tempProd[i].EstimatedTax;
            let ShippingHandling = tempProd[i].ShippingHandling;
            tempProd[i]["Currency"] = "BDT";
            tempProd[i]["OrderTotal"] = tempTotal;
            tempProd[i]["BasePrice"] = parseFloat(currencyRate * Price).toFixed(
              2
            );
            tempProd[i]["EstimatedTax"] = parseFloat(currencyRate * EstimatedTax).toFixed(
              2
            );
            tempProd[i]["ShippingHandling"] = parseFloat(currencyRate * ShippingHandling).toFixed(
              2
            );

          }
        }
        else {
          console.log("United States case--------------------------")
          if (tempProd[i].Currency == "BDT") {
            let Price = tempProd[i].BasePrice;
            let EstimatedTax = tempProd[i].EstimatedTax;
            let ShippingHandling = tempProd[i].ShippingHandling;
            tempProd[i]["Currency"] = "USD";
            tempProd[i]["OrderTotal"] = tempTotal;
            tempProd[i]["BasePrice"] = parseFloat(currencyRate * Price).toFixed(
              2
            );
            tempProd[i]["EstimatedTax"] = parseFloat(currencyRate * EstimatedTax).toFixed(
              2
            );
            tempProd[i]["ShippingHandling"] = parseFloat(currencyRate * ShippingHandling).toFixed(
              2
            );
            console.log(tempPC[i]["Currency"], "tempPC[i]")
          }

        }
        var obj = {
          ...tempProd[i],
        };
        console.log(obj, "obj")
        let variantsLength = tempPC[i].length;

        if (Region == "Bangladesh") {
          console.log("case 1 -------------------------------")
          for (let j = 0; j < variantsLength; j++) {
            let Price = tempPC[i][j].ProductCombinationPrice;
            if (tempPC[i][j].Currency == "USD") {
              tempPC[i][j]["Currency"] = "BDT";
              tempPC[i][j]["ProductCombinationPrice"] = parseFloat(
                currencyRate * Price
              ).toFixed(2);
              console.log(tempPC[i][j].Currency, "tempPC[i][j].Currency")
            }
          }
        } else {
          console.log("case 2 -------------------------------")
          for (let j = 0; j < variantsLength; j++) {
            let Price = tempPC[i][j].ProductCombinationPrice;
            if (tempPC[i][j].Currency == "BDT") {
              tempPC[i][j]["Currency"] = "USD";
              tempPC[i][j]["ProductCombinationPrice"] = parseFloat(
                currencyRate * Price
              ).toFixed(2);
            }
          }
        }
        obj["ProductCombinations"] = tempPC[i];
        tempArray.push(obj);
      }
      for (let i = 0; i < tempArray.length; i++) {
        if (!orderName.includes(tempArray[i].OrderNumber)) {
          orderName.push(tempArray[i].OrderNumber);
          orderDate.push(tempArray[i].OrderDate);
          paymentStatus.push(tempArray[i].PaymentStatus);
          transactionID.push(tempArray[i].TransactionID);
          allowStorePickup.push(tempArray[i].AllowStorePickup);
          readyPickupForUser.push(tempArray[i].ReadyPickupForUser);
          readyPickupForAdmin.push(tempArray[i].ReadyPickupForAdmin);
          allowAdminPickup.push(tempArray[i].AllowAdminPickup);
          statusHistory.push(tempArray[i].StatusHistory);
          processStatus.push(tempArray[i].ProcessStatus);
          deliveryStatus.push(tempArray[i].DeliveryStatus);
          trackingNumber.push(tempArray[i].TrackingNumber);
          orderTotal.push(tempArray[i].OrderTotal);
          shippingHandling.push(tempArray[i].ShippingHandling);
          estimatedTax.push(tempArray[i].EstimatedTax);
        }
      }
      for (let i = 0; i < orderName.length; i++) {
        var obj = {
          OrderNumber: orderName[i],
          OrderDate: orderDate[i],
          PaymentStatus: paymentStatus[i],
          TransactionID: transactionID[i],
          AllowStorePickup: allowStorePickup[i],
          ReadyPickupForUser: readyPickupForUser[i],
          ReadyPickupForAdmin: readyPickupForAdmin[i],
          AllowAdminPickup: allowAdminPickup[i],
          StatusHistory: statusHistory[i],
          ProcessStatus: processStatus[i],
          DeliveryStatus: deliveryStatus[i],
          TrackingNumber: trackingNumber[i],
          OrderTotal: orderTotal[i],
          ShippingHandling: shippingHandling[i],
          EstimatedTax: estimatedTax[i],
          ProductDetail: [],
        };
        for (let j = 0; j < tempArray.length; j++) {
          if (orderName[i] === tempArray[j].OrderNumber) {
            obj.ProductDetail.push(tempArray[j]);
          }
        }
        tempAOrderDetails.push(obj);
      }
      if (productCombinationDetail && productCombinationDetail.length > 0) {
        orderShippingDetail = await connection.query(
          `SELECT o.ID AS DeliveryAddressID,o.OrderNumber,o.Name AS DeliveryName,o.PhoneNumber AS DeliveryPhoneNumber,o.Address1 AS DeliveryAddress1,o.Address2 AS DeliveryAddress2,o.City AS DeliveryCity,o.State AS DeliveryState,o.CountryID AS DeliveryCountryID,c.Country AS DeliveryCountry,o.ZipCode AS DeliveryZipCode,o.DesireDate,o.UserNote AS DeliveryUserNote,s.*,v.CompanyName,v.Address1 AS VendorAddress,v.BusinessPhone
            FROM processorder p 
            INNER JOIN orderdeliveryaddress o ON o.OrderNumber = p.OrderNumber
            INNER JOIN country c ON c.CountryID = o.CountryID
            LEFT JOIN vendorstore s ON s.VendorStoreID = p.VendorStoreID
            LEFT JOIN vendor v ON v.VendorID = s.VendorID
            WHERE  p.OrderNumber = "${OrderNumber}" 
           `,
          {
            type: QueryTypes.SELECT,
          }
        );
        let deliveryDriverDetails = null;
        if (orderShippingDetail && orderShippingDetail.length > 0) {
          deliveryDriverDetailsQuery = await connection.query(
            `SELECT d.*,p.*
            FROM processorder o
            INNER JOIN deliverydriver d ON d.DeliveryDriverID = o.DeliveryDriverID
            INNER JOIN profile p ON p.UserID = d.DeliveryDriverID
            WHERE o.OrderNumber = "${OrderNumber}"
           `,
            {
              type: QueryTypes.SELECT,
            }
          );
          if (
            deliveryDriverDetailsQuery &&
            deliveryDriverDetailsQuery.length > 0
          ) {
            deliveryDriverDetails = deliveryDriverDetailsQuery[0];
          }
          let getStorePickupDetails = await connection.query(
            `SELECT v.CompanyName,s.*
               FROM processorder o
               INNER JOIN vendorstore s ON s.VendorStoreID = o.VendorStoreID
               INNER JOIN vendor v ON v.VendorID = s.VendorID
               WHERE o.OrderNumber = "${OrderNumber}" AND o.AllowStorePickup="Y"
           `,
            {
              type: QueryTypes.SELECT,
            }
          );
          if (getStorePickupDetails && getStorePickupDetails.length > 0) {
            res.status(200).json({
              status: true,
              orderDetails: tempAOrderDetails[0],
              orderShippingDetail: orderShippingDetail[0],
              deliveryDriverDetails,
              getStorePickupDetails: getStorePickupDetails[0],
            });
          } else {
            res.status(200).json({
              status: true,
              orderDetails: tempAOrderDetails[0],
              orderShippingDetail: orderShippingDetail[0],
              deliveryDriverDetails,
              getStorePickupDetails: null,
            });
          }
        } else {
          res.status(200).json({
            status: false,
            orderDetails: null,
            orderShippingDetail: null,
            deliveryDriverDetails: null,
            getStorePickupDetails: null,
          });
        }
      } else {
        res.status(200).json({
          status: false,
          orderDetails: null,
          orderShippingDetail: null,
          deliveryDriverDetails: null,
          getStorePickupDetails: null,
        });
      }
    } else {
      res.status(200).json({
        status: false,
        orderDetails: null,
        orderShippingDetail: null,
        deliveryDriverDetails: null,
        getStorePickupDetails: null,
      });
    }
  } catch (err) {
    console.log(err.message);
    next(err);
    res.status(200).json({
      status: false,
      orderDetails: null,
      orderShippingDetail: null,
      deliveryDriverDetails: null,
      getStorePickupDetails: null,
    });
  }
};





exports.adOld2getOrderDetailsForInvoice = async (req, res, next) => {
  try {
    const Region = req.region;
    let OrderNumber = req.params.id;
    let productCombinationPriceDetail = [];
    let getProcessOrderDetails = await connection.query(
      `SELECT o.*,v.CountryID AS VendorCountry
         FROM processorder o
         LEFT JOIN product p ON o.ProductID= p.ProductID
         LEFT JOIN vendor v ON v.VendorID= p.VendorID
         WHERE o.OrderNumber="${OrderNumber}"
     `,
      {
        type: QueryTypes.SELECT,
      }
    );
    let viewOrderListQuery = `SELECT p.ProductID,p.Title,m.TransactionID,s.OrderNumber,s.AllowStorePickup,s.AllowAdminPickup,s.ReadyPickupForUser,s.ReadyPickupForAdmin,s.OrderDate,m.PaymentStatus,p.Price AS BasePrice,s.Quantity,p.Currency,s.UserID,g.Small,g.Medium,g.Large,i.MainImage,s.StatusHistory,s.ProcessStatus,s.DeliveryDriverID,s.ConsignmentId,r.CountryID AS VendorCountry,s.DeliveryStatus,s.TrackingNumber,m.OrderTotal,m.ShippingHandling,m.EstimatedTax,
      (SELECT COUNT(t.ProductID)
      from productreviewrating t WHERE t.ProductID = p.ProductID) AS REVIEW_COUNT,
      (SELECT AVG(t.Rating) from productreviewrating t WHERE t.ProductID = p.ProductID) AS  AVG_Rating
          FROM (((((((( product p
          LEFT JOIN productvariantoption o ON o.ProductID IN( p.ProductID))
          LEFT JOIN productvariantoptionvalue v  ON  v.OptionID IN (o.OptionID))
          LEFT JOIN productimage i  ON  i.OptionValueID IN (v.OptionValueID))
          LEFT JOIN imagegallery g  ON  g.ImageGalleryID IN (i.ImageGalleryID))
          LEFT JOIN productvariantcombination c  ON  c.OptionValueID IN (v.OptionValueID))
          INNER JOIN processorder s ON s.ProductID IN(c.ProductID))
           LEFT JOIN vendor r ON (r.VendorID= p.VendorID))
          LEFT JOIN processpayment m ON m.OrderNumber IN(s.OrderNumber))
          WHERE i.MainImage='Y' AND s.OrderNumber="${OrderNumber}"
          GROUP BY s.ProcessOrderID `;
    let viewOrderList = await connection.query(viewOrderListQuery, {
      type: QueryTypes.SELECT,
    });
    let productCombinationDetail;
    if (viewOrderList && viewOrderList.length > 0) {
      for (let i = 0; i < getProcessOrderDetails.length; i++) {
        let ProductVariantCombinationDetail = [];
        ProductVariantCombinationDetail.push(
          getProcessOrderDetails[i].ProductVariantCombinationDetail
        );
        ProductVariantCombinationDetail = `(${ProductVariantCombinationDetail.join(
          ","
        )})`;
        productCombinationDetail = await connection.query(
          `SELECT p.ProductID,c.ProductVariantCombinationID,c.VendorStoreID,c.Price AS ProductCombinationPrice,c.AvailableInventory,o.OptionID,o.OptionName,v.OptionValue,v.OptionValueID,p.Currency
              FROM ((((product p
              LEFT JOIN productvariantoption o ON o.ProductID IN( p.ProductID))
              LEFT JOIN productvariantoptionvalue v  ON  v.OptionID IN (o.OptionID))
              LEFT JOIN productvariantcombination c  ON  c.OptionValueID IN (v.OptionValueID))
              LEFT JOIN processorder s ON s.ProductID IN(c.ProductID))
              WHERE  c.ProductVariantCombinationID IN ${ProductVariantCombinationDetail}
              GROUP BY c.OptionValueID
             `,
          {
            type: QueryTypes.SELECT,
          }
        );
        productCombinationPriceDetail.push(productCombinationDetail);
      }
      let VendorCountry = getProcessOrderDetails[0].VendorCountry;
      let currencyRate;
      let getCurrencyRates = await connection.query(
        "SELECT * FROM currencyrate",
        {
          type: QueryTypes.SELECT,
        }
      );
      if (Region == "Bangladesh") {
        currencyRate = getCurrencyRates[1].Rate;
      } else {
        currencyRate = getCurrencyRates[0].Rate;
      }
      let orderName = [];
      let orderDate = [];
      let paymentStatus = [];
      let transactionID = [];
      let tempPC = productCombinationPriceDetail;
      let tempProd = viewOrderList;
      let tempArray = [];
      let allowStorePickup = [];
      let readyPickupForUser = [];
      let readyPickupForAdmin = [];
      let allowAdminPickup = [];
      let statusHistory = [];
      let processStatus = [];
      let trackingNumber = [];
      var arr = [];
      let tempAOrderDetails = [];
      let deliveryStatus = [];
      let orderTotal = [];
      let shippingHandling = [];
      let estimatedTax = [];
      console.log(currencyRate, "currencyRate---===========================")
      for (let i = 0; i < tempProd.length; i++) {

        let tempTotal = parseFloat(currencyRate * tempProd[i].OrderTotal).toFixed(2);

        console.log(tempProd, "")
        //!cuurency conversion
        //!  new
        if (Region == "Bangladesh") {
          console.log("THERE===============>", tempProd[i]);
          if (tempProd[i].Currency == "USD") {
            let Price = tempProd[i].BasePrice;
            let EstimatedTax = tempProd[i].EstimatedTax;
            let ShippingHandling = tempProd[i].ShippingHandling;
            tempProd[i]["Currency"] = "BDT";
            tempProd[i]["OrderTotal"] = tempTotal;
            tempProd[i]["BasePrice"] = parseFloat(currencyRate * Price).toFixed(
              2
            );
            tempProd[i]["EstimatedTax"] = parseFloat(currencyRate * EstimatedTax).toFixed(
              2
            );
            tempProd[i]["ShippingHandling"] = parseFloat(currencyRate * ShippingHandling).toFixed(
              2
            );

          }
        }
        else {
          if (tempProd[i].Currency == "BDT") {
            tempPC[i]["Currency"] = "USD";
            tempProd[i]["OrderTotal"] = tempTotal;
            tempProd[i]["BasePrice"] = parseFloat(currencyRate * Price).toFixed(
              2
            );

          }

        }
        var obj = {
          ...tempProd[i],
        };
        let variantsLength = tempPC[i].length;

        if (Region == "Bangladesh") {
          console.log("case 1 -------------------------------")
          for (let j = 0; j < variantsLength; j++) {
            let Price = tempPC[i][j].ProductCombinationPrice;
            if (tempPC[i][j].Currency == "USD") {
              tempPC[i][j]["Currency"] = "BDT";
              tempPC[i][j]["ProductCombinationPrice"] = parseFloat(
                currencyRate * Price
              ).toFixed(2);
              console.log(tempPC[i][j].Currency, "tempPC[i][j].Currency")
            }
          }
        } else {
          console.log("case 2 -------------------------------")
          for (let j = 0; j < variantsLength; j++) {
            let Price = tempPC[i][j].ProductCombinationPrice;
            if (tempPC[i][j].Currency == "BDT") {
              tempPC[i][j]["Currency"] = "USD";
              tempPC[i][j]["ProductCombinationPrice"] = parseFloat(
                currencyRate * Price
              ).toFixed(2);
            }
          }
        }
        obj["ProductCombinations"] = tempPC[i];
        tempArray.push(obj);
      }
      for (let i = 0; i < tempArray.length; i++) {
        if (!orderName.includes(tempArray[i].OrderNumber)) {
          orderName.push(tempArray[i].OrderNumber);
          orderDate.push(tempArray[i].OrderDate);
          paymentStatus.push(tempArray[i].PaymentStatus);
          transactionID.push(tempArray[i].TransactionID);
          allowStorePickup.push(tempArray[i].AllowStorePickup);
          readyPickupForUser.push(tempArray[i].ReadyPickupForUser);
          readyPickupForAdmin.push(tempArray[i].ReadyPickupForAdmin);
          allowAdminPickup.push(tempArray[i].AllowAdminPickup);
          statusHistory.push(tempArray[i].StatusHistory);
          processStatus.push(tempArray[i].ProcessStatus);
          deliveryStatus.push(tempArray[i].DeliveryStatus);
          trackingNumber.push(tempArray[i].TrackingNumber);
          orderTotal.push(tempArray[i].OrderTotal);
          shippingHandling.push(tempArray[i].ShippingHandling);
          estimatedTax.push(tempArray[i].EstimatedTax);
        }
      }
      for (let i = 0; i < orderName.length; i++) {
        var obj = {
          OrderNumber: orderName[i],
          OrderDate: orderDate[i],
          PaymentStatus: paymentStatus[i],
          TransactionID: transactionID[i],
          AllowStorePickup: allowStorePickup[i],
          ReadyPickupForUser: readyPickupForUser[i],
          ReadyPickupForAdmin: readyPickupForAdmin[i],
          AllowAdminPickup: allowAdminPickup[i],
          StatusHistory: statusHistory[i],
          ProcessStatus: processStatus[i],
          DeliveryStatus: deliveryStatus[i],
          TrackingNumber: trackingNumber[i],
          OrderTotal: orderTotal[i],
          ShippingHandling: shippingHandling[i],
          EstimatedTax: estimatedTax[i],
          ProductDetail: [],
        };
        for (let j = 0; j < tempArray.length; j++) {
          if (orderName[i] === tempArray[j].OrderNumber) {
            obj.ProductDetail.push(tempArray[j]);
          }
        }
        tempAOrderDetails.push(obj);
      }
      if (productCombinationDetail && productCombinationDetail.length > 0) {
        orderShippingDetail = await connection.query(
          `SELECT o.ID AS DeliveryAddressID,o.OrderNumber,o.Name AS DeliveryName,o.PhoneNumber AS DeliveryPhoneNumber,o.Address1 AS DeliveryAddress1,o.Address2 AS DeliveryAddress2,o.City AS DeliveryCity,o.State AS DeliveryState,o.CountryID AS DeliveryCountryID,c.Country AS DeliveryCountry,o.ZipCode AS DeliveryZipCode,o.DesireDate,o.UserNote AS DeliveryUserNote,s.*,v.CompanyName,v.Address1 AS VendorAddress,v.BusinessPhone
            FROM processorder p
            INNER JOIN orderdeliveryaddress o ON o.OrderNumber = p.OrderNumber
            INNER JOIN country c ON c.CountryID = o.CountryID
            LEFT JOIN vendorstore s ON s.VendorStoreID = p.VendorStoreID
            LEFT JOIN vendor v ON v.VendorID = s.VendorID
            WHERE  p.OrderNumber = "${OrderNumber}"
           `,
          {
            type: QueryTypes.SELECT,
          }
        );
        let deliveryDriverDetails = null;
        if (orderShippingDetail && orderShippingDetail.length > 0) {
          deliveryDriverDetailsQuery = await connection.query(
            `SELECT d.*,p.*
            FROM processorder o
            INNER JOIN deliverydriver d ON d.DeliveryDriverID = o.DeliveryDriverID
            INNER JOIN profile p ON p.UserID = d.DeliveryDriverID
            WHERE o.OrderNumber = "${OrderNumber}"
           `,
            {
              type: QueryTypes.SELECT,
            }
          );
          if (
            deliveryDriverDetailsQuery &&
            deliveryDriverDetailsQuery.length > 0
          ) {
            deliveryDriverDetails = deliveryDriverDetailsQuery[0];
          }
          let getStorePickupDetails = await connection.query(
            `SELECT v.CompanyName,s.*
               FROM processorder o
               INNER JOIN vendorstore s ON s.VendorStoreID = o.VendorStoreID
               INNER JOIN vendor v ON v.VendorID = s.VendorID
               WHERE o.OrderNumber = "${OrderNumber}" AND o.AllowStorePickup="Y"
           `,
            {
              type: QueryTypes.SELECT,
            }
          );
          if (getStorePickupDetails && getStorePickupDetails.length > 0) {
            res.status(200).json({
              status: true,
              orderDetails: tempAOrderDetails[0],
              orderShippingDetail: orderShippingDetail[0],
              deliveryDriverDetails,
              getStorePickupDetails: getStorePickupDetails[0],
            });
          } else {
            res.status(200).json({
              status: true,
              orderDetails: tempAOrderDetails[0],
              orderShippingDetail: orderShippingDetail[0],
              deliveryDriverDetails,
              getStorePickupDetails: null,
            });
          }
        } else {
          res.status(200).json({
            status: false,
            orderDetails: null,
            orderShippingDetail: null,
            deliveryDriverDetails: null,
            getStorePickupDetails: null,
          });
        }
      } else {
        res.status(200).json({
          status: false,
          orderDetails: null,
          orderShippingDetail: null,
          deliveryDriverDetails: null,
          getStorePickupDetails: null,
        });
      }
    } else {
      res.status(200).json({
        status: false,
        orderDetails: null,
        orderShippingDetail: null,
        deliveryDriverDetails: null,
        getStorePickupDetails: null,
      });
    }
  } catch (err) {
    console.log(err.message);
    next(err);
    res.status(200).json({
      status: false,
      orderDetails: null,
      orderShippingDetail: null,
      deliveryDriverDetails: null,
      getStorePickupDetails: null,
    });
  }
};



exports.adOldgetOrderDetailsForInvoice = async (req, res, next) => {
  try {
    let OrderNumber = req.params.id;
    let productCombinationPriceDetail = [];
    let getProcessOrderDetails = await connection.query(
      `SELECT o.*,v.CountryID AS VendorCountry
         FROM processorder o
         LEFT JOIN product p ON o.ProductID= p.ProductID
         LEFT JOIN vendor v ON v.VendorID= p.VendorID
         WHERE o.OrderNumber="${OrderNumber}" 
     `,
      {
        type: QueryTypes.SELECT,
      }
    );
    let viewOrderListQuery = `SELECT p.ProductID,p.Title,m.TransactionID,s.OrderNumber,s.AllowStorePickup,s.AllowAdminPickup,s.ReadyPickupForUser,s.ReadyPickupForAdmin,s.OrderDate,m.PaymentStatus,p.Price AS BasePrice,s.Quantity,p.Currency,s.UserID,g.Small,g.Medium,g.Large,i.MainImage,s.StatusHistory,s.ProcessStatus,s.DeliveryDriverID,s.ConsignmentId,r.CountryID AS VendorCountry,s.DeliveryStatus,s.TrackingNumber,m.OrderTotal,m.ShippingHandling,m.EstimatedTax,
      (SELECT COUNT(t.ProductID)
      from productreviewrating t WHERE t.ProductID = p.ProductID) AS REVIEW_COUNT,
      (SELECT AVG(t.Rating) from productreviewrating t WHERE t.ProductID = p.ProductID) AS  AVG_Rating
          FROM (((((((( product p      
          LEFT JOIN productvariantoption o ON o.ProductID IN( p.ProductID))
          LEFT JOIN productvariantoptionvalue v  ON  v.OptionID IN (o.OptionID))  
          LEFT JOIN productimage i  ON  i.OptionValueID IN (v.OptionValueID))
          LEFT JOIN imagegallery g  ON  g.ImageGalleryID IN (i.ImageGalleryID))
          LEFT JOIN productvariantcombination c  ON  c.OptionValueID IN (v.OptionValueID))
          INNER JOIN processorder s ON s.ProductID IN(c.ProductID))
           LEFT JOIN vendor r ON (r.VendorID= p.VendorID))
          LEFT JOIN processpayment m ON m.OrderNumber IN(s.OrderNumber))
          WHERE i.MainImage='Y' AND s.OrderNumber="${OrderNumber}" 
          GROUP BY s.ProcessOrderID `;
    let viewOrderList = await connection.query(viewOrderListQuery, {
      type: QueryTypes.SELECT,
    });
    let productCombinationDetail;
    if (viewOrderList && viewOrderList.length > 0) {
      for (let i = 0; i < getProcessOrderDetails.length; i++) {
        let ProductVariantCombinationDetail = [];
        ProductVariantCombinationDetail.push(
          getProcessOrderDetails[i].ProductVariantCombinationDetail
        );
        ProductVariantCombinationDetail = `(${ProductVariantCombinationDetail.join(
          ","
        )})`;
        productCombinationDetail = await connection.query(
          `SELECT p.ProductID,c.ProductVariantCombinationID,c.VendorStoreID,c.Price AS ProductCombinationPrice,c.AvailableInventory,o.OptionID,o.OptionName,v.OptionValue,v.OptionValueID,p.Currency
              FROM ((((product p
              LEFT JOIN productvariantoption o ON o.ProductID IN( p.ProductID))
              LEFT JOIN productvariantoptionvalue v  ON  v.OptionID IN (o.OptionID)) 
              LEFT JOIN productvariantcombination c  ON  c.OptionValueID IN (v.OptionValueID))
              LEFT JOIN processorder s ON s.ProductID IN(c.ProductID))
              WHERE  c.ProductVariantCombinationID IN ${ProductVariantCombinationDetail} 
              GROUP BY c.OptionValueID
             `,
          {
            type: QueryTypes.SELECT,
          }
        );
        productCombinationPriceDetail.push(productCombinationDetail);
      }
      let VendorCountry = getProcessOrderDetails[0].VendorCountry;
      let currencyRate;
      let getCurrencyRates = await connection.query(
        "SELECT * FROM currencyrate",
        {
          type: QueryTypes.SELECT,
        }
      );
      if (VendorCountry == "16") {
        currencyRate = getCurrencyRates[1].Rate;
      } else {
        currencyRate = getCurrencyRates[0].Rate;
      }
      let orderName = [];
      let orderDate = [];
      let paymentStatus = [];
      let transactionID = [];
      let tempPC = productCombinationPriceDetail;
      let tempProd = viewOrderList;
      let tempArray = [];
      let allowStorePickup = [];
      let readyPickupForUser = [];
      let readyPickupForAdmin = [];
      let allowAdminPickup = [];
      let statusHistory = [];
      let processStatus = [];
      let trackingNumber = [];
      var arr = [];
      let tempAOrderDetails = [];
      let deliveryStatus = [];
      let orderTotal = [];
      let shippingHandling = [];
      let estimatedTax = [];
      for (let i = 0; i < tempProd.length; i++) {
        //!cuurency conversion
        if (VendorCountry == "16") {
          let Price = tempProd[i].BasePrice;
          if (tempProd[i].Currency == "$") {
            tempProd[i]["Currency"] = "BDT";
            tempProd[i]["BasePrice"] = parseFloat(currencyRate * Price).toFixed(
              2
            );
          }
        } else if (VendorCountry == "226") {
          let Price = tempProd[i].BasePrice;
          if (tempProd[i].Currency == "BDT") {
            tempProd[i]["Currency"] = "$";
            tempProd[i]["BasePrice"] = parseFloat(currencyRate * Price).toFixed(
              2
            );
          }
        } else {
          let Price = tempProd[i].BasePrice;
          tempProd[i]["Currency"] = "$";
          tempProd[i]["BasePrice"] = parseFloat(currencyRate * Price).toFixed(
            2
          );
        }
        var obj = {
          ...tempProd[i],
        };
        let variantsLength = tempPC[i].length;
        if (VendorCountry == "16") {
          for (let j = 0; j < variantsLength; j++) {
            let Price = tempPC[i][j].ProductCombinationPrice;
            if (tempPC[i][j].Currency == "$") {
              tempPC[i][j]["Currency"] = "BDT";
              tempPC[i][j]["ProductCombinationPrice"] = parseFloat(
                currencyRate * Price
              ).toFixed(2);
            }
          }
        } else if (VendorCountry == "226") {
          for (let j = 0; j < variantsLength; j++) {
            let Price = tempPC[i][j].ProductCombinationPrice;
            if (tempPC[i][j].Currency == "BDT") {
              tempPC[i][j]["Currency"] = "$";
              tempPC[i][j]["ProductCombinationPrice"] = parseFloat(
                currencyRate * Price
              ).toFixed(2);
            }
          }
        } else {
          for (let j = 0; j < variantsLength; j++) {
            let Price = tempPC[i][j].ProductCombinationPrice;
            tempPC[i][j]["Currency"] = "$";
            tempPC[i][j]["ProductCombinationPrice"] = parseFloat(
              currencyRate * Price
            ).toFixed(2);
          }
        }
        obj["ProductCombinations"] = tempPC[i];
        tempArray.push(obj);
      }
      for (let i = 0; i < tempArray.length; i++) {
        if (!orderName.includes(tempArray[i].OrderNumber)) {
          orderName.push(tempArray[i].OrderNumber);
          orderDate.push(tempArray[i].OrderDate);
          paymentStatus.push(tempArray[i].PaymentStatus);
          transactionID.push(tempArray[i].TransactionID);
          allowStorePickup.push(tempArray[i].AllowStorePickup);
          readyPickupForUser.push(tempArray[i].ReadyPickupForUser);
          readyPickupForAdmin.push(tempArray[i].ReadyPickupForAdmin);
          allowAdminPickup.push(tempArray[i].AllowAdminPickup);
          statusHistory.push(tempArray[i].StatusHistory);
          processStatus.push(tempArray[i].ProcessStatus);
          deliveryStatus.push(tempArray[i].DeliveryStatus);
          trackingNumber.push(tempArray[i].TrackingNumber);
          orderTotal.push(tempArray[i].OrderTotal);
          shippingHandling.push(tempArray[i].ShippingHandling);
          estimatedTax.push(tempArray[i].EstimatedTax);
        }
      }
      for (let i = 0; i < orderName.length; i++) {
        var obj = {
          OrderNumber: orderName[i],
          OrderDate: orderDate[i],
          PaymentStatus: paymentStatus[i],
          TransactionID: transactionID[i],
          AllowStorePickup: allowStorePickup[i],
          ReadyPickupForUser: readyPickupForUser[i],
          ReadyPickupForAdmin: readyPickupForAdmin[i],
          AllowAdminPickup: allowAdminPickup[i],
          StatusHistory: statusHistory[i],
          ProcessStatus: processStatus[i],
          DeliveryStatus: deliveryStatus[i],
          TrackingNumber: trackingNumber[i],
          OrderTotal: orderTotal[i],
          ShippingHandling: shippingHandling[i],
          EstimatedTax: estimatedTax[i],
          ProductDetail: [],
        };
        for (let j = 0; j < tempArray.length; j++) {
          if (orderName[i] === tempArray[j].OrderNumber) {
            obj.ProductDetail.push(tempArray[j]);
          }
        }
        tempAOrderDetails.push(obj);
      }
      if (productCombinationDetail && productCombinationDetail.length > 0) {
        orderShippingDetail = await connection.query(
          `SELECT o.ID AS DeliveryAddressID,o.OrderNumber,o.Name AS DeliveryName,o.PhoneNumber AS DeliveryPhoneNumber,o.Address1 AS DeliveryAddress1,o.Address2 AS DeliveryAddress2,o.City AS DeliveryCity,o.State AS DeliveryState,o.CountryID AS DeliveryCountryID,c.Country AS DeliveryCountry,o.ZipCode AS DeliveryZipCode,o.DesireDate,o.UserNote AS DeliveryUserNote,s.*,v.CompanyName,v.Address1 AS VendorAddress,v.BusinessPhone
            FROM processorder p 
            INNER JOIN orderdeliveryaddress o ON o.OrderNumber = p.OrderNumber
            INNER JOIN country c ON c.CountryID = o.CountryID
            LEFT JOIN vendorstore s ON s.VendorStoreID = p.VendorStoreID
	    LEFT JOIN vendor v ON v.VendorID = s.VendorID
            WHERE  p.OrderNumber = "${OrderNumber}" 
           `,
          {
            type: QueryTypes.SELECT,
          }
        );
        let deliveryDriverDetails = null;
        if (orderShippingDetail && orderShippingDetail.length > 0) {
          deliveryDriverDetailsQuery = await connection.query(
            `SELECT d.*,p.*
            FROM processorder o
            INNER JOIN deliverydriver d ON d.DeliveryDriverID = o.DeliveryDriverID
            INNER JOIN profile p ON p.UserID = d.DeliveryDriverID
            WHERE o.OrderNumber = "${OrderNumber}"
           `,
            {
              type: QueryTypes.SELECT,
            }
          );
          if (
            deliveryDriverDetailsQuery &&
            deliveryDriverDetailsQuery.length > 0
          ) {
            deliveryDriverDetails = deliveryDriverDetailsQuery[0];
          }
          let getStorePickupDetails = await connection.query(
            `SELECT v.CompanyName,s.*
               FROM processorder o
               INNER JOIN vendorstore s ON s.VendorStoreID = o.VendorStoreID
               INNER JOIN vendor v ON v.VendorID = s.VendorID
               WHERE o.OrderNumber = "${OrderNumber}" AND o.AllowStorePickup="Y"
           `,
            {
              type: QueryTypes.SELECT,
            }
          );
          if (getStorePickupDetails && getStorePickupDetails.length > 0) {
            res.status(200).json({
              status: true,
              orderDetails: tempAOrderDetails[0],
              orderShippingDetail: orderShippingDetail[0],
              deliveryDriverDetails,
              getStorePickupDetails: getStorePickupDetails[0],
            });
          } else {
            res.status(200).json({
              status: true,
              orderDetails: tempAOrderDetails[0],
              orderShippingDetail: orderShippingDetail[0],
              deliveryDriverDetails,
              getStorePickupDetails: null,
            });
          }
        } else {
          res.status(200).json({
            status: false,
            orderDetails: null,
            orderShippingDetail: null,
            deliveryDriverDetails: null,
            getStorePickupDetails: null,
          });
        }
      } else {
        res.status(200).json({
          status: false,
          orderDetails: null,
          orderShippingDetail: null,
          deliveryDriverDetails: null,
          getStorePickupDetails: null,
        });
      }
    } else {
      res.status(200).json({
        status: false,
        orderDetails: null,
        orderShippingDetail: null,
        deliveryDriverDetails: null,
        getStorePickupDetails: null,
      });
    }
  } catch (err) {
    console.log(err.message);
    next(err);
    res.status(200).json({
      status: false,
      orderDetails: null,
      orderShippingDetail: null,
      deliveryDriverDetails: null,
      getStorePickupDetails: null,
    });
  }
};
exports.viewDeliveryDriverPendingRequestsByAdmin = async (req, res, next) => {
  try {
    let getDeliveryDriverDetailsQuery = `SELECT d.*,p.*
     FROM deliverydriver d
     INNER JOIN profile p ON p.UserID=d.DeliveryDriverID
     WHERE d.ReviewedByAdmin="N" ORDER BY DeliveryDriverID LIMIT 50`;
    let getDeliveryDriverDetails = await connection.query(
      getDeliveryDriverDetailsQuery,
      {
        type: QueryTypes.SELECT,
      }
    );
    if (getDeliveryDriverDetails && getDeliveryDriverDetails.length > 0) {
      res.status(200).json({
        status: true,
        deliveryDriverDetails: getDeliveryDriverDetails,
      });
    } else {
      res.status(200).json({
        status: false,
        message: "NO delivery driver Record found",
        deliveryDriverDetails: [],
      });
    }
  } catch (err) {
    next(err);
    res.status(200).json({
      status: false,
      deliveryDriverDetails: [],
      message: err.message,
    });
  }
};
exports.updateDeliveryDriverStatusByAdmin = async (req, res, next) => {
  let transaction;
  try {
    let DeliveryDriverID = req.params.id;
    transaction = await connection.transaction();
    let LastUpdate = new Date().toISOString().slice(0, 19).replace("T", " ");
    let getDeliveryDriverDetailsQuery = `SELECT * FROM deliverydriver WHERE ReviewedByAdmin="N" `;
    let getDeliveryDriverDetails = await connection.query(
      getDeliveryDriverDetailsQuery,
      {
        type: QueryTypes.SELECT,
        transaction,
      }
    );
    if (getDeliveryDriverDetails && getDeliveryDriverDetails.length > 0) {
      let updateDriverStatusQuery = `UPDATE deliverydriver,profile 
      SET deliverydriver.ReviewedByAdmin="Y", deliverydriver.LastUpdate="${LastUpdate}",profile.DeliveryPerson="Y" WHERE deliverydriver.DeliveryDriverID ="${DeliveryDriverID}" AND profile.UserID ="${DeliveryDriverID}"  `;
      let updateDriverStatus = await connection.query(updateDriverStatusQuery, {
        transaction,
      });
      if (updateDriverStatus) {
        let TypeID = "5";
        let CreaterID = "1";
        let Body = {
          DeliveryDriverID,
          body: "Congratulations !! Your Registration is approved By Admin and you are now Banglabazar Delivery Person",
        };
        let Message = Body.body;
        let ReceiverID = DeliveryDriverID;
        let getDeviceIDQuery = ` SELECT DeviceID,EmailAddress
        FROM profile 
        WHERE UserID=${DeliveryDriverID}`;
        let getDeviceID = await connection.query(getDeviceIDQuery, {
          type: QueryTypes.SELECT,
          transaction,
        });
        let DeviceID = getDeviceID[0].DeviceID;
        let EmailAddress = getDeviceID[0].EmailAddress;
        if (DeviceID == null || DeviceID == "NULL" || DeviceID == "null") {
          console.log("NULL CONDITION -----------------");
          sendEmail(EmailAddress, Message, TypeID);
          if (transaction) await transaction.commit(); //!final commit
          res.status(200).json({
            status: true,
            message: "Succesfully Updated Driver Status",
          });
        } else if (DeviceID && DeviceID.length > 0) {
          sendEmail(EmailAddress, Message, TypeID);
          let sendNotification = await Notification(
            TypeID,
            Body,
            CreaterID,
            ReceiverID,
            transaction
          );
          if (sendNotification) {
            if (transaction) await transaction.commit(); //!final commit
            res.status(200).json({
              status: true,
              message: "Succesfully Updated Driver Status",
            });
          } else {
            if (transaction) await transaction.rollback();
            res.status(200).json({
              status: false,
              message: "Error while sending Notification to User ",
            });
          }
        }
      } else {
        if (transaction) await transaction.rollback();
        res.status(200).json({
          status: false,
          message: "error while updating driver status",
        });
      }
    } else {
      if (transaction) await transaction.rollback();
      res.status(200).json({
        status: false,
        message: "NO pending approval requests",
      });
    }
  } catch (err) {
    if (transaction) await transaction.rollback();
    next(err);
    res.status(200).json({
      status: false,
      message: err.message,
    });
  }
};
exports.getOrdersByStatusFilters = async (req, res, next) => {
  try {
    const {
      sort,
      status,
      limit,
      offset,
      search,
      ReadyPickupForAdmin,
      ReadyPickupForUser,
    } = req.body;
    let productCombinationPriceDetail = [];
    let ordersCount = await connection.query(
      `SELECT COUNT(OrderNumber) as total_records FROM processorder WHERE ProcessStatus="${status}" AND ReadyPickupForAdmin="${ReadyPickupForAdmin}" AND ReadyPickupForUser="${ReadyPickupForUser}" `,
      {
        type: QueryTypes.SELECT,
      }
    );
    if (ordersCount && ordersCount.length > 0) {
      let getProcessOrderDetails = await connection.query(
        `SELECT * from processorder WHERE ProcessStatus="${status}" AND ReadyPickupForAdmin="${ReadyPickupForAdmin}" AND ReadyPickupForUser="${ReadyPickupForUser}"
     `,
        {
          type: QueryTypes.SELECT,
        }
      );
      let viewOrderListQuery =
        `SELECT p.ProductID,p.Title,m.TransactionID,s.OrderNumber,s.AllowStorePickup,s.AllowAdminPickup,s.ReadyPickupForUser,s.ReadyPickupForAdmin,s.OrderDate,m.PaymentStatus,p.Price AS BasePrice, p.VendorID,p.Currency,s.UserID,g.Small,g.Medium,g.Large,i.MainImage,s.ConsignmentId,s.DeliveryDriverID,s.DeliveryStatus,
      (SELECT COUNT(t.ProductID)
      from productreviewrating t WHERE t.ProductID = p.ProductID) AS REVIEW_COUNT,
      (SELECT AVG(t.Rating) from productreviewrating t WHERE t.ProductID = p.ProductID) AS  AVG_Rating
          FROM ((((((( product p      
          LEFT JOIN productvariantoption o ON o.ProductID IN( p.ProductID))
          LEFT JOIN productvariantoptionvalue v  ON  v.OptionID IN (o.OptionID))  
          LEFT JOIN productimage i  ON  i.OptionValueID IN (v.OptionValueID))
          LEFT JOIN imagegallery g  ON  g.ImageGalleryID IN (i.ImageGalleryID))
          LEFT JOIN productvariantcombination c  ON  c.OptionValueID IN (v.OptionValueID))
          INNER JOIN processorder s ON s.ProductID IN(c.ProductID))
          LEFT JOIN processpayment m ON m.OrderNumber IN(s.OrderNumber))
          WHERE i.MainImage='Y'  AND s.ProcessStatus="${status}" AND (s.OrderNumber LIKE "%${search}%") AND ReadyPickupForAdmin="${ReadyPickupForAdmin}" AND ReadyPickupForUser="${ReadyPickupForUser}"
          GROUP BY s.ProcessOrderID
          ORDER by s.ProcessOrderID ${sort} limit ` +
        limit +
        " offset " +
        offset;
      let viewOrderList = await connection.query(viewOrderListQuery, {
        type: QueryTypes.SELECT,
      });
      let productCombinationDetail;
      if (viewOrderList && viewOrderList.length > 0) {
        for (let i = 0; i < getProcessOrderDetails.length; i++) {
          let ProductVariantCombinationDetail = [];
          ProductVariantCombinationDetail.push(
            getProcessOrderDetails[i].ProductVariantCombinationDetail
          );
          ProductVariantCombinationDetail = `(${ProductVariantCombinationDetail.join(
            ","
          )})`;
          productCombinationDetail = await connection.query(
            `SELECT p.ProductID,c.ProductVariantCombinationID,c.VendorStoreID,c.Price AS ProductCombinationPrice,c.AvailableInventory,o.OptionID,o.OptionName,v.OptionValue,v.OptionValueID
              FROM ((((product p
              LEFT JOIN productvariantoption o ON o.ProductID IN( p.ProductID))
              LEFT JOIN productvariantoptionvalue v  ON  v.OptionID IN (o.OptionID)) 
              LEFT JOIN productvariantcombination c  ON  c.OptionValueID IN (v.OptionValueID))
              LEFT JOIN processorder s ON s.ProductID IN(c.ProductID))
              WHERE  c.ProductVariantCombinationID IN ${ProductVariantCombinationDetail}
              GROUP BY c.OptionValueID
              ORDER by s.ProcessOrderID ${sort} 
             `,
            {
              type: QueryTypes.SELECT,
            }
          );
          productCombinationPriceDetail.push(productCombinationDetail);
        }
        let orderName = [];
        let orderDate = [];
        let paymentStatus = [];
        let transactionID = [];
        let tempPC = productCombinationPriceDetail;
        let tempProd = viewOrderList;
        let tempArray = [];
        let allowStorePickup = [];
        let readyPickupForUser = [];
        let readyPickupForAdmin = [];
        let allowAdminPickup = [];
        var deliveryDriverID = [];
        let tempAOrderDetails = [];
        let consignmentID = [];
        let deliveryStatus = [];
        for (let i = 0; i < tempProd.length; i++) {
          var obj = {
            ...tempProd[i],
          };
          obj["ProductCombinations"] = tempPC[i];
          tempArray.push(obj);
        }
        for (let i = 0; i < tempArray.length; i++) {
          if (!orderName.includes(tempArray[i].OrderNumber)) {
            orderName.push(tempArray[i].OrderNumber);
            orderDate.push(tempArray[i].OrderDate);
            paymentStatus.push(tempArray[i].PaymentStatus);
            transactionID.push(tempArray[i].TransactionID);
            allowStorePickup.push(tempArray[i].AllowStorePickup);
            readyPickupForUser.push(tempArray[i].ReadyPickupForUser);
            readyPickupForAdmin.push(tempArray[i].ReadyPickupForAdmin);
            allowAdminPickup.push(tempArray[i].AllowAdminPickup);
            deliveryDriverID.push(tempArray[i].DeliveryDriverID);
            consignmentID.push(tempArray[i].ConsignmentId);
            deliveryStatus.push(tempArray[i].DeliveryStatus);
          }
        }
        for (let i = 0; i < orderName.length; i++) {
          var obj = {
            OrderNumber: orderName[i],
            OrderDate: orderDate[i],
            PaymentStatus: paymentStatus[i],
            TransactionID: transactionID[i],
            AllowStorePickup: allowStorePickup[i],
            ReadyPickupForUser: readyPickupForUser[i],
            ReadyPickupForAdmin: readyPickupForAdmin[i],
            AllowAdminPickup: allowAdminPickup[i],
            DeliveryDriverID: deliveryDriverID[i],
            ConsignmentId: consignmentID[i],
            DeliveryStatus: deliveryStatus[i],
            ProductDetail: [],
          };
          for (let j = 0; j < tempArray.length; j++) {
            if (orderName[i] === tempArray[j].OrderNumber) {
              obj.ProductDetail.push(tempArray[j]);
            }
          }
          tempAOrderDetails.push(obj);
        }
        if (productCombinationDetail && productCombinationDetail.length > 0) {
          res.status(200).json({
            status: true,
            total_records: ordersCount[0].total_records,
            orderDetails: tempAOrderDetails,
          });
        } else {
          res.status(200).json({
            status: true,
            total_records: ordersCount[0].total_records,
            orderDetails: [],
          });
        }
      } else {
        res.status(200).json({
          status: true,
          total_records: ordersCount[0].total_records,
          orderDetails: [],
        });
      }
    } else {
      res.status(200).json({
        status: true,
        total_records: ordersCount[0].total_records,
        orderDetails: [],
      });
    }
  } catch (err) {
    console.log(err.message);
    res.status(200).json({
      status: false,
      orderDetails: [],
    });
  }
};
exports.getRefundOrderDetailOld = async (req, res, next) => {
  try {
    let { limit, offset, sort, search, status } = req.body;
    let productCombinationPriceDetail = [];
    limit = parseInt(limit);
    offset = parseInt(offset);
    offset = limit * offset;
    let getCount = await connection.query(
      `SELECT COUNT(*) as total_records  from (SELECT COUNT(OrderNumber) as total_records from processorder WHERE ReturnReason NOT IN ('NULL','null','Refund Initiated','undefined','Refunded') GROUP BY OrderNumber )OrderNumber`,
      {
        type: QueryTypes.SELECT,
      }
    );
    console.log(getCount);
    if (getCount[0].total_records && getCount[0].total_records > 0) {
      let viewOrderListQuery = `SELECT p.ProductID,p.Title,m.TransactionID,s.OrderNumber,s.AllowStorePickup,s.AllowAdminPickup,s.ReadyPickupForUser,s.ReadyPickupForAdmin,s.OrderDate,m.PaymentStatus,p.Price AS BasePrice,s.Quantity,p.Currency,s.UserID,g.Small,g.Medium,g.Large,i.MainImage,s.StatusHistory,s.ProcessStatus,s.DeliveryDriverID,s.ConsignmentId,s.*,r.CountryID AS VendorCountry,
      pr.*,r.*,vs.*
          FROM (((((((((( product p      
          LEFT JOIN productvariantoption o ON o.ProductID IN( p.ProductID))
          LEFT JOIN productvariantoptionvalue v  ON  v.OptionID IN (o.OptionID))  
          LEFT JOIN productimage i  ON  i.OptionValueID IN (v.OptionValueID))
          LEFT JOIN imagegallery g  ON  g.ImageGalleryID IN (i.ImageGalleryID))
          LEFT JOIN productvariantcombination c  ON  c.OptionValueID IN (v.OptionValueID))
          INNER JOIN processorder s ON s.ProductID IN(c.ProductID))
          INNER JOIN processrefand pr ON pr.ProcessOrderID IN(s.ProcessOrderID))
          LEFT JOIN vendor r ON (r.VendorID= p.VendorID))
          LEFT JOIN vendorstore vs ON vs.VendorStoreID IN(s.VendorStoreID))
          LEFT JOIN processpayment m ON m.OrderNumber IN(s.OrderNumber))
          WHERE i.MainImage='Y' AND s.RefundStatus="${status}" AND s.ReturnReason NOT IN ('NULL','null','undefined') AND s.OrderNumber IN (select * from (SELECT OrderNumber from processorder WHERE ReturnReason NOT IN ('NULL','null','undefined') AND  RefundStatus="${status}" AND  OrderNumber LIKE "%${search}%" GROUP BY OrderNumber LIMIT ${limit} OFFSET ${offset} ) OrderNumber)
          GROUP BY s.ProcessOrderID
          ORDER BY s.ProcessOrderID ${sort}`;
      let viewOrderList = await connection.query(viewOrderListQuery, {
        type: QueryTypes.SELECT,
      });
      let productCombinationDetail;
      if (viewOrderList && viewOrderList.length > 0) {
        for (let i = 0; i < viewOrderList.length; i++) {
          let ProductVariantCombinationDetail = [];
          ProductVariantCombinationDetail.push(
            viewOrderList[i].ProductVariantCombinationDetail
          );
          ProductVariantCombinationDetail = `(${ProductVariantCombinationDetail.join(
            ","
          )})`;
          productCombinationDetail = await connection.query(
            `SELECT p.ProductID,c.ProductVariantCombinationID,c.VendorStoreID,c.Price AS ProductCombinationPrice,c.AvailableInventory,o.OptionID,o.OptionName,v.OptionValue,v.OptionValueID,p.Currency
              FROM ((((product p
              LEFT JOIN productvariantoption o ON o.ProductID IN( p.ProductID))
              LEFT JOIN productvariantoptionvalue v  ON  v.OptionID IN (o.OptionID)) 
              LEFT JOIN productvariantcombination c  ON  c.OptionValueID IN (v.OptionValueID))
              LEFT JOIN processorder s ON s.ProductID IN(c.ProductID))
              WHERE  c.ProductVariantCombinationID IN ${ProductVariantCombinationDetail} 
              GROUP BY c.OptionValueID
              ORDER BY s.ProcessOrderID ASC
             `,
            {
              type: QueryTypes.SELECT,
            }
          );
          productCombinationPriceDetail.push(productCombinationDetail);
        }

        let getCurrencyRates = await connection.query(
          "SELECT * FROM currencyrate",
          {
            type: QueryTypes.SELECT,
          }
        );
        let VendorCountry = viewOrderList[0].VendorCountry;
        let currencyRate;
        if (VendorCountry == "16") {
          currencyRate = getCurrencyRates[1].Rate;
        } else {
          currencyRate = getCurrencyRates[0].Rate;
        }
        let orderName = [];
        let orderDate = [];
        let paymentStatus = [];
        let transactionID = [];
        let tempPC = productCombinationPriceDetail;
        let tempProd = viewOrderList;
        let tempArray = [];
        let allowStorePickup = [];
        let readyPickupForUser = [];
        let readyPickupForAdmin = [];
        let allowAdminPickup = [];
        let statusHistory = [];
        let processStatus = [];
        let tempAOrderDetails = [];

        for (let i = 0; i < tempProd.length; i++) {
          //!cuurency conversion
          if (VendorCountry == "16") {
            let Price = tempProd[i].BasePrice;
            if (tempProd[i].Currency == "$") {
              tempProd[i]["Currency"] = "BDT";
              tempProd[i]["BasePrice"] = parseFloat(
                currencyRate * Price
              ).toFixed(2);
            }
          } else if (VendorCountry == "226") {
            let Price = tempProd[i].BasePrice;
            if (tempProd[i].Currency == "BDT") {
              tempProd[i]["Currency"] = "$";
              tempProd[i]["BasePrice"] = parseFloat(
                currencyRate * Price
              ).toFixed(2);
            }
          } else {
            let Price = tempProd[i].BasePrice;
            tempProd[i]["Currency"] = "$";
            tempProd[i]["BasePrice"] = parseFloat(currencyRate * Price).toFixed(
              2
            );
          }
          var obj = {
            ...tempProd[i],
          };
          let variantsLength = tempPC[i].length;
          if (VendorCountry == "16") {
            for (let j = 0; j < variantsLength; j++) {
              let Price = tempPC[i][j].ProductCombinationPrice;
              if (tempPC[i][j].Currency == "$") {
                tempPC[i][j]["Currency"] = "BDT";
                tempPC[i][j]["ProductCombinationPrice"] = parseFloat(
                  currencyRate * Price
                ).toFixed(2);
              }
            }
          } else if (VendorCountry == "226") {
            for (let j = 0; j < variantsLength; j++) {
              let Price = tempPC[i][j].ProductCombinationPrice;
              if (tempPC[i][j].Currency == "BDT") {
                tempPC[i][j]["Currency"] = "$";
                tempPC[i][j]["ProductCombinationPrice"] = parseFloat(
                  currencyRate * Price
                ).toFixed(2);
              }
            }
          } else {
            for (let j = 0; j < variantsLength; j++) {
              let Price = tempPC[i][j].ProductCombinationPrice;
              tempPC[i][j]["Currency"] = "$";
              tempPC[i][j]["ProductCombinationPrice"] = parseFloat(
                currencyRate * Price
              ).toFixed(2);
            }
          }
          obj["ProductCombinations"] = tempPC[i];
          tempArray.push(obj);
        }
        for (let i = 0; i < tempArray.length; i++) {
          if (!orderName.includes(tempArray[i].OrderNumber)) {
            orderName.push(tempArray[i].OrderNumber);
            orderDate.push(tempArray[i].OrderDate);
            paymentStatus.push(tempArray[i].PaymentStatus);
            transactionID.push(tempArray[i].TransactionID);
            allowStorePickup.push(tempArray[i].AllowStorePickup);
            readyPickupForUser.push(tempArray[i].ReadyPickupForUser);
            readyPickupForAdmin.push(tempArray[i].ReadyPickupForAdmin);
            allowAdminPickup.push(tempArray[i].AllowAdminPickup);
            statusHistory.push(tempArray[i].StatusHistory);
            processStatus.push(tempArray[i].ProcessStatus);
          }
        }
        for (let i = 0; i < orderName.length; i++) {
          var obj = {
            OrderNumber: orderName[i],
            OrderDate: orderDate[i],
            PaymentStatus: paymentStatus[i],
            TransactionID: transactionID[i],
            AllowStorePickup: allowStorePickup[i],
            ReadyPickupForUser: readyPickupForUser[i],
            ReadyPickupForAdmin: readyPickupForAdmin[i],
            AllowAdminPickup: allowAdminPickup[i],
            StatusHistory: statusHistory[i],
            ProcessStatus: processStatus[i],
            ProductDetail: [],
          };
          for (let j = 0; j < tempArray.length; j++) {
            if (orderName[i] === tempArray[j].OrderNumber) {
              obj.ProductDetail.push(tempArray[j]);
            }
          }
          tempAOrderDetails.push(obj);
        }
        if (productCombinationDetail && productCombinationDetail.length > 0) {
          res.status(200).json({
            status: true,
            total_records: getCount[0].total_records,
            orderDetails: tempAOrderDetails,
          });
        } else {
          res.status(200).json({
            status: false,
            message: "Error while getting product combinations detail",
            orderDetails: [],
          });
        }
      } else {
        res.status(200).json({
          status: true,
          total_records: getCount[0].total_records,
          orderDetails: [],
        });
      }
    } else {
      res.status(200).json({
        status: true,
        total_records: getCount[0].total_records,
        orderDetails: [],
      });
    }
  } catch (err) {
    console.log(err.message);
    next(err);
    res.status(200).json({
      status: false,
      message: err.message,
      orderDetails: [],
    });
  }
};
exports.getRefundOrderDetailFree = async (req, res, next) => {
  try {
    let { limit, offset, sort, search, status } = req.body;
    let productCombinationPriceDetail = [];
    limit = parseInt(limit);
    offset = parseInt(offset);
    offset = limit * offset;
    let getCount = await connection.query(
      ` SELECT COUNT(*) as total_records  from (SELECT COUNT(OrderNumber) as total_records 
        from processorder po 
        INNER JOIN product p on p.ProductID = po.ProductID
        WHERE po.ReturnOrderStatus IS NULL AND po.ReturnReason NOT IN ('NULL','null','Refund Initiated','undefined','Refunded') AND p.FreeProductReturn="Y"
        GROUP BY po.OrderNumber )OrderNumber`,
      {
        type: QueryTypes.SELECT,
      }
    );
    console.log(getCount);
    if (getCount[0].total_records && getCount[0].total_records > 0) {
      let viewOrderListQuery = `SELECT p.ProductID,p.Title,m.TransactionID,s.OrderNumber,s.AllowStorePickup,s.AllowAdminPickup,s.ReadyPickupForUser,s.ReadyPickupForAdmin,s.OrderDate,m.PaymentStatus,p.Price AS BasePrice,s.Quantity,p.Currency,s.UserID,g.Small,g.Medium,g.Large,i.MainImage,s.StatusHistory,s.ProcessStatus,s.DeliveryDriverID,s.ConsignmentId,s.*,r.CountryID AS VendorCountry,
      pr.*,r.*,vs.*
          FROM (((((((((( product p      
          LEFT JOIN productvariantoption o ON o.ProductID IN( p.ProductID))
          LEFT JOIN productvariantoptionvalue v  ON  v.OptionID IN (o.OptionID))  
          LEFT JOIN productimage i  ON  i.OptionValueID IN (v.OptionValueID))
          LEFT JOIN imagegallery g  ON  g.ImageGalleryID IN (i.ImageGalleryID))
          LEFT JOIN productvariantcombination c  ON  c.OptionValueID IN (v.OptionValueID))
          INNER JOIN processorder s ON s.ProductID IN(c.ProductID))
          INNER JOIN processrefand pr ON pr.ProcessOrderID IN(s.ProcessOrderID))
          LEFT JOIN vendor r ON (r.VendorID= p.VendorID))
          LEFT JOIN vendorstore vs ON vs.VendorStoreID IN(s.VendorStoreID))
          LEFT JOIN processpayment m ON m.OrderNumber IN(s.OrderNumber))
          WHERE i.MainImage='Y' AND s.ReturnOrderStatus IS NULL AND p.FreeProductReturn="Y" AND s.RefundStatus="${status}" AND s.ReturnReason NOT IN ('NULL','null','undefined') AND s.OrderNumber IN (select * from (SELECT OrderNumber from processorder po
          INNER JOIN product p on p.ProductID = po.ProductID
          WHERE  po.ReturnOrderStatus IS NULL AND po.ReturnReason NOT IN ('NULL','null','undefined') AND  p.FreeProductReturn="Y" AND  po.RefundStatus="${status}" AND  po.OrderNumber LIKE "%${search}%" GROUP BY po.OrderNumber LIMIT ${limit} OFFSET ${offset} ) OrderNumber)
          GROUP BY s.ProcessOrderID
          ORDER BY s.ProcessOrderID ${sort}`;
      let viewOrderList = await connection.query(viewOrderListQuery, {
        type: QueryTypes.SELECT,
      });
      let productCombinationDetail;
      if (viewOrderList && viewOrderList.length > 0) {
        for (let i = 0; i < viewOrderList.length; i++) {
          let ProductVariantCombinationDetail = [];
          ProductVariantCombinationDetail.push(
            viewOrderList[i].ProductVariantCombinationDetail
          );
          ProductVariantCombinationDetail = `(${ProductVariantCombinationDetail.join(
            ","
          )})`;
          productCombinationDetail = await connection.query(
            `SELECT p.ProductID,c.ProductVariantCombinationID,c.VendorStoreID,c.Price AS ProductCombinationPrice,c.AvailableInventory,o.OptionID,o.OptionName,v.OptionValue,v.OptionValueID,p.Currency
              FROM ((((product p
              LEFT JOIN productvariantoption o ON o.ProductID IN( p.ProductID))
              LEFT JOIN productvariantoptionvalue v  ON  v.OptionID IN (o.OptionID)) 
              LEFT JOIN productvariantcombination c  ON  c.OptionValueID IN (v.OptionValueID))
              LEFT JOIN processorder s ON s.ProductID IN(c.ProductID))
              WHERE  c.ProductVariantCombinationID IN ${ProductVariantCombinationDetail} 
              GROUP BY c.OptionValueID
              ORDER BY s.ProcessOrderID ASC
             `,
            {
              type: QueryTypes.SELECT,
            }
          );
          productCombinationPriceDetail.push(productCombinationDetail);
        }

        let getCurrencyRates = await connection.query(
          "SELECT * FROM currencyrate",
          {
            type: QueryTypes.SELECT,
          }
        );
        let VendorCountry = viewOrderList[0].VendorCountry;
        let currencyRate;
        if (VendorCountry == "16") {
          currencyRate = getCurrencyRates[1].Rate;
        } else {
          currencyRate = getCurrencyRates[0].Rate;
        }
        let orderName = [];
        let orderDate = [];
        let paymentStatus = [];
        let transactionID = [];
        let tempPC = productCombinationPriceDetail;
        let tempProd = viewOrderList;
        let tempArray = [];
        let allowStorePickup = [];
        let readyPickupForUser = [];
        let readyPickupForAdmin = [];
        let allowAdminPickup = [];
        let statusHistory = [];
        let processStatus = [];
        let tempAOrderDetails = [];

        for (let i = 0; i < tempProd.length; i++) {
          //!cuurency conversion
          if (VendorCountry == "16") {
            let Price = tempProd[i].BasePrice;
            if (tempProd[i].Currency == "$") {
              tempProd[i]["Currency"] = "BDT";
              tempProd[i]["BasePrice"] = parseFloat(
                currencyRate * Price
              ).toFixed(2);
            }
          } else if (VendorCountry == "226") {
            let Price = tempProd[i].BasePrice;
            if (tempProd[i].Currency == "BDT") {
              tempProd[i]["Currency"] = "$";
              tempProd[i]["BasePrice"] = parseFloat(
                currencyRate * Price
              ).toFixed(2);
            }
          } else {
            let Price = tempProd[i].BasePrice;
            tempProd[i]["Currency"] = "$";
            tempProd[i]["BasePrice"] = parseFloat(currencyRate * Price).toFixed(
              2
            );
          }
          var obj = {
            ...tempProd[i],
          };
          let variantsLength = tempPC[i].length;
          if (VendorCountry == "16") {
            for (let j = 0; j < variantsLength; j++) {
              let Price = tempPC[i][j].ProductCombinationPrice;
              if (tempPC[i][j].Currency == "$") {
                tempPC[i][j]["Currency"] = "BDT";
                tempPC[i][j]["ProductCombinationPrice"] = parseFloat(
                  currencyRate * Price
                ).toFixed(2);
              }
            }
          } else if (VendorCountry == "226") {
            for (let j = 0; j < variantsLength; j++) {
              let Price = tempPC[i][j].ProductCombinationPrice;
              if (tempPC[i][j].Currency == "BDT") {
                tempPC[i][j]["Currency"] = "$";
                tempPC[i][j]["ProductCombinationPrice"] = parseFloat(
                  currencyRate * Price
                ).toFixed(2);
              }
            }
          } else {
            for (let j = 0; j < variantsLength; j++) {
              let Price = tempPC[i][j].ProductCombinationPrice;
              tempPC[i][j]["Currency"] = "$";
              tempPC[i][j]["ProductCombinationPrice"] = parseFloat(
                currencyRate * Price
              ).toFixed(2);
            }
          }
          obj["ProductCombinations"] = tempPC[i];
          tempArray.push(obj);
        }
        for (let i = 0; i < tempArray.length; i++) {
          if (!orderName.includes(tempArray[i].OrderNumber)) {
            orderName.push(tempArray[i].OrderNumber);
            orderDate.push(tempArray[i].OrderDate);
            paymentStatus.push(tempArray[i].PaymentStatus);
            transactionID.push(tempArray[i].TransactionID);
            allowStorePickup.push(tempArray[i].AllowStorePickup);
            readyPickupForUser.push(tempArray[i].ReadyPickupForUser);
            readyPickupForAdmin.push(tempArray[i].ReadyPickupForAdmin);
            allowAdminPickup.push(tempArray[i].AllowAdminPickup);
            statusHistory.push(tempArray[i].StatusHistory);
            processStatus.push(tempArray[i].ProcessStatus);
          }
        }
        for (let i = 0; i < orderName.length; i++) {
          var obj = {
            OrderNumber: orderName[i],
            OrderDate: orderDate[i],
            PaymentStatus: paymentStatus[i],
            TransactionID: transactionID[i],
            AllowStorePickup: allowStorePickup[i],
            ReadyPickupForUser: readyPickupForUser[i],
            ReadyPickupForAdmin: readyPickupForAdmin[i],
            AllowAdminPickup: allowAdminPickup[i],
            StatusHistory: statusHistory[i],
            ProcessStatus: processStatus[i],
            ProductDetail: [],
          };
          for (let j = 0; j < tempArray.length; j++) {
            if (orderName[i] === tempArray[j].OrderNumber) {
              obj.ProductDetail.push(tempArray[j]);
            }
          }
          tempAOrderDetails.push(obj);
        }
        if (productCombinationDetail && productCombinationDetail.length > 0) {
          res.status(200).json({
            status: true,
            total_records: getCount[0].total_records,
            orderDetails: tempAOrderDetails,
          });
        } else {
          res.status(200).json({
            status: false,
            message: "Error while getting product combinations detail",
            orderDetails: [],
          });
        }
      } else {
        res.status(200).json({
          status: true,
          total_records: getCount[0].total_records,
          orderDetails: [],
        });
      }
    } else {
      res.status(200).json({
        status: true,
        total_records: getCount[0].total_records,
        orderDetails: [],
      });
    }
  } catch (err) {
    console.log(err.message);
    next(err);
    res.status(200).json({
      status: false,
      message: err.message,
      orderDetails: [],
    });
  }
};
exports.getRefundOrderDetailPaid = async (req, res, next) => {
  try {
    let { limit, offset, sort, search, status } = req.body;
    let productCombinationPriceDetail = [];
    limit = parseInt(limit);
    offset = parseInt(offset);
    offset = limit * offset;
    let getCount = await connection.query(
      ` SELECT COUNT(*) as total_records  from (SELECT COUNT(OrderNumber) as total_records 
        from processorder po 
        INNER JOIN product p on p.ProductID = po.ProductID
        WHERE po.ReturnOrderStatus IS NULL AND po.ReturnReason NOT IN ('NULL','null','Refund Initiated','undefined','Refunded') AND p.FreeProductReturn="N"
        GROUP BY po.OrderNumber )OrderNumber`,
      {
        type: QueryTypes.SELECT,
      }
    );
    console.log(getCount);
    if (getCount[0].total_records && getCount[0].total_records > 0) {
      let viewOrderListQuery = `SELECT p.ProductID,p.Title,m.TransactionID,s.OrderNumber,s.AllowStorePickup,s.AllowAdminPickup,s.ReadyPickupForUser,s.ReadyPickupForAdmin,s.OrderDate,m.PaymentStatus,p.Price AS BasePrice,s.Quantity,p.Currency,s.UserID,g.Small,g.Medium,g.Large,i.MainImage,s.StatusHistory,s.ProcessStatus,s.DeliveryDriverID,s.ConsignmentId,s.*,r.CountryID AS VendorCountry,
      pr.*,r.*,vs.*
          FROM (((((((((( product p      
          LEFT JOIN productvariantoption o ON o.ProductID IN( p.ProductID))
          LEFT JOIN productvariantoptionvalue v  ON  v.OptionID IN (o.OptionID))  
          LEFT JOIN productimage i  ON  i.OptionValueID IN (v.OptionValueID))
          LEFT JOIN imagegallery g  ON  g.ImageGalleryID IN (i.ImageGalleryID))
          LEFT JOIN productvariantcombination c  ON  c.OptionValueID IN (v.OptionValueID))
          INNER JOIN processorder s ON s.ProductID IN(c.ProductID))
          INNER JOIN processrefand pr ON pr.ProcessOrderID IN(s.ProcessOrderID))
          LEFT JOIN vendor r ON (r.VendorID= p.VendorID))
          LEFT JOIN vendorstore vs ON vs.VendorStoreID IN(s.VendorStoreID))
          LEFT JOIN processpayment m ON m.OrderNumber IN(s.OrderNumber))
          WHERE i.MainImage='Y' AND s.ReturnOrderStatus IS NULL AND  p.FreeProductReturn="N" AND s.RefundStatus="${status}" AND s.ReturnReason NOT IN ('NULL','null','undefined') AND s.OrderNumber IN (select * from (SELECT OrderNumber from processorder po
          INNER JOIN product p on p.ProductID = po.ProductID
          WHERE  po.ReturnOrderStatus IS NULL AND po.ReturnReason NOT IN ('NULL','null','undefined') AND  p.FreeProductReturn="N" AND  po.RefundStatus="${status}" AND  po.OrderNumber LIKE "%${search}%" GROUP BY po.OrderNumber LIMIT ${limit} OFFSET ${offset} ) OrderNumber)
          GROUP BY s.ProcessOrderID
          ORDER BY s.ProcessOrderID ${sort}`;
      let viewOrderList = await connection.query(viewOrderListQuery, {
        type: QueryTypes.SELECT,
      });
      let productCombinationDetail;
      if (viewOrderList && viewOrderList.length > 0) {
        for (let i = 0; i < viewOrderList.length; i++) {
          let ProductVariantCombinationDetail = [];
          ProductVariantCombinationDetail.push(
            viewOrderList[i].ProductVariantCombinationDetail
          );
          ProductVariantCombinationDetail = `(${ProductVariantCombinationDetail.join(
            ","
          )})`;
          productCombinationDetail = await connection.query(
            `SELECT p.ProductID,c.ProductVariantCombinationID,c.VendorStoreID,c.Price AS ProductCombinationPrice,c.AvailableInventory,o.OptionID,o.OptionName,v.OptionValue,v.OptionValueID,p.Currency
              FROM ((((product p
              LEFT JOIN productvariantoption o ON o.ProductID IN( p.ProductID))
              LEFT JOIN productvariantoptionvalue v  ON  v.OptionID IN (o.OptionID)) 
              LEFT JOIN productvariantcombination c  ON  c.OptionValueID IN (v.OptionValueID))
              LEFT JOIN processorder s ON s.ProductID IN(c.ProductID))
              WHERE  c.ProductVariantCombinationID IN ${ProductVariantCombinationDetail} 
              GROUP BY c.OptionValueID
              ORDER BY s.ProcessOrderID ASC
             `,
            {
              type: QueryTypes.SELECT,
            }
          );
          productCombinationPriceDetail.push(productCombinationDetail);
        }

        let getCurrencyRates = await connection.query(
          "SELECT * FROM currencyrate",
          {
            type: QueryTypes.SELECT,
          }
        );
        let VendorCountry = viewOrderList[0].VendorCountry;
        let currencyRate;
        if (VendorCountry == "16") {
          currencyRate = getCurrencyRates[1].Rate;
        } else {
          currencyRate = getCurrencyRates[0].Rate;
        }
        let orderName = [];
        let orderDate = [];
        let paymentStatus = [];
        let transactionID = [];
        let tempPC = productCombinationPriceDetail;
        let tempProd = viewOrderList;
        let tempArray = [];
        let allowStorePickup = [];
        let readyPickupForUser = [];
        let readyPickupForAdmin = [];
        let allowAdminPickup = [];
        let statusHistory = [];
        let processStatus = [];
        let tempAOrderDetails = [];

        for (let i = 0; i < tempProd.length; i++) {
          //!cuurency conversion
          if (VendorCountry == "16") {
            let Price = tempProd[i].BasePrice;
            if (tempProd[i].Currency == "$") {
              tempProd[i]["Currency"] = "BDT";
              tempProd[i]["BasePrice"] = parseFloat(
                currencyRate * Price
              ).toFixed(2);
            }
          } else if (VendorCountry == "226") {
            let Price = tempProd[i].BasePrice;
            if (tempProd[i].Currency == "BDT") {
              tempProd[i]["Currency"] = "$";
              tempProd[i]["BasePrice"] = parseFloat(
                currencyRate * Price
              ).toFixed(2);
            }
          } else {
            let Price = tempProd[i].BasePrice;
            tempProd[i]["Currency"] = "$";
            tempProd[i]["BasePrice"] = parseFloat(currencyRate * Price).toFixed(
              2
            );
          }
          var obj = {
            ...tempProd[i],
          };
          let variantsLength = tempPC[i].length;
          if (VendorCountry == "16") {
            for (let j = 0; j < variantsLength; j++) {
              let Price = tempPC[i][j].ProductCombinationPrice;
              if (tempPC[i][j].Currency == "$") {
                tempPC[i][j]["Currency"] = "BDT";
                tempPC[i][j]["ProductCombinationPrice"] = parseFloat(
                  currencyRate * Price
                ).toFixed(2);
              }
            }
          } else if (VendorCountry == "226") {
            for (let j = 0; j < variantsLength; j++) {
              let Price = tempPC[i][j].ProductCombinationPrice;
              if (tempPC[i][j].Currency == "BDT") {
                tempPC[i][j]["Currency"] = "$";
                tempPC[i][j]["ProductCombinationPrice"] = parseFloat(
                  currencyRate * Price
                ).toFixed(2);
              }
            }
          } else {
            for (let j = 0; j < variantsLength; j++) {
              let Price = tempPC[i][j].ProductCombinationPrice;
              tempPC[i][j]["Currency"] = "$";
              tempPC[i][j]["ProductCombinationPrice"] = parseFloat(
                currencyRate * Price
              ).toFixed(2);
            }
          }
          obj["ProductCombinations"] = tempPC[i];
          tempArray.push(obj);
        }
        for (let i = 0; i < tempArray.length; i++) {
          if (!orderName.includes(tempArray[i].OrderNumber)) {
            orderName.push(tempArray[i].OrderNumber);
            orderDate.push(tempArray[i].OrderDate);
            paymentStatus.push(tempArray[i].PaymentStatus);
            transactionID.push(tempArray[i].TransactionID);
            allowStorePickup.push(tempArray[i].AllowStorePickup);
            readyPickupForUser.push(tempArray[i].ReadyPickupForUser);
            readyPickupForAdmin.push(tempArray[i].ReadyPickupForAdmin);
            allowAdminPickup.push(tempArray[i].AllowAdminPickup);
            statusHistory.push(tempArray[i].StatusHistory);
            processStatus.push(tempArray[i].ProcessStatus);
          }
        }
        for (let i = 0; i < orderName.length; i++) {
          var obj = {
            OrderNumber: orderName[i],
            OrderDate: orderDate[i],
            PaymentStatus: paymentStatus[i],
            TransactionID: transactionID[i],
            AllowStorePickup: allowStorePickup[i],
            ReadyPickupForUser: readyPickupForUser[i],
            ReadyPickupForAdmin: readyPickupForAdmin[i],
            AllowAdminPickup: allowAdminPickup[i],
            StatusHistory: statusHistory[i],
            ProcessStatus: processStatus[i],
            ProductDetail: [],
          };
          for (let j = 0; j < tempArray.length; j++) {
            if (orderName[i] === tempArray[j].OrderNumber) {
              obj.ProductDetail.push(tempArray[j]);
            }
          }
          tempAOrderDetails.push(obj);
        }
        if (productCombinationDetail && productCombinationDetail.length > 0) {
          res.status(200).json({
            status: true,
            total_records: getCount[0].total_records,
            orderDetails: tempAOrderDetails,
          });
        } else {
          res.status(200).json({
            status: false,
            message: "Error while getting product combinations detail",
            orderDetails: [],
          });
        }
      } else {
        res.status(200).json({
          status: true,
          total_records: getCount[0].total_records,
          orderDetails: [],
        });
      }
    } else {
      res.status(200).json({
        status: true,
        total_records: getCount[0].total_records,
        orderDetails: [],
      });
    }
  } catch (err) {
    console.log(err.message);
    next(err);
    res.status(200).json({
      status: false,
      message: err.message,
      orderDetails: [],
    });
  }
};
exports.changeOrderStatuses = async (req, res, next) => {
  try {
    const { type, status, OrderNumber, ConsignmentId, DeliveryDriverID } =
      req.body;
    let LastUpdate = new Date().toISOString().slice(0, 19).replace("T", " ");
    if (type == "0") {
      let getOrderDetail = await connection.query(
        `SELECT * from processorder  WHERE  OrderNumber="${OrderNumber}" AND DeliveryDriverID="${DeliveryDriverID}" `,
        {
          type: QueryTypes.SELECT,
        }
      );
      if (getOrderDetail && getOrderDetail.length > 0) {
        let changeOrderStatus = await connection.query(
          `UPDATE processorder SET ProcessStatus="${status}", LastUpdate="${LastUpdate}" WHERE OrderNumber="${OrderNumber}" AND DeliveryDriverID="${DeliveryDriverID}" `
        );
        if (changeOrderStatus) {
          res.status(200).json({
            status: true,
            message: "Order Status Updated Sucessfully ",
          });
        } else {
          res.status(200).json({
            status: false,
            message: "Error while updating order status ",
          });
        }
      } else {
        res.status(200).json({
          status: false,
          message: "No record found to update against this data ",
        });
      }
    }
    if (type == "1") {
      let getOrderDetail = await connection.query(
        `SELECT * from processorder  WHERE OrderNumber="${OrderNumber}" AND ConsignmentId="${ConsignmentId}" `,
        {
          type: QueryTypes.SELECT,
        }
      );
      if (getOrderDetail && getOrderDetail.length > 0) {
        let changeOrderStatus = await connection.query(
          `UPDATE processorder SET ProcessStatus="${status}", LastUpdate="${LastUpdate}" WHERE OrderNumber="${OrderNumber}" AND ConsignmentId="${ConsignmentId}" `
        );
        if (changeOrderStatus) {
          res.status(200).json({
            status: true,
            message: "Order Status Updated Sucessfully ",
          });
        } else {
          res.status(200).json({
            status: false,
            message: "Error while updating order status ",
          });
        }
      } else {
        res.status(200).json({
          status: false,
          message: "No record found to update against this data ",
        });
      }
    }
    if (type == "2") {
      let getOrderDetail = await connection.query(
        `SELECT * from processorder  WHERE OrderNumber="${OrderNumber}" AND ReadyPickupForUser="Y" `,
        {
          type: QueryTypes.SELECT,
        }
      );
      if (getOrderDetail && getOrderDetail.length > 0) {
        let changeOrderStatus = await connection.query(
          `UPDATE processorder SET ProcessStatus="${status}", LastUpdate="${LastUpdate}",DeliveryDate="${LastUpdate}" WHERE OrderNumber="${OrderNumber}" AND ReadyPickupForUser="Y" `
        );
        if (changeOrderStatus && changeOrderStatus.length > 0) {
          res.status(200).json({
            status: true,
            message: "Order Status Updated Sucessfully ",
          });
        } else {
          res.status(200).json({
            status: false,
            message: "Error while updating order status ",
          });
        }
      } else {
        res.status(200).json({
          status: false,
          message: "No record found to update against this data ",
        });
      }
    }
  } catch (err) {
    next(err);
    res.status(200).json({
      status: false,
      error: err.message,
    });
  }
};
exports.notifyUser = async (req, res, next) => {
  let transaction;
  try {
    const { senderID, receiverID } = req.body;
    transaction = await connection.transaction();

    let getUserName = await connection.query(
      `SELECT UserName
      FROM profile WHERE UserID="${senderID}"`,
      {
        type: QueryTypes.SELECT,
        transaction,
      }
    );
    if (getUserName && getUserName.length > 0) {
      let UserName = getUserName[0].UserName;

      let TypeID = "3";
      let Body = {
        body: `You have a new message from ${UserName} `,
      };
      let sendNotification = await Notification(
        TypeID,
        Body,
        senderID,
        receiverID,
        transaction
      );
      if (sendNotification) {
        if (transaction) await transaction.commit(); //!final commit
        res.status(200).json({
          status: true,
          message: "User Notify Succesfully",
        });
      } else {
        if (transaction) await transaction.rollback();
        res.status(200).json({
          status: false,
          message: "Error while sending Notification to User ",
        });
      }
    } else {
      if (transaction) await transaction.rollback();
      res.status(200).json({
        status: false,
        message: "Error while getting Username ",
      });
    }
  } catch (err) {
    console.log(err.message);
    if (transaction) await transaction.rollback();
    res.status(200).json({
      status: false,
      error: err.message,
    });
  }
};
exports.getRefundOrderDetailByOrderID = async (req, res, next) => {
  try {
    const OrderNumber = req.params.id;
    const type = req.params.type;
    let productCombinationPriceDetail = [];
    let viewOrderListQuery = `SELECT p.ProductID,p.Title,m.TransactionID,s.OrderNumber,s.AllowStorePickup,s.AllowAdminPickup,s.ReadyPickupForUser,s.ReadyPickupForAdmin,s.OrderDate,m.PaymentStatus,p.Price AS BasePrice,s.Quantity,p.Currency,s.UserID,g.Small,g.Medium,g.Large,i.MainImage,s.StatusHistory,s.ProcessStatus,s.DeliveryDriverID,s.ConsignmentId,s.*,r.CountryID AS VendorCountry,p.FreeProductReturn,
      (SELECT COUNT(t.ProductID)
      from productreviewrating t WHERE t.ProductID = p.ProductID) AS REVIEW_COUNT,
      (SELECT AVG(t.Rating) from productreviewrating t WHERE t.ProductID = p.ProductID) AS  AVG_Rating
          FROM (((((((( product p      
          LEFT JOIN productvariantoption o ON o.ProductID IN( p.ProductID))
          LEFT JOIN productvariantoptionvalue v  ON  v.OptionID IN (o.OptionID))  
          LEFT JOIN productimage i  ON  i.OptionValueID IN (v.OptionValueID))
          LEFT JOIN imagegallery g  ON  g.ImageGalleryID IN (i.ImageGalleryID))
          LEFT JOIN productvariantcombination c  ON  c.OptionValueID IN (v.OptionValueID))
          INNER JOIN processorder s ON s.ProductID IN(c.ProductID))
          LEFT JOIN vendor r ON (r.VendorID= p.VendorID))
          LEFT JOIN processpayment m ON m.OrderNumber IN(s.OrderNumber))
          WHERE i.MainImage='Y' AND p.RefundStatus="Processing" AND p.FreeProductReturn="${type}" AND s.OrderNumber="${OrderNumber}" AND s.ReturnReason NOT IN ('NULL','null','undefined','Refunded')
          GROUP BY s.ProcessOrderID
          ORDER BY s.ProcessOrderID ASC`;
    let viewOrderList = await connection.query(viewOrderListQuery, {
      type: QueryTypes.SELECT,
    });
    let productCombinationDetail;
    if (viewOrderList && viewOrderList.length > 0) {
      for (let i = 0; i < viewOrderList.length; i++) {
        let ProductVariantCombinationDetail = [];
        ProductVariantCombinationDetail.push(
          viewOrderList[i].ProductVariantCombinationDetail
        );
        ProductVariantCombinationDetail = `(${ProductVariantCombinationDetail.join(
          ","
        )})`;
        productCombinationDetail = await connection.query(
          `SELECT p.ProductID,c.ProductVariantCombinationID,c.VendorStoreID,c.Price AS ProductCombinationPrice,c.AvailableInventory,o.OptionID,o.OptionName,v.OptionValue,v.OptionValueID,p.Currency
              FROM ((((product p
              LEFT JOIN productvariantoption o ON o.ProductID IN( p.ProductID))
              LEFT JOIN productvariantoptionvalue v  ON  v.OptionID IN (o.OptionID)) 
              LEFT JOIN productvariantcombination c  ON  c.OptionValueID IN (v.OptionValueID))
              LEFT JOIN processorder s ON s.ProductID IN(c.ProductID))
              WHERE  c.ProductVariantCombinationID IN ${ProductVariantCombinationDetail} 
              GROUP BY c.OptionValueID
              ORDER BY s.ProcessOrderID ASC
             `,
          {
            type: QueryTypes.SELECT,
          }
        );
        productCombinationPriceDetail.push(productCombinationDetail);
      }

      let getCurrencyRates = await connection.query(
        "SELECT * FROM currencyrate",
        {
          type: QueryTypes.SELECT,
        }
      );
      let VendorCountry = viewOrderList[0].VendorCountry;
      let currencyRate;
      if (VendorCountry == "16") {
        currencyRate = getCurrencyRates[1].Rate;
      } else {
        currencyRate = getCurrencyRates[0].Rate;
      }
      let orderName = [];
      let orderDate = [];
      let paymentStatus = [];
      let transactionID = [];
      let tempPC = productCombinationPriceDetail;
      let tempProd = viewOrderList;
      let tempArray = [];
      let allowStorePickup = [];
      let readyPickupForUser = [];
      let readyPickupForAdmin = [];
      let allowAdminPickup = [];
      let statusHistory = [];
      let processStatus = [];
      let tempAOrderDetails = [];

      for (let i = 0; i < tempProd.length; i++) {
        //!cuurency conversion
        if (VendorCountry == "16") {
          let Price = tempProd[i].BasePrice;
          if (tempProd[i].Currency == "$") {
            tempProd[i]["Currency"] = "BDT";
            tempProd[i]["BasePrice"] = parseFloat(currencyRate * Price).toFixed(
              2
            );
          }
        } else if (VendorCountry == "226") {
          let Price = tempProd[i].BasePrice;
          if (tempProd[i].Currency == "BDT") {
            tempProd[i]["Currency"] = "$";
            tempProd[i]["BasePrice"] = parseFloat(currencyRate * Price).toFixed(
              2
            );
          }
        } else {
          let Price = tempProd[i].BasePrice;
          tempProd[i]["Currency"] = "$";
          tempProd[i]["BasePrice"] = parseFloat(currencyRate * Price).toFixed(
            2
          );
        }
        var obj = {
          ...tempProd[i],
        };
        let variantsLength = tempPC[i].length;
        if (VendorCountry == "16") {
          for (let j = 0; j < variantsLength; j++) {
            let Price = tempPC[i][j].ProductCombinationPrice;
            if (tempPC[i][j].Currency == "$") {
              tempPC[i][j]["Currency"] = "BDT";
              tempPC[i][j]["ProductCombinationPrice"] = parseFloat(
                currencyRate * Price
              ).toFixed(2);
            }
          }
        } else if (VendorCountry == "226") {
          for (let j = 0; j < variantsLength; j++) {
            let Price = tempPC[i][j].ProductCombinationPrice;
            if (tempPC[i][j].Currency == "BDT") {
              tempPC[i][j]["Currency"] = "$";
              tempPC[i][j]["ProductCombinationPrice"] = parseFloat(
                currencyRate * Price
              ).toFixed(2);
            }
          }
        } else {
          for (let j = 0; j < variantsLength; j++) {
            let Price = tempPC[i][j].ProductCombinationPrice;
            tempPC[i][j]["Currency"] = "$";
            tempPC[i][j]["ProductCombinationPrice"] = parseFloat(
              currencyRate * Price
            ).toFixed(2);
          }
        }
        obj["ProductCombinations"] = tempPC[i];
        tempArray.push(obj);
      }
      for (let i = 0; i < tempArray.length; i++) {
        if (!orderName.includes(tempArray[i].OrderNumber)) {
          orderName.push(tempArray[i].OrderNumber);
          orderDate.push(tempArray[i].OrderDate);
          paymentStatus.push(tempArray[i].PaymentStatus);
          transactionID.push(tempArray[i].TransactionID);
          allowStorePickup.push(tempArray[i].AllowStorePickup);
          readyPickupForUser.push(tempArray[i].ReadyPickupForUser);
          readyPickupForAdmin.push(tempArray[i].ReadyPickupForAdmin);
          allowAdminPickup.push(tempArray[i].AllowAdminPickup);
          statusHistory.push(tempArray[i].StatusHistory);
          processStatus.push(tempArray[i].ProcessStatus);
        }
      }
      for (let i = 0; i < orderName.length; i++) {
        var obj = {
          OrderNumber: orderName[i],
          OrderDate: orderDate[i],
          PaymentStatus: paymentStatus[i],
          TransactionID: transactionID[i],
          AllowStorePickup: allowStorePickup[i],
          ReadyPickupForUser: readyPickupForUser[i],
          ReadyPickupForAdmin: readyPickupForAdmin[i],
          AllowAdminPickup: allowAdminPickup[i],
          StatusHistory: statusHistory[i],
          ProcessStatus: processStatus[i],
          ProductDetail: [],
        };
        for (let j = 0; j < tempArray.length; j++) {
          if (orderName[i] === tempArray[j].OrderNumber) {
            obj.ProductDetail.push(tempArray[j]);
          }
        }
        tempAOrderDetails.push(obj);
      }
      if (productCombinationDetail && productCombinationDetail.length > 0) {
        res.status(200).json({
          status: true,
          orderDetails: tempAOrderDetails[0],
        });
      } else {
        res.status(200).json({
          status: false,
          orderDetails: [],
        });
      }
    } else {
      res.status(200).json({
        status: true,
        orderDetails: [],
      });
    }
  } catch (err) {
    console.log(err.message);
    next(err);
    res.status(200).json({
      status: false,
      orderDetails: [],
    });
  }
};
exports.shippingByVendorOrders = async (req, res, next) => {
  try {
    let { limit, offset, sort, search } = req.body;
    let VendorID = req.UserID;
    let productCombinationPriceDetail = [];
    let getProcessOrderDetails = await connection.query(
      `SELECT COUNT(DISTINCT OrderNumber) AS total_records
         FROM processorder o
         LEFT JOIN product p ON o.ProductID= p.ProductID
         LEFT JOIN vendor v ON v.VendorID= p.VendorID
         WHERE o.DeliveryStatus="VS" AND p.VendorID="${VendorID}"
     `,
      {
        type: QueryTypes.SELECT,
      }
    );
    if (
      getProcessOrderDetails[0].total_records &&
      getProcessOrderDetails[0].total_records > 0
    ) {
      let viewOrderListQuery = `SELECT p.ProductID,p.Title,m.TransactionID,s.OrderNumber,s.AllowStorePickup,s.AllowAdminPickup,s.ReadyPickupForUser,s.ReadyPickupForAdmin,s.OrderDate,m.PaymentStatus,p.Price AS BasePrice,s.Quantity,p.Currency,s.UserID,g.Small,g.Medium,g.Large,i.MainImage,s.StatusHistory,s.ProcessStatus,s.DeliveryDriverID,s.ConsignmentId,r.CountryID AS VendorCountry,s.ProductVariantCombinationDetail,
      (SELECT COUNT(t.ProductID)
      from productreviewrating t WHERE t.ProductID = p.ProductID) AS REVIEW_COUNT,
      (SELECT AVG(t.Rating) from productreviewrating t WHERE t.ProductID = p.ProductID) AS  AVG_Rating
          FROM (((((((( product p      
          LEFT JOIN productvariantoption o ON o.ProductID IN( p.ProductID))
          LEFT JOIN productvariantoptionvalue v  ON  v.OptionID IN (o.OptionID))  
          LEFT JOIN productimage i  ON  i.OptionValueID IN (v.OptionValueID))
          LEFT JOIN imagegallery g  ON  g.ImageGalleryID IN (i.ImageGalleryID))
          LEFT JOIN productvariantcombination c  ON  c.OptionValueID IN (v.OptionValueID))
          LEFT JOIN processorder s ON s.ProductID IN(c.ProductID))
          LEFT JOIN vendor r ON (r.VendorID= p.VendorID))
          LEFT JOIN processpayment m ON m.OrderNumber IN(s.OrderNumber))
          WHERE i.MainImage='Y' AND s.DeliveryStatus="VS" AND p.VendorID="${VendorID}" AND s.OrderNumber IN 
          (select * from (SELECT OrderNumber 
          FROM processorder o
          LEFT JOIN product p ON o.ProductID= p.ProductID
          LEFT JOIN vendor v ON v.VendorID= p.VendorID
          WHERE o.DeliveryStatus="VS" AND p.VendorID="${VendorID}" AND OrderNumber LIKE "%${search}%" 
          GROUP BY OrderNumber 
          ORDER BY ProcessOrderID ${sort} 
          LIMIT ${limit} OFFSET ${offset} ) OrderNumber)
          GROUP BY s.ProcessOrderID 
          ORDER BY s.ProcessOrderID ${sort} `;
      let viewOrderList = await connection.query(viewOrderListQuery, {
        type: QueryTypes.SELECT,
      });
      console.log(viewOrderList.length);
      //console.log(viewOrderList,"viewOrderList")

      // let productCombinationDetail;
      if (viewOrderList && viewOrderList.length > 0) {
        for (let i = 0; i < viewOrderList.length; i++) {
          let ProductVariantCombinationDetail = [];
          ProductVariantCombinationDetail.push(
            viewOrderList[i].ProductVariantCombinationDetail
          );
          ProductVariantCombinationDetail = `(${ProductVariantCombinationDetail.join(
            ","
          )})`;
          productCombinationDetail = await connection.query(
            `SELECT p.ProductID,c.ProductVariantCombinationID,c.VendorStoreID,c.Price AS ProductCombinationPrice,c.AvailableInventory,o.OptionID,o.OptionName,v.OptionValue,v.OptionValueID,p.Currency
              FROM ((((product p
              LEFT JOIN productvariantoption o ON o.ProductID IN( p.ProductID))
              LEFT JOIN productvariantoptionvalue v  ON  v.OptionID IN (o.OptionID)) 
              LEFT JOIN productvariantcombination c  ON  c.OptionValueID IN (v.OptionValueID))
              LEFT JOIN processorder s ON s.ProductID IN(c.ProductID))
              WHERE  c.ProductVariantCombinationID IN ${ProductVariantCombinationDetail} 
              GROUP BY c.OptionValueID
             `,
            {
              type: QueryTypes.SELECT,
            }
          );
          productCombinationPriceDetail.push(productCombinationDetail);
        }
        let VendorCountry = getProcessOrderDetails[0].VendorCountry;
        let currencyRate;
        let getCurrencyRates = await connection.query(
          "SELECT * FROM currencyrate",
          {
            type: QueryTypes.SELECT,
          }
        );
        if (VendorCountry == "16") {
          currencyRate = getCurrencyRates[1].Rate;
        } else {
          currencyRate = getCurrencyRates[0].Rate;
        }
        let orderName = [];
        let orderDate = [];
        let paymentStatus = [];
        let transactionID = [];
        let tempPC = productCombinationPriceDetail;
        let tempProd = viewOrderList;
        let tempArray = [];
        let allowStorePickup = [];
        let readyPickupForUser = [];
        let readyPickupForAdmin = [];
        let allowAdminPickup = [];
        let statusHistory = [];
        let processStatus = [];
        var arr = [];
        let tempAOrderDetails = [];
        for (let i = 0; i < tempProd.length; i++) {
          //!cuurency conversion
          if (VendorCountry == "16") {
            let Price = tempProd[i].BasePrice;
            if (tempProd[i].Currency == "$") {
              tempProd[i]["Currency"] = "BDT";
              tempProd[i]["BasePrice"] = parseFloat(
                currencyRate * Price
              ).toFixed(2);
            }
          } else if (VendorCountry == "226") {
            let Price = tempProd[i].BasePrice;
            if (tempProd[i].Currency == "BDT") {
              tempProd[i]["Currency"] = "$";
              tempProd[i]["BasePrice"] = parseFloat(
                currencyRate * Price
              ).toFixed(2);
            }
          } else {
            let Price = tempProd[i].BasePrice;
            tempProd[i]["Currency"] = "$";
            tempProd[i]["BasePrice"] = parseFloat(currencyRate * Price).toFixed(
              2
            );
          }
          var obj = {
            ...tempProd[i],
          };
          let variantsLength = tempPC[i].length;
          if (VendorCountry == "16") {
            for (let j = 0; j < variantsLength; j++) {
              let Price = tempPC[i][j].ProductCombinationPrice;
              if (tempPC[i][j].Currency == "$") {
                tempPC[i][j]["Currency"] = "BDT";
                tempPC[i][j]["ProductCombinationPrice"] = parseFloat(
                  currencyRate * Price
                ).toFixed(2);
              }
            }
          } else if (VendorCountry == "226") {
            for (let j = 0; j < variantsLength; j++) {
              let Price = tempPC[i][j].ProductCombinationPrice;
              if (tempPC[i][j].Currency == "BDT") {
                tempPC[i][j]["Currency"] = "$";
                tempPC[i][j]["ProductCombinationPrice"] = parseFloat(
                  currencyRate * Price
                ).toFixed(2);
              }
            }
          } else {
            for (let j = 0; j < variantsLength; j++) {
              let Price = tempPC[i][j].ProductCombinationPrice;
              tempPC[i][j]["Currency"] = "$";
              tempPC[i][j]["ProductCombinationPrice"] = parseFloat(
                currencyRate * Price
              ).toFixed(2);
            }
          }
          obj["ProductCombinations"] = tempPC[i];
          tempArray.push(obj);
        }
        for (let i = 0; i < tempArray.length; i++) {
          if (!orderName.includes(tempArray[i].OrderNumber)) {
            orderName.push(tempArray[i].OrderNumber);
            orderDate.push(tempArray[i].OrderDate);
            paymentStatus.push(tempArray[i].PaymentStatus);
            transactionID.push(tempArray[i].TransactionID);
            allowStorePickup.push(tempArray[i].AllowStorePickup);
            readyPickupForUser.push(tempArray[i].ReadyPickupForUser);
            readyPickupForAdmin.push(tempArray[i].ReadyPickupForAdmin);
            allowAdminPickup.push(tempArray[i].AllowAdminPickup);
            statusHistory.push(tempArray[i].StatusHistory);
            processStatus.push(tempArray[i].ProcessStatus);
          }
        }
        for (let i = 0; i < orderName.length; i++) {
          var obj = {
            OrderNumber: orderName[i],
            OrderDate: orderDate[i],
            PaymentStatus: paymentStatus[i],
            TransactionID: transactionID[i],
            AllowStorePickup: allowStorePickup[i],
            ReadyPickupForUser: readyPickupForUser[i],
            ReadyPickupForAdmin: readyPickupForAdmin[i],
            AllowAdminPickup: allowAdminPickup[i],
            StatusHistory: statusHistory[i],
            ProcessStatus: processStatus[i],
            ProductDetail: [],
          };
          for (let j = 0; j < tempArray.length; j++) {
            if (orderName[i] === tempArray[j].OrderNumber) {
              obj.ProductDetail.push(tempArray[j]);
            }
          }
          tempAOrderDetails.push(obj);
        }
        if (productCombinationDetail && productCombinationDetail.length > 0) {
          orderShippingDetail = await connection.query(
            `SELECT o.ID AS DeliveryAddressID,o.OrderNumber,o.Name AS DeliveryName,o.PhoneNumber AS DeliveryPhoneNumber,o.Address1 AS DeliveryAddress1,o.Address2 AS DeliveryAddress2,o.City AS DeliveryCity,o.State AS DeliveryState,o.CountryID AS DeliveryCountryID,c.Country AS DeliveryCountry,o.ZipCode AS DeliveryZipCode,o.DesireDate,o.UserNote AS DeliveryUserNote,s.*
            FROM processorder p 
            INNER JOIN orderdeliveryaddress o ON o.OrderNumber = p.OrderNumber
            INNER JOIN country c ON c.CountryID = o.CountryID
            LEFT JOIN vendorstore s ON s.VendorStoreID = p.VendorStoreID
            WHERE p.DeliveryStatus="VS" AND s.VendorID="${VendorID}"
           `,
            {
              type: QueryTypes.SELECT,
            }
          );
          if (orderShippingDetail && orderShippingDetail.length > 0) {
            res.status(200).json({
              status: true,
              total_records: getProcessOrderDetails[0].total_records,
              orderDetails: tempAOrderDetails,
              orderShippingDetail: orderShippingDetail[0],
            });
          } else {
            res.status(200).json({
              total_records: getProcessOrderDetails[0].total_records,
              status: true,
              orderDetails: tempAOrderDetails,
              orderShippingDetail: orderShippingDetail[0],
            });
          }
        } else {
          res.status(200).json({
            status: false,
            total_records: null,
            orderDetails: null,
            orderShippingDetail: null,
          });
        }
      } else {
        res.status(200).json({
          status: true,
          total_records: getProcessOrderDetails[0].total_records,
          orderDetails: [],
          orderShippingDetail: [],
        });
      }
    } else {
      res.status(200).json({
        status: true,
        total_records: getProcessOrderDetails[0].total_records,
        orderDetails: [],
        orderShippingDetail: [],
      });
    }
  } catch (err) {
    console.log(err.message);
    next(err);
    res.status(200).json({
      status: false,
      total_records: null,
      orderDetails: null,
      orderShippingDetail: null,
    });
  }
};
//! PaytoVendor Api's
exports.getOrderByVendorPaymentStatusOld = async (req, res, next) => {
  try {
    const { sort, search, limit, offset, Status } = req.body;

    let productCombinationPriceDetail = [];
    let ordersCount = await connection.query(
      `SELECT COUNT(DISTINCT OrderNumber) as total_records
      FROM processorder WHERE ProcessStatus="Delivered" AND DeliveryDate < DATE_SUB(NOW(), INTERVAL 30 DAY) 
 `,
      {
        type: QueryTypes.SELECT,
      }
    );
    // IFNULL(y.ShippingCostVendorCity, u.ShippingCostVendorCountry) AS ShippingCostVendor
    console.log(ordersCount);
    if (ordersCount[0].total_records && ordersCount[0].total_records > 0) {
      // let CURRENT_DATE = new Date().toISOString().slice(0, 19).replace("T", " ");
      let viewOrderListQuery =
        `SELECT IFNULL(y.ShippingCostVendorCity, u.ShippingCostVendorCountry) AS BackEndCost,s.OrderNumber,s.ProcessOrderID,p.ProductID,p.Title,p.Price AS ProductPrice,s.ItemsPrice ,s.ProcessStatus,s.OrderDate,s.PaymentType,IF(s.DeliveryStatus NOT IN ('VS'),s.ItemsShippingHandling,null) AS ShippingCostBanglabazar,IF (s.DeliveryStatus ='VS' AND s.PaymentType="cod",null,(SELECT BackEndCost)) AS ShippingCostVendor,a.CommissionRate,(s.ItemsPrice*a.CommissionRate) AS BanglaBazarPaymentAmount,(s.ItemsPrice-(SELECT BanglaBazarPaymentAmount)) AS AmountAfterCommission,(SELECT AmountAfterCommission) AS VendorPaymentAmount,s.VendorPaymentStatus,f.UserName AS VendorName,n.CompanyName,s.ReturnReason,s.ProductVariantCombinationDetail,s.ItemsShippingHandling,s.ItemsEstimatedTax,s.DeliveryDate,s.DeliveryStatus,vp.ProcessDate
          FROM  product p      
          LEFT JOIN productvariantoption o ON o.ProductID = p.ProductID
          LEFT JOIN productvariantoptionvalue v  ON  v.OptionID  =o.OptionID  
          LEFT JOIN productimage i  ON  i.OptionValueID  =v.OptionValueID
          LEFT JOIN imagegallery g  ON  g.ImageGalleryID  =i.ImageGalleryID
          LEFT JOIN productvariantcombination c  ON  c.OptionValueID  =v.OptionValueID
          LEFT JOIN processorder s ON s.ProductID =c.ProductID
          LEFT JOIN vendorstore e ON e.VendorStoreID =s.VendorStoreID
          LEFT JOIN vendor n ON n.VendorID =e.VendorID
          LEFT JOIN orderdeliveryaddress r ON r.OrderNumber =s.OrderNumber
          LEFT JOIN shippingcostvendorcity y ON y.ProductID =p.ProductID  
          LEFT JOIN shippingcostvendorcountry u ON u.ProductID  =p.ProductID
          LEFT JOIN vendorcommissionrate a ON a.VendorID  = n.VendorID
          LEFT JOIN profile f ON f.UserID =n.VendorID
          LEFT JOIN processpayment m ON m.OrderNumber =s.OrderNumber
          LEFT JOIN vendorpaymentprocess vp ON vp.ProcessOrderID =s.ProcessOrderID
          WHERE i.MainImage='Y' AND s.ProcessStatus="Delivered" AND s.VendorPaymentStatus="${Status}" AND (n.CompanyName LIKE "%${search}%") AND s.DeliveryDate < DATE_SUB(NOW(), INTERVAL 15 DAY) AND s.ReturnReason IS NULL OR
          s.ReturnReason  = ' ' AND y.CityID =r.CityID
          GROUP BY s.ProcessOrderID
          ORDER BY s.ProcessOrderID ${sort}
         limit ` +
        limit +
        " offset " +
        offset;
      let viewOrderList = await connection.query(viewOrderListQuery, {
        type: QueryTypes.SELECT,
      });
      console.log(viewOrderList);
      let productCombinationDetail;
      if (viewOrderList && viewOrderList.length > 0) {
        for (let i = 0; i < viewOrderList.length; i++) {
          let ProductVariantCombinationDetail = [];
          ProductVariantCombinationDetail.push(
            viewOrderList[i].ProductVariantCombinationDetail
          );
          ProductVariantCombinationDetail = `(${ProductVariantCombinationDetail.join(
            ","
          )})`;
          productCombinationDetail = await connection.query(
            `SELECT p.ProductID,c.ProductVariantCombinationID,c.VendorStoreID,c.Price AS ProductCombinationPrice,c.AvailableInventory,o.OptionID,o.OptionName,v.OptionValue,v.OptionValueID
              FROM ((((product p
              LEFT JOIN productvariantoption o ON o.ProductID IN( p.ProductID))
              LEFT JOIN productvariantoptionvalue v  ON  v.OptionID IN (o.OptionID)) 
              LEFT JOIN productvariantcombination c  ON  c.OptionValueID IN (v.OptionValueID))
              LEFT JOIN processorder s ON s.ProductID IN(c.ProductID))
              WHERE  c.ProductVariantCombinationID IN ${ProductVariantCombinationDetail} 
              GROUP BY c.OptionValueID
             `,
            {
              type: QueryTypes.SELECT,
            }
          );
          productCombinationPriceDetail.push(productCombinationDetail);
        }

        let tempPC = productCombinationPriceDetail;
        let tempProd = viewOrderList;
        let tempArray = [];
        let tempAOrderDetails = [];
        for (let i = 0; i < tempProd.length; i++) {
          var obj = {
            ...tempProd[i],
          };
          obj["ProductCombinations"] = tempPC[i];
          tempArray.push(obj);
        }
        /*  for (let i = 0; i < tempArray.length; i++) {
          if (!orderName.includes(tempArray[i].OrderNumber)) {
            orderName.push(tempArray[i].OrderNumber);
            orderDate.push(tempArray[i].OrderDate);
            paymentStatus.push(tempArray[i].PaymentStatus);
            transactionID.push(tempArray[i].TransactionID);
            allowStorePickup.push(tempArray[i].AllowStorePickup);
            readyPickupForUser.push(tempArray[i].ReadyPickupForUser);
            readyPickupForAdmin.push(tempArray[i].ReadyPickupForAdmin);
            allowAdminPickup.push(tempArray[i].AllowAdminPickup);
            deliveryStatus.push(tempArray[i].DeliveryStatus);
          }
        } */
        /*  for (let i = 0; i < orderName.length; i++) {
          var obj = {
            OrderNumber: orderName[i],
            OrderDate: orderDate[i],
            PaymentStatus: paymentStatus[i],
            TransactionID: transactionID[i],
            AllowStorePickup: allowStorePickup[i],
            ReadyPickupForUser: readyPickupForUser[i],
            ReadyPickupForAdmin: readyPickupForAdmin[i],
            AllowAdminPickup: allowAdminPickup[i],
            DeliveryStatus: deliveryStatus[i],
            ProductDetail: [],
          };
          for (let j = 0; j < tempArray.length; j++) {
            if (orderName[i] === tempArray[j].OrderNumber) {
              obj.ProductDetail.push(tempArray[j]);
            }
          }
          tempAOrderDetails.push(obj);
        } */
        if (productCombinationDetail && productCombinationDetail.length > 0) {
          res.status(200).json({
            status: true,
            total_records: ordersCount[0].total_records,
            orderDetails: tempArray,
          });
        } else {
          res.status(200).json({
            status: true,
            total_records: ordersCount[0].total_records,
            orderDetails: [],
          });
        }
      } else {
        res.status(200).json({
          status: true,
          total_records: ordersCount[0].total_records,
          orderDetails: [],
        });
      }
    } else {
      res.status(200).json({
        status: true,
        total_records: ordersCount[0].total_records,
        orderDetails: [],
      });
    }
  } catch (err) {
    console.log(err.message);
    next(err);
    res.status(200).json({
      status: false,
      orderDetails: [],
    });
  }
};
exports.getOrderByVendorPaymentStatus = async (req, res, next) => {
  try {
    const { sort, search, limit, offset, Status } = req.body;

    let productCombinationPriceDetail = [];
    //! changes here made was DISTINCT is removed from ( OrderNumber)
    let ordersCount = await connection.query(
      `SELECT COUNT( OrderNumber) as total_records
      FROM processorder WHERE ProcessStatus="Delivered" AND DeliveryDate < DATE_SUB(NOW(), INTERVAL 30 DAY) 
 `,
      {
        type: QueryTypes.SELECT,
      }
    );
    // (-s.ItemsShippingHandling)+( SELECT ShippingCostVendor)
    // CASE
    //     WHEN s.DeliveryStatus ='VS' AND s.PaymentType="cod" THEN 0
    //     WHEN s.DeliveryStatus ='VS' AND s.PaymentType="card" THEN (SELECT BackEndCost)
    //     ELSE 0
    //     END AS ShippingCostVendor
    console.log(ordersCount);

    if (ordersCount[0].total_records && ordersCount[0].total_records > 0) {
      let viewOrderListQuery =
        `SELECT IFNULL(y.ShippingCostVendorCity, u.ShippingCostVendorCountry) AS BackEndCost,s.OrderNumber,s.ProcessOrderID,p.ProductID,p.Title,p.Price AS ProductPrice,s.ItemsPrice ,s.ProcessStatus,s.OrderDate,s.PaymentType,IF(s.DeliveryStatus NOT IN ('VS'),s.ItemsShippingHandling,0) AS ShippingCostBanglabazar,a.CommissionRate,s.VendorPaymentStatus,f.UserName AS VendorName,n.CompanyName,s.ReturnReason,s.ProductVariantCombinationDetail,s.ItemsShippingHandling,s.ItemsEstimatedTax,s.DeliveryDate,s.DeliveryStatus,vp.ProcessDate,s.RefundStatus,p.FreeProductReturn,
          CASE
          WHEN s.RefundStatus IN ('Refunded') AND s.PaymentType="cod" THEN (s.ItemsPrice*0.05) 
          WHEN s.RefundStatus IN ('Refunded') AND s.PaymentType="card" THEN (s.ItemsPrice*0.05)
          ELSE s.ItemsPrice*a.CommissionRate
          END AS BanglaBazarPaymentAmount,
          CASE
           WHEN s.RefundStatus IN ('Refunded') AND p.FreeProductReturn="Y" THEN 
              CASE
              WHEN s.DeliveryStatus ='VS' AND s.PaymentType="cod" THEN 0
              WHEN s.DeliveryStatus ='VS' AND s.PaymentType="card" THEN 0
              ELSE (-s.ItemsShippingHandling)
              END 
           WHEN s.RefundStatus IN ('Refunded')  AND p.FreeProductReturn="N" THEN
              CASE
              WHEN s.DeliveryStatus ='VS' AND s.PaymentType="card" THEN (SELECT BackEndCost)
              ELSE 0
              END 
           ELSE 
              CASE
              WHEN s.DeliveryStatus ='VS' AND s.PaymentType="cod" THEN  (s.ItemsPrice-s.ItemsPrice*a.CommissionRate)
              WHEN s.DeliveryStatus ='VS' AND s.PaymentType="card" THEN (SELECT BackEndCost)+ (s.ItemsPrice-s.ItemsPrice*a.CommissionRate)
              ELSE (s.ItemsPrice-s.ItemsPrice*a.CommissionRate)
              END 
          END AS VendorPaymentAmount
          FROM  product p      
          LEFT JOIN productvariantoption o ON o.ProductID = p.ProductID
          LEFT JOIN productvariantoptionvalue v  ON  v.OptionID  =o.OptionID  
          LEFT JOIN productimage i  ON  i.OptionValueID  =v.OptionValueID
          LEFT JOIN imagegallery g  ON  g.ImageGalleryID  =i.ImageGalleryID
          LEFT JOIN productvariantcombination c  ON  c.OptionValueID  =v.OptionValueID
          LEFT JOIN processorder s ON s.ProductID =c.ProductID
          LEFT JOIN vendorstore e ON e.VendorStoreID =s.VendorStoreID
          LEFT JOIN vendor n ON n.VendorID =e.VendorID
          LEFT JOIN orderdeliveryaddress r ON r.OrderNumber =s.OrderNumber
          LEFT JOIN shippingcostvendorcity y ON y.ProductID =p.ProductID  
          LEFT JOIN shippingcostvendorcountry u ON u.ProductID  =p.ProductID
          LEFT JOIN vendorcommissionrate a ON a.VendorID  = n.VendorID
          LEFT JOIN profile f ON f.UserID =n.VendorID
          LEFT JOIN processpayment m ON m.OrderNumber =s.OrderNumber
          LEFT JOIN vendorpaymentprocess vp ON vp.ProcessOrderID =s.ProcessOrderID
          WHERE i.MainImage='Y' AND s.ProcessStatus="Delivered" AND s.VendorPaymentStatus="${Status}" AND (n.CompanyName LIKE "%${search}%") AND s.DeliveryDate < DATE_SUB(NOW(), INTERVAL 30 DAY)
          GROUP BY s.ProcessOrderID
          ORDER BY s.ProcessOrderID ${sort}
         limit ` +
        limit +
        " offset " +
        offset;
      let viewOrderList = await connection.query(viewOrderListQuery, {
        type: QueryTypes.SELECT,
      });
      console.log(viewOrderList, "vieworderlist");
      let productCombinationDetail;
      if (viewOrderList && viewOrderList.length > 0) {
        for (let i = 0; i < viewOrderList.length; i++) {
          let ProductVariantCombinationDetail = [];
          ProductVariantCombinationDetail.push(
            viewOrderList[i].ProductVariantCombinationDetail
          );
          ProductVariantCombinationDetail = `(${ProductVariantCombinationDetail.join(
            ","
          )})`;
          productCombinationDetail = await connection.query(
            `SELECT p.ProductID,c.ProductVariantCombinationID,c.VendorStoreID,c.Price AS ProductCombinationPrice,c.AvailableInventory,o.OptionID,o.OptionName,v.OptionValue,v.OptionValueID
              FROM ((((product p
              LEFT JOIN productvariantoption o ON o.ProductID IN( p.ProductID))
              LEFT JOIN productvariantoptionvalue v  ON  v.OptionID IN (o.OptionID)) 
              LEFT JOIN productvariantcombination c  ON  c.OptionValueID IN (v.OptionValueID))
              LEFT JOIN processorder s ON s.ProductID IN(c.ProductID))
              WHERE  c.ProductVariantCombinationID IN ${ProductVariantCombinationDetail} 
              GROUP BY c.OptionValueID
             `,
            {
              type: QueryTypes.SELECT,
            }
          );
          productCombinationPriceDetail.push(productCombinationDetail);
        }

        let tempPC = productCombinationPriceDetail;
        let tempProd = viewOrderList;
        let tempArray = [];
        let tempAOrderDetails = [];
        for (let i = 0; i < tempProd.length; i++) {
          var obj = {
            ...tempProd[i],
          };
          obj["ProductCombinations"] = tempPC[i];
          tempArray.push(obj);
        }
        /*  for (let i = 0; i < tempArray.length; i++) {
          if (!orderName.includes(tempArray[i].OrderNumber)) {
            orderName.push(tempArray[i].OrderNumber);
            orderDate.push(tempArray[i].OrderDate);
            paymentStatus.push(tempArray[i].PaymentStatus);
            transactionID.push(tempArray[i].TransactionID);
            allowStorePickup.push(tempArray[i].AllowStorePickup);
            readyPickupForUser.push(tempArray[i].ReadyPickupForUser);
            readyPickupForAdmin.push(tempArray[i].ReadyPickupForAdmin);
            allowAdminPickup.push(tempArray[i].AllowAdminPickup);
            deliveryStatus.push(tempArray[i].DeliveryStatus);
          }
        } */
        /*  for (let i = 0; i < orderName.length; i++) {
          var obj = {
            OrderNumber: orderName[i],
            OrderDate: orderDate[i],
            PaymentStatus: paymentStatus[i],
            TransactionID: transactionID[i],
            AllowStorePickup: allowStorePickup[i],
            ReadyPickupForUser: readyPickupForUser[i],
            ReadyPickupForAdmin: readyPickupForAdmin[i],
            AllowAdminPickup: allowAdminPickup[i],
            DeliveryStatus: deliveryStatus[i],
            ProductDetail: [],
          };
          for (let j = 0; j < tempArray.length; j++) {
            if (orderName[i] === tempArray[j].OrderNumber) {
              obj.ProductDetail.push(tempArray[j]);
            }
          }
          tempAOrderDetails.push(obj);
        } */
        if (productCombinationDetail && productCombinationDetail.length > 0) {
          res.status(200).json({
            status: true,
            total_records: ordersCount[0].total_records,
            orderDetails: tempArray,
          });
        } else {
          res.status(200).json({
            status: true,
            total_records: ordersCount[0].total_records,
            orderDetails: [],
          });
        }
      } else {
        res.status(200).json({
          status: true,
          total_records: ordersCount[0].total_records,
          orderDetails: [],
        });
      }
    } else {
      res.status(200).json({
        status: true,
        total_records: ordersCount[0].total_records,
        orderDetails: [],
      });
    }
  } catch (err) {
    console.log(err.message);
    next(err);
    res.status(200).json({
      status: false,
      orderDetails: [],
    });
  }
};
exports.updateVendorCommission = async (req, res, next) => {
  try {
    const {
      VendorID,
      CommissionRate,
      EffectiveStartDate,
      EffectiveEndDate,
      AdminNote,
    } = req.body;
    console.log(req.body, "------------------------------");
    let LastUpdate = new Date().toISOString().slice(0, 19).replace("T", " ");
    let addVendorComissionRateQuery = `insert into vendorcommissionrate (VendorID,CommissionRate,EffectiveStartDate ,EffectiveEndDate, LastUpdate, AdminNote)`;
    addVendorComissionRateQuery += ` values (?,?,?,?,?,?) `;
    addVendorComissionRateQuery += ` ON DUPLICATE KEY UPDATE CommissionRate="${CommissionRate}",LastUpdate=VALUES(LastUpdate)`;
    let addVendorComissionRate = await connection.query(
      addVendorComissionRateQuery,
      {
        replacements: [
          VendorID,
          CommissionRate,
          EffectiveStartDate,
          EffectiveEndDate,
          LastUpdate,
          AdminNote,
        ],
      }
    );
    if (addVendorComissionRate) {
      res.status(200).json({
        status: true,
        message: "Successfully added Vendor Commission Rate",
      });
    } else {
      res.status(200).json({
        status: false,
        message: "Unable to add Vendor Commission Rate",
      });
    }
  } catch (err) {
    console.log(err.message);
    next(err);
    res.status(200).json({
      status: false,
      message: err.message,
    });
  }
};
exports.getVendorDetails = async (req, res, next) => {
  try {
    const { search } = req.body;
    let getVendorBusiness = await connection.query(
      `
    SELECT p.UserID AS VendorID,p.UserName AS VendorName,v.CompanyName,v.CountryID,c.Country,v.BusinessEmail,v.BusinessPhone,v.BusinessURL,v.PageURL
    ,COUNT(vs.VendorStoreID) AS Total_Stores
     FROM vendor v
    LEFT JOIN profile p ON p.UserID=v.VendorID
    LEFT JOIN country c ON c.CountryID=v.CountryID
    LEFT JOIN vendorstore vs ON vs.VendorID=v.VendorID
    WHERE p.UserName LIKE "%${search}%"
    GROUP BY v.VendorID
 `,
      {
        type: QueryTypes.SELECT,
      }
    );
    if (getVendorBusiness && getVendorBusiness.length > 0) {
      res.status(200).json({
        status: true,
        getVendorBusiness,
      });
    } else {
      res.status(200).json({
        status: true,
        message: "No Vendor Business Record found",
        getVendorBusiness: [],
      });
    }
  } catch (err) {
    next(err);
    res.status(200).json({
      status: false,
      profile: {},
      error: err.message,
    });
  }
};
exports.getOrderByVendorIDPaymentStatus = async (req, res, next) => {
  try {
    //const { sort, limit, offset, Status } = req.body;
    const VendorID = req.params.id;
    let productCombinationPriceDetail = [];
    let viewOrderListQuery = `SELECT IFNULL(y.ShippingCostVendorCity, u.ShippingCostVendorCountry) AS BackEndCost,s.OrderNumber,s.ProcessOrderID,p.ProductID,p.Title,p.Price AS ProductPrice,s.ItemsPrice ,s.ProcessStatus,s.OrderDate,s.PaymentType,IF(s.DeliveryStatus NOT IN ('VS'),s.ItemsShippingHandling,0) AS ShippingCostBanglabazar,a.CommissionRate,s.VendorPaymentStatus,f.UserName AS VendorName,n.CompanyName,s.ReturnReason,s.ProductVariantCombinationDetail,s.ItemsShippingHandling,s.ItemsEstimatedTax,s.DeliveryDate,s.DeliveryStatus,vp.ProcessDate,s.RefundStatus,p.FreeProductReturn,
    SELECT IFNULL(y.ShippingCostVendorCity, u.ShippingCostVendorCountry) AS BackEndCost,s.OrderNumber,s.ProcessOrderID,p.ProductID,p.Title,p.Price AS ProductPrice,s.ItemsPrice ,s.ProcessStatus,s.OrderDate,s.PaymentType,IF(s.DeliveryStatus NOT IN ('VS'),s.ItemsShippingHandling,0) AS ShippingCostBanglabazar,a.CommissionRate,s.VendorPaymentStatus,f.UserName AS VendorName,n.CompanyName,s.ReturnReason,s.ProductVariantCombinationDetail,s.ItemsShippingHandling,s.ItemsEstimatedTax,s.DeliveryDate,s.DeliveryStatus,vp.ProcessDate,s.RefundStatus,p.FreeProductReturn,
    CASE
    WHEN s.RefundStatus IN ('Refunded') AND s.PaymentType="cod" THEN (s.ItemsPrice*0.05) 
    WHEN s.RefundStatus IN ('Refunded') AND s.PaymentType="card" THEN (s.ItemsPrice*0.05)
    ELSE s.ItemsPrice*a.CommissionRate
    END AS BanglaBazarPaymentAmount,
    CASE
     WHEN s.RefundStatus IN ('Refunded') AND p.FreeProductReturn="Y" THEN 
        CASE
        WHEN s.DeliveryStatus ='VS' AND s.PaymentType="cod" THEN 0
        WHEN s.DeliveryStatus ='VS' AND s.PaymentType="card" THEN 0
        ELSE (-s.ItemsShippingHandling)
        END 
     WHEN s.RefundStatus IN ('Refunded')  AND p.FreeProductReturn="N" THEN
        CASE
        WHEN s.DeliveryStatus ='VS' AND s.PaymentType="card" THEN (SELECT BackEndCost)
        ELSE 0
        END 
     ELSE 
        CASE
        WHEN s.DeliveryStatus ='VS' AND s.PaymentType="cod" THEN  (s.ItemsPrice-s.ItemsPrice*a.CommissionRate)
        WHEN s.DeliveryStatus ='VS' AND s.PaymentType="card" THEN (SELECT BackEndCost)+ (s.ItemsPrice-s.ItemsPrice*a.CommissionRate)
        ELSE (s.ItemsPrice-s.ItemsPrice*a.CommissionRate)
        END 
    END AS VendorPaymentAmount
          FROM  product p      
          LEFT JOIN productvariantoption o ON o.ProductID = p.ProductID
          LEFT JOIN productvariantoptionvalue v  ON  v.OptionID  =o.OptionID  
          LEFT JOIN productimage i  ON  i.OptionValueID  =v.OptionValueID
          LEFT JOIN imagegallery g  ON  g.ImageGalleryID  =i.ImageGalleryID
          LEFT JOIN productvariantcombination c  ON  c.OptionValueID  =v.OptionValueID
          LEFT JOIN processorder s ON s.ProductID =c.ProductID
          LEFT JOIN vendorstore e ON e.VendorStoreID =s.VendorStoreID
          LEFT JOIN vendor n ON n.VendorID =e.VendorID
          LEFT JOIN orderdeliveryaddress r ON r.OrderNumber =s.OrderNumber
          LEFT JOIN shippingcostvendorcity y ON y.ProductID =p.ProductID  
          LEFT JOIN shippingcostvendorcountry u ON u.ProductID  =p.ProductID
          LEFT JOIN vendorcommissionrate a ON a.VendorID  = n.VendorID
          LEFT JOIN profile f ON f.UserID =n.VendorID
          LEFT JOIN processpayment m ON m.OrderNumber =s.OrderNumber
          LEFT JOIN vendorpaymentprocess vp ON vp.ProcessOrderID =s.ProcessOrderID
          WHERE i.MainImage='Y' AND s.ProcessStatus="Delivered" AND s.VendorPaymentStatus="N" AND (n.VendorID="${VendorID}") AND s.DeliveryDate < DATE_SUB(NOW(), INTERVAL 15 DAY) AND s.ReturnReason IS NULL OR
          s.ReturnReason  = ' ' AND y.CityID =r.CityID
          GROUP BY s.ProcessOrderID
          ORDER BY s.ProcessOrderID DESC
         `;
    let viewOrderList = await connection.query(viewOrderListQuery, {
      type: QueryTypes.SELECT,
    });
    console.log(viewOrderList);
    let productCombinationDetail;
    if (viewOrderList && viewOrderList.length > 0) {
      for (let i = 0; i < viewOrderList.length; i++) {
        let ProductVariantCombinationDetail = [];
        ProductVariantCombinationDetail.push(
          viewOrderList[i].ProductVariantCombinationDetail
        );
        ProductVariantCombinationDetail = `(${ProductVariantCombinationDetail.join(
          ","
        )})`;
        productCombinationDetail = await connection.query(
          `SELECT p.ProductID,c.ProductVariantCombinationID,c.VendorStoreID,c.Price AS ProductCombinationPrice,c.AvailableInventory,o.OptionID,o.OptionName,v.OptionValue,v.OptionValueID
              FROM ((((product p
              LEFT JOIN productvariantoption o ON o.ProductID IN( p.ProductID))
              LEFT JOIN productvariantoptionvalue v  ON  v.OptionID IN (o.OptionID)) 
              LEFT JOIN productvariantcombination c  ON  c.OptionValueID IN (v.OptionValueID))
              LEFT JOIN processorder s ON s.ProductID IN(c.ProductID))
              WHERE  c.ProductVariantCombinationID IN ${ProductVariantCombinationDetail} 
              GROUP BY c.OptionValueID
             `,
          {
            type: QueryTypes.SELECT,
          }
        );
        productCombinationPriceDetail.push(productCombinationDetail);
      }

      let tempPC = productCombinationPriceDetail;
      let tempProd = viewOrderList;
      let tempArray = [];
      let tempAOrderDetails = [];
      for (let i = 0; i < tempProd.length; i++) {
        var obj = {
          ...tempProd[i],
        };
        obj["ProductCombinations"] = tempPC[i];
        tempArray.push(obj);
      }
      /*  for (let i = 0; i < tempArray.length; i++) {
          if (!orderName.includes(tempArray[i].OrderNumber)) {
            orderName.push(tempArray[i].OrderNumber);
            orderDate.push(tempArray[i].OrderDate);
            paymentStatus.push(tempArray[i].PaymentStatus);
            transactionID.push(tempArray[i].TransactionID);
            allowStorePickup.push(tempArray[i].AllowStorePickup);
            readyPickupForUser.push(tempArray[i].ReadyPickupForUser);
            readyPickupForAdmin.push(tempArray[i].ReadyPickupForAdmin);
            allowAdminPickup.push(tempArray[i].AllowAdminPickup);
            deliveryStatus.push(tempArray[i].DeliveryStatus);
          }
        } */
      /*  for (let i = 0; i < orderName.length; i++) {
          var obj = {
            OrderNumber: orderName[i],
            OrderDate: orderDate[i],
            PaymentStatus: paymentStatus[i],
            TransactionID: transactionID[i],
            AllowStorePickup: allowStorePickup[i],
            ReadyPickupForUser: readyPickupForUser[i],
            ReadyPickupForAdmin: readyPickupForAdmin[i],
            AllowAdminPickup: allowAdminPickup[i],
            DeliveryStatus: deliveryStatus[i],
            ProductDetail: [],
          };
          for (let j = 0; j < tempArray.length; j++) {
            if (orderName[i] === tempArray[j].OrderNumber) {
              obj.ProductDetail.push(tempArray[j]);
            }
          }
          tempAOrderDetails.push(obj);
        } */
      if (productCombinationDetail && productCombinationDetail.length > 0) {
        res.status(200).json({
          status: true,
          orderDetails: tempArray,
        });
      } else {
        res.status(200).json({
          status: true,
          orderDetails: [],
        });
      }
    } else {
      res.status(200).json({
        status: true,
        orderDetails: [],
      });
    }
  } catch (err) {
    console.log(err.message);
    next(err);
    res.status(200).json({
      status: false,
      orderDetails: [],
    });
  }
};
exports.addVendorPaymentProcess = async (req, res, next) => {
  let transaction;
  try {
    transaction = await connection.transaction();
    const { VendorPaymentDetails } = req.body;
    const VendorPaymentDetail = JSON.parse(VendorPaymentDetails);
    let PaymentConfirmation = req.file.path;
    console.log(PaymentConfirmation, "PaymentConfirmation");
    let ProcessOrderID = [];
    for (let i = 0; i < VendorPaymentDetail.length; i++) {
      ProcessOrderID.push(VendorPaymentDetail[i].ProcessOrderID);
    }
    ProcessOrderID = `(${ProcessOrderID.join(",")})`;
    console.log(ProcessOrderID);
    let LastUpdate = new Date().toISOString().slice(0, 19).replace("T", " ");

    let insertVendorPaymentProcessQuery = `INSERT INTO vendorpaymentprocess ( ProcessOrderID, ShippingCostBanglabazar,ShippingCostVendor,CommissionRate,VendorPaymentAmount,AdminPaymentAmount,ProcessDate,ProcessStatus) values  `;

    for (let i = 0; i < VendorPaymentDetail.length; i++) {
      if (i == VendorPaymentDetail.length - 1) {
        insertVendorPaymentProcessQuery += `('${VendorPaymentDetail[i].ProcessOrderID}','${VendorPaymentDetail[i].ShippingCostBanglabazar}','${VendorPaymentDetail[i].ShippingCostVendor}', '${VendorPaymentDetail[i].CommissionRate}','${VendorPaymentDetail[i].VendorPaymentAmount}', '${VendorPaymentDetail[i].AdminPaymentAmount}','${LastUpdate}',"Y")`;
      } else {
        insertVendorPaymentProcessQuery += `('${VendorPaymentDetail[i].ProcessOrderID}','${VendorPaymentDetail[i].ShippingCostBanglabazar}','${VendorPaymentDetail[i].ShippingCostVendor}', '${VendorPaymentDetail[i].CommissionRate}','${VendorPaymentDetail[i].VendorPaymentAmount}', '${VendorPaymentDetail[i].AdminPaymentAmount}','${LastUpdate}',"Y"),`;
      }
    }
    let insertVendorPaymentProcess = await connection.query(
      insertVendorPaymentProcessQuery,
      { transaction }
    );
    if (insertVendorPaymentProcess) {
      let updateVendorPaymentStatusQuery = `UPDATE processorder,vendorpaymentprocess
        SET processorder.VendorPaymentStatus="Y",
        vendorpaymentprocess.PaymentConfirmation =?
        WHERE processorder.ProcessOrderID IN ${ProcessOrderID} 
        AND vendorpaymentprocess.ProcessOrderID IN ${ProcessOrderID} `;

      let updateVendorPaymentStatus = await connection.query(
        updateVendorPaymentStatusQuery,
        { replacements: [PaymentConfirmation], transaction }
      );
      if (updateVendorPaymentStatus) {
        if (transaction) await transaction.commit();
        res.status(200).json({
          status: true,
          message: "Successfully added Vendor Payment Details ",
        });
      } else {
        if (transaction) await transaction.rollback();
        res.status(200).json({
          status: false,
          message: "Error while updating Vendor Payment Status ",
        });
      }
    } else {
      if (transaction) await transaction.rollback();
      res.status(200).json({
        status: false,
        message: "Error while adding Vendor Payment Details ",
      });
    }
  } catch (err) {
    if (transaction) await transaction.rollback();
    console.log(err.message);
    next(err);
    res.status(200).json({
      status: false,
      message: err.message,
    });
  }
};
exports.getVendorPaymentDetails = async (req, res, next) => {
  try {
    const { sort, limit, offset, Status } = req.body;
    const VendorID = req.params.id;
    // let CURRENT_DATE = new Date().toISOString().slice(0, 19).replace("T", " ");
    let vendorPaymentDetailQuery = `SELECT s.OrderNumber,p.Title,s.ProcessOrderID,s.ItemsPrice ,s.ProcessStatus,s.OrderDate,s.ReturnReason,v.*,s.DeliveryStatus
          FROM processorder s 
          LEFT JOIN product p ON p.ProductID =s.ProductID
          LEFT JOIN vendorpaymentprocess v ON v.ProcessOrderID =s.ProcessOrderID
          LEFT JOIN vendorstore vs ON vs.VendorStoreID =s.VendorStoreID
          WHERE s.ProcessStatus="Delivered" AND s.VendorPaymentStatus="Y" AND (vs.VendorID="${VendorID}") AND s.DeliveryDate < DATE_SUB(NOW(), INTERVAL 15 DAY) AND s.ReturnReason IS NULL OR s.ReturnReason  = ' '
          GROUP BY s.ProcessOrderID
          ORDER BY s.ProcessOrderID DESC
         `;
    let vendorPaymentDetail = await connection.query(vendorPaymentDetailQuery, {
      type: QueryTypes.SELECT,
    });
    if (vendorPaymentDetail && vendorPaymentDetail.length > 0) {
      res.status(200).json({
        status: true,
        vendorPaymentDetail: vendorPaymentDetail,
      });
    } else {
      res.status(200).json({
        status: false,
        vendorPaymentDetail: [],
      });
    }
  } catch (err) {
    console.log(err.message);
    next(err);
    res.status(200).json({
      status: false,
      vendorPaymentDetail: [],
    });
  }
};
//!COD Delivery Driver Api's
exports.getCodPaymentOrders = async (req, res, next) => {
  try {
    const { sort, limit, offset } = req.body;
    let productCombinationPriceDetail = [];
    let ordersCount = await connection.query(
      `SELECT COUNT(DISTINCT OrderNumber) AS total_records
      FROM processorder WHERE ProcessStatus="Delivered" AND PaymentType="cod" AND PaytoAdminCod="Y" AND DriverCodPaymentStatus="N" AND DeliveryDriverID NOT IN ('NULL','null','') `,
      {
        type: QueryTypes.SELECT,
      }
    );
    if (ordersCount[0].total_records && ordersCount[0].total_records > 0) {
      let viewOrderListQuery =
        `SELECT p.ProductID,p.Title,m.TransactionID,s.OrderNumber,s.AllowStorePickup,s.AllowAdminPickup,s.ReadyPickupForUser,s.ReadyPickupForAdmin,s.OrderDate,m.PaymentStatus,p.Price AS BasePrice,p.Currency,s.UserID,g.Small,g.Medium,g.Large,i.MainImage,s.ConsignmentId,s.DriverDepositProof,s.DeliveryDriverID,s.ProcessStatus,s.DeliveryStatus,m.OrderTotal,s.PaymentType,s.ItemsPrice,s.ItemsEstimatedTax,s.ItemsShippingHandling,s.ProductVariantCombinationDetail,d.*,pf.UserName,pf.ProfilePic
                FROM ((((((((( product p      
                LEFT JOIN productvariantoption o ON o.ProductID IN( p.ProductID))
                LEFT JOIN productvariantoptionvalue v  ON  v.OptionID IN (o.OptionID))  
                LEFT JOIN productimage i  ON  i.OptionValueID IN (v.OptionValueID))
                LEFT JOIN imagegallery g  ON  g.ImageGalleryID IN (i.ImageGalleryID))
                LEFT JOIN productvariantcombination c  ON  c.OptionValueID IN (v.OptionValueID))
                INNER JOIN processorder s ON s.ProductID IN(c.ProductID))
                LEFT JOIN processpayment m ON m.OrderNumber IN(s.OrderNumber))
                LEFT JOIN deliverydriver d ON d.DeliveryDriverID IN(s.DeliveryDriverID))
                LEFT JOIN profile pf ON pf.UserID IN(d.DeliveryDriverID))
                WHERE i.MainImage='Y' AND s.ProcessStatus="Delivered" AND s.PaymentType="cod" AND s.PaytoAdminCod="Y" AND s.DriverCodPaymentStatus="N" AND s.DeliveryDriverID NOT IN ('NULL','null','')   
                GROUP BY s.ProcessOrderID
                ORDER by s.ProcessOrderID ${sort} limit ` +
        limit +
        " offset " +
        offset;
      let viewOrderList = await connection.query(viewOrderListQuery, {
        type: QueryTypes.SELECT,
      });
      let productCombinationDetail;
      if (viewOrderList && viewOrderList.length > 0) {
        for (let i = 0; i < viewOrderList.length; i++) {
          let ProductVariantCombinationDetail = [];
          ProductVariantCombinationDetail.push(
            viewOrderList[i].ProductVariantCombinationDetail
          );
          ProductVariantCombinationDetail = `(${ProductVariantCombinationDetail.join(
            ","
          )})`;
          productCombinationDetail = await connection.query(
            `SELECT p.ProductID,c.ProductVariantCombinationID,c.VendorStoreID,c.Price AS ProductCombinationPrice,c.AvailableInventory,o.OptionID,o.OptionName,v.OptionValue,v.OptionValueID
                    FROM ((((product p
                    LEFT JOIN productvariantoption o ON o.ProductID IN( p.ProductID))
                    LEFT JOIN productvariantoptionvalue v  ON  v.OptionID IN (o.OptionID)) 
                    LEFT JOIN productvariantcombination c  ON  c.OptionValueID IN (v.OptionValueID))
                    LEFT JOIN processorder s ON s.ProductID IN(c.ProductID))
                    WHERE  c.ProductVariantCombinationID IN ${ProductVariantCombinationDetail}
                    GROUP BY c.OptionValueID
                    ORDER by s.ProcessOrderID ${sort} 
                   `,
            {
              type: QueryTypes.SELECT,
            }
          );
          productCombinationPriceDetail.push(productCombinationDetail);
        }
        let orderName = [];
        let orderDate = [];
        let paymentStatus = [];
        let transactionID = [];
        let tempPC = productCombinationPriceDetail;
        let tempProd = viewOrderList;
        let tempArray = [];
        let allowStorePickup = [];
        let readyPickupForUser = [];
        let readyPickupForAdmin = [];
        let allowAdminPickup = [];
        var deliveryDriverID = [];
        let tempAOrderDetails = [];
        let consignmentID = [];
        let processStatus = [];
        for (let i = 0; i < tempProd.length; i++) {
          var obj = {
            ...tempProd[i],
          };
          obj["ProductCombinations"] = tempPC[i];
          tempArray.push(obj);
        }
        for (let i = 0; i < tempArray.length; i++) {
          if (!orderName.includes(tempArray[i].OrderNumber)) {
            orderName.push(tempArray[i].OrderNumber);
            orderDate.push(tempArray[i].OrderDate);
            paymentStatus.push(tempArray[i].PaymentStatus);
            transactionID.push(tempArray[i].TransactionID);
            allowStorePickup.push(tempArray[i].AllowStorePickup);
            readyPickupForUser.push(tempArray[i].ReadyPickupForUser);
            readyPickupForAdmin.push(tempArray[i].ReadyPickupForAdmin);
            allowAdminPickup.push(tempArray[i].AllowAdminPickup);
            deliveryDriverID.push(tempArray[i].DeliveryDriverID);
            consignmentID.push(tempArray[i].ConsignmentId);
            processStatus.push(tempArray[i].ProcessStatus);
          }
        }
        for (let i = 0; i < orderName.length; i++) {
          var obj = {
            OrderNumber: orderName[i],
            OrderDate: orderDate[i],
            PaymentStatus: paymentStatus[i],
            TransactionID: transactionID[i],
            AllowStorePickup: allowStorePickup[i],
            ReadyPickupForUser: readyPickupForUser[i],
            ReadyPickupForAdmin: readyPickupForAdmin[i],
            AllowAdminPickup: allowAdminPickup[i],
            DeliveryDriverID: deliveryDriverID[i],
            ConsignmentId: consignmentID[i],
            ProcessStatus: processStatus[i],
            ProductDetail: [],
          };
          for (let j = 0; j < tempArray.length; j++) {
            if (orderName[i] === tempArray[j].OrderNumber) {
              obj.ProductDetail.push(tempArray[j]);
            }
          }
          tempAOrderDetails.push(obj);
        }
        if (productCombinationDetail && productCombinationDetail.length > 0) {
          res.status(200).json({
            status: true,
            total_records: ordersCount[0].total_records,
            orderDetails: tempAOrderDetails,
          });
        } else {
          res.status(200).json({
            status: false,
            total_records: ordersCount[0].total_records,
            orderDetails: [],
          });
        }
      } else {
        res.status(200).json({
          status: true,
          total_records: ordersCount[0].total_records,
          orderDetails: [],
        });
      }
    } else {
      res.status(200).json({
        status: true,
        total_records: ordersCount[0].total_records,
        orderDetails: [],
      });
    }
  } catch (err) {
    console.log(err.message);
    next(err);
    res.status(200).json({
      status: false,
      orderDetails: [],
    });
  }
};
exports.updateDriverPaymentStatus = async (req, res, next) => {
  try {
    const { OrderDetail } = req.body;
    const OrderNumber = `(${OrderDetail.join(",")})`;
    let retrivePreviousStatusHistory = await connection.query(
      `SELECT OrderNumber,StatusHistory from processorder WHERE OrderNumber IN ${OrderNumber}  `,
      {
        type: QueryTypes.SELECT,
      }
    );
    if (
      retrivePreviousStatusHistory &&
      retrivePreviousStatusHistory.length > 0
    ) {
      //      console.log(retrivePreviousStatusHistory)

      let LastUpdate = new Date().toISOString().slice(0, 19).replace("T", " ");
      let parsePreviousStatusHistory = [];
      let addPreviousStatusHistory = [];
      let updateDriverPaymentStatus = true;
      for (let i = 0; i < retrivePreviousStatusHistory.length; i++) {
        parsePreviousStatusHistory = JSON.parse(
          retrivePreviousStatusHistory[i].StatusHistory
        );
        parsePreviousStatusHistory.push(LastUpdate);
        addPreviousStatusHistory.push(parsePreviousStatusHistory);
        try {
          let updateDriverPaymentStatusQuery = `UPDATE processorder SET DriverCodPaymentStatus="Y",StatusHistory='${JSON.stringify(
            parsePreviousStatusHistory
          )}' WHERE OrderNumber= "${retrivePreviousStatusHistory[i].OrderNumber
            }" `;
          updateDriverPaymentStatus = await connection.query(
            updateDriverPaymentStatusQuery
          );
        } catch (e) {
          console.log(e.message, "---------------");
          updateDriverCodPaymentStatus = false;
          res.status(200).json({
            status: false,
            message: e.message,
          });
        }
      }
      if (updateDriverPaymentStatus) {
        res.status(200).json({
          status: true,
          message: "Successfully approved Driver payment",
        });
      } else {
        res.status(200).json({
          status: false,
          message: "unable to approve Driver payment",
        });
      }
    }
  } catch (err) {
    console.log(err.message, "-----------------------------");
    next(err);
    res.status(200).json({
      status: false,
      message: err.message,
    });
  }
};
exports.getSubCategoryByVendorId = async (req, res, next) => {
  try {
    const VendorID = req.params.id;
    let getSubCategoryByVendorID = await connection.query(
      `SELECT  s.SubCategory,v.* 
      FROM vendorsubcategory v
      LEFT JOIN subcategory s ON s.SubCategoryID=v.SubCategoryID 
      WHERE v.VendorID="${VendorID}"    `,
      {
        type: QueryTypes.SELECT,
      }
    );
    if (getSubCategoryByVendorID && getSubCategoryByVendorID.length > 0) {
      res.status(200).json({
        status: true,
        getVendorSubcategory: getSubCategoryByVendorID,
      });
    } else {
      res.status(200).json({
        status: true,
        getVendorSubcategory: [],
      });
    }
  } catch (err) {
    next(err);
    res.status(200).json({
      status: false,
      getVendorSubcategory: {},
      error: err.message,
    });
  }
};
exports.getVendorSubcategoryUpdated = async (req, res, next) => {
  try {
    let VendorID = req.params.id;
    let viewVendorSubCategory = await connection.query(
      `
          SELECT c.*, s.SubCategoryPic,cy.Category,CONCAT(cy.Category, ' --> ', s.SubCategory) AS SubCategory,s.SubCategoryID
          FROM vendorsubcategory c 
          INNER JOIN subcategory s ON s.SubCategoryID = c.SubCategoryID
          INNER JOIN category cy ON s.CategoryID = cy.CategoryID
          WHERE c.VendorID = "${VendorID}" `,
      {
        type: QueryTypes.SELECT,
      }
    );
    if (viewVendorSubCategory && viewVendorSubCategory.length > 0) {
      res.status(200).json({
        status: true,
        VendorSubCategory: viewVendorSubCategory,
      });
    } else {
      res.status(200).json({
        status: false,
        message: "Vendor SubCategory does not exist for this Vendor",
        VendorSubCategory: [],
      });
    }
  } catch (err) {
    next(err);
    res.status(200).json({
      status: false,
      VendorSubCategory: [],
      error: err.message,
    });
    console.log(err.message);
  }
};
exports.deleteVendorSubCategoryById = async (req, res, next) => {
  try {
    const { SubCategoryID, VendorID, ID } = req.body;

    let checkIFProductExists = await connection.query(
      `select * from product where VendorID = "${VendorID}" AND SubCategoryID="${SubCategoryID}" `,
      {
        type: QueryTypes.SELECT,
      }
    );
    console.log(checkIFProductExists);
    if (checkIFProductExists && checkIFProductExists.length > 0) {
      res.status(200).json({
        status: false,
        message: `Product Already exists against this SubCategory Cannot be deleted`,
      });
    } else {
      let deleteVendorSubCategory = await connection.query(
        `DELETE FROM vendorsubcategory WHERE ID="${ID}" `
      );
      if (deleteVendorSubCategory) {
        res.status(200).json({
          status: true,
          message: `Vendor SubCategory deleted successfully`,
        });
      } else {
        res.status(200).json({
          status: false,
          message: `Error while deleting this Vendor SubCategory`,
        });
      }
    }
  } catch (err) {
    next(err);
    res.status(200).json({
      status: false,
      error: err.message,
    });
    console.log(err.message);
  }
};
exports.updateVendorSubCategoryById = async (req, res, next) => {
  try {
    const { VendorID, SubCategoryNote, SubCategoryID } = req.body;
    let LastUpdate = new Date().toISOString().slice(0, 19).replace("T", " ");
    let addVendorSubCategoryQuery = `insert into vendorsubcategory (VendorID,SubCategoryID,LastUpdate ,AdminNote) VALUES`;
    for (let i = 0; i < SubCategoryID.length; i++) {
      if (i == SubCategoryID.length - 1) {
        addVendorSubCategoryQuery += `('${VendorID}', '${SubCategoryID[i]}','${LastUpdate}','${SubCategoryNote}')`;
      } else {
        addVendorSubCategoryQuery += `('${VendorID}', '${SubCategoryID[i]}','${LastUpdate}','${SubCategoryNote}'),`;
      }
    }
    addVendorSubCategoryQuery += ` ON DUPLICATE KEY UPDATE LastUpdate=VALUES(LastUpdate),AdminNote=VALUES(AdminNote)`;
    let addVendorSubCategory = await connection.query(
      addVendorSubCategoryQuery
    );
    if (addVendorSubCategory) {
      res.status(200).json({
        status: true,
        message: `Successfully updated Vendor SubCategory`,
      });
    } else {
      res.status(200).json({
        status: false,
        message: `Error while updating Vendor SubCategory`,
      });
    }
  } catch (err) {
    console.log(err);
    res.status(200).json({
      status: false,
      error: err.message,
    });
    console.log(err.message);
  }
};
//! PaytoDriver Api's
exports.getDriverDetailsBySearchFilter = async (req, res, next) => {
  try {
    const { search } = req.body;
    let getDriverDetails = await connection.query(
      `
     SELECT p.UserName AS DeliveryDriverName,d.*,COUNT(DISTINCT po.OrderNumber) AS Orders_Count
     FROM deliverydriver d
     LEFT JOIN processorder po ON po.DeliveryDriverID=d.DeliveryDriverID
     LEFT JOIN profile p ON p.UserID=d.DeliveryDriverID
     WHERE p.UserName LIKE "%${search}%" AND po.DriverCodPaymentStatus="Y"
     GROUP BY po.DeliveryDriverID
 `,
      {
        type: QueryTypes.SELECT,
      }
    );
    if (getDriverDetails && getDriverDetails.length > 0) {
      res.status(200).json({
        status: true,
        getDriverDetails,
      });
    } else {
      res.status(200).json({
        status: true,
        message: "No Vendor Business Record found",
        getDriverDetails: [],
      });
    }
  } catch (err) {
    next(err);
    res.status(200).json({
      status: false,
      getDriverDetails: [],
      error: err.message,
    });
  }
};
// exports.getDriverDetails = async (req, res, next) => {
//   try {
//     let { sort, status, limit, offset } = req.body;
//     limit = parseInt(limit);
//     offset = parseInt(offset);
//     offset = limit * offset;
//     const getDriverCount = await connection.query(
//       `
//     SELECT COUNT(DISTINCT po.DeliveryDriverID) AS total_records
//     FROM deliverydriver d
//     LEFT JOIN processorder po ON po.DeliveryDriverID=d.DeliveryDriverID
//     WHERE po.DriverCodPaymentStatus="Y"
// `,
//       {
//         type: QueryTypes.SELECT,
//       }
//     );
//     if (getDriverCount[0].total_records && getDriverCount[0].total_records  > 0) {
//       let getDriverDetailsQuery =
//         `SELECT p.UserName AS DeliveryDriverName,d.*,COUNT(DISTINCT po.OrderNumber) AS Orders_Count,po.*
//      FROM deliverydriver d
//      LEFT JOIN processorder po ON po.DeliveryDriverID=d.DeliveryDriverID
//      LEFT JOIN profile p ON p.UserID=d.DeliveryDriverID
//      WHERE po.DriverCodPaymentStatus="Y" AND PayToDriver="${status}"
//      GROUP BY po.DeliveryDriverID
//      ORDER BY ProcessOrderID ${sort}
//      limit ` +
//         limit +
//         " offset " +
//         offset;

//       let getDriverDetails = await connection.query(getDriverDetailsQuery, {
//         type: QueryTypes.SELECT,
//       });
//       if (getDriverDetails && getDriverDetails.length > 0) {
//         res.status(200).json({
//           status: true,
//           total_records: getDriverCount[0].total_records,
//           getDriverDetails,
//         });
//       } else {
//         res.status(200).json({
//           status: true,
//           total_records: getDriverCount[0].total_records,
//           getDriverDetails: [],
//         });
//       }
//     } else {
//       res.status(200).json({
//         status: true,
//         total_records: getDriverCount[0].total_records,
//         getDriverDetails: [],
//       });
//     }
//   } catch (err) {
//     next(err);
//     res.status(200).json({
//       status: false,
//       total_records: getDriverCount[0].total_records,
//       getDriverDetails: [],
//       error: err.message,
//     });
//   }
// };
exports.getDriverDetails = async (req, res, next) => {
  try {
    let { sort, status, limit, offset } = req.body;
    limit = parseInt(limit);
    offset = parseInt(offset);
    offset = limit * offset;
    let productCombinationPriceDetail = [];
    //!here inner query is to select COD orders only if a driver is assigned to it and it has payment status Y so what is happening below is excluding orders where COD AND PAYMENT STATUS IS N
    const getDriverCount = await connection.query(
      `
      SELECT COUNT(DISTINCT po.OrderNumber) AS total_records
      FROM deliverydriver d
      LEFT JOIN processorder po ON po.DeliveryDriverID=d.DeliveryDriverID
      WHERE po.PayToDriver="N" AND po.ProcessStatus="Delivered" AND po.DeliveryDate < DATE_SUB(NOW(), INTERVAL 15 DAY)
      AND po.OrderNumber NOT IN (SELECT OrderNumber
        FROM processorder 
        WHERE (if(DeliveryDriverID != "NULL" AND PaymentType="cod" AND DriverCodPaymentStatus="N",OrderNumber,null)))
`,
      {
        type: QueryTypes.SELECT,
      }
    );
    // console.log(getDriverCount);
    // return;
    if (
      getDriverCount[0].total_records &&
      getDriverCount[0].total_records > 0
    ) {
      let getDriverDetailsQuery =
        `SELECT s.OrderNumber,s.ProcessOrderID,p.ProductID,p.Title,p.Price AS ProductPrice,s.ItemsPrice ,s.ProcessStatus,s.OrderDate,s.PaymentType,f.UserName AS DriverName,s.ReturnReason,s.ProductVariantCombinationDetail,s.ItemsShippingHandling,s.ItemsEstimatedTax,s.DeliveryDate,s.DeliveryStatus,d.*,s.DeliveryDriverID,s.PayToDriver,s.DeliveryDate,s.OrderNumber AS CountOrder,m.ShippingHandling AS TotalShippingAmount,
        CASE 
        WHEN s.ReturnOrder="Y" AND s.ReturnOrderStatus="Refunded" THEN (m.ShippingHandling*2*0.05)
        ELSE (m.ShippingHandling*0.05) 
        END AS BanglaBazarPaymentAmount,
        CASE 
        WHEN ReturnOrder="Y" AND ReturnOrderStatus="Refunded" THEN ((m.ShippingHandling*2-m.ShippingHandling*2*0.05)
        ELSE (m.ShippingHandling-m.ShippingHandling*0.05) 
        END AS DriverPaymentAmount 
      FROM product p
      LEFT JOIN productvariantoption o ON o.ProductID = p.ProductID
      LEFT JOIN productvariantoptionvalue v  ON  v.OptionID  =o.OptionID  
      LEFT JOIN productimage i  ON  i.OptionValueID  =v.OptionValueID
      LEFT JOIN imagegallery g  ON  g.ImageGalleryID  =i.ImageGalleryID
      LEFT JOIN productvariantcombination c  ON  c.OptionValueID  =v.OptionValueID
      LEFT JOIN processorder s ON s.ProductID =c.ProductID
      LEFT JOIN processpayment m ON m.OrderNumber =s.OrderNumber
      LEFT JOIN deliverydriver d ON d.DeliveryDriverID=s.DeliveryDriverID
      LEFT JOIN profile f ON f.UserID =d.DeliveryDriverID
      WHERE i.MainImage='Y' AND s.PayToDriver="${status}" AND s.DeliveryDriverID != "NULL" AND s.DeliveryDriverID != "null" AND s.DeliveryDriverID != "" AND s.ProcessStatus="Delivered" AND s.DeliveryDate < DATE_SUB(NOW(), INTERVAL 30 DAY)
      AND s.OrderNumber NOT IN (SELECT OrderNumber
        FROM processorder 
        WHERE (if(DeliveryDriverID != "NULL" AND PaymentType="cod" AND DriverCodPaymentStatus="N",OrderNumber,null)))
      GROUP BY s.ProcessOrderID
      ORDER BY s.ProcessOrderID ${sort}
         limit ` +
        limit +
        " offset " +
        offset;
      let getDriverDetails = await connection.query(getDriverDetailsQuery, {
        type: QueryTypes.SELECT,
      });
      console.log(getDriverDetails);
      let productCombinationDetail;
      if (getDriverDetails && getDriverDetails.length > 0) {
        for (let i = 0; i < getDriverDetails.length; i++) {
          let ProductVariantCombinationDetail = [];
          ProductVariantCombinationDetail.push(
            getDriverDetails[i].ProductVariantCombinationDetail
          );
          ProductVariantCombinationDetail = `(${ProductVariantCombinationDetail.join(
            ","
          )})`;
          productCombinationDetail = await connection.query(
            `SELECT p.ProductID,c.ProductVariantCombinationID,c.VendorStoreID,c.Price AS ProductCombinationPrice,c.AvailableInventory,o.OptionID,o.OptionName,v.OptionValue,v.OptionValueID
              FROM ((((product p
              LEFT JOIN productvariantoption o ON o.ProductID IN( p.ProductID))
              LEFT JOIN productvariantoptionvalue v  ON  v.OptionID IN (o.OptionID)) 
              LEFT JOIN productvariantcombination c  ON  c.OptionValueID IN (v.OptionValueID))
              LEFT JOIN processorder s ON s.ProductID IN(c.ProductID))
              WHERE  c.ProductVariantCombinationID IN ${ProductVariantCombinationDetail} 
              GROUP BY c.OptionValueID
             `,
            {
              type: QueryTypes.SELECT,
            }
          );
          productCombinationPriceDetail.push(productCombinationDetail);
        }

        let tempPC = productCombinationPriceDetail;
        let tempProd = getDriverDetails;
        let tempArray = [];
        let tempAOrderDetails = [];
        let orderName = [];
        let orderDate = [];
        let deliveryDate = [];
        var deliveryDriverID = [];
        let payToDriver = [];
        let driverPaymentAmount = [];
        let totalShippingAmount = [];
        let banglaBazarPaymentAmount = [];
        for (let i = 0; i < tempProd.length; i++) {
          var obj = {
            ...tempProd[i],
          };
          obj["ProductCombinations"] = tempPC[i];
          tempArray.push(obj);
        }
        for (let i = 0; i < tempArray.length; i++) {
          if (!orderName.includes(tempArray[i].OrderNumber)) {
            orderName.push(tempArray[i].OrderNumber);
            orderDate.push(tempArray[i].OrderDate);
            deliveryDriverID.push(tempArray[i].DeliveryDriverID);
            payToDriver.push(tempArray[i].PayToDriver);
            deliveryDate.push(tempArray[i].DeliveryDate);
            totalShippingAmount.push(tempArray[i].TotalShippingAmount);
            driverPaymentAmount.push(tempArray[i].DriverPaymentAmount);
            banglaBazarPaymentAmount.push(
              tempArray[i].BanglaBazarPaymentAmount
            );
          }
        }
        for (let i = 0; i < orderName.length; i++) {
          var obj = {
            OrderNumber: orderName[i],
            OrderDate: orderDate[i],
            DeliveryDriverID: deliveryDriverID[i],
            PayToDriver: payToDriver[i],
            DeliveryDate: deliveryDate[i],
            TotalShippingAmount: totalShippingAmount[i],
            DriverPaymentAmount: driverPaymentAmount[i],
            BanglaBazarPaymentAmount: banglaBazarPaymentAmount[i],
            ProductDetail: [],
          };
          for (let j = 0; j < tempArray.length; j++) {
            if (orderName[i] === tempArray[j].OrderNumber) {
              obj.ProductDetail.push(tempArray[j]);
            }
          }
          tempAOrderDetails.push(obj);
        }

        if (productCombinationDetail && productCombinationDetail.length > 0) {
          res.status(200).json({
            status: true,
            total_records: getDriverCount[0].total_records,
            getDriverDetails: tempAOrderDetails,
          });
        } else {
          res.status(200).json({
            status: true,
            total_records: getDriverCount[0].total_records,
            getDriverDetails: [],
          });
        }
      } else {
        res.status(200).json({
          status: true,
          total_records: getDriverCount[0].total_records,
          getDriverDetails: [],
        });
      }
    } else {
      res.status(200).json({
        status: true,
        total_records: getDriverCount[0].total_records,
        getDriverDetails: [],
      });
    }
  } catch (err) {
    console.log(err.message);
    next(err);
    res.status(200).json({
      status: false,
      getDriverDetails: [],
      message: err.message,
    });
  }
};
exports.getDriverPaymentOrderByDriverIDOld = async (req, res, next) => {
  try {
    let { sort, status, limit, offset } = req.body;
    const DeliveryDriverID = req.params.id;
    limit = parseInt(limit);
    offset = parseInt(offset);
    offset = limit * offset;
    let productCombinationPriceDetail = [];
    let getDriverDetailsQuery = `SELECT s.OrderNumber,s.ProcessOrderID,p.ProductID,p.Title,p.Price AS ProductPrice,s.ItemsPrice ,s.ProcessStatus,s.OrderDate,s.PaymentType,f.UserName AS DriverName,s.ReturnReason,s.ProductVariantCombinationDetail,s.ItemsShippingHandling,s.ItemsEstimatedTax,s.DeliveryDate,s.DeliveryStatus,d.*,s.DeliveryDriverID,s.PayToDriver,s.DeliveryDate,
    s.OrderNumber AS CountOrder,m.ShippingHandling AS TotalShippingAmount, (m.ShippingHandling*0.05) AS BanglaBazarPaymentAmount,(m.ShippingHandling-m.ShippingHandling*0.05) AS DriverPaymentAmount
      FROM product p
      LEFT JOIN productvariantoption o ON o.ProductID = p.ProductID
      LEFT JOIN productvariantoptionvalue v  ON  v.OptionID  =o.OptionID  
      LEFT JOIN productimage i  ON  i.OptionValueID  =v.OptionValueID
      LEFT JOIN imagegallery g  ON  g.ImageGalleryID  =i.ImageGalleryID
      LEFT JOIN productvariantcombination c  ON  c.OptionValueID  =v.OptionValueID
      LEFT JOIN processorder s ON s.ProductID =c.ProductID
      LEFT JOIN processpayment m ON m.OrderNumber =s.OrderNumber
      LEFT JOIN deliverydriver d ON d.DeliveryDriverID=s.DeliveryDriverID
      LEFT JOIN profile f ON f.UserID =d.DeliveryDriverID
      WHERE i.MainImage='Y' AND s.PayToDriver="N" AND s.DeliveryDriverID != "NULL" AND s.DeliveryDriverID != "null" AND s.DeliveryDriverID != "" AND s.ProcessStatus="Delivered" AND s.DeliveryDate < DATE_SUB(NOW(), INTERVAL 15 DAY)
      AND s.OrderNumber NOT IN (SELECT OrderNumber
        FROM processorder 
        WHERE (if(DeliveryDriverID != "NULL" AND PaymentType="cod" AND DriverCodPaymentStatus="N",OrderNumber,null)))
        AND s.DeliveryDriverID="${DeliveryDriverID}"
      GROUP BY s.ProcessOrderID
      ORDER BY s.ProcessOrderID DESC
         `;
    let getDriverDetails = await connection.query(getDriverDetailsQuery, {
      type: QueryTypes.SELECT,
    });
    console.log(getDriverDetails);
    let productCombinationDetail;
    if (getDriverDetails && getDriverDetails.length > 0) {
      for (let i = 0; i < getDriverDetails.length; i++) {
        let ProductVariantCombinationDetail = [];
        ProductVariantCombinationDetail.push(
          getDriverDetails[i].ProductVariantCombinationDetail
        );
        ProductVariantCombinationDetail = `(${ProductVariantCombinationDetail.join(
          ","
        )})`;
        productCombinationDetail = await connection.query(
          `SELECT p.ProductID,c.ProductVariantCombinationID,c.VendorStoreID,c.Price AS ProductCombinationPrice,c.AvailableInventory,o.OptionID,o.OptionName,v.OptionValue,v.OptionValueID
              FROM ((((product p
              LEFT JOIN productvariantoption o ON o.ProductID IN( p.ProductID))
              LEFT JOIN productvariantoptionvalue v  ON  v.OptionID IN (o.OptionID)) 
              LEFT JOIN productvariantcombination c  ON  c.OptionValueID IN (v.OptionValueID))
              LEFT JOIN processorder s ON s.ProductID IN(c.ProductID))
              WHERE  c.ProductVariantCombinationID IN ${ProductVariantCombinationDetail} 
              GROUP BY c.OptionValueID
             `,
          {
            type: QueryTypes.SELECT,
          }
        );
        productCombinationPriceDetail.push(productCombinationDetail);
      }

      let tempPC = productCombinationPriceDetail;
      let tempProd = getDriverDetails;
      let tempArray = [];
      let tempAOrderDetails = [];
      let orderName = [];
      let orderDate = [];
      let deliveryDate = [];
      var deliveryDriverID = [];
      let driverPaymentAmount = [];
      let totalShippingAmount = [];
      let banglaBazarPaymentAmount = [];
      for (let i = 0; i < tempProd.length; i++) {
        var obj = {
          ...tempProd[i],
        };
        obj["ProductCombinations"] = tempPC[i];
        tempArray.push(obj);
      }
      for (let i = 0; i < tempArray.length; i++) {
        if (!orderName.includes(tempArray[i].OrderNumber)) {
          orderName.push(tempArray[i].OrderNumber);
          orderDate.push(tempArray[i].OrderDate);
          deliveryDriverID.push(tempArray[i].DeliveryDriverID);
          payToDriver.push(tempArray[i].PayToDriver);
          deliveryDate.push(tempArray[i].DeliveryDate);
          totalShippingAmount.push(tempArray[i].TotalShippingAmount);
          driverPaymentAmount.push(tempArray[i].DriverPaymentAmount);
          banglaBazarPaymentAmount.push(tempArray[i].BanglaBazarPaymentAmount);
        }
      }
      for (let i = 0; i < orderName.length; i++) {
        var obj = {
          OrderNumber: orderName[i],
          OrderDate: orderDate[i],
          DeliveryDriverID: deliveryDriverID[i],
          PayToDriver: payToDriver[i],
          DeliveryDate: deliveryDate[i],
          TotalShippingAmount: totalShippingAmount[i],
          DriverPaymentAmount: driverPaymentAmount[i],
          BanglaBazarPaymentAmount: banglaBazarPaymentAmount[i],
          ProductDetail: [],
        };
        for (let j = 0; j < tempArray.length; j++) {
          if (orderName[i] === tempArray[j].OrderNumber) {
            obj.ProductDetail.push(tempArray[j]);
          }
        }
        tempAOrderDetails.push(obj);
      }

      if (productCombinationDetail && productCombinationDetail.length > 0) {
        res.status(200).json({
          status: true,

          getDriverDetails: tempAOrderDetails,
        });
      } else {
        res.status(200).json({
          status: true,

          getDriverDetails: [],
        });
      }
    } else {
      res.status(200).json({
        status: true,

        getDriverDetails: [],
      });
    }
  } catch (err) {
    console.log(err.message);
    next(err);
    res.status(200).json({
      status: false,
      getDriverDetails: [],
      message: err.message,
    });
  }
};
exports.addDriverPaymentProcess = async (req, res, next) => {
  let transaction;
  try {
    transaction = await connection.transaction();
    const { DriverPaymentDetails } = req.body;
    const DriverPaymentDetail = JSON.parse(DriverPaymentDetails);
    console.log(DriverPaymentDetail);
    let PaymentConfirmation = req.file.path;
    console.log(PaymentConfirmation, "PaymentConfirmation");
    let OrderNumber = [];
    for (let i = 0; i < DriverPaymentDetail.length; i++) {
      OrderNumber.push(DriverPaymentDetail[i].OrderNumber);
    }
    OrderNumber = `(${OrderNumber.join(",")})`;
    console.log(OrderNumber);
    let LastUpdate = new Date().toISOString().slice(0, 19).replace("T", " ");

    let insertDriverPaymentProcessQuery = `INSERT INTO driverpaymentprocess ( OrderNumber,DeliveryCity,TotalShippingAmount,DriverPaymentAmount,BanglaBazarPaymentAmount,ProcessDate,ProcessStatus) values  `;

    for (let i = 0; i < DriverPaymentDetail.length; i++) {
      if (i == DriverPaymentDetail.length - 1) {
        insertDriverPaymentProcessQuery += `('${DriverPaymentDetail[i].OrderNumber}','${DriverPaymentDetail[i].DeliveryCity}','${DriverPaymentDetail[i].TotalShippingAmount}','${DriverPaymentDetail[i].DriverPaymentAmount}', '${DriverPaymentDetail[i].BanglaBazarPaymentAmount}','${LastUpdate}',"Y")`;
      } else {
        insertDriverPaymentProcessQuery += `('${DriverPaymentDetail[i].OrderNumber}','${DriverPaymentDetail[i].DeliveryCity}','${DriverPaymentDetail[i].TotalShippingAmount}','${DriverPaymentDetail[i].DriverPaymentAmount}', '${DriverPaymentDetail[i].BanglaBazarPaymentAmount}','${LastUpdate}',"Y"),`;
      }
    }
    let insertDriverPaymentProcess = await connection.query(
      insertDriverPaymentProcessQuery,
      { transaction }
    );
    if (insertDriverPaymentProcess) {
      let updateDriverPaymentStatusQuery = `UPDATE processorder,driverpaymentprocess
        SET processorder.PayToDriver="Y",
        driverpaymentprocess.PaymentConfirmation =?
        WHERE processorder.OrderNumber IN ${OrderNumber} 
        AND driverpaymentprocess.OrderNumber IN ${OrderNumber} `;

      let updateDriverPaymentStatus = await connection.query(
        updateDriverPaymentStatusQuery,
        { replacements: [PaymentConfirmation], transaction }
      );
      if (updateDriverPaymentStatus) {
        if (transaction) await transaction.commit();
        res.status(200).json({
          status: true,
          message: "Successfully added Driver Payment Details ",
        });
      } else {
        if (transaction) await transaction.rollback();
        res.status(200).json({
          status: false,
          message: "Error while updating Driver Payment Status ",
        });
      }
    } else {
      if (transaction) await transaction.rollback();
      res.status(200).json({
        status: false,
        message: "Error while adding Driver Payment Details ",
      });
    }
  } catch (err) {
    if (transaction) await transaction.rollback();
    console.log(err.message);
    next(err);
    res.status(200).json({
      status: false,
      message: err.message,
    });
  }
};
exports.getDriverPaymentDetails = async (req, res, next) => {
  try {
    const DeliveryDriverID = req.params.id;
    let productCombinationPriceDetail = [];
    let getDriverDetailsQuery = `SELECT s.OrderNumber,s.ProcessOrderID,p.ProductID,p.Title,p.Price AS ProductPrice,s.ItemsPrice ,s.ProcessStatus,s.OrderDate,s.PaymentType,s.ReturnReason,s.ProductVariantCombinationDetail,s.ItemsShippingHandling,s.ItemsEstimatedTax,s.DeliveryDate,s.DeliveryStatus,s.DeliveryDriverID,s.PayToDriver,s.DeliveryDate,d.*,s.OrderNumber AS CountOrder,
    m.ShippingHandling AS TotalShippingAmount,
    CASE 
    WHEN s.ReturnOrder="Y" AND s.ReturnOrderStatus="Refunded" THEN (m.ShippingHandling*2*0.05)
    ELSE (m.ShippingHandling*0.05) 
    END AS BanglaBazarPaymentAmount,
    CASE 
    WHEN ReturnOrder="Y" AND ReturnOrderStatus="Refunded" THEN ((m.ShippingHandling*2-m.ShippingHandling*2*0.05)
    ELSE (m.ShippingHandling-m.ShippingHandling*0.05) 
    END AS DriverPaymentAmount 
      FROM product p
      LEFT JOIN productvariantoption o ON o.ProductID = p.ProductID
      LEFT JOIN productvariantoptionvalue v  ON  v.OptionID  =o.OptionID  
      LEFT JOIN productimage i  ON  i.OptionValueID  =v.OptionValueID
      LEFT JOIN imagegallery g  ON  g.ImageGalleryID  =i.ImageGalleryID
      LEFT JOIN productvariantcombination c  ON  c.OptionValueID  =v.OptionValueID
      LEFT JOIN processorder s ON s.ProductID =c.ProductID
      LEFT JOIN processpayment m ON m.OrderNumber =s.OrderNumber
      LEFT JOIN driverpaymentprocess d ON d.OrderNumber =s.OrderNumber
      WHERE i.MainImage='Y' AND s.ProcessStatus="Delivered" AND s.PayToDriver="Y" AND s.DeliveryDriverID="${DeliveryDriverID}" AND s.DeliveryDate < DATE_SUB(NOW(), INTERVAL 30 DAY) 
      GROUP BY s.ProcessOrderID
      ORDER BY s.ProcessOrderID DESC
         `;
    let getDriverDetails = await connection.query(getDriverDetailsQuery, {
      type: QueryTypes.SELECT,
    });
    console.log(getDriverDetails);
    let productCombinationDetail;
    if (getDriverDetails && getDriverDetails.length > 0) {
      for (let i = 0; i < getDriverDetails.length; i++) {
        let ProductVariantCombinationDetail = [];
        ProductVariantCombinationDetail.push(
          getDriverDetails[i].ProductVariantCombinationDetail
        );
        ProductVariantCombinationDetail = `(${ProductVariantCombinationDetail.join(
          ","
        )})`;
        productCombinationDetail = await connection.query(
          `SELECT p.ProductID,c.ProductVariantCombinationID,c.VendorStoreID,c.Price AS ProductCombinationPrice,c.AvailableInventory,o.OptionID,o.OptionName,v.OptionValue,v.OptionValueID
              FROM ((((product p
              LEFT JOIN productvariantoption o ON o.ProductID IN( p.ProductID))
              LEFT JOIN productvariantoptionvalue v  ON  v.OptionID IN (o.OptionID)) 
              LEFT JOIN productvariantcombination c  ON  c.OptionValueID IN (v.OptionValueID))
              LEFT JOIN processorder s ON s.ProductID IN(c.ProductID))
              WHERE  c.ProductVariantCombinationID IN ${ProductVariantCombinationDetail} 
              GROUP BY c.OptionValueID
             `,
          {
            type: QueryTypes.SELECT,
          }
        );
        productCombinationPriceDetail.push(productCombinationDetail);
      }

      let tempPC = productCombinationPriceDetail;
      let tempProd = getDriverDetails;
      let tempArray = [];
      let tempAOrderDetails = [];
      let orderName = [];
      let orderDate = [];
      let deliveryDate = [];
      var deliveryDriverID = [];
      let payToDriver = [];
      let driverPaymentAmount = [];
      let totalShippingAmount = [];
      let banglaBazarPaymentAmount = [];
      for (let i = 0; i < tempProd.length; i++) {
        var obj = {
          ...tempProd[i],
        };
        obj["ProductCombinations"] = tempPC[i];
        tempArray.push(obj);
      }
      for (let i = 0; i < tempArray.length; i++) {
        if (!orderName.includes(tempArray[i].OrderNumber)) {
          orderName.push(tempArray[i].OrderNumber);
          orderDate.push(tempArray[i].OrderDate);
          deliveryDriverID.push(tempArray[i].DeliveryDriverID);
          payToDriver.push(tempArray[i].PayToDriver);
          deliveryDate.push(tempArray[i].DeliveryDate);
          totalShippingAmount.push(tempArray[i].TotalShippingAmount);
          driverPaymentAmount.push(tempArray[i].DriverPaymentAmount);
          banglaBazarPaymentAmount.push(tempArray[i].BanglaBazarPaymentAmount);
        }
      }
      for (let i = 0; i < orderName.length; i++) {
        var obj = {
          OrderNumber: orderName[i],
          OrderDate: orderDate[i],
          DeliveryDriverID: deliveryDriverID[i],
          PayToDriver: payToDriver[i],
          TotalShippingAmount: totalShippingAmount[i],
          DriverPaymentAmount: driverPaymentAmount[i],
          BanglaBazarPaymentAmount: banglaBazarPaymentAmount[i],
          ProductDetail: [],
        };
        for (let j = 0; j < tempArray.length; j++) {
          if (orderName[i] === tempArray[j].OrderNumber) {
            obj.ProductDetail.push(tempArray[j]);
          }
        }
        tempAOrderDetails.push(obj);
      }

      if (productCombinationDetail && productCombinationDetail.length > 0) {
        res.status(200).json({
          status: true,

          getDriverDetails: tempAOrderDetails,
        });
      } else {
        res.status(200).json({
          status: true,

          getDriverDetails: [],
        });
      }
    } else {
      res.status(200).json({
        status: true,

        getDriverDetails: [],
      });
    }
  } catch (err) {
    console.log(err.message);
    next(err);
    res.status(200).json({
      status: false,
      getDriverDetails: [],
      message: err.message,
    });
  }
};
//! COD Feature For Vendor Products
exports.setVendorCodStatus = async (req, res, next) => {
  try {
    const { VendorID, Status } = req.body;
    let getVendorProductsDetails = await connection.query(
      `SELECT * from product WHERE VendorID="${VendorID}" `,
      { type: QueryTypes.SELECT }
    );
    if (
      getVendorProductsDetails &&
      getVendorProductsDetails.length > 0 &&
      Status === "N"
    ) {
      let updateVendorAndProductsCodStatus = await connection.query(
        `UPDATE vendor,product
        SET vendor.VendorCodStatus = "N",
        product.ProductCodStatus ="N"
        WHERE
        vendor.VendorID="${VendorID}"
        AND product.VendorID = "${VendorID}"
         `
      );
      if (updateVendorAndProductsCodStatus) {
        res.status(200).json({
          status: true,
          message: "Successfully Updated vendor COD status",
        });
      } else {
        res.status(200).json({
          status: false,
          message: "Unable to update vendor COD status",
        });
      }
    } else {
      let updateVendorCodStatus = await connection.query(
        `UPDATE vendor SET VendorCodStatus="${Status}" WHERE VendorID="${VendorID}" `
      );
      if (updateVendorCodStatus) {
        res.status(200).json({
          status: true,
          message: "Successfully updated vendor COD status",
        });
      } else {
        res.status(200).json({
          status: false,
          message: "Unable to update vendor COD status",
        });
      }
    }
  } catch (err) {
    console.log(err.message, "-----------------------------");
    next(err);
    res.status(200).json({
      status: false,
      message: err.message,
    });
  }
};
exports.getDriverPaymentOrderByDriverID = async (req, res, next) => {
  try {
    let { sort, status, limit, offset } = req.body;
    const DeliveryDriverID = req.params.id;
    limit = parseInt(limit);
    offset = parseInt(offset);
    offset = limit * offset;
    let productCombinationPriceDetail = [];
    let getDriverDetailsQuery = `SELECT s.OrderNumber,s.ProcessOrderID,p.ProductID,p.Title,p.Price AS ProductPrice,s.ItemsPrice ,s.ProcessStatus,s.OrderDate,s.PaymentType,f.UserName AS DriverName,s.ReturnReason,s.ProductVariantCombinationDetail,s.ItemsShippingHandling,s.ItemsEstimatedTax,s.DeliveryDate,s.DeliveryStatus,d.*,s.DeliveryDriverID,s.PayToDriver,s.DeliveryDate,
    s.OrderNumber AS CountOrder,m.ShippingHandling AS TotalShippingAmount,
    CASE 
        WHEN s.ReturnOrder="Y" AND s.ReturnOrderStatus="Refunded" THEN (m.ShippingHandling*2*0.05)
        ELSE (m.ShippingHandling*0.05) 
        END AS BanglaBazarPaymentAmount,
        CASE 
        WHEN ReturnOrder="Y" AND ReturnOrderStatus="Refunded" THEN ((m.ShippingHandling*2-m.ShippingHandling*2*0.05)
        ELSE (m.ShippingHandling-m.ShippingHandling*0.05) 
        END AS DriverPaymentAmount 
      FROM product p
      LEFT JOIN productvariantoption o ON o.ProductID = p.ProductID
      LEFT JOIN productvariantoptionvalue v  ON  v.OptionID  =o.OptionID  
      LEFT JOIN productimage i  ON  i.OptionValueID  =v.OptionValueID
      LEFT JOIN imagegallery g  ON  g.ImageGalleryID =i.ImageGalleryID
      LEFT JOIN productvariantcombination c  ON  c.OptionValueID  =v.OptionValueID
      LEFT JOIN processorder s ON s.ProductID =c.ProductID
      LEFT JOIN processpayment m ON m.OrderNumber =s.OrderNumber
      LEFT JOIN deliverydriver d ON d.DeliveryDriverID=s.DeliveryDriverID
      LEFT JOIN profile f ON f.UserID =d.DeliveryDriverID
      WHERE i.MainImage='Y' AND s.PayToDriver="N" AND s.DeliveryDriverID != "NULL" AND s.DeliveryDriverID != "null" AND s.DeliveryDriverID != "" AND s.ProcessStatus="Delivered" AND s.DeliveryDate < DATE_SUB(NOW(), INTERVAL 30 DAY)
      AND s.OrderNumber NOT IN (SELECT OrderNumber
        FROM processorder 
        WHERE (if(DeliveryDriverID != "NULL" AND PaymentType="cod" AND DriverCodPaymentStatus="N",OrderNumber,null)))
        AND s.DeliveryDriverID="${DeliveryDriverID}"
      GROUP BY s.ProcessOrderID
      ORDER BY s.ProcessOrderID DESC
         `;
    let getDriverDetails = await connection.query(getDriverDetailsQuery, {
      type: QueryTypes.SELECT,
    });
    console.log(getDriverDetails);

    let productCombinationDetail;
    if (getDriverDetails && getDriverDetails.length > 0) {
      for (let i = 0; i < getDriverDetails.length; i++) {
        let ProductVariantCombinationDetail = [];
        ProductVariantCombinationDetail.push(
          getDriverDetails[i].ProductVariantCombinationDetail
        );
        ProductVariantCombinationDetail = `(${ProductVariantCombinationDetail.join(
          ","
        )})`;
        productCombinationDetail = await connection.query(
          `SELECT p.ProductID,c.ProductVariantCombinationID,c.VendorStoreID,c.Price AS ProductCombinationPrice,c.AvailableInventory,o.OptionID,o.OptionName,v.OptionValue,v.OptionValueID
              FROM ((((product p
              LEFT JOIN productvariantoption o ON o.ProductID IN( p.ProductID))
              LEFT JOIN productvariantoptionvalue v  ON  v.OptionID IN (o.OptionID)) 
              LEFT JOIN productvariantcombination c  ON  c.OptionValueID IN (v.OptionValueID))
              LEFT JOIN processorder s ON s.ProductID IN(c.ProductID))
              WHERE  c.ProductVariantCombinationID IN ${ProductVariantCombinationDetail} 
              GROUP BY c.OptionValueID
             `,
          {
            type: QueryTypes.SELECT,
          }
        );
        productCombinationPriceDetail.push(productCombinationDetail);
      }

      let tempPC = productCombinationPriceDetail;
      let tempProd = getDriverDetails;
      let tempArray = [];
      let tempAOrderDetails = [];
      let orderName = [];
      let orderDate = [];
      let deliveryDate = [];
      var deliveryDriverID = [];
      let payToDriver = [];
      let driverPaymentAmount = [];
      let totalShippingAmount = [];
      let banglaBazarPaymentAmount = [];
      for (let i = 0; i < tempProd.length; i++) {
        var obj = {
          ...tempProd[i],
        };
        obj["ProductCombinations"] = tempPC[i];
        tempArray.push(obj);
      }
      for (let i = 0; i < tempArray.length; i++) {
        if (!orderName.includes(tempArray[i].OrderNumber)) {
          orderName.push(tempArray[i].OrderNumber);
          orderDate.push(tempArray[i].OrderDate);
          deliveryDriverID.push(tempArray[i].DeliveryDriverID);
          payToDriver.push(tempArray[i].PayToDriver);
          deliveryDate.push(tempArray[i].DeliveryDate);
          totalShippingAmount.push(tempArray[i].TotalShippingAmount);
          driverPaymentAmount.push(tempArray[i].DriverPaymentAmount);
          banglaBazarPaymentAmount.push(tempArray[i].BanglaBazarPaymentAmount);
        }
      }
      for (let i = 0; i < orderName.length; i++) {
        var obj = {
          OrderNumber: orderName[i],
          OrderDate: orderDate[i],
          DeliveryDriverID: deliveryDriverID[i],
          PayToDriver: payToDriver[i],
          DeliveryDate: deliveryDate[i],
          TotalShippingAmount: totalShippingAmount[i],
          DriverPaymentAmount: driverPaymentAmount[i],
          BanglaBazarPaymentAmount: banglaBazarPaymentAmount[i],
          ProductDetail: [],
        };
        for (let j = 0; j < tempArray.length; j++) {
          if (orderName[i] === tempArray[j].OrderNumber) {
            obj.ProductDetail.push(tempArray[j]);
          }
        }
        tempAOrderDetails.push(obj);
      }

      if (productCombinationDetail && productCombinationDetail.length > 0) {
        res.status(200).json({
          status: true,

          getDriverDetails: tempAOrderDetails,
        });
      } else {
        res.status(200).json({
          status: true,

          getDriverDetails: [],
        });
      }
    } else {
      res.status(200).json({
        status: true,

        getDriverDetails: [],
      });
    }
  } catch (err) {
    console.log(err.message);
    next(err);
    res.status(200).json({
      status: false,
      getDriverDetails: [],
      message: err.message,
    });
  }
};
exports.assignReturnOrder = async (req, res, next) => {
  let transaction;
  try {
    transaction = await connection.transaction();
    const { Status, OrderNumber, ProcessOrderIDs, type } = req.body;
    console.log(ProcessOrderIDs);
    if (Status === "dd") {
      let checkIfDriverExists = await connection.query(
        `SELECT d.*,o.OrderNumber
      from orderdeliveryaddress o
      INNER JOIN deliverydriver d ON d.CityID=o.CityID
      WHERE o.OrderNumber="${OrderNumber}" `,
        { type: QueryTypes.SELECT, transaction }
      );
      console.log(checkIfDriverExists);

      if (checkIfDriverExists && checkIfDriverExists.length > 0) {
        let getDriverID = await connection.query(
          `SELECT OrderNumber,ProcessOrderID,DeliveryDriverID
        from processorder  WHERE OrderNumber="${OrderNumber}" `,
          { type: QueryTypes.SELECT, transaction }
        );

        console.log(getDriverID);
        if (
          getDriverID[0].DeliveryDriverID === null ||
          getDriverID[0].DeliveryDriverID === "null" ||
          getDriverID[0].DeliveryDriverID === "NULL"
        ) {
          if (transaction) await transaction.rollback();
          res.status(200).json({
            status: false,
            message: "Error !! Delivery driver not found from db ",
          });
        } else {
          const idsWrappedInQuotes = ProcessOrderIDs.map(
            (ProcessOrderIDs) => `'${ProcessOrderIDs}'`
          );
          let ProcessOrderID = `(${idsWrappedInQuotes.join(",")})`;
          const DeliveryDriverID = getDriverID[0].DeliveryDriverID;
          let currentdateAndTime = [];
          let LastUpdate = new Date()
            .toISOString()
            .slice(0, 19)
            .replace("T", " ");
          currentdateAndTime[0] = LastUpdate;
          let ReturnStatusHistory = JSON.stringify(currentdateAndTime);

          let assignReturnOrder = await connection.query(
            `UPDATE processorder SET ReturnOrder="Y",ReturnOrderStatus="Assigned",ReturnOrderStatusHistory='${ReturnStatusHistory}' WHERE OrderNumber="${OrderNumber}" AND ProcessOrderID IN ${ProcessOrderID} `,
            { transaction }
          );
          if (assignReturnOrder) {
            let DriverAndUserDetail = await connection.query(
              `SELECT p.UserID,p.EmailAddress,dd.*
          from processorder po
          LEFT JOIN profile p ON p.UserID=po.UserID
          LEFT JOIN deliverydriver dd ON dd.DeliveryDriverID=po.DeliveryDriverID
           WHERE po.OrderNumber="${OrderNumber}" AND dd.DeliveryDriverID="${DeliveryDriverID}"`,
              { type: QueryTypes.SELECT, transaction }
            );
            if (DriverAndUserDetail && DriverAndUserDetail.length > 0) {
              //! user case
              const TypeID = "7";
              const CreaterID = "1";
              let Message;
              let EmailAddress;
              let UserID;
              let notification_body;
              let ReceiverID;
              for (let i = 0; i < 2; i++) {
                if (i === 0) {
                  //! 0 is user case
                  EmailAddress = DriverAndUserDetail[0].EmailAddress;
                  UserID = DriverAndUserDetail[0].UserID;
                  Message = `BanglaBazar Deliver Person is assigned to your return Order # ${OrderNumber} `;
                  notification_body = `BanglaBazar Deliver Person is assigned to your return Order # ${OrderNumber} `;
                  ReceiverID = UserID;
                }
                if (i === 1) {
                  //! 1 is delivery driver case
                  EmailAddress = DriverAndUserDetail[0].BusinessEmail;
                  Message = `You are assigned to Return Order # ${OrderNumber} click to get details `;
                  notification_body = `You are assigned to Return Order # ${OrderNumber} click to get details  `;
                  ReceiverID = DeliveryDriverID;
                }

                const userMailResponse = sendEmail(
                  EmailAddress,
                  Message,
                  TypeID
                );
                if (userMailResponse) {
                  let Body = {
                    OrderNumber: OrderNumber,
                    body: notification_body,
                  };

                  let sendNotification = await Notification(
                    TypeID,
                    Body,
                    CreaterID,
                    ReceiverID,
                    transaction
                  );
                  console.log(sendNotification, "sendNotification");
                  if (sendNotification) {
                    if (i === 1) {
                      if (transaction) await transaction.commit();
                      res.status(200).json({
                        status: true,
                        message:
                          "Successfully assigned delivery driver to return order",
                        driverDetail: DriverAndUserDetail[0],
                      });
                    } else {
                      continue;
                    }
                  } else {
                    if (transaction) await transaction.rollback();
                    res.status(200).json({
                      status: false,
                      message: "Error while sending notification to user",
                    });
                  }
                } else {
                  if (transaction) await transaction.rollback();
                  res.status(200).json({
                    status: false,
                    message:
                      "Error while sending mail to user about driver assigning",
                  });
                }
              }
            } else {
              if (transaction) await transaction.rollback();
              res.status(200).json({
                status: false,
                message: "Error while updating return order status",
              });
            }
          }
        }
      } else {
        if (transaction) await transaction.rollback();
        res.status(200).json({
          status: false,
          message: "Delivery driver does not exist in delivery city",
        });
      }
    } else if (Status === "VS") {
      const idsWrappedInQuotes = ProcessOrderIDs.map(
        (ProcessOrderIDs) => `'${ProcessOrderIDs}'`
      );
      let ProcessOrderID = `(${idsWrappedInQuotes.join(",")})`;
      let currentdateAndTime = [];
      let LastUpdate = new Date().toISOString().slice(0, 19).replace("T", " ");
      currentdateAndTime[0] = LastUpdate;
      let ReturnStatusHistory = JSON.stringify(currentdateAndTime);

      let assignReturnOrder = await connection.query(
        `UPDATE processorder SET ReturnOrder="Y",ReturnOrderStatus="Assigned",ReturnOrderStatusHistory='${ReturnStatusHistory}' WHERE OrderNumber="${OrderNumber}" AND ProcessOrderID IN ${ProcessOrderID} `,
        { transaction }
      );
      if (assignReturnOrder) {
        let getUserDeatils = await connection.query(
          `SELECT p.UserID,p.EmailAddress
      from processorder po
      LEFT JOIN profile p ON p.UserID=po.UserID
       WHERE po.OrderNumber="${OrderNumber}" AND ProcessOrderID IN ${ProcessOrderID} `,
          { type: QueryTypes.SELECT, transaction }
        );
        if (getUserDeatils && getUserDeatils.length > 0) {
          //! user case
          const TypeID = "7";
          const CreaterID = "1";
          let Message;
          let EmailAddress;
          let UserID;
          let notification_body;
          let ReceiverID;

          EmailAddress = getUserDeatils[0].EmailAddress;
          UserID = getUserDeatils[0].UserID;
          Message = `Vendor own shipping is assigned to your return Order # ${OrderNumber} `;
          notification_body = `Vendor own shipping is assigned to your return Order # ${OrderNumber} `;
          ReceiverID = UserID;
          const userMailResponse = sendEmail(EmailAddress, Message, TypeID);
          if (userMailResponse) {
            let Body = {
              OrderNumber: OrderNumber,
              body: notification_body,
            };

            let sendNotification = await Notification(
              TypeID,
              Body,
              CreaterID,
              ReceiverID,
              transaction
            );
            console.log(sendNotification, "sendNotification");
            if (sendNotification) {
              if (transaction) await transaction.commit();
              res.status(200).json({
                status: true,
                message:
                  "Successfully assigned Vendor own shipping to return order",
                driverDetail: getUserDeatils[0],
              });
            } else {
              if (transaction) await transaction.rollback();
              res.status(200).json({
                status: false,
                message: "Error while sending notification to user",
              });
            }
          } else {
            if (transaction) await transaction.rollback();
            res.status(200).json({
              status: false,
              message:
                "Error while sending mail to user about Vendor own shipping assigning",
            });
          }
        } else {
          if (transaction) await transaction.rollback();
          res.status(200).json({
            status: false,
            message: "Error while updating return order status",
          });
        }
      } else {
        if (transaction) await transaction.rollback();
        next(err);
        res.status(200).json({
          status: false,
          message: "Error while assigning return order",
        });
      }
    } else if (Status === "SP") {
      const idsWrappedInQuotes = ProcessOrderIDs.map(
        (ProcessOrderIDs) => `'${ProcessOrderIDs}'`
      );
      let ProcessOrderID = `(${idsWrappedInQuotes.join(",")})`;
      let currentdateAndTime = [];
      let LastUpdate = new Date().toISOString().slice(0, 19).replace("T", " ");
      currentdateAndTime[0] = LastUpdate;
      let ReturnStatusHistory = JSON.stringify(currentdateAndTime);

      let assignReturnOrder = await connection.query(
        `UPDATE processorder SET ReturnOrder="Y",ReturnOrderStatus="Assigned",ReturnOrderStatusHistory='${ReturnStatusHistory}' WHERE OrderNumber="${OrderNumber}" AND ProcessOrderID IN ${ProcessOrderID} `,
        { transaction }
      );
      if (assignReturnOrder) {
        let getUserDeatils = await connection.query(
          `SELECT p.UserID,p.EmailAddress
      from processorder po
      INNER JOIN profile p ON p.UserID=po.UserID
      WHERE po.OrderNumber="${OrderNumber}" `,
          { type: QueryTypes.SELECT, transaction }
        );
        if (getUserDeatils && getUserDeatils.length > 0) {
          const UserID = getUserDeatils[0].UserID;
          const UserEmailAddress = getUserDeatils[0].EmailAddress;

          const TypeID = "7";
          const CreaterID = "1";
          let Message = `Please drop products against Refund Order # ${OrderNumber} at Vendor Store click to get details`;
          const userMailResponse = sendEmail(UserEmailAddress, Message, TypeID);
          if (userMailResponse) {
            let Body = {
              OrderNumber: OrderNumber,
              body: `Please drop products against Refund Order # ${OrderNumber} at Vendor Store click to get details`,
            };
            let ReceiverID = UserID;
            let sendNotification = await Notification(
              TypeID,
              Body,
              CreaterID,
              ReceiverID,
              transaction
            );
            console.log(sendNotification, "sendNotification");
            if (sendNotification) {
              if (transaction) await transaction.commit();
              res.status(200).json({
                status: true,
                message: "Successfully notified user about store pickup",
              });
            } else {
              if (transaction) await transaction.rollback();
              res.status(200).json({
                status: false,
                message: "Error while sending notification to user",
              });
            }
          } else {
            if (transaction) await transaction.rollback();
            res.status(200).json({
              status: false,
              message: "Error while sending mail to user",
            });
          }
        } else {
          if (transaction) await transaction.rollback();
          res.status(200).json({
            status: false,
            message: "Error while getting user details from DB",
          });
        }
      } else {
        if (transaction) await transaction.rollback();
        next(err);
        res.status(200).json({
          status: false,
          message: "Error while assigning return order",
        });
      }
    } else if (Status === "pathao") {
      const idsWrappedInQuotes = ProcessOrderIDs.map(
        (ProcessOrderIDs) => `'${ProcessOrderIDs}'`
      );
      let ProcessOrderID = `(${idsWrappedInQuotes.join(",")})`;
      let currentdateAndTime = [];
      let LastUpdate = new Date().toISOString().slice(0, 19).replace("T", " ");
      currentdateAndTime[0] = LastUpdate;
      let ReturnStatusHistory = JSON.stringify(currentdateAndTime);

      let assignReturnOrder = await connection.query(
        `UPDATE processorder SET ReturnOrder="Y",ReturnOrderStatus="Assigned",ReturnOrderStatusHistory='${ReturnStatusHistory}' WHERE OrderNumber="${OrderNumber}" AND ProcessOrderID IN ${ProcessOrderID} `,
        { transaction }
      );
      if (assignReturnOrder) {
        let getUserDeatils = await connection.query(
          `SELECT p.UserID,p.EmailAddress
          from processorder po
          LEFT JOIN profile p ON p.UserID=po.UserID
           WHERE po.OrderNumber="${OrderNumber}" AND ProcessOrderID IN ${ProcessOrderID} `,
          { type: QueryTypes.SELECT, transaction }
        );
        if (getUserDeatils && getUserDeatils.length > 0) {
          //! user case
          const TypeID = "7";
          const CreaterID = "1";
          let Message;
          let EmailAddress;
          let UserID;
          let notification_body;
          let ReceiverID;

          EmailAddress = getUserDeatils[0].EmailAddress;
          UserID = getUserDeatils[0].UserID;
          Message = `Pathao is assigned to your return Order # ${OrderNumber} `;
          notification_body = `Pathao is assigned to your return Order # ${OrderNumber} `;
          ReceiverID = UserID;
          const userMailResponse = sendEmail(EmailAddress, Message, TypeID);
          if (userMailResponse) {
            let Body = {
              OrderNumber: OrderNumber,
              body: notification_body,
            };

            let sendNotification = await Notification(
              TypeID,
              Body,
              CreaterID,
              ReceiverID,
              transaction
            );
            console.log(sendNotification, "sendNotification");
            if (sendNotification) {
              if (transaction) await transaction.commit();
              res.status(200).json({
                status: true,
                message: "Successfully assigned pathao to return order",
                driverDetail: getUserDeatils[0],
              });
            } else {
              if (transaction) await transaction.rollback();
              res.status(200).json({
                status: false,
                message: "Error while sending notification to user",
              });
            }
          } else {
            if (transaction) await transaction.rollback();
            res.status(200).json({
              status: false,
              message: "Error while sending mail to user about assigning",
            });
          }
        } else {
          if (transaction) await transaction.rollback();
          res.status(200).json({
            status: false,
            message: "Error while updating return order status",
          });
        }
      } else {
        if (transaction) await transaction.rollback();
        next(err);
        res.status(200).json({
          status: false,
          message: "Error while assigning return order",
        });
      }
    } else if (Status === "usps") {
      const idsWrappedInQuotes = ProcessOrderIDs.map(
        (ProcessOrderIDs) => `'${ProcessOrderIDs}'`
      );
      let ProcessOrderID = `(${idsWrappedInQuotes.join(",")})`;
      let currentdateAndTime = [];
      let LastUpdate = new Date().toISOString().slice(0, 19).replace("T", " ");
      currentdateAndTime[0] = LastUpdate;
      let ReturnStatusHistory = JSON.stringify(currentdateAndTime);

      let assignReturnOrder = await connection.query(
        `UPDATE processorder SET ReturnOrder="Y",ReturnOrderStatus="Assigned",ReturnOrderStatusHistory='${ReturnStatusHistory}' WHERE OrderNumber="${OrderNumber}" AND ProcessOrderID IN ${ProcessOrderID} `,
        { transaction }
      );
      if (assignReturnOrder) {
        let getUserDeatils = await connection.query(
          `SELECT p.UserID,p.EmailAddress
          from processorder po
          LEFT JOIN profile p ON p.UserID=po.UserID
           WHERE po.OrderNumber="${OrderNumber}" AND ProcessOrderID IN ${ProcessOrderID} `,
          { type: QueryTypes.SELECT, transaction }
        );
        if (getUserDeatils && getUserDeatils.length > 0) {
          //! user case
          const TypeID = "7";
          const CreaterID = "1";
          let Message;
          let EmailAddress;
          let UserID;
          let notification_body;
          let ReceiverID;

          EmailAddress = getUserDeatils[0].EmailAddress;
          UserID = getUserDeatils[0].UserID;
          type === "Y"
            ? (Message = `Admin approve your refund request and USPS is assigned to your return Order # ${OrderNumber} `)
            : (Message = `Admin approve your refund request.Now You have to return your own Order # ${OrderNumber} as this is paid return order `);
          type === "Y"
            ? (notification_body = `Admin approve your refund request and USPS is assigned to your return Order # ${OrderNumber} `)
            : (notification_body = `Admin approve your refund request.Now You have to return your own Order # ${OrderNumber} as this is paid return order `);
          ReceiverID = UserID;
          const userMailResponse = sendEmail(EmailAddress, Message, TypeID);
          if (userMailResponse) {
            let Body = {
              OrderNumber: OrderNumber,
              body: notification_body,
              status: "Processing",
              type: type,
            };

            let sendNotification = await Notification(
              TypeID,
              Body,
              CreaterID,
              ReceiverID,
              transaction
            );
            console.log(sendNotification, "sendNotification");
            if (sendNotification) {
              if (transaction) await transaction.commit();
              res.status(200).json({
                status: true,
                message: "Successfully assigned usps to return order",
                driverDetail: getUserDeatils[0],
              });
            } else {
              if (transaction) await transaction.rollback();
              res.status(200).json({
                status: false,
                message: "Error while sending notification to user",
              });
            }
          } else {
            if (transaction) await transaction.rollback();
            res.status(200).json({
              status: false,
              message: "Error while sending mail to user about assigning",
            });
          }
        } else {
          if (transaction) await transaction.rollback();
          res.status(200).json({
            status: false,
            message: "Error while updating return order status",
          });
        }
      } else {
        if (transaction) await transaction.rollback();
        next(err);
        res.status(200).json({
          status: false,
          message: "Error while assigning return order",
        });
      }
    } else {
      if (transaction) await transaction.rollback();
      next(err);
      res.status(200).json({
        status: false,
        getDriverDetails: [],
        message: "Invalid delivery status ",
      });
    }
  } catch (err) {
    console.log(err.message);
    if (transaction) await transaction.rollback();
    next(err);
    res.status(200).json({
      status: false,
      getDriverDetails: [],
      message: err.message,
    });
  }
};
exports.assignReturnOrderUSA = async (req, res, next) => {
  let transaction;
  try {
    transaction = await connection.transaction();
    const { Status, OrderNumber, ProcessOrderIDs, type } = req.body;
    let path = req.file.path;
    let str = "\\";
    let RefundDocument = path.split(str).join("//");
    console.log(ProcessOrderIDs);
    if (Status === "usps") {
      const idsWrappedInQuotes = ProcessOrderIDs.map(
        (ProcessOrderIDs) => `'${ProcessOrderIDs}'`
      );
      let ProcessOrderID = `(${idsWrappedInQuotes.join(",")})`;
      let currentdateAndTime = [];
      let LastUpdate = new Date().toISOString().slice(0, 19).replace("T", " ");
      currentdateAndTime[0] = LastUpdate;
      let ReturnStatusHistory = JSON.stringify(currentdateAndTime);

      let assignReturnOrder = await connection.query(
        `UPDATE processorder SET ReturnOrder="Y",ReturnOrderStatus="Assigned",ReturnOrderStatusHistory='${ReturnStatusHistory}' WHERE OrderNumber="${OrderNumber}" AND ProcessOrderID IN ${ProcessOrderID} `,
        { transaction }
      );
      if (assignReturnOrder) {
        let getUserDeatils = await connection.query(
          `SELECT p.UserID,p.EmailAddress
          from processorder po
          LEFT JOIN profile p ON p.UserID=po.UserID
           WHERE po.OrderNumber="${OrderNumber}" AND ProcessOrderID IN ${ProcessOrderID} `,
          { type: QueryTypes.SELECT, transaction }
        );
        if (getUserDeatils && getUserDeatils.length > 0) {
          //! user case
          const TypeID = "7";
          const CreaterID = "1";
          let Message;
          let EmailAddress;
          let UserID;
          let notification_body;
          let ReceiverID;

          EmailAddress = getUserDeatils[0].EmailAddress;
          UserID = getUserDeatils[0].UserID;
          type === "Y"
            ? (Message = `Admin approve your refund request and now you have to drop Order # ${OrderNumber} in drop box office or mail box outside of your home`)
            : (Message = `Admin approve your refund request.Now You have to return your own Order # ${OrderNumber} as this is paid return order `);
          type === "Y"
            ? (notification_body = `Admin approve your refund request and now you have to drop Order # ${OrderNumber} in drop box office or mail box outside of your home`)
            : (notification_body = `Admin approve your refund request.Now You have to return your own Order # ${OrderNumber} as this is paid return order `);
          ReceiverID = UserID;
          const userMailResponse = sendEmail(EmailAddress, Message, TypeID);
          if (userMailResponse) {
            let Body = {
              OrderNumber: OrderNumber,
              body: notification_body,
              status: "Processing",
              type: type,
            };

            let sendNotification = await Notification(
              TypeID,
              Body,
              CreaterID,
              ReceiverID,
              transaction
            );
            console.log(sendNotification, "sendNotification");
            if (sendNotification) {
              let updateReturnShippingLabel = await connection.query(
                `UPDATE processrefand 
                 SET UspsReturnShippingLabel=?
                 WHERE ProcessOrderID IN ${ProcessOrderID} `,
                { replacements: [RefundDocument], transaction }
              );
              if (updateReturnShippingLabel) {
                const type_ID = "8";
                let _body = `Please click on this link to download usps shipping label.You have to attached this label with return order.`;
                let Body = {
                  OrderNumber: OrderNumber,
                  body: _body,
                  path: RefundDocument,
                };
                let _sendNotification = await Notification(
                  type_ID,
                  Body,
                  CreaterID,
                  ReceiverID,
                  transaction
                );
                if (_sendNotification) {
                  if (transaction) await transaction.commit();
                  res.status(200).json({
                    status: true,
                    message: "Successfully assigned return order",
                  });
                } else {
                  if (transaction) await transaction.rollback();
                  res.status(200).json({
                    status: false,
                    message: "Error while updating shipping label",
                  });
                }
              } else {
                if (transaction) await transaction.rollback();
                res.status(200).json({
                  status: false,
                  message: "Error while updating shipping label",
                });
              }
            }
          } else {
            if (transaction) await transaction.rollback();
            res.status(200).json({
              status: false,
              message: "Error while sending mail to user about assigning",
            });
          }
        } else {
          if (transaction) await transaction.rollback();
          res.status(200).json({
            status: false,
            message: "Error while updating return order status",
          });
        }
      } else {
        if (transaction) await transaction.rollback();
        next(err);
        res.status(200).json({
          status: false,
          message: "Error while assigning return order",
        });
      }
    } else {
      if (transaction) await transaction.rollback();
      next(err);
      res.status(200).json({
        status: false,
        getDriverDetails: [],
        message: "Invalid delivery status ",
      });
    }
  } catch (err) {
    console.log(err.message);
    if (transaction) await transaction.rollback();
    next(err);
    res.status(200).json({
      status: false,
      getDriverDetails: [],
      message: err.message,
    });
  }
};
exports.codRefundApis = async (req, res, next) => {
  let transaction;
  try {
    const { OrderNumber, ProcessOrderIDs, AccountNo } = req.body;
    console.log(req.body);
    const RefundCodDepositProof = req.file.path;
    const idsWrappedInQuotes = ProcessOrderIDs.map(
      (ProcessOrderIDs) => `'${ProcessOrderIDs}'`
    );
    let ProcessOrderID = `(${idsWrappedInQuotes.join(",")})`;
    let LastUpdate = new Date().toISOString().slice(0, 19).replace("T", " ");
    let parsePreviousStatusHistory = [];
    const getPreviousRefundHistory = await connection.query(
      `SELECT StatusHistory FROM processorder WHERE ProcessOrderID IN ${ProcessOrderID}`,
      { type: QueryTypes.SELECT, transaction }
    );

    if (getPreviousRefundHistory && getPreviousRefundHistory.length > 0) {
      parsePreviousStatusHistory = JSON.parse(
        getPreviousRefundHistory[0].StatusHistory
      );
      parsePreviousStatusHistory.push(LastUpdate);
      let updateReturnOrderDetailsQuery = `
      UPDATE processorder,processrefand 
      SET processorder.RefundStatus="Refunded",processorder.RefundStatusHistory='${JSON.stringify(
        parsePreviousStatusHistory
      )}',processrefand.ProcessRefandResponse=?
      WHERE processorder.ProcessOrderID IN ${ProcessOrderID} AND processrefand.ProcessOrderID IN ${ProcessOrderID} 
 `;
      let updateReturnOrderDetails = await connection.query(
        updateReturnOrderDetailsQuery,
        { replacements: [RefundCodDepositProof], transaction }
      );
      if (updateReturnOrderDetails) {
        const getUserDeatils = await connection.query(
          `SELECT p.UserID ,p.EmailAddress
        from processorder po
        INNER JOIN profile p ON p.UserID=po.UserID
        where po.OrderNumber="${OrderNumber}"
   `,
          { type: QueryTypes.SELECT, transaction }
        );
        const TypeID = "7";
        const senderID = "1";
        let EmailAddress = getUserDeatils[0].EmailAddress;
        const receiverID = getUserDeatils[0].UserID;
        let Message = `Admin has inititaed payment process against your refund OrderNumber ${OrderNumber}, you will get your payment back in 10 to 12 days in your given Account No ${AccountNo} `;
        sendEmail(EmailAddress, Message, TypeID);
        let Body = {
          OrderNumber: OrderNumber,
          body: `Admin has inititaed payment process against your refund OrderNumber ${OrderNumber}, you will get your payment back in 10 to 12 days in your given Account No ${AccountNo}  `,
        };
        let sendNotification = await Notification(
          TypeID,
          Body,
          senderID,
          receiverID,
          transaction
        );
        if (sendNotification) {
          if (transaction) await transaction.commit();
          res.status(200).json({
            status: true,
            message: "Successfuly inititaed refund payment process",
          });
        } else {
          if (transaction) await transaction.rollback();
          res.status(200).json({
            status: false,
            message: "Error while sending Notification to User ",
          });
        }
      } else {
        if (transaction) await transaction.rollback();
        next(err);
        res.status(200).json({
          status: false,
          message: err.message,
        });
      }
    } else {
      if (transaction) await transaction.rollback();
      next(err);
      res.status(200).json({
        status: false,
        message: "Error while getting refund status history from DB",
      });
    }
  } catch (err) {
    if (transaction) await transaction.rollback();
    next(err);
    res.status(200).json({
      status: false,
      message: err.message,
    });
  }
};
exports.getProductConfirmRefundOrdersOld = async (req, res, next) => {
  try {
    // let Region = req.region;
    // const currencyRate = req.currency_rate;
    let { limit, offset, sort, search } = req.body;
    let productCombinationPriceDetail = [];
    limit = parseInt(limit);
    offset = parseInt(offset);
    offset = limit * offset;
    let getCount = await connection.query(
      `SELECT COUNT(DISTINCT o.OrderNumber) AS total_records
      FROM processorder o
      INNER JOIN processrefand pr ON pr.ProcessOrderID= o.ProcessOrderID
      WHERE OrderNumber NOT IN (SELECT o.OrderNumber
      FROM processorder o
      INNER JOIN processrefand pr ON pr.ProcessOrderID= o.ProcessOrderID 
      WHERE pr.RefandProductReceiveDate IS NULL OR pr.RefandProductReceiveDate='' ) 
     `,
      {
        type: QueryTypes.SELECT,
      }
    );
    console.log(getCount);
    if (getCount[0].total_records && getCount[0].total_records > 0) {
      let viewOrderListQuery = `SELECT p.ProductID,p.Title,m.TransactionID,s.OrderNumber,s.AllowStorePickup,s.AllowAdminPickup,s.ReadyPickupForUser,s.ReadyPickupForAdmin,s.OrderDate,m.PaymentStatus,p.Price AS BasePrice,s.Quantity,p.Currency,s.UserID,g.Small,g.Medium,g.Large,i.MainImage,s.StatusHistory,s.ProcessStatus,s.DeliveryDriverID,s.ConsignmentId,s.*,r.CountryID AS VendorCountry,pr.*,s.RefundStatus,s.RefundStatusHistory
          FROM ((((((((( product p      
          LEFT JOIN productvariantoption o ON o.ProductID IN( p.ProductID))
          LEFT JOIN productvariantoptionvalue v  ON  v.OptionID IN (o.OptionID))  
          LEFT JOIN productimage i  ON  i.OptionValueID IN (v.OptionValueID))
          LEFT JOIN imagegallery g  ON  g.ImageGalleryID IN (i.ImageGalleryID))
          LEFT JOIN productvariantcombination c  ON  c.OptionValueID IN (v.OptionValueID))
          LEFT JOIN processorder s ON s.ProductID IN(c.ProductID))
          INNER JOIN processrefand pr ON pr.ProcessOrderID IN (s.ProcessOrderID))
          LEFT JOIN vendor r ON (r.VendorID= p.VendorID))
          LEFT JOIN processpayment m ON m.OrderNumber IN(s.OrderNumber))
          WHERE i.MainImage='Y'  AND s.RefundStatus="Processing" AND s.OrderNumber LIKE "%${search}%" AND s.OrderNumber NOT IN  (select * from ( SELECT o.OrderNumber
            FROM processorder o
            INNER JOIN processrefand pr ON pr.ProcessOrderID= o.ProcessOrderID 
            WHERE pr.RefandProductReceiveDate IS NULL OR pr.RefandProductReceiveDate='' ) OrderNumber)
            GROUP BY s.ProcessOrderID  
            ORDER BY s.ProcessOrderID ${sort} 
            LIMIT ${limit} OFFSET ${offset}`;
      let viewOrderList = await connection.query(viewOrderListQuery, {
        type: QueryTypes.SELECT,
      });
      //!This version of MariaDB doesn't yet support 'LIMIT & IN/ALL/ANY/SOME subquery' to bypass this error above i am using extra select * in above subquery
      console.log(viewOrderList);
      let productCombinationDetail;
      if (viewOrderList && viewOrderList.length > 0) {
        for (let i = 0; i < viewOrderList.length; i++) {
          let ProductVariantCombinationDetail = [];
          ProductVariantCombinationDetail.push(
            viewOrderList[i].ProductVariantCombinationDetail
          );
          ProductVariantCombinationDetail = `(${ProductVariantCombinationDetail.join(
            ","
          )})`;
          productCombinationDetail = await connection.query(
            `SELECT p.ProductID,c.ProductVariantCombinationID,c.VendorStoreID,c.Price AS ProductCombinationPrice,c.AvailableInventory,o.OptionID,o.OptionName,v.OptionValue,v.OptionValueID,p.Currency
              FROM ((((product p
              LEFT JOIN productvariantoption o ON o.ProductID IN( p.ProductID))
              LEFT JOIN productvariantoptionvalue v  ON  v.OptionID IN (o.OptionID)) 
              LEFT JOIN productvariantcombination c  ON  c.OptionValueID IN (v.OptionValueID))
              LEFT JOIN processorder s ON s.ProductID IN(c.ProductID))
              WHERE  c.ProductVariantCombinationID IN ${ProductVariantCombinationDetail} 
              GROUP BY c.OptionValueID
              ORDER BY s.ProcessOrderID ASC
             `,
            {
              type: QueryTypes.SELECT,
            }
          );
          productCombinationPriceDetail.push(productCombinationDetail);
        }

        let getCurrencyRates = await connection.query(
          "SELECT * FROM currencyrate",
          {
            type: QueryTypes.SELECT,
          }
        );
        let VendorCountry = viewOrderList[0].VendorCountry;
        let currencyRate;
        if (VendorCountry == "16") {
          currencyRate = getCurrencyRates[1].Rate;
        } else {
          currencyRate = getCurrencyRates[0].Rate;
        }
        let orderName = [];
        let orderDate = [];
        let paymentStatus = [];
        let transactionID = [];
        let tempPC = productCombinationPriceDetail;
        let tempProd = viewOrderList;
        let tempArray = [];
        let allowStorePickup = [];
        let readyPickupForUser = [];
        let readyPickupForAdmin = [];
        let allowAdminPickup = [];
        let statusHistory = [];
        let processStatus = [];
        let tempAOrderDetails = [];

        for (let i = 0; i < tempProd.length; i++) {
          //!cuurency conversion
          if (VendorCountry == "16") {
            let Price = tempProd[i].BasePrice;
            if (tempProd[i].Currency == "$") {
              tempProd[i]["Currency"] = "BDT";
              tempProd[i]["BasePrice"] = parseFloat(
                currencyRate * Price
              ).toFixed(2);
            }
          } else if (VendorCountry == "226") {
            let Price = tempProd[i].BasePrice;
            if (tempProd[i].Currency == "BDT") {
              tempProd[i]["Currency"] = "$";
              tempProd[i]["BasePrice"] = parseFloat(
                currencyRate * Price
              ).toFixed(2);
            }
          } else {
            let Price = tempProd[i].BasePrice;
            tempProd[i]["Currency"] = "$";
            tempProd[i]["BasePrice"] = parseFloat(currencyRate * Price).toFixed(
              2
            );
          }
          var obj = {
            ...tempProd[i],
          };
          let variantsLength = tempPC[i].length;
          if (VendorCountry == "16") {
            for (let j = 0; j < variantsLength; j++) {
              let Price = tempPC[i][j].ProductCombinationPrice;
              if (tempPC[i][j].Currency == "$") {
                tempPC[i][j]["Currency"] = "BDT";
                tempPC[i][j]["ProductCombinationPrice"] = parseFloat(
                  currencyRate * Price
                ).toFixed(2);
              }
            }
          } else if (VendorCountry == "226") {
            for (let j = 0; j < variantsLength; j++) {
              let Price = tempPC[i][j].ProductCombinationPrice;
              if (tempPC[i][j].Currency == "BDT") {
                tempPC[i][j]["Currency"] = "$";
                tempPC[i][j]["ProductCombinationPrice"] = parseFloat(
                  currencyRate * Price
                ).toFixed(2);
              }
            }
          } else {
            for (let j = 0; j < variantsLength; j++) {
              let Price = tempPC[i][j].ProductCombinationPrice;
              tempPC[i][j]["Currency"] = "$";
              tempPC[i][j]["ProductCombinationPrice"] = parseFloat(
                currencyRate * Price
              ).toFixed(2);
            }
          }
          obj["ProductCombinations"] = tempPC[i];
          tempArray.push(obj);
        }
        for (let i = 0; i < tempArray.length; i++) {
          if (!orderName.includes(tempArray[i].OrderNumber)) {
            orderName.push(tempArray[i].OrderNumber);
            orderDate.push(tempArray[i].OrderDate);
            paymentStatus.push(tempArray[i].PaymentStatus);
            transactionID.push(tempArray[i].TransactionID);
            allowStorePickup.push(tempArray[i].AllowStorePickup);
            readyPickupForUser.push(tempArray[i].ReadyPickupForUser);
            readyPickupForAdmin.push(tempArray[i].ReadyPickupForAdmin);
            allowAdminPickup.push(tempArray[i].AllowAdminPickup);
            statusHistory.push(tempArray[i].StatusHistory);
            processStatus.push(tempArray[i].ProcessStatus);
          }
        }
        for (let i = 0; i < orderName.length; i++) {
          var obj = {
            OrderNumber: orderName[i],
            OrderDate: orderDate[i],
            PaymentStatus: paymentStatus[i],
            TransactionID: transactionID[i],
            AllowStorePickup: allowStorePickup[i],
            ReadyPickupForUser: readyPickupForUser[i],
            ReadyPickupForAdmin: readyPickupForAdmin[i],
            AllowAdminPickup: allowAdminPickup[i],
            StatusHistory: statusHistory[i],
            ProcessStatus: processStatus[i],
            ProductDetail: [],
          };
          for (let j = 0; j < tempArray.length; j++) {
            if (orderName[i] === tempArray[j].OrderNumber) {
              obj.ProductDetail.push(tempArray[j]);
            }
          }
          tempAOrderDetails.push(obj);
        }
        if (productCombinationDetail && productCombinationDetail.length > 0) {
          res.status(200).json({
            status: true,
            total_records: getCount[0].total_records,
            orderDetails: tempAOrderDetails,
          });
        } else {
          res.status(200).json({
            status: false,
            orderDetails: [],
          });
        }
      } else {
        res.status(200).json({
          status: true,
          total_records: getCount[0].total_records,
          orderDetails: [],
        });
      }
    } else {
      res.status(200).json({
        status: true,
        total_records: getCount[0].total_records,
        orderDetails: [],
      });
    }
  } catch (err) {
    console.log(err.message);
    next(err);
    res.status(200).json({
      status: false,
      orderDetails: [],
    });
  }
};
exports.getProductConfirmRefundOrdersFree = async (req, res, next) => {
  try {
    // let Region = req.region;
    // const currencyRate = req.currency_rate;
    let { limit, offset, sort, search } = req.body;
    let productCombinationPriceDetail = [];
    limit = parseInt(limit);
    offset = parseInt(offset);
    offset = limit * offset;
    let getCount = await connection.query(
      `SELECT COUNT(DISTINCT o.OrderNumber) AS total_records
      FROM processorder o
      INNER JOIN processrefand pr ON pr.ProcessOrderID= o.ProcessOrderID
      INNER JOIN product p ON p.ProductID= o.ProductID
      WHERE p.FreeProductReturn="Y" AND OrderNumber NOT IN (SELECT o.OrderNumber
      FROM processorder o
      INNER JOIN processrefand pr ON pr.ProcessOrderID= o.ProcessOrderID 
      INNER JOIN product p ON p.ProductID= o.ProductID
      WHERE p.FreeProductReturn="Y" AND pr.RefandProductReceiveDate IS NULL OR pr.RefandProductReceiveDate='' ) 
     `,
      {
        type: QueryTypes.SELECT,
      }
    );
    console.log(getCount);
    if (getCount[0].total_records && getCount[0].total_records > 0) {
      let viewOrderListQuery = `SELECT p.ProductID,p.Title,m.TransactionID,s.OrderNumber,s.AllowStorePickup,s.AllowAdminPickup,s.ReadyPickupForUser,s.ReadyPickupForAdmin,s.OrderDate,m.PaymentStatus,p.Price AS BasePrice,s.Quantity,p.Currency,s.UserID,g.Small,g.Medium,g.Large,i.MainImage,s.StatusHistory,s.ProcessStatus,s.DeliveryDriverID,s.ConsignmentId,s.*,r.CountryID AS VendorCountry,pr.*,s.RefundStatus,s.RefundStatusHistory
          FROM ((((((((( product p      
          LEFT JOIN productvariantoption o ON o.ProductID IN( p.ProductID))
          LEFT JOIN productvariantoptionvalue v  ON  v.OptionID IN (o.OptionID))  
          LEFT JOIN productimage i  ON  i.OptionValueID IN (v.OptionValueID))
          LEFT JOIN imagegallery g  ON  g.ImageGalleryID IN (i.ImageGalleryID))
          LEFT JOIN productvariantcombination c  ON  c.OptionValueID IN (v.OptionValueID))
          LEFT JOIN processorder s ON s.ProductID IN(c.ProductID))
          INNER JOIN processrefand pr ON pr.ProcessOrderID IN (s.ProcessOrderID))
          LEFT JOIN vendor r ON (r.VendorID= p.VendorID))
          LEFT JOIN processpayment m ON m.OrderNumber IN(s.OrderNumber))
          WHERE i.MainImage='Y' AND p.FreeProductReturn="Y" AND s.RefundStatus="Processing" AND s.OrderNumber LIKE "%${search}%" AND s.OrderNumber NOT IN  (select * from ( SELECT o.OrderNumber
            FROM processorder o
            INNER JOIN processrefand pr ON pr.ProcessOrderID= o.ProcessOrderID 
            INNER JOIN product p ON p.ProductID= o.ProductID
            WHERE  p.FreeProductReturn="Y"  AND pr.RefandProductReceiveDate IS NULL OR pr.RefandProductReceiveDate='' ) OrderNumber)
            GROUP BY s.ProcessOrderID  
            ORDER BY s.ProcessOrderID ${sort} 
            LIMIT ${limit} OFFSET ${offset}`;
      let viewOrderList = await connection.query(viewOrderListQuery, {
        type: QueryTypes.SELECT,
      });
      //!This version of MariaDB doesn't yet support 'LIMIT & IN/ALL/ANY/SOME subquery' to bypass this error above i am using extra select * in above subquery
      console.log(viewOrderList);
      let productCombinationDetail;
      if (viewOrderList && viewOrderList.length > 0) {
        for (let i = 0; i < viewOrderList.length; i++) {
          let ProductVariantCombinationDetail = [];
          ProductVariantCombinationDetail.push(
            viewOrderList[i].ProductVariantCombinationDetail
          );
          ProductVariantCombinationDetail = `(${ProductVariantCombinationDetail.join(
            ","
          )})`;
          productCombinationDetail = await connection.query(
            `SELECT p.ProductID,c.ProductVariantCombinationID,c.VendorStoreID,c.Price AS ProductCombinationPrice,c.AvailableInventory,o.OptionID,o.OptionName,v.OptionValue,v.OptionValueID,p.Currency
              FROM ((((product p
              LEFT JOIN productvariantoption o ON o.ProductID IN( p.ProductID))
              LEFT JOIN productvariantoptionvalue v  ON  v.OptionID IN (o.OptionID)) 
              LEFT JOIN productvariantcombination c  ON  c.OptionValueID IN (v.OptionValueID))
              LEFT JOIN processorder s ON s.ProductID IN(c.ProductID))
              WHERE  c.ProductVariantCombinationID IN ${ProductVariantCombinationDetail} 
              GROUP BY c.OptionValueID
              ORDER BY s.ProcessOrderID ASC
             `,
            {
              type: QueryTypes.SELECT,
            }
          );
          productCombinationPriceDetail.push(productCombinationDetail);
        }

        let getCurrencyRates = await connection.query(
          "SELECT * FROM currencyrate",
          {
            type: QueryTypes.SELECT,
          }
        );
        let VendorCountry = viewOrderList[0].VendorCountry;
        let currencyRate;
        if (VendorCountry == "16") {
          currencyRate = getCurrencyRates[1].Rate;
        } else {
          currencyRate = getCurrencyRates[0].Rate;
        }
        let orderName = [];
        let orderDate = [];
        let paymentStatus = [];
        let transactionID = [];
        let tempPC = productCombinationPriceDetail;
        let tempProd = viewOrderList;
        let tempArray = [];
        let allowStorePickup = [];
        let readyPickupForUser = [];
        let readyPickupForAdmin = [];
        let allowAdminPickup = [];
        let statusHistory = [];
        let processStatus = [];
        let tempAOrderDetails = [];

        for (let i = 0; i < tempProd.length; i++) {
          //!cuurency conversion
          if (VendorCountry == "16") {
            let Price = tempProd[i].BasePrice;
            if (tempProd[i].Currency == "$") {
              tempProd[i]["Currency"] = "BDT";
              tempProd[i]["BasePrice"] = parseFloat(
                currencyRate * Price
              ).toFixed(2);
            }
          } else if (VendorCountry == "226") {
            let Price = tempProd[i].BasePrice;
            if (tempProd[i].Currency == "BDT") {
              tempProd[i]["Currency"] = "$";
              tempProd[i]["BasePrice"] = parseFloat(
                currencyRate * Price
              ).toFixed(2);
            }
          } else {
            let Price = tempProd[i].BasePrice;
            tempProd[i]["Currency"] = "$";
            tempProd[i]["BasePrice"] = parseFloat(currencyRate * Price).toFixed(
              2
            );
          }
          var obj = {
            ...tempProd[i],
          };
          let variantsLength = tempPC[i].length;
          if (VendorCountry == "16") {
            for (let j = 0; j < variantsLength; j++) {
              let Price = tempPC[i][j].ProductCombinationPrice;
              if (tempPC[i][j].Currency == "$") {
                tempPC[i][j]["Currency"] = "BDT";
                tempPC[i][j]["ProductCombinationPrice"] = parseFloat(
                  currencyRate * Price
                ).toFixed(2);
              }
            }
          } else if (VendorCountry == "226") {
            for (let j = 0; j < variantsLength; j++) {
              let Price = tempPC[i][j].ProductCombinationPrice;
              if (tempPC[i][j].Currency == "BDT") {
                tempPC[i][j]["Currency"] = "$";
                tempPC[i][j]["ProductCombinationPrice"] = parseFloat(
                  currencyRate * Price
                ).toFixed(2);
              }
            }
          } else {
            for (let j = 0; j < variantsLength; j++) {
              let Price = tempPC[i][j].ProductCombinationPrice;
              tempPC[i][j]["Currency"] = "$";
              tempPC[i][j]["ProductCombinationPrice"] = parseFloat(
                currencyRate * Price
              ).toFixed(2);
            }
          }
          obj["ProductCombinations"] = tempPC[i];
          tempArray.push(obj);
        }
        for (let i = 0; i < tempArray.length; i++) {
          if (!orderName.includes(tempArray[i].OrderNumber)) {
            orderName.push(tempArray[i].OrderNumber);
            orderDate.push(tempArray[i].OrderDate);
            paymentStatus.push(tempArray[i].PaymentStatus);
            transactionID.push(tempArray[i].TransactionID);
            allowStorePickup.push(tempArray[i].AllowStorePickup);
            readyPickupForUser.push(tempArray[i].ReadyPickupForUser);
            readyPickupForAdmin.push(tempArray[i].ReadyPickupForAdmin);
            allowAdminPickup.push(tempArray[i].AllowAdminPickup);
            statusHistory.push(tempArray[i].StatusHistory);
            processStatus.push(tempArray[i].ProcessStatus);
          }
        }
        for (let i = 0; i < orderName.length; i++) {
          var obj = {
            OrderNumber: orderName[i],
            OrderDate: orderDate[i],
            PaymentStatus: paymentStatus[i],
            TransactionID: transactionID[i],
            AllowStorePickup: allowStorePickup[i],
            ReadyPickupForUser: readyPickupForUser[i],
            ReadyPickupForAdmin: readyPickupForAdmin[i],
            AllowAdminPickup: allowAdminPickup[i],
            StatusHistory: statusHistory[i],
            ProcessStatus: processStatus[i],
            ProductDetail: [],
          };
          for (let j = 0; j < tempArray.length; j++) {
            if (orderName[i] === tempArray[j].OrderNumber) {
              obj.ProductDetail.push(tempArray[j]);
            }
          }
          tempAOrderDetails.push(obj);
        }
        if (productCombinationDetail && productCombinationDetail.length > 0) {
          res.status(200).json({
            status: true,
            total_records: getCount[0].total_records,
            orderDetails: tempAOrderDetails,
          });
        } else {
          res.status(200).json({
            status: false,
            orderDetails: [],
          });
        }
      } else {
        res.status(200).json({
          status: true,
          total_records: getCount[0].total_records,
          orderDetails: [],
        });
      }
    } else {
      res.status(200).json({
        status: true,
        total_records: getCount[0].total_records,
        orderDetails: [],
      });
    }
  } catch (err) {
    console.log(err.message);
    next(err);
    res.status(200).json({
      status: false,
      orderDetails: [],
    });
  }
};
exports.getProductConfirmRefundOrdersPaid = async (req, res, next) => {
  try {
    // let Region = req.region;
    // const currencyRate = req.currency_rate;
    let { limit, offset, sort, search } = req.body;
    let productCombinationPriceDetail = [];
    limit = parseInt(limit);
    offset = parseInt(offset);
    offset = limit * offset;
    let getCount = await connection.query(
      `SELECT COUNT(DISTINCT o.OrderNumber) AS total_records
      FROM processorder o
      INNER JOIN processrefand pr ON pr.ProcessOrderID= o.ProcessOrderID
      INNER JOIN product p ON p.ProductID= o.ProductID
      WHERE p.FreeProductReturn="N" AND OrderNumber NOT IN (SELECT o.OrderNumber
      FROM processorder o
      INNER JOIN processrefand pr ON pr.ProcessOrderID= o.ProcessOrderID 
      INNER JOIN product p ON p.ProductID= o.ProductID
      WHERE p.FreeProductReturn="N" AND pr.RefandProductReceiveDate IS NULL OR pr.RefandProductReceiveDate='' ) 
     `,
      {
        type: QueryTypes.SELECT,
      }
    );
    console.log(getCount);
    if (getCount[0].total_records && getCount[0].total_records > 0) {
      let viewOrderListQuery = `SELECT p.ProductID,p.Title,m.TransactionID,s.OrderNumber,s.AllowStorePickup,s.AllowAdminPickup,s.ReadyPickupForUser,s.ReadyPickupForAdmin,s.OrderDate,m.PaymentStatus,p.Price AS BasePrice,s.Quantity,p.Currency,s.UserID,g.Small,g.Medium,g.Large,i.MainImage,s.StatusHistory,s.ProcessStatus,s.DeliveryDriverID,s.ConsignmentId,s.*,r.CountryID AS VendorCountry,pr.*,s.RefundStatus,s.RefundStatusHistory
          FROM ((((((((( product p      
          LEFT JOIN productvariantoption o ON o.ProductID IN( p.ProductID))
          LEFT JOIN productvariantoptionvalue v  ON  v.OptionID IN (o.OptionID))  
          LEFT JOIN productimage i  ON  i.OptionValueID IN (v.OptionValueID))
          LEFT JOIN imagegallery g  ON  g.ImageGalleryID IN (i.ImageGalleryID))
          LEFT JOIN productvariantcombination c  ON  c.OptionValueID IN (v.OptionValueID))
          LEFT JOIN processorder s ON s.ProductID IN(c.ProductID))
          INNER JOIN processrefand pr ON pr.ProcessOrderID IN (s.ProcessOrderID))
          LEFT JOIN vendor r ON (r.VendorID= p.VendorID))
          LEFT JOIN processpayment m ON m.OrderNumber IN(s.OrderNumber))
          WHERE i.MainImage='Y' AND p.FreeProductReturn="N" AND s.RefundStatus="Processing" AND s.OrderNumber LIKE "%${search}%" AND s.OrderNumber NOT IN  (select * from ( SELECT o.OrderNumber
            FROM processorder o
            INNER JOIN processrefand pr ON pr.ProcessOrderID= o.ProcessOrderID 
            INNER JOIN product p ON p.ProductID= o.ProductID
            WHERE  p.FreeProductReturn="N"  AND pr.RefandProductReceiveDate IS NULL OR pr.RefandProductReceiveDate='' ) OrderNumber)
            GROUP BY s.ProcessOrderID  
            ORDER BY s.ProcessOrderID ${sort} 
            LIMIT ${limit} OFFSET ${offset}`;
      let viewOrderList = await connection.query(viewOrderListQuery, {
        type: QueryTypes.SELECT,
      });
      //!This version of MariaDB doesn't yet support 'LIMIT & IN/ALL/ANY/SOME subquery' to bypass this error above i am using extra select * in above subquery
      console.log(viewOrderList);
      let productCombinationDetail;
      if (viewOrderList && viewOrderList.length > 0) {
        for (let i = 0; i < viewOrderList.length; i++) {
          let ProductVariantCombinationDetail = [];
          ProductVariantCombinationDetail.push(
            viewOrderList[i].ProductVariantCombinationDetail
          );
          ProductVariantCombinationDetail = `(${ProductVariantCombinationDetail.join(
            ","
          )})`;
          productCombinationDetail = await connection.query(
            `SELECT p.ProductID,c.ProductVariantCombinationID,c.VendorStoreID,c.Price AS ProductCombinationPrice,c.AvailableInventory,o.OptionID,o.OptionName,v.OptionValue,v.OptionValueID,p.Currency
              FROM ((((product p
              LEFT JOIN productvariantoption o ON o.ProductID IN( p.ProductID))
              LEFT JOIN productvariantoptionvalue v  ON  v.OptionID IN (o.OptionID)) 
              LEFT JOIN productvariantcombination c  ON  c.OptionValueID IN (v.OptionValueID))
              LEFT JOIN processorder s ON s.ProductID IN(c.ProductID))
              WHERE  c.ProductVariantCombinationID IN ${ProductVariantCombinationDetail} 
              GROUP BY c.OptionValueID
              ORDER BY s.ProcessOrderID ASC
             `,
            {
              type: QueryTypes.SELECT,
            }
          );
          productCombinationPriceDetail.push(productCombinationDetail);
        }

        let getCurrencyRates = await connection.query(
          "SELECT * FROM currencyrate",
          {
            type: QueryTypes.SELECT,
          }
        );
        let VendorCountry = viewOrderList[0].VendorCountry;
        let currencyRate;
        if (VendorCountry == "16") {
          currencyRate = getCurrencyRates[1].Rate;
        } else {
          currencyRate = getCurrencyRates[0].Rate;
        }
        let orderName = [];
        let orderDate = [];
        let paymentStatus = [];
        let transactionID = [];
        let tempPC = productCombinationPriceDetail;
        let tempProd = viewOrderList;
        let tempArray = [];
        let allowStorePickup = [];
        let readyPickupForUser = [];
        let readyPickupForAdmin = [];
        let allowAdminPickup = [];
        let statusHistory = [];
        let processStatus = [];
        let tempAOrderDetails = [];

        for (let i = 0; i < tempProd.length; i++) {
          //!cuurency conversion
          if (VendorCountry == "16") {
            let Price = tempProd[i].BasePrice;
            if (tempProd[i].Currency == "$") {
              tempProd[i]["Currency"] = "BDT";
              tempProd[i]["BasePrice"] = parseFloat(
                currencyRate * Price
              ).toFixed(2);
            }
          } else if (VendorCountry == "226") {
            let Price = tempProd[i].BasePrice;
            if (tempProd[i].Currency == "BDT") {
              tempProd[i]["Currency"] = "$";
              tempProd[i]["BasePrice"] = parseFloat(
                currencyRate * Price
              ).toFixed(2);
            }
          } else {
            let Price = tempProd[i].BasePrice;
            tempProd[i]["Currency"] = "$";
            tempProd[i]["BasePrice"] = parseFloat(currencyRate * Price).toFixed(
              2
            );
          }
          var obj = {
            ...tempProd[i],
          };
          let variantsLength = tempPC[i].length;
          if (VendorCountry == "16") {
            for (let j = 0; j < variantsLength; j++) {
              let Price = tempPC[i][j].ProductCombinationPrice;
              if (tempPC[i][j].Currency == "$") {
                tempPC[i][j]["Currency"] = "BDT";
                tempPC[i][j]["ProductCombinationPrice"] = parseFloat(
                  currencyRate * Price
                ).toFixed(2);
              }
            }
          } else if (VendorCountry == "226") {
            for (let j = 0; j < variantsLength; j++) {
              let Price = tempPC[i][j].ProductCombinationPrice;
              if (tempPC[i][j].Currency == "BDT") {
                tempPC[i][j]["Currency"] = "$";
                tempPC[i][j]["ProductCombinationPrice"] = parseFloat(
                  currencyRate * Price
                ).toFixed(2);
              }
            }
          } else {
            for (let j = 0; j < variantsLength; j++) {
              let Price = tempPC[i][j].ProductCombinationPrice;
              tempPC[i][j]["Currency"] = "$";
              tempPC[i][j]["ProductCombinationPrice"] = parseFloat(
                currencyRate * Price
              ).toFixed(2);
            }
          }
          obj["ProductCombinations"] = tempPC[i];
          tempArray.push(obj);
        }
        for (let i = 0; i < tempArray.length; i++) {
          if (!orderName.includes(tempArray[i].OrderNumber)) {
            orderName.push(tempArray[i].OrderNumber);
            orderDate.push(tempArray[i].OrderDate);
            paymentStatus.push(tempArray[i].PaymentStatus);
            transactionID.push(tempArray[i].TransactionID);
            allowStorePickup.push(tempArray[i].AllowStorePickup);
            readyPickupForUser.push(tempArray[i].ReadyPickupForUser);
            readyPickupForAdmin.push(tempArray[i].ReadyPickupForAdmin);
            allowAdminPickup.push(tempArray[i].AllowAdminPickup);
            statusHistory.push(tempArray[i].StatusHistory);
            processStatus.push(tempArray[i].ProcessStatus);
          }
        }
        for (let i = 0; i < orderName.length; i++) {
          var obj = {
            OrderNumber: orderName[i],
            OrderDate: orderDate[i],
            PaymentStatus: paymentStatus[i],
            TransactionID: transactionID[i],
            AllowStorePickup: allowStorePickup[i],
            ReadyPickupForUser: readyPickupForUser[i],
            ReadyPickupForAdmin: readyPickupForAdmin[i],
            AllowAdminPickup: allowAdminPickup[i],
            StatusHistory: statusHistory[i],
            ProcessStatus: processStatus[i],
            ProductDetail: [],
          };
          for (let j = 0; j < tempArray.length; j++) {
            if (orderName[i] === tempArray[j].OrderNumber) {
              obj.ProductDetail.push(tempArray[j]);
            }
          }
          tempAOrderDetails.push(obj);
        }
        if (productCombinationDetail && productCombinationDetail.length > 0) {
          res.status(200).json({
            status: true,
            total_records: getCount[0].total_records,
            orderDetails: tempAOrderDetails,
          });
        } else {
          res.status(200).json({
            status: false,
            orderDetails: [],
          });
        }
      } else {
        res.status(200).json({
          status: true,
          total_records: getCount[0].total_records,
          orderDetails: [],
        });
      }
    } else {
      res.status(200).json({
        status: true,
        total_records: getCount[0].total_records,
        orderDetails: [],
      });
    }
  } catch (err) {
    console.log(err.message);
    next(err);
    res.status(200).json({
      status: false,
      orderDetails: [],
    });
  }
};
exports.getAllRefundOrders = async (req, res, next) => {
  try {
    // let Region = req.region;
    // const currencyRate = req.currency_rate;
    let { limit, offset, sort, search } = req.body;
    let productCombinationPriceDetail = [];
    limit = parseInt(limit);
    offset = parseInt(offset);
    offset = limit * offset;
    let getCount = await connection.query(
      `SELECT COUNT(DISTINCT o.OrderNumber) AS total_records
      FROM processorder o
      INNER JOIN processrefand pr ON pr.ProcessOrderID= o.ProcessOrderID
      WHERE  pr.ProcessRefandResponse NOT IN ('NULL','null','undefined') AND o.RefundStatus="Refunded" 
     `,
      {
        type: QueryTypes.SELECT,
      }
    );
    console.log(getCount);
    if (getCount[0].total_records && getCount[0].total_records > 0) {
      let viewOrderListQuery = `SELECT p.ProductID,p.Title,m.TransactionID,s.OrderNumber,s.AllowStorePickup,s.AllowAdminPickup,s.ReadyPickupForUser,s.ReadyPickupForAdmin,s.OrderDate,m.PaymentStatus,p.Price AS BasePrice,s.Quantity,p.Currency,s.UserID,g.Small,g.Medium,g.Large,i.MainImage,s.StatusHistory,s.ProcessStatus,s.DeliveryDriverID,s.ConsignmentId,s.*,r.CountryID AS VendorCountry,pr.*,s.RefundStatus,s.RefundStatusHistory
          FROM ((((((((( product p      
          LEFT JOIN productvariantoption o ON o.ProductID IN( p.ProductID))
          LEFT JOIN productvariantoptionvalue v  ON  v.OptionID IN (o.OptionID))  
          LEFT JOIN productimage i  ON  i.OptionValueID IN (v.OptionValueID))
          LEFT JOIN imagegallery g  ON  g.ImageGalleryID IN (i.ImageGalleryID))
          LEFT JOIN productvariantcombination c  ON  c.OptionValueID IN (v.OptionValueID))
          LEFT JOIN processorder s ON s.ProductID IN(c.ProductID))
          INNER JOIN processrefand pr ON pr.ProcessOrderID IN (s.ProcessOrderID))
          LEFT JOIN vendor r ON (r.VendorID= p.VendorID))
          LEFT JOIN processpayment m ON m.OrderNumber IN(s.OrderNumber))
          WHERE i.MainImage='Y'  AND s.OrderNumber LIKE "%${search}%" AND  pr.ProcessRefandResponse NOT IN ('NULL','null','undefined') AND s.RefundStatus="Refunded" 
            ORDER BY s.ProcessOrderID ${sort} 
            LIMIT ${limit} OFFSET ${offset}`;
      let viewOrderList = await connection.query(viewOrderListQuery, {
        type: QueryTypes.SELECT,
      });
      console.log(viewOrderList);
      let productCombinationDetail;
      if (viewOrderList && viewOrderList.length > 0) {
        for (let i = 0; i < viewOrderList.length; i++) {
          let ProductVariantCombinationDetail = [];
          ProductVariantCombinationDetail.push(
            viewOrderList[i].ProductVariantCombinationDetail
          );
          ProductVariantCombinationDetail = `(${ProductVariantCombinationDetail.join(
            ","
          )})`;
          productCombinationDetail = await connection.query(
            `SELECT p.ProductID,c.ProductVariantCombinationID,c.VendorStoreID,c.Price AS ProductCombinationPrice,c.AvailableInventory,o.OptionID,o.OptionName,v.OptionValue,v.OptionValueID,p.Currency
              FROM ((((product p
              LEFT JOIN productvariantoption o ON o.ProductID IN( p.ProductID))
              LEFT JOIN productvariantoptionvalue v  ON  v.OptionID IN (o.OptionID)) 
              LEFT JOIN productvariantcombination c  ON  c.OptionValueID IN (v.OptionValueID))
              LEFT JOIN processorder s ON s.ProductID IN(c.ProductID))
              WHERE  c.ProductVariantCombinationID IN ${ProductVariantCombinationDetail} 
              GROUP BY c.OptionValueID
              ORDER BY s.ProcessOrderID ASC
             `,
            {
              type: QueryTypes.SELECT,
            }
          );
          productCombinationPriceDetail.push(productCombinationDetail);
        }

        let getCurrencyRates = await connection.query(
          "SELECT * FROM currencyrate",
          {
            type: QueryTypes.SELECT,
          }
        );
        let VendorCountry = viewOrderList[0].VendorCountry;
        let currencyRate;
        if (VendorCountry == "16") {
          currencyRate = getCurrencyRates[1].Rate;
        } else {
          currencyRate = getCurrencyRates[0].Rate;
        }
        let orderName = [];
        let orderDate = [];
        let paymentStatus = [];
        let transactionID = [];
        let tempPC = productCombinationPriceDetail;
        let tempProd = viewOrderList;
        let tempArray = [];
        let allowStorePickup = [];
        let readyPickupForUser = [];
        let readyPickupForAdmin = [];
        let allowAdminPickup = [];
        let statusHistory = [];
        let processStatus = [];
        let tempAOrderDetails = [];

        for (let i = 0; i < tempProd.length; i++) {
          //!cuurency conversion
          if (VendorCountry == "16") {
            let Price = tempProd[i].BasePrice;
            if (tempProd[i].Currency == "$") {
              tempProd[i]["Currency"] = "BDT";
              tempProd[i]["BasePrice"] = parseFloat(
                currencyRate * Price
              ).toFixed(2);
            }
          } else if (VendorCountry == "226") {
            let Price = tempProd[i].BasePrice;
            if (tempProd[i].Currency == "BDT") {
              tempProd[i]["Currency"] = "$";
              tempProd[i]["BasePrice"] = parseFloat(
                currencyRate * Price
              ).toFixed(2);
            }
          } else {
            let Price = tempProd[i].BasePrice;
            tempProd[i]["Currency"] = "$";
            tempProd[i]["BasePrice"] = parseFloat(currencyRate * Price).toFixed(
              2
            );
          }
          var obj = {
            ...tempProd[i],
          };
          let variantsLength = tempPC[i].length;
          if (VendorCountry == "16") {
            for (let j = 0; j < variantsLength; j++) {
              let Price = tempPC[i][j].ProductCombinationPrice;
              if (tempPC[i][j].Currency == "$") {
                tempPC[i][j]["Currency"] = "BDT";
                tempPC[i][j]["ProductCombinationPrice"] = parseFloat(
                  currencyRate * Price
                ).toFixed(2);
              }
            }
          } else if (VendorCountry == "226") {
            for (let j = 0; j < variantsLength; j++) {
              let Price = tempPC[i][j].ProductCombinationPrice;
              if (tempPC[i][j].Currency == "BDT") {
                tempPC[i][j]["Currency"] = "$";
                tempPC[i][j]["ProductCombinationPrice"] = parseFloat(
                  currencyRate * Price
                ).toFixed(2);
              }
            }
          } else {
            for (let j = 0; j < variantsLength; j++) {
              let Price = tempPC[i][j].ProductCombinationPrice;
              tempPC[i][j]["Currency"] = "$";
              tempPC[i][j]["ProductCombinationPrice"] = parseFloat(
                currencyRate * Price
              ).toFixed(2);
            }
          }
          obj["ProductCombinations"] = tempPC[i];
          tempArray.push(obj);
        }
        for (let i = 0; i < tempArray.length; i++) {
          if (!orderName.includes(tempArray[i].OrderNumber)) {
            orderName.push(tempArray[i].OrderNumber);
            orderDate.push(tempArray[i].OrderDate);
            paymentStatus.push(tempArray[i].PaymentStatus);
            transactionID.push(tempArray[i].TransactionID);
            allowStorePickup.push(tempArray[i].AllowStorePickup);
            readyPickupForUser.push(tempArray[i].ReadyPickupForUser);
            readyPickupForAdmin.push(tempArray[i].ReadyPickupForAdmin);
            allowAdminPickup.push(tempArray[i].AllowAdminPickup);
            statusHistory.push(tempArray[i].StatusHistory);
            processStatus.push(tempArray[i].ProcessStatus);
          }
        }
        for (let i = 0; i < orderName.length; i++) {
          var obj = {
            OrderNumber: orderName[i],
            OrderDate: orderDate[i],
            PaymentStatus: paymentStatus[i],
            TransactionID: transactionID[i],
            AllowStorePickup: allowStorePickup[i],
            ReadyPickupForUser: readyPickupForUser[i],
            ReadyPickupForAdmin: readyPickupForAdmin[i],
            AllowAdminPickup: allowAdminPickup[i],
            StatusHistory: statusHistory[i],
            ProcessStatus: processStatus[i],
            ProductDetail: [],
          };
          for (let j = 0; j < tempArray.length; j++) {
            if (orderName[i] === tempArray[j].OrderNumber) {
              obj.ProductDetail.push(tempArray[j]);
            }
          }
          tempAOrderDetails.push(obj);
        }
        if (productCombinationDetail && productCombinationDetail.length > 0) {
          res.status(200).json({
            status: true,
            total_records: getCount[0].total_records,
            orderDetails: tempAOrderDetails,
          });
        } else {
          res.status(200).json({
            status: false,
            orderDetails: [],
          });
        }
      } else {
        res.status(200).json({
          status: true,
          total_records: getCount[0].total_records,
          orderDetails: [],
        });
      }
    } else {
      res.status(200).json({
        status: true,
        total_records: getCount[0].total_records,
        orderDetails: [],
      });
    }
  } catch (err) {
    console.log(err.message);
    next(err);
    res.status(200).json({
      status: false,
      orderDetails: [],
    });
  }
};


exports.sendContactEmail = async (req, res) => {
  try {


    const { EmailAddress, subject, name, message } = req.body
    await sendContactUsEmail(EmailAddress, subject, name, message)
    res.status(200).json({
      msg: "Mail is sned to admin",
      success: true
    })
  } catch (err) {
    console.log(err);
    res.status(500).json({
      msg: "Mail sent Failed",
      success: false
    })
  }
}
exports.sendContactAdminEmail = async (req, res) => {
  try {


    const { EmailAddress, subject, name, message } = req.body
    const result = await sendContactAdminMail(EmailAddress, subject, name, message)
    // const result = await sendMail('adeelnasirkbw@gmail.com', 2732)
    console.log("result", result);
    res.status(200).json({
      msg: "Mail is send to admin",
      success: true
    })
  } catch (err) {
    console.log(err);
    res.status(500).json({
      msg: "Mail send Failed",
      success: false
    })
  }
}

exports.getStatiticContent = async (req, res) => {
  try {
    const { ContentType } = req.body;

    let result = await connection.query(
      `select * from staticcontent where ContentType = '${ContentType}'`,
      {
        type: QueryTypes.SELECT,
      }
    );
    const obj = result[0].jsonContent
    console.log(JSON.parse(obj));
    res.status(200).json({
      status: true,
      data: { ...result[0], jsonContent: JSON.parse(obj) },
    })

  } catch (err) {
    res.status(200).json({
      status: false,
      error: err.message,
    });
  }
};
