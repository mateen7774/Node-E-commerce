const connection = require("../../db/db.connection");
const axios = require("axios");
const { QueryTypes } = require("sequelize");
let fs = require("fs");
const {
  Notification,
} = require("../../controllers/usersControllers/users.controller");
const { sendEmail } = require("../../utils/notificationsMail");


exports.deliveryRateDomestic = async (req, res, next) => {
  try {
    let Region = req.region;
    // const currencyRate = req.currency_rate;
    const getCurrencyRates = req.getCurrencyRates;
    console.log("getCurrencyRates", getCurrencyRates)
    var { recipient_zip, ProductIDs, DriverAvailability, recipient_city } =
      req.body;
    let saveResponse = [];
    let saveResponse1 = [];
    let getProductDetails = [];
    let temp_product = [];
    console.log(req.body, "---------------------------body");



    const Product_ID = ProductIDs[0]
    console.log("Product_ID", Product_ID)

    let productCurrency = await connection.query(
      `SELECT Currency FROM product WHERE ProductID="${Product_ID}"`, {
      type: QueryTypes.SELECT,
    });

    const fromCurrency = productCurrency[0]['Currency']


    let ProductID = `(${ProductIDs.join(",")})`;
    let getProductShippingStatus = await connection.query(
      `SELECT ProductID,ShippingByAdmin,StoreName from product WHERE ProductID IN ${ProductID} `,
      {
        type: QueryTypes.SELECT,
      }
    );
    const BanglaBazarProducts = getProductShippingStatus.filter((obj) => {
      return obj.ShippingByAdmin === "Y";
    });
    const VendorProducts = getProductShippingStatus.filter((obj) => {
      return obj.ShippingByAdmin === "N";
    });
    if (BanglaBazarProducts && BanglaBazarProducts.length > 0) {
      console.log(
        "Banglabazar case------------------------------------------------------------------------------------------"
      );
      if (DriverAvailability === "Y") {
        for (let i = 0; i < BanglaBazarProducts.length; i++) {
          const ProductID = BanglaBazarProducts[i].ProductID;
          var getDriverShippingCost = await connection.query(
            `SELECT p.ProductID AS PRODUCTID,p.Price,p.Weight,p.ShippingByVendor,c.CityID,c.FlatDeliveryRate,IFNULL(c.FlatDeliveryRate, y.FlatDeliveryRate) AS BaseShippingCost,IFNULL(c.FlatDeliveryRateKilo,y.FlatDeliveryRateKilo) AS DeliveryRateKilo,IF(p.Weight>1,(SELECT DeliveryRateKilo)*Weight ,0) AS PerKgShippingCost,
          (SELECT BaseShippingCost)+(SELECT PerKgShippingCost) AS DriverShippingCost
              FROM product p
              LEFT JOIN productcity pc ON pc.ProductID=p.ProductID
              LEFT JOIN city c ON c.CityID=pc.CityID
              LEFT JOIN productcountry py ON py.ProductID=p.ProductID
              LEFT JOIN country y ON y.CountryID=py.CountryID
              WHERE p.ProductID= "${ProductID}" AND p.ShippingByVendor="N" 
          `,
            {
              type: QueryTypes.SELECT,
            }
          );
          console.log(getDriverShippingCost, "at index", i);
          if (getDriverShippingCost && getDriverShippingCost.length > 0) {
            let obj = {
              message: "Price",
              type: "success",
              code: 200,
              data: {
                price: parseFloat(getDriverShippingCost[0].DriverShippingCost),
                discount: 0,
                promo_discount: 0,
                plan_id: 100,
                cod_enabled: 1,
                additional_charge: 0,
                ProductID: ProductID,
              },
            };
            saveResponse.push(obj);
          }
        }
      } else {
        console.log(
          "inside else block -------------------------------------------------------"
        );
        getProductDetails = await connection.query(
          `SELECT p.ProductID,v.ZipCode,SUM(p.Weight)AS Weight,p.ShippingByAdmin,SUM(p.Length)AS Length,SUM(p.Height)AS Height,SUM(p.Width) AS Width,GROUP_CONCAT(p.ProductID SEPARATOR "," ) AS TempProductID
            FROM product p
            LEFT JOIN vendorstore v ON v.StoreName=p.StoreName
            WHERE p.ProductID IN ${ProductID} AND p.ShippingByVendor="N"
            GROUP BY p.StoreName
  `,
          {
            type: QueryTypes.SELECT,
          }
        );
        console.log(getProductDetails, "getProductDetails");
        const promises = getProductDetails.map(async (item, i) => {
          const ZipCode = item.ZipCode;
          let Weight = parseFloat(item.Weight * 35.274).toFixed(2); //converting kg to oz just for dimesions check
          let Width = parseFloat(item.Width * 0.393701).toFixed(2);
          let Length = parseFloat(item.Length * 0.393701).toFixed(2);
          let Height = parseFloat(item.Height * 0.393701).toFixed(2);
          let TempProducts = item.TempProductID;
          let serviceCode = "usps_first_class";
          if (
            Weight > 15.99 ||
            Width > 17.99 ||
            Length > 21.99 ||
            Height > 0.14
          ) {
            serviceCode = "usps_express";
          }
          var options = {
            carrierCode: "usps",
            serviceCode: serviceCode,
            packageTypeCode: "usps_custom_package",
            sender: {
              country: "US",
              zip: ZipCode,
            },
            receiver: {
              city: recipient_city.toString(),
              country: "US",
              zip: recipient_zip,
            },
            residential: true,
            signatureOptionCode: null,
            weightUnit: "lb",
            dimUnit: "in",
            currency: "USD",
            customsCurrency: "USD",
            pieces: [
              {
                weight: parseFloat(item.Weight * 2.20462)
                  .toFixed(2)
                  .toString(), //converting kg to lb
                length: Length.toString(),
                width: Width.toString(),
                height: Height.toString(),
                insuranceAmount: null,
                declaredValue: null, //! for domestic null and for international must be true
              },
            ],
          };
          console.log(
            options,
            "options--------------------------------------------"
          );
          let response = await axios.post(
            `https://xpsshipper.com/restapi/v1/customers/${process.env.CustomerID}/quote`,
            options,
            {
              headers: {
                Authorization: "RSIS " + process.env.APIKey,
              },
            }
          );
          console.log(
            response.data.totalAmount,
            "response.data.totalAmount      at",
            i
          );
          let Price = response.data.totalAmount;
          let temp_obj = {
            Price: parseFloat(Price),
            TempProducts,
          };
          temp_product.push(temp_obj);
        });
        await Promise.all(promises);

        for (let i = 0; i < temp_product.length; i++) {
          let str = temp_product[i].TempProducts;
          let tempPrice = temp_product[i].Price;
          var array = str.split(",");
          let tempLength = array.length;
          for (let j = 0; j < array.length; j++) {
            Price = tempPrice / tempLength;
            let obj = {
              message: "Price",
              type: "success",
              code: 200,
              data: {
                price: parseFloat(Price),
                discount: 0,
                promo_discount: 0,
                plan_id: 1000,
                cod_enabled: 1,
                additional_charge: 0,
                ProductID: array[j],
              },
            };
            saveResponse.push(obj);
          }
        }
      }
    }

    if (VendorProducts && VendorProducts.length > 0) {
      console.log(
        "Vendor case------------------------------------------------------------------------------------------"
      );
      for (let i = 0; i < VendorProducts.length; i++) {
        const ProductID = VendorProducts[i].ProductID;
        console.log(ProductID, "ProductID");
        let getShippingCost = await connection.query(
          `SELECT p.ProductID AS PRODUCTID,p.Price,p.Weight,p.ShippingByVendor,c.ShippingCostVendorCity,IFNULL(c.ShippingCostVendorCity, s.ShippingCostVendorCountry) AS BaseShippingCost,IFNULL(c.ShippingCostKiloVendorCity,s.ShippingCostKiloVendorCountry) AS DeliveryRateKilo,IF(p.Weight>1,(SELECT DeliveryRateKilo)*Weight ,0) AS PerKgShippingCost,(SELECT BaseShippingCost)+(SELECT PerKgShippingCost) AS VendorShippingCost
            FROM product p
            LEFT JOIN shippingcostvendorcity c ON c.ProductID=p.ProductID
            LEFT JOIN shippingcostvendorcountry s ON s.ProductID=p.ProductID
            WHERE p.ProductID= "${ProductID}" AND p.ShippingByVendor="Y"
        `,
          {
            type: QueryTypes.SELECT,
          }
        );
        console.log(getShippingCost[0], "getShippingCost at index", i);
        if (getShippingCost && getShippingCost.length > 0) {
          let obj = {
            message: "Price",
            type: "success",
            code: 200,
            data: {
              price: parseFloat(getShippingCost[0].VendorShippingCost),
              discount: 0,
              promo_discount: 0,
              plan_id: 0,
              cod_enabled: 1,
              additional_charge: 0,
              ProductID: ProductID,
            },
          };
          saveResponse1.push(obj);
        }
      }
    }

    Array.prototype.push.apply(saveResponse, saveResponse1); //merge arrays
    const sortByObject = ProductIDs.reduce((obj, item, index) => {
      return {
        ...obj,
        [item]: index,
      };
    }, {});

    customSort = saveResponse.sort(
      (a, b) => sortByObject[a.data.ProductID] - sortByObject[b.data.ProductID]
    );
    //sort according to input order
    if (Region !== "United States") {
      let currencyRate;
      for (let i = 0; i < customSort.length; i++) {
        let Price = customSort[i].data.price;

        const selectCurrency = getCurrencyRates.filter(item => item.FromCurrency === fromCurrency);
        currencyRate = selectCurrency.length ? selectCurrency[0].Rate : null;

        currencyRate = Number(currencyRate)

        if (selectCurrency.length > 0) {
          // console.log(Price, "at index", i)
          let additional_charge = customSort[i].data.additional_charge;
          customSort[i].data["additional_charge"] = parseFloat(
            currencyRate * additional_charge
          ).toFixed(2);
          customSort[i].data["price"] = parseFloat(currencyRate * Price).toFixed(
            2
          );
        }

      }
    }
    console.log(customSort, "customSort");
    res.status(200).send({
      status: true,
      saveResponse: customSort,
    });
  } catch (e) {
    console.log(e);
    res.status(400).json({
      status: false,
      message: "Something went wrong",
      error: e,
    });
  }
};

//old 12/29/2023
// exports.deliveryRateDomestic = async (req, res, next) => {
//   try {
//     let Region = req.region;
//     const currencyRate = req.currency_rate;
//     var { recipient_zip, ProductIDs, DriverAvailability, recipient_city } =
//       req.body;
//     console.log(req.body);
//     let saveResponse = [];
//     let saveResponse1 = [];
//     let getProductDetails = [];
//     let temp_product = [];
//     console.log(req.body, "---------------------------body");
//     let ProductID = `(${ProductIDs.join(",")})`;
//     let getProductShippingStatus = await connection.query(
//       `SELECT ProductID,ShippingByAdmin,StoreName from product WHERE ProductID IN ${ProductID} `,
//       {
//         type: QueryTypes.SELECT,
//       }
//     );
//     const BanglaBazarProducts = getProductShippingStatus.filter((obj) => {
//       return obj.ShippingByAdmin === "Y";
//     });
//     const VendorProducts = getProductShippingStatus.filter((obj) => {
//       return obj.ShippingByAdmin === "N";
//     });
//     if (BanglaBazarProducts && BanglaBazarProducts.length > 0) {
//       console.log(
//         "Banglabazar case------------------------------------------------------------------------------------------"
//       );
//       if (DriverAvailability === "Y") {
//         for (let i = 0; i < BanglaBazarProducts.length; i++) {
//           const ProductID = BanglaBazarProducts[i].ProductID;
//           var getDriverShippingCost = await connection.query(
//             `SELECT p.ProductID AS PRODUCTID,p.Price,p.Weight,p.ShippingByVendor,c.CityID,c.FlatDeliveryRate,IFNULL(c.FlatDeliveryRate, y.FlatDeliveryRate) AS BaseShippingCost,IFNULL(c.FlatDeliveryRateKilo,y.FlatDeliveryRateKilo) AS DeliveryRateKilo,IF(p.Weight>1,(SELECT DeliveryRateKilo)*Weight ,0) AS PerKgShippingCost,
//           (SELECT BaseShippingCost)+(SELECT PerKgShippingCost) AS DriverShippingCost
//               FROM product p
//               LEFT JOIN productcity pc ON pc.ProductID=p.ProductID
//               LEFT JOIN city c ON c.CityID=pc.CityID
//               LEFT JOIN productcountry py ON py.ProductID=p.ProductID
//               LEFT JOIN country y ON y.CountryID=py.CountryID
//               WHERE p.ProductID= "${ProductID}" AND p.ShippingByVendor="N" 
//           `,
//             {
//               type: QueryTypes.SELECT,
//             }
//           );
//           console.log(getDriverShippingCost, "at index", i);
//           if (getDriverShippingCost && getDriverShippingCost.length > 0) {
//             let obj = {
//               message: "Price",
//               type: "success",
//               code: 200,
//               data: {
//                 price: parseFloat(getDriverShippingCost[0].DriverShippingCost),
//                 discount: 0,
//                 promo_discount: 0,
//                 plan_id: 100,
//                 cod_enabled: 1,
//                 additional_charge: 0,
//                 ProductID: ProductID,
//               },
//             };
//             saveResponse.push(obj);
//           }
//         }
//       } else {
//         console.log(
//           "inside else block -------------------------------------------------------"
//         );
//         getProductDetails = await connection.query(
//           `SELECT p.ProductID,v.ZipCode,SUM(p.Weight)AS Weight,p.ShippingByAdmin,SUM(p.Length)AS Length,SUM(p.Height)AS Height,SUM(p.Width) AS Width,GROUP_CONCAT(p.ProductID SEPARATOR "," ) AS TempProductID
//             FROM product p
//             LEFT JOIN vendorstore v ON v.StoreName=p.StoreName
//             WHERE p.ProductID IN ${ProductID} AND p.ShippingByVendor="N"
//             GROUP BY p.StoreName
//   `,
//           {
//             type: QueryTypes.SELECT,
//           }
//         );
//         console.log(getProductDetails, "getProductDetails");
//         const promises = getProductDetails.map(async (item, i) => {
//           const ZipCode = item.ZipCode;
//           let Weight = parseFloat(item.Weight * 35.274).toFixed(2); //converting kg to oz just for dimesions check
//           let Width = parseFloat(item.Width * 0.393701).toFixed(2);
//           let Length = parseFloat(item.Length * 0.393701).toFixed(2);
//           let Height = parseFloat(item.Height * 0.393701).toFixed(2);
//           let TempProducts = item.TempProductID;
//           let serviceCode = "usps_first_class";
//           if (
//             Weight > 15.99 ||
//             Width > 17.99 ||
//             Length > 21.99 ||
//             Height > 0.14
//           ) {
//             serviceCode = "usps_express";
//           }
//           var options = {
//             carrierCode: "usps",
//             serviceCode: serviceCode,
//             packageTypeCode: "usps_custom_package",
//             sender: {
//               country: "US",
//               zip: ZipCode,
//             },
//             receiver: {
//               city: recipient_city.toString(),
//               country: "US",
//               zip: recipient_zip,
//             },
//             residential: true,
//             signatureOptionCode: null,
//             weightUnit: "lb",
//             dimUnit: "in",
//             currency: "USD",
//             customsCurrency: "USD",
//             pieces: [
//               {
//                 weight: parseFloat(item.Weight * 2.20462)
//                   .toFixed(2)
//                   .toString(), //converting kg to lb
//                 length: Length.toString(),
//                 width: Width.toString(),
//                 height: Height.toString(),
//                 insuranceAmount: null,
//                 declaredValue: null, //! for domestic null and for international must be true
//               },
//             ],
//           };
//           console.log(
//             options,
//             "options--------------------------------------------"
//           );
//           let response = await axios.post(
//             `https://xpsshipper.com/restapi/v1/customers/${process.env.CustomerID}/quote`,
//             options,
//             {
//               headers: {
//                 Authorization: "RSIS " + process.env.APIKey,
//               },
//             }
//           );
//           console.log(
//             response.data.totalAmount,
//             "response.data.totalAmount      at",
//             i
//           );
//           let Price = response.data.totalAmount;
//           let temp_obj = {
//             Price: parseFloat(Price),
//             TempProducts,
//           };
//           temp_product.push(temp_obj);
//         });
//         await Promise.all(promises);

//         for (let i = 0; i < temp_product.length; i++) {
//           let str = temp_product[i].TempProducts;
//           let tempPrice = temp_product[i].Price;
//           var array = str.split(",");
//           let tempLength = array.length;
//           for (let j = 0; j < array.length; j++) {
//             Price = tempPrice / tempLength;
//             let obj = {
//               message: "Price",
//               type: "success",
//               code: 200,
//               data: {
//                 price: parseFloat(Price),
//                 discount: 0,
//                 promo_discount: 0,
//                 plan_id: 1000,
//                 cod_enabled: 1,
//                 additional_charge: 0,
//                 ProductID: array[j],
//               },
//             };
//             saveResponse.push(obj);
//           }
//         }
//       }
//     }

//     if (VendorProducts && VendorProducts.length > 0) {
//       console.log(
//         "Vendor case------------------------------------------------------------------------------------------"
//       );
//       for (let i = 0; i < VendorProducts.length; i++) {
//         const ProductID = VendorProducts[i].ProductID;
//         console.log(ProductID, "ProductID");
//         let getShippingCost = await connection.query(
//           `SELECT p.ProductID AS PRODUCTID,p.Price,p.Weight,p.ShippingByVendor,c.ShippingCostVendorCity,IFNULL(c.ShippingCostVendorCity, s.ShippingCostVendorCountry) AS BaseShippingCost,IFNULL(c.ShippingCostKiloVendorCity,s.ShippingCostKiloVendorCountry) AS DeliveryRateKilo,IF(p.Weight>1,(SELECT DeliveryRateKilo)*Weight ,0) AS PerKgShippingCost,(SELECT BaseShippingCost)+(SELECT PerKgShippingCost) AS VendorShippingCost
//             FROM product p
//             LEFT JOIN shippingcostvendorcity c ON c.ProductID=p.ProductID
//             LEFT JOIN shippingcostvendorcountry s ON s.ProductID=p.ProductID
//             WHERE p.ProductID= "${ProductID}" AND p.ShippingByVendor="Y"
//         `,
//           {
//             type: QueryTypes.SELECT,
//           }
//         );
//         console.log(getShippingCost[0], "getShippingCost at index", i);
//         if (getShippingCost && getShippingCost.length > 0) {
//           let obj = {
//             message: "Price",
//             type: "success",
//             code: 200,
//             data: {
//               price: parseFloat(getShippingCost[0].VendorShippingCost),
//               discount: 0,
//               promo_discount: 0,
//               plan_id: 0,
//               cod_enabled: 1,
//               additional_charge: 0,
//               ProductID: ProductID,
//             },
//           };
//           saveResponse1.push(obj);
//         }
//       }
//     }

//     Array.prototype.push.apply(saveResponse, saveResponse1); //merge arrays
//     const sortByObject = ProductIDs.reduce((obj, item, index) => {
//       return {
//         ...obj,
//         [item]: index,
//       };
//     }, {});

//     customSort = saveResponse.sort(
//       (a, b) => sortByObject[a.data.ProductID] - sortByObject[b.data.ProductID]
//     );
//     //sort according to input order
//     if (Region == "Bangladesh") {
//       for (let i = 0; i < customSort.length; i++) {
//         let Price = customSort[i].data.price;
//         // console.log(Price, "at index", i)
//         let additional_charge = customSort[i].data.additional_charge;
//         customSort[i].data["additional_charge"] = parseFloat(
//           currencyRate * additional_charge
//         ).toFixed(2);
//         customSort[i].data["price"] = parseFloat(currencyRate * Price).toFixed(
//           2
//         );
//       }
//     }
//     console.log(customSort, "customSort");
//     res.status(200).send({
//       status: true,
//       saveResponse: customSort,
//     });
//   } catch (e) {
//     console.log(e);
//     res.status(400).json({
//       status: false,
//       message: "Something went wrong",
//       error: e,
//     });
//   }
// };

exports.deliveryRateGlobal = async (req, res, next) => {
  try {
    let Region = req.region;
    const getCurrencyRates = req.getCurrencyRates;
    console.log("getCurrencyRates", getCurrencyRates)
    var { recipient_zip, ProductIDs, recipient_city } = req.body;

    let saveResponse = [];
    let saveResponse1 = [];
    let getProductDetails = [];
    let temp_product = [];
    console.log(req.body, "---------------------------body");


    const Product_ID = ProductIDs[0]
    console.log("Product_ID", Product_ID)

    let productCurrency = await connection.query(
      `SELECT Currency FROM product WHERE ProductID="${Product_ID}"`, {
      type: QueryTypes.SELECT,
    });

    const fromCurrency = productCurrency[0]['Currency']

    let ProductID = `(${ProductIDs.join(",")})`;
    let getProductShippingStatus = await connection.query(
      `SELECT ProductID,ShippingByAdmin,StoreName from product WHERE ProductID IN ${ProductID} `,
      {
        type: QueryTypes.SELECT,
      }
    );
    const BanglaBazarProducts = getProductShippingStatus.filter((obj) => {
      return obj.ShippingByAdmin === "Y";
    });
    const VendorProducts = getProductShippingStatus.filter((obj) => {
      return obj.ShippingByAdmin === "N";
    });
    if (BanglaBazarProducts && BanglaBazarProducts.length > 0) {
      console.log(
        "Banglabazar case------------------------------------------------------------------------------------------"
      );
      console.log(
        "inside block -------------------------------------------------------"
      );
      getProductDetails = await connection.query(
        `SELECT p.ProductID,v.ZipCode,SUM(p.Weight)AS Weight,p.ShippingByAdmin,SUM(p.Length)AS Length,SUM(p.Height)AS Height,SUM(p.Width) AS Width,GROUP_CONCAT(p.ProductID SEPARATOR "," ) AS TempProductID,GROUP_CONCAT(p.Price SEPARATOR "," ) AS ProductPrice
            FROM product p
            LEFT JOIN vendorstore v ON v.StoreName=p.StoreName
            WHERE p.ProductID IN ${ProductID} AND p.ShippingByVendor="N"
            GROUP BY p.StoreName
  `,
        {
          type: QueryTypes.SELECT,
        }
      );

      const promises = getProductDetails.map(async (item, i) => {
        let string = item.ProductPrice;
        var result = string.match(/\d+/g).reduce(function (a, b) {
          return +a + +b;
        });
        const ZipCode = item.ZipCode;
        let Weight = parseFloat(item.Weight * 35.274).toFixed(2);
        let Width = parseFloat(item.Width * 0.393701).toFixed(2);
        let Length = parseFloat(item.Length * 0.393701).toFixed(2);
        let Height = parseFloat(item.Height * 0.393701).toFixed(2);
        let TempProducts = item.TempProductID;
        let ProductPrice = result.toString();
        let serviceCode = "usps_international_first_class";
        let girth = Width + Length + Height;
        if (Weight > 64.0 || girth > 107.87) {
          serviceCode = "usps_international_express";
        }
        //usps_international_priority,
        //usps_international_first_class,
        //usps_international_express
        var options = {
          carrierCode: "usps",
          serviceCode: serviceCode,
          packageTypeCode: "usps_custom_package",
          sender: {
            country: "US",
            zip: ZipCode,
          },
          receiver: {
            city: recipient_city.toString(),
            country: "BD",
            zip: recipient_zip,
          },
          residential: true,
          signatureOptionCode: null,
          weightUnit: "lb",
          dimUnit: "in",
          currency: "USD",
          customsCurrency: "USD",
          pieces: [
            {
              weight: parseFloat(item.Weight * 2.20462)
                .toFixed(2)
                .toString(), //converting kg to lb
              length: Length.toString(),
              width: Width.toString(),
              height: Height.toString(),
              insuranceAmount: null,
              declaredValue: ProductPrice, //! for domestic null and for international must be true
            },
          ],
        };
        console.log(
          options,
          "options--------------------------------------------"
        );
        let response = await axios.post(
          `https://xpsshipper.com/restapi/v1/customers/${process.env.CustomerID}/quote`,
          options,
          {
            headers: {
              Authorization: "RSIS " + process.env.APIKey,
            },
          }
        );
        console.log(response.data, "response.data.totalAmount      at", i);
        let Price = response.data.totalAmount;
        let temp_obj = {
          Price: Price,
          TempProducts,
        };
        temp_product.push(temp_obj);
      });
      await Promise.all(promises);

      for (let i = 0; i < temp_product.length; i++) {
        let str = temp_product[i].TempProducts;
        let tempPrice = temp_product[i].Price;
        var array = str.split(",");
        let tempLength = array.length;
        for (let j = 0; j < array.length; j++) {
          Price = tempPrice / tempLength;
          let obj = {
            message: "Price",
            type: "success",
            code: 200,
            data: {
              price: Price,
              discount: 0,
              promo_discount: 0,
              plan_id: 1000,
              cod_enabled: 1,
              additional_charge: 0,
              ProductID: array[j],
            },
          };
          saveResponse.push(obj);
        }
      }
    }

    if (VendorProducts && VendorProducts.length > 0) {
      console.log(
        "Vendor case------------------------------------------------------------------------------------------"
      );
      for (let i = 0; i < VendorProducts.length; i++) {
        const ProductID = VendorProducts[i].ProductID;
        console.log(ProductID, "ProductID");
        let getShippingCost = await connection.query(
          `SELECT p.ProductID AS PRODUCTID,p.Price,p.Weight,p.ShippingByVendor,c.ShippingCostVendorCity,IFNULL(c.ShippingCostVendorCity, s.ShippingCostVendorCountry) AS BaseShippingCost,IFNULL(c.ShippingCostKiloVendorCity,s.ShippingCostKiloVendorCountry) AS DeliveryRateKilo,IF(p.Weight>1,(SELECT DeliveryRateKilo)*Weight ,0) AS PerKgShippingCost,(SELECT BaseShippingCost)+(SELECT PerKgShippingCost) AS VendorShippingCost
            FROM product p
            LEFT JOIN shippingcostvendorcity c ON c.ProductID=p.ProductID
            LEFT JOIN shippingcostvendorcountry s ON s.ProductID=p.ProductID
            WHERE p.ProductID= "${ProductID}" AND p.ShippingByVendor="Y"
        `,
          {
            type: QueryTypes.SELECT,
          }
        );
        console.log(getShippingCost[0], "getShippingCost at index", i);
        if (getShippingCost && getShippingCost.length > 0) {
          let obj = {
            message: "Price",
            type: "success",
            code: 200,
            data: {
              price: getShippingCost[0].VendorShippingCost,
              discount: 0,
              promo_discount: 0,
              plan_id: 0,
              cod_enabled: 1,
              additional_charge: 0,
              ProductID: ProductID,
            },
          };
          saveResponse1.push(obj);
        }
      }
    }

    Array.prototype.push.apply(saveResponse, saveResponse1); //merge arrays
    const sortByObject = ProductIDs.reduce((obj, item, index) => {
      return {
        ...obj,
        [item]: index,
      };
    }, {});

    customSort = saveResponse.sort(
      (a, b) => sortByObject[a.data.ProductID] - sortByObject[b.data.ProductID]
    );
    //sort according to input order
    if (Region !== "United States") {
      let currencyRate;
      for (let i = 0; i < customSort.length; i++) {
        let Price = customSort[i].data.price;
        // console.log(Price, "at index", i)

        const selectCurrency = getCurrencyRates.filter(item => item.FromCurrency === fromCurrency);
        currencyRate = selectCurrency.length ? selectCurrency[0].Rate : null;

        currencyRate = Number(currencyRate)

        if (selectCurrency.length > 0) {
          let additional_charge = customSort[i].data.additional_charge;
          customSort[i].data["additional_charge"] = parseFloat(
            currencyRate * additional_charge
          ).toFixed(2);
          customSort[i].data["price"] = parseFloat(currencyRate * Price).toFixed(
            2
          );
        }

      }
    }
    console.log(customSort, "customSort");
    res.status(200).send({
      status: true,
      saveResponse: customSort,
    });
  } catch (e) {
    console.log(e);
    res.status(400).json({
      status: false,
      message: "Something went wrong",
      error: e,
    });
  }
};

//old 12/29/2023
// exports.deliveryRateGlobal = async (req, res, next) => {
//   try {
//     let Region = req.region;
//     const currencyRate = req.currency_rate;
//     var { recipient_zip, ProductIDs, recipient_city } = req.body;
//     console.log(req.body);
//     let saveResponse = [];
//     let saveResponse1 = [];
//     let getProductDetails = [];
//     let temp_product = [];
//     console.log(req.body, "---------------------------body");
//     let ProductID = `(${ProductIDs.join(",")})`;
//     let getProductShippingStatus = await connection.query(
//       `SELECT ProductID,ShippingByAdmin,StoreName from product WHERE ProductID IN ${ProductID} `,
//       {
//         type: QueryTypes.SELECT,
//       }
//     );
//     const BanglaBazarProducts = getProductShippingStatus.filter((obj) => {
//       return obj.ShippingByAdmin === "Y";
//     });
//     const VendorProducts = getProductShippingStatus.filter((obj) => {
//       return obj.ShippingByAdmin === "N";
//     });
//     if (BanglaBazarProducts && BanglaBazarProducts.length > 0) {
//       console.log(
//         "Banglabazar case------------------------------------------------------------------------------------------"
//       );
//       console.log(
//         "inside block -------------------------------------------------------"
//       );
//       getProductDetails = await connection.query(
//         `SELECT p.ProductID,v.ZipCode,SUM(p.Weight)AS Weight,p.ShippingByAdmin,SUM(p.Length)AS Length,SUM(p.Height)AS Height,SUM(p.Width) AS Width,GROUP_CONCAT(p.ProductID SEPARATOR "," ) AS TempProductID,GROUP_CONCAT(p.Price SEPARATOR "," ) AS ProductPrice
//             FROM product p
//             LEFT JOIN vendorstore v ON v.StoreName=p.StoreName
//             WHERE p.ProductID IN ${ProductID} AND p.ShippingByVendor="N"
//             GROUP BY p.StoreName
//   `,
//         {
//           type: QueryTypes.SELECT,
//         }
//       );

//       const promises = getProductDetails.map(async (item, i) => {
//         let string = item.ProductPrice;
//         var result = string.match(/\d+/g).reduce(function (a, b) {
//           return +a + +b;
//         });
//         const ZipCode = item.ZipCode;
//         let Weight = parseFloat(item.Weight * 35.274).toFixed(2);
//         let Width = parseFloat(item.Width * 0.393701).toFixed(2);
//         let Length = parseFloat(item.Length * 0.393701).toFixed(2);
//         let Height = parseFloat(item.Height * 0.393701).toFixed(2);
//         let TempProducts = item.TempProductID;
//         let ProductPrice = result.toString();
//         let serviceCode = "usps_international_first_class";
//         let girth = Width + Length + Height;
//         if (Weight > 64.0 || girth > 107.87) {
//           serviceCode = "usps_international_express";
//         }
//         //usps_international_priority,
//         //usps_international_first_class,
//         //usps_international_express
//         var options = {
//           carrierCode: "usps",
//           serviceCode: serviceCode,
//           packageTypeCode: "usps_custom_package",
//           sender: {
//             country: "US",
//             zip: ZipCode,
//           },
//           receiver: {
//             city: recipient_city.toString(),
//             country: "BD",
//             zip: recipient_zip,
//           },
//           residential: true,
//           signatureOptionCode: null,
//           weightUnit: "lb",
//           dimUnit: "in",
//           currency: "USD",
//           customsCurrency: "USD",
//           pieces: [
//             {
//               weight: parseFloat(item.Weight * 2.20462)
//                 .toFixed(2)
//                 .toString(), //converting kg to lb
//               length: Length.toString(),
//               width: Width.toString(),
//               height: Height.toString(),
//               insuranceAmount: null,
//               declaredValue: ProductPrice, //! for domestic null and for international must be true
//             },
//           ],
//         };
//         console.log(
//           options,
//           "options--------------------------------------------"
//         );
//         let response = await axios.post(
//           `https://xpsshipper.com/restapi/v1/customers/${process.env.CustomerID}/quote`,
//           options,
//           {
//             headers: {
//               Authorization: "RSIS " + process.env.APIKey,
//             },
//           }
//         );
//         console.log(response.data, "response.data.totalAmount      at", i);
//         let Price = response.data.totalAmount;
//         let temp_obj = {
//           Price: Price,
//           TempProducts,
//         };
//         temp_product.push(temp_obj);
//       });
//       await Promise.all(promises);

//       for (let i = 0; i < temp_product.length; i++) {
//         let str = temp_product[i].TempProducts;
//         let tempPrice = temp_product[i].Price;
//         var array = str.split(",");
//         let tempLength = array.length;
//         for (let j = 0; j < array.length; j++) {
//           Price = tempPrice / tempLength;
//           let obj = {
//             message: "Price",
//             type: "success",
//             code: 200,
//             data: {
//               price: Price,
//               discount: 0,
//               promo_discount: 0,
//               plan_id: 1000,
//               cod_enabled: 1,
//               additional_charge: 0,
//               ProductID: array[j],
//             },
//           };
//           saveResponse.push(obj);
//         }
//       }
//     }

//     if (VendorProducts && VendorProducts.length > 0) {
//       console.log(
//         "Vendor case------------------------------------------------------------------------------------------"
//       );
//       for (let i = 0; i < VendorProducts.length; i++) {
//         const ProductID = VendorProducts[i].ProductID;
//         console.log(ProductID, "ProductID");
//         let getShippingCost = await connection.query(
//           `SELECT p.ProductID AS PRODUCTID,p.Price,p.Weight,p.ShippingByVendor,c.ShippingCostVendorCity,IFNULL(c.ShippingCostVendorCity, s.ShippingCostVendorCountry) AS BaseShippingCost,IFNULL(c.ShippingCostKiloVendorCity,s.ShippingCostKiloVendorCountry) AS DeliveryRateKilo,IF(p.Weight>1,(SELECT DeliveryRateKilo)*Weight ,0) AS PerKgShippingCost,(SELECT BaseShippingCost)+(SELECT PerKgShippingCost) AS VendorShippingCost
//             FROM product p
//             LEFT JOIN shippingcostvendorcity c ON c.ProductID=p.ProductID
//             LEFT JOIN shippingcostvendorcountry s ON s.ProductID=p.ProductID
//             WHERE p.ProductID= "${ProductID}" AND p.ShippingByVendor="Y"
//         `,
//           {
//             type: QueryTypes.SELECT,
//           }
//         );
//         console.log(getShippingCost[0], "getShippingCost at index", i);
//         if (getShippingCost && getShippingCost.length > 0) {
//           let obj = {
//             message: "Price",
//             type: "success",
//             code: 200,
//             data: {
//               price: getShippingCost[0].VendorShippingCost,
//               discount: 0,
//               promo_discount: 0,
//               plan_id: 0,
//               cod_enabled: 1,
//               additional_charge: 0,
//               ProductID: ProductID,
//             },
//           };
//           saveResponse1.push(obj);
//         }
//       }
//     }

//     Array.prototype.push.apply(saveResponse, saveResponse1); //merge arrays
//     const sortByObject = ProductIDs.reduce((obj, item, index) => {
//       return {
//         ...obj,
//         [item]: index,
//       };
//     }, {});

//     customSort = saveResponse.sort(
//       (a, b) => sortByObject[a.data.ProductID] - sortByObject[b.data.ProductID]
//     );
//     //sort according to input order
//     if (Region == "Bangladesh") {
//       for (let i = 0; i < customSort.length; i++) {
//         let Price = customSort[i].data.price;
//         // console.log(Price, "at index", i)
//         let additional_charge = customSort[i].data.additional_charge;
//         customSort[i].data["additional_charge"] = parseFloat(
//           currencyRate * additional_charge
//         ).toFixed(2);
//         customSort[i].data["price"] = parseFloat(currencyRate * Price).toFixed(
//           2
//         );
//       }
//     }
//     console.log(customSort, "customSort");
//     res.status(200).send({
//       status: true,
//       saveResponse: customSort,
//     });
//   } catch (e) {
//     console.log(e);
//     res.status(400).json({
//       status: false,
//       message: "Something went wrong",
//       error: e,
//     });
//   }
// };

exports.markOrderBookedBackup = async (req, res, next) => {
  let transaction;
  try {
    const { OrderNumber, BookingNumber, TrackingNumber } = req.body;
    let getUserDetails = await connection.query(
      ` SELECT p.EmailAddress,po.UserID
    FROM profile p
    INNER JOIN processorder po ON po.UserID=p.UserID
    WHERE po.OrderNumber=${OrderNumber}`,
      {
        type: QueryTypes.SELECT,
        transaction,
      }
    );
    if (getUserDetails && getUserDetails.length > 0) {
      let EmailAddress = getUserDetails[0].EmailAddress;
      let ReceiverID = getUserDetails[0].UserID;
      let currentdateAndTime = [];
      let LastUpdate = new Date().toISOString().slice(0, 19).replace("T", " ");
      currentdateAndTime[0] = LastUpdate;
      let StatusHistory = JSON.stringify(currentdateAndTime);

      let assignOrderToUsps = await connection.query(
        `UPDATE processorder SET ProcessStatus="Assigned",UspsOrderStatus="Booked",BookingNumber='${BookingNumber}',TrackingNumber='${TrackingNumber}',StatusHistory='${StatusHistory}',LastUpdate="${LastUpdate}"
         WHERE OrderNumber="${OrderNumber}"  `,
        {
          transaction,
        }
      );
      if (assignOrderToUsps) {
        let TypeID = "6";
        let CreaterID = "1";
        let Body = {
          OrderNumber: OrderNumber,
          body: `Your OrderNumber ${OrderNumber} is Assigned to USPS`,
        };
        let Message = `Your OrderNumber ${OrderNumber} is Assigned to USPS`;
        sendEmail(EmailAddress, Message, TypeID);
        let sendNotification = await Notification(
          TypeID,
          Body,
          CreaterID,
          ReceiverID,
          transaction
        );
        console.log(sendNotification, "sendNotification");
        if (sendNotification) {
          if (transaction) await transaction.commit();
          res.status(200).json({
            status: true,
            message: " Order is Assigned to USPS Successfully",
          });
        } else {
          if (transaction) await transaction.rollback();
          res.status(200).json({
            status: false,
            message: "Error while sending Notification to User ",
          });
        }
      } else {
        if (transaction) await transaction.rollback();
        res.status(200).json({
          status: false,
          message: "Error While assigning USPS the given Order  ",
        });
      }
    } else {
      if (transaction) await transaction.rollback();
      res.status(400).json({
        status: false,
        message: "Error while geeting user details from DB",
      });
    }
  } catch (e) {
    if (transaction) await transaction.rollback();
    console.log(e);
    res.status(400).json({
      status: false,
      message: e.message,
    });
  }
};
exports.updateOrderWebHook = async (req, res, next) => {
  let transaction;
  try {
    console.log(req);
    let token = req.headers["x-rsis-key"];
    if (token === process.env.APIKey) {
      let orderId = req.body.orderId;
      let trackingNumbers = req.body.trackingNumbers;
      const OrderNumber = orderId;

      let getUserDetails = await connection.query(
        ` SELECT p.EmailAddress,po.UserID
    FROM profile p
    INNER JOIN processorder po ON po.UserID=p.UserID
    WHERE po.OrderNumber=${OrderNumber}`,
        {
          type: QueryTypes.SELECT,
          transaction,
        }
      );
      if (getUserDetails && getUserDetails.length > 0) {
        let EmailAddress = getUserDetails[0].EmailAddress;
        let ReceiverID = getUserDetails[0].UserID;
        let currentdateAndTime = [];
        let LastUpdate = new Date()
          .toISOString()
          .slice(0, 19)
          .replace("T", " ");
        currentdateAndTime[0] = LastUpdate;
        let StatusHistory = JSON.stringify(currentdateAndTime);
        var trackingNumber = trackingNumbers.split(",")[0];
        console.log(trackingNumber);
        let options = {
          keyword: trackingNumber.toString(),
        };
        let shipmentDetails = await axios.post(
          `https://xpsshipper.com/restapi/v1/customers/${process.env.CustomerID}/searchShipments`,
          options,
          {
            headers: {
              Authorization: "RSIS " + process.env.APIKey,
            },
          }
        );
        console.log(shipmentDetails.data.shipments);
        if (shipmentDetails.data && shipmentDetails.data.shipments.length > 0) {
          let BookingNumber = shipmentDetails.data.shipments[0].bookNumber;
          console.log(BookingNumber);
          let assignOrderToUsps = await connection.query(
            `UPDATE processorder SET ProcessStatus="Assigned",UspsOrderStatus="Booked",BookingNumber='${BookingNumber}',TrackingNumber='${trackingNumbers}',StatusHistory='${StatusHistory}',LastUpdate="${LastUpdate}"
         WHERE OrderNumber="${OrderNumber}"  `,
            {
              transaction,
            }
          );
          if (assignOrderToUsps) {
            let TypeID = "6";
            let CreaterID = "1";
            let Body = {
              OrderNumber: OrderNumber,
              body: `Your OrderNumber ${OrderNumber} is Assigned to USPS`,
            };
            let Message = `Your OrderNumber ${OrderNumber} is Assigned to USPS`;
            sendEmail(EmailAddress, Message, TypeID);
            let sendNotification = await Notification(
              TypeID,
              Body,
              CreaterID,
              ReceiverID,
              transaction
            );
            console.log(sendNotification, "sendNotification");
            if (sendNotification) {
              if (transaction) await transaction.commit();
              res.status(200).json({
                status: true,
                message: " Order is Assigned to USPS Successfully",
              });
            } else {
              if (transaction) await transaction.rollback();
              res.status(200).json({
                status: false,
                message: "Error while sending Notification to User ",
              });
            }
          } else {
            if (transaction) await transaction.rollback();
            res.status(200).json({
              status: false,
              message: "Error While assigning USPS the given Order  ",
            });
          }
        } else {
          if (transaction) await transaction.rollback();
          res.status(400).json({
            status: false,
            message: "Error while getting shipment details from XPS",
          });
        }
      } else {
        if (transaction) await transaction.rollback();
        res.status(400).json({
          status: false,
          message: "Error while getting user details from DB",
        });
      }
    } else {
      if (transaction) await transaction.rollback();
      res.status(400).json({
        status: false,
        message: "Inavlid Token , Not authorized to access this route",
      });
    }
  } catch (e) {
    if (transaction) await transaction.rollback();
    console.log(e);
    res.status(400).json({
      status: false,
      message: e.message,
    });
  }
};
exports.retrieveShipment = async (req, res, next) => {
  try {
    const OrderNumber = req.params.id;

    let getBookingDetails = await connection.query(
      ` SELECT OrderNumber,BookingNumber FROM processorder 
    WHERE OrderNumber=${OrderNumber}`,
      {
        type: QueryTypes.SELECT,
      }
    );
    if (getBookingDetails && getBookingDetails.length > 0) {
      let BookingNumber = getBookingDetails[0].BookingNumber;
      let response = await axios.get(
        `https://xpsshipper.com/restapi/v1/customers/${process.env.CustomerID}/services`,
        {
          headers: {
            Authorization: "RSIS " + process.env.APIKey,
          },
        }
      );
      if (response) {
        res.status(200).json({
          status: true,
          message: response.data,
        });
      } else {
        res.status(200).json({
          status: false,
          message: response.data,
        });
      }
    } else {
      res.status(400).json({
        status: false,
        message: "Error while getting detail from DB",
      });
    }
  } catch (e) {
    console.log(e);
    res.status(400).json({
      status: false,
      message: e.response.data,
    });
  }
};
exports.retrieveShippingLabel = async (req, res, next) => {
  try {
    console.log(req.params.id);
    const OrderNumber = req.params.id;
    // const { labelImageFormat } = req.body;//PDF or PNG //right now we are using only PDF
    let getBookingDetails = await connection.query(
      ` SELECT OrderNumber,BookingNumber FROM processorder 
        WHERE OrderNumber=${OrderNumber}`,
      {
        type: QueryTypes.SELECT,
      }
    );
    console.log(getBookingDetails, "getBookingDetails")
    if (getBookingDetails && getBookingDetails.length > 0) {
      let BookingNumber = getBookingDetails[0].BookingNumber;
      let response = await axios.get(
        `https://xpsshipper.com/restapi/v1/customers/${process.env.CustomerID}/shipments/${BookingNumber}/label/PDF`,
        {
          responseType: "arraybuffer",
          responseEncoding: "binary",
          headers: {
            Authorization: "RSIS " + process.env.APIKey,
          },
        }
      );
      console.log(response.data, "response.data")
      if (response) {
        var result = response.data;
        //fs.writeFileSync(`${OrderNumber}`+".pdf", result,'base64');
        res.status(200).json({
          status: true,
          shippingLabel: result,
        });
      } else {
        res.status(200).json({
          status: false,
          message: response.data.error,
        });
      }
    } else {
      res.status(400).json({
        status: false,
        response: "Error while getting detail from DB",
      });
    }
  } catch (e) {
    console.log(e.message);
    res.status(400).json({
      status: false,
      response: e,
    });
  }
};
exports.getUSPSOrdersBySuperAdmin = async (req, res, next) => {
  try {
    const { limit, offset } = req.body;
    let productCombinationPriceDetail = [];
    let ordersCount = await connection.query(
      `SELECT COUNT(DISTINCT OrderNumber) AS total_records
       FROM processorder
       WHERE  (DeliveryStatus="usps" || DeliveryStatus="usps_intl") AND ProcessStatus="Processing" AND AllowAdminPickup = "Y" AND
       ReadyPickupForAdmin = "Y" AND UspsOrderStatus !="On Panel"
 `,
      {
        type: QueryTypes.SELECT,
      }
    );
    console.log(ordersCount);
    if (ordersCount && ordersCount.length > 0) {
      let viewOrderListQuery = `SELECT p.ProductID,p.Title,m.TransactionID,s.OrderNumber,s.AllowStorePickup,s.AllowAdminPickup,s.ReadyPickupForUser,s.ReadyPickupForAdmin,s.OrderDate,m.PaymentStatus,p.Price AS BasePrice,p.Currency,s.UserID,g.Small,g.Medium,g.Large,i.MainImage
      ,s.ProductVariantCombinationDetail,
    (SELECT COUNT(t.ProductID)
    from productreviewrating t WHERE t.ProductID = p.ProductID) AS REVIEW_COUNT,
    (SELECT AVG(t.Rating) from productreviewrating t WHERE t.ProductID = p.ProductID) AS  AVG_Rating
        FROM ((((((( product p      
        LEFT JOIN productvariantoption o ON o.ProductID IN( p.ProductID))
        LEFT JOIN productvariantoptionvalue v  ON  v.OptionID IN (o.OptionID))  
        LEFT JOIN productimage i  ON  i.OptionValueID IN (v.OptionValueID))
        LEFT JOIN imagegallery g  ON  g.ImageGalleryID IN (i.ImageGalleryID))
        LEFT JOIN productvariantcombination c  ON  c.OptionValueID IN (v.OptionValueID))
        INNER JOIN processorder s ON s.ProductID IN(c.ProductID))
        LEFT JOIN processpayment m ON m.OrderNumber IN(s.OrderNumber))
        WHERE i.MainImage='Y' AND (s.DeliveryStatus="usps" || s.DeliveryStatus="usps_intl") AND UspsOrderStatus !="On Panel" AND s.ProcessStatus="Processing" AND s.OrderNumber IN (select * from(SELECT OrderNumber
        FROM processorder
        WHERE  (DeliveryStatus="usps" || DeliveryStatus="usps_intl") AND ProcessStatus="Processing" AND AllowAdminPickup = "Y" AND
        ReadyPickupForAdmin = "Y" AND UspsOrderStatus !="On Panel"
        GROUP BY OrderNumber
        ORDER by ProcessOrderID ASC
        limit ${limit} offset ${offset}) OrderNumber)
        GROUP BY s.ProcessOrderID
        ORDER by s.ProcessOrderID ASC`;
      let viewOrderList = await connection.query(viewOrderListQuery, {
        type: QueryTypes.SELECT,
      });

      let productCombinationDetail;
      if (viewOrderList && viewOrderList.length > 0) {
        for (let i = 0; i < viewOrderList.length; i++) {
          let ProductVariantCombinationDetail = [];
          ProductVariantCombinationDetail.push(
            viewOrderList[i].ProductVariantCombinationDetail
          );
          ProductVariantCombinationDetail = `(${ProductVariantCombinationDetail.join(
            ","
          )})`;
          productCombinationDetail = await connection.query(
            `SELECT p.ProductID,c.ProductVariantCombinationID,c.VendorStoreID,c.Price AS ProductCombinationPrice,c.AvailableInventory,o.OptionID,o.OptionName,v.OptionValue,v.OptionValueID
            FROM ((((product p
            LEFT JOIN productvariantoption o ON o.ProductID IN( p.ProductID))
            LEFT JOIN productvariantoptionvalue v  ON  v.OptionID IN (o.OptionID)) 
            LEFT JOIN productvariantcombination c  ON  c.OptionValueID IN (v.OptionValueID))
            LEFT JOIN processorder s ON s.ProductID IN(c.ProductID))
            WHERE  c.ProductVariantCombinationID IN ${ProductVariantCombinationDetail}
            GROUP BY c.OptionValueID
           `,
            {
              type: QueryTypes.SELECT,
            }
          );
          productCombinationPriceDetail.push(productCombinationDetail);
        }
        let orderName = [];
        let orderDate = [];
        let paymentStatus = [];
        let transactionID = [];
        let tempPC = productCombinationPriceDetail;
        let tempProd = viewOrderList;
        let tempArray = [];
        let allowStorePickup = [];
        let readyPickupForUser = [];
        let readyPickupForAdmin = [];
        let allowAdminPickup = [];
        var arr = [];
        let tempAOrderDetails = [];
        for (let i = 0; i < tempProd.length; i++) {
          var obj = {
            ...tempProd[i],
          };
          obj["ProductCombinations"] = tempPC[i];
          tempArray.push(obj);
        }
        for (let i = 0; i < tempArray.length; i++) {
          if (!orderName.includes(tempArray[i].OrderNumber)) {
            orderName.push(tempArray[i].OrderNumber);
            orderDate.push(tempArray[i].OrderDate);
            paymentStatus.push(tempArray[i].PaymentStatus);
            transactionID.push(tempArray[i].TransactionID);
            allowStorePickup.push(tempArray[i].AllowStorePickup);
            readyPickupForUser.push(tempArray[i].ReadyPickupForUser);
            readyPickupForAdmin.push(tempArray[i].ReadyPickupForAdmin);
            allowAdminPickup.push(tempArray[i].AllowAdminPickup);
          }
        }
        for (let i = 0; i < orderName.length; i++) {
          var obj = {
            OrderNumber: orderName[i],
            OrderDate: orderDate[i],
            PaymentStatus: paymentStatus[i],
            TransactionID: transactionID[i],
            AllowStorePickup: allowStorePickup[i],
            ReadyPickupForUser: readyPickupForUser[i],
            ReadyPickupForAdmin: readyPickupForAdmin[i],
            AllowAdminPickup: allowAdminPickup[i],
            ProductDetail: [],
          };
          for (let j = 0; j < tempArray.length; j++) {
            if (orderName[i] === tempArray[j].OrderNumber) {
              obj.ProductDetail.push(tempArray[j]);
            }
          }
          tempAOrderDetails.push(obj);
        }
        if (productCombinationDetail && productCombinationDetail.length > 0) {
          res.status(200).json({
            status: true,
            total_records: ordersCount[0].total_records,
            orderDetails: tempAOrderDetails,
          });
        } else {
          res.status(200).json({
            status: true,
            total_records: ordersCount[0].total_records,
            orderDetails: [],
          });
        }
      } else {
        res.status(200).json({
          status: true,
          total_records: ordersCount[0].total_records,
          orderDetails: [],
        });
      }
    } else {
      res.status(200).json({
        status: true,
        total_records: ordersCount.length,
        orderDetails: [],
      });
    }
  } catch (e) {
    console.log(e);
    res.status(400).json({
      status: false,
      message: e.message,
    });
  }
};
///
// const convert = require("xml-js");
// const { default: axios } = require("axios");
// //let xmlParser = require('xmltojson');
// const router = express.Router();
// const port = 6000;
// const user_id = "399BANGL8065";
// const password = "608VB37MD556";
// const base_url = " https://secure.shippingapis.com/ShippingAPI.dll";

// ///
// const USPS = require("usps-webtools");
// const usps = new USPS({
//   server: "https://secure.shippingapis.com/ShippingAPI.dll",
//   userId: "399BANGL8065",
//   ttl: 10000, //TTL in milliseconds for request
// });
//The Address/Standardization “Verify” API, which corrects errors in street addresses, including abbreviations and missing information, and supplies ZIP Codes and ZIP Codes + 4. The Verify API supports up to five lookups per transaction. By eliminating address errors, you will improve overall package delivery service.
// exports.verifyAddress = async (req, res, next) => {
//   var {
//     address1,
//     address2,
//     state,
//     zip
//   } = req.body;
//   const xml = `<AddressValidateRequest USERID="${user_id}">
//         <Revision>1</Revision>
//         <Address ID="0">
//         <Address1>${address1}</Address1>
//         <Address2>${address2}</Address2>
//         <City/>
//         <State>${state}</State>
//         <Zip5>${zip}</Zip5>
//         <Zip4/>
//         </Address>
//         </AddressValidateRequest>`;
//   const api = "Verify";
//   try {
//     const response = await axios.get(`${base_url}?API=${api}&XML=${xml}`);
//     var {
//       data
//     } = response;
//     var result = convert.xml2json(data, {
//       compact: true,
//       spaces: 4
//     });
//     result = JSON.parse(result);
//     if (data.includes("<Error>")) {
//       res.status(200).json({
//         status: false,
//         data: null,
//         ErrorData: result["AddressValidateResponse"],
//         message: result["AddressValidateResponse"]["Address"]["Error"]["Description"]["_text"]
//       });
//     } else {
//       res.status(200).json({
//         status: true,
//         data: result["AddressValidateResponse"],
//         ErrorData: null,
//         message: "Response returned"
//       });
//     }
//   } catch (e) {
//     console.log(e);
//     res.status(400).json({
//       status: false,
//       message: "Something went wrong",
//       error: e,
//     });
//   }
// };
// //The ZipCodeLookup API, which returns the ZIP Code and ZIP Code + 4 corresponding to the given address, city, and state (use USPS state abbreviations). The ZipCodeLookup API processes up to five lookups per request.
// exports.zipCodeLookup = async (req, res, next) => {
//   var {
//     address1,
//     address2,
//     city,
//     state,
//     zip
//   } = req.body;
//   console.log(req.body)
//   const xml = `<ZipCodeLookupRequest USERID="${user_id}">
//       <Address ID="1">
//       <Address1>${address1}</Address1>
//       <Address2>${address2}</Address2>
//       <City>${city}</City>
//       <State>${state}</State>
//       <Zip5>${zip}</Zip5>
//       <Zip4></Zip4>
//       </Address>
//       </ZipCodeLookupRequest>`;
//   const api = "ZipCodeLookup";
//   try {
//     const response = await axios.get(`${base_url}?API=${api}&XML=${xml}`);
//     const {
//       data
//     } = response;
//     res.status(200).json(data);
//   } catch (e) {
//     console.log(e);
//     res.status(400).json({
//       status: false,
//       message: "Something went wrong",
//       error: e,
//     });
//   }
// };
// exports.cityStateLookup = async (req, res, next) => {
//   var {
//     address1,
//     address2,
//     city,
//     state,
//     zip
//   } = req.body;
//   const xml = ` <CityStateLookupRequest USERID="${user_id}">
//   <ZipCode ID='0'>
//   <Zip5>${zip}</Zip5>
//   </ZipCode>
//   </CityStateLookupRequest>`;
//   const api = "CityStateLookup";
//   try {
//     const response = await axios.get(`${base_url}?API=${api}&XML=${xml}`);
//     const {
//       data
//     } = response;
//     res.status(200).json(data);
//   } catch (e) {
//     console.log(e);
//     res.status(400).json({
//       status: false,
//       message: "Something went wrong",
//       error: e,
//     });
//   }
// };
// //The RateV4 API lets customers calculate the rate for domestic packages and envelopes given the weight and dimensions of the item. The RateV4 API limits the data requested to twenty-five (25) packages per transaction.
// exports.schedulePickup = async (FirstName, LastName, Address2, City, State, ZIP4, Phone, EstimatedWeight) => {
//   const xml = `<CarrierPickupScheduleRequest USERID="${user_id}">
//   <FirstName>${FirstName}</FirstName>
//   <LastName>${LastName}</LastName>
//   <FirmName>ABC Corp.</FirmName>
//   <SuiteOrApt>Suite 777</SuiteOrApt>
//   <Address2>${Address2}</Address2>
//   <Urbanization></Urbanization>
//   <City>${City}</City>
//   <State>${State}</State>
//   <ZIP5>${ZIP4}</ZIP5>
//   <ZIP4>${ZIP4}</ZIP4>
//   <Phone>${Phone}</Phone>
//   <Extension>201</Extension>
//   <Package>
//   <ServiceType>PriorityMailExpress</ServiceType>
//   <Count>2</Count>
//   </Package>
//   <Package>
//   <ServiceType>PriorityMail</ServiceType>
//   <Count>1</Count>
//   </Package>
//   <EstimatedWeight>${EstimatedWeight}</EstimatedWeight>
//   <PackageLocation>Front Door</PackageLocation>
//   <SpecialInstructions>Packages are behind the screen door.</SpecialInstructions>
//   </CarrierPickupScheduleRequest>`;
//   const api = "CarrierPickupSchedule";
//   try {
//     const response = await axios.get(`${base_url}?API=${api}&XML=${xml}`);
//     const {
//       data
//     } = response;
//     console.log(xml)
//     return data;
//   } catch (e) {
//     console.log(e)

//   }
// };
// exports.evsLabel = async (FromName, FromAddress1, FromAddress2, FromCity, FromState, FromZip5, FromPhone, ToName,ToAddress2,ToCity,ToState,ToCountry,ToZip5,ToPhone,Description,Quantity,Value,NetPounds,NetOunces,GrossPounds,GrossOunces) => {
//   const xml = `<eVSExpressMailIntlRequest USERID="${user_id}">
//   <Option></Option>
//   <Revision>2</Revision>
//   <ImageParameters>
//   <ImageParameter>4X6LABEL</ImageParameter>
//   </ImageParameters>
//   <FromFirstName>Joseph</FromFirstName>
//   <FromMiddleInitial>J</FromMiddleInitial>
//   <FromLastName>Jones</FromLastName>
//   <FromFirm>Postal Service</FromFirm>
//   <FromAddress1>Suite 101</FromAddress1>
//   <FromAddress2>901 D Street SW</FromAddress2>
//   <FromUrbanization/>
//   <FromCity>Washington</FromCity>
//   <FromState>DC</FromState>
//   <FromZip5>20024</FromZip5>
//   <FromZip4>6129</FromZip4>
//   <FromPhone>9198887652</FromPhone>
//   <FromCustomsReference>45655332</FromCustomsReference>
//   <ToFirstName>Jon</ToFirstName>
//   <ToLastName>John</ToLastName>
//   <ToFirm>Coffee Five</ToFirm>
//   <ToAddress1>R. da Quitanda, 86 - quiosque 01</ToAddress1>
//   <ToCity>Centro</ToCity>
//   <ToProvince>Rio de Janeiro</ToProvince>
//   <ToCountry>BRAZIL</ToCountry>
//   <ToPostalCode>20091-902</ToPostalCode>
//   <ToPOBoxFlag>N</ToPOBoxFlag>
//   <ToPhone>7771234567</ToPhone>
//   <ToFax>3012929999</ToFax>
//   <ToEmail>myemail@email.com</ToEmail>
//   <ImportersReferenceNumber>E382788</ImportersReferenceNumber>
//   <NonDeliveryOption>RETURN</NonDeliveryOption>
//   <Container>VARIABLE</Container>
//   <ShippingContents>
//   <ItemDetail>
//   <Description>Cleaning Manual</Description>
//   <Quantity>1</Quantity>
//   <Value>15</Value>
//   <NetPounds>0</NetPounds>
//   <NetOunces>10</NetOunces>
//   <HSTariffNumber>490110</HSTariffNumber>
//   <CountryOfOrigin>UNITED STATES</CountryOfOrigin>
//   </ItemDetail>
//   </ShippingContents>
//   <InsuredNumber>E789656</InsuredNumber>
//   <InsuredAmount>15</InsuredAmount>
//   <Postage>5</Postage>
//   <GrossPounds>0</GrossPounds>
//   <GrossOunces>10</GrossOunces>
//   <ContentType>MERCHANDISE</ContentType>
//   <Agreement>Y</Agreement>
//   <Comments>eVSExpressMailIntl</Comments>
//   <LicenseNumber>LIC-24356879</LicenseNumber>
//   <CertificateNumber>CERT-97865342</CertificateNumber>
//   <InvoiceNumber>INV-040903</InvoiceNumber>
//   <ImageType>PDF</ImageType>
//   <ImageLayout>ONEPERFILE</ImageLayout>
//   <CustomerRefNo>EF789UJK</CustomerRefNo>
//   <POZipCode/>
//   <LabelDate>10/10/20</LabelDate>
//   <HoldForManifest>N</HoldForManifest>
//   <Length>12</Length>
//   <Width>0.5</Width>
//   <Height>9</Height>
//   <Girth>0</Girth>
//   <LabelTime>06:57:37</LabelTime>
//   <MeterPaymentFlag>Y</MeterPaymentFlag>
//   <ActionCode>M0</ActionCode>
//   <OptOutOfSPE>false</OptOutOfSPE>
//   <ImportersReferenceType>TAXCODE</ImportersReferenceType>
//   <ImportersTelephoneNumber>8976667878</ImportersTelephoneNumber>
//   <ImportersEmail>nancy@email.com</ImportersEmail>
//   <Machinable>false</Machinable>
//   <DestinationRateIndicator>N</DestinationRateIndicator>
//   </eVSExpressMailIntlRequest>
//   `;
//   const api = "eVS";
//   try {
//     const response = await axios.get(`${base_url}?API=${api}&XML=${xml}`);
//     const { data } = response;
//     return data;
//   } catch (e) {
//     console.log(e);
//   }
// };
