const connection = require("../../db/db.connection");
const {
  QueryTypes
} = require("sequelize");
var invNum = require("invoice-number");
const {
  Notification,
} = require("../../controllers/usersControllers/users.controller");
var crypto = require("crypto");
const {
  sendEmail
} = require("../../utils/notificationsMail");
const moment = require("moment");

//! Paymentgateway crud
exports.addPaymentGateway = async (req, res, next) => {
  try {
    const {
      GatewayName,
      Account,
      ClientID,
      ClientSecret,
      EndPoint,
      Rate,
      PerTransaction,
      BusinessEmail,
      BusinessPhone,
      BusinessURL,
      CurrencyCode,
      Active,
      AdminNote,
    } = req.body;
    let checkIFGatewayNameExists = await GatewayNameCheck(GatewayName); //!check if Gateway Name already exists
    console.log(checkIFGatewayNameExists);
    if (checkIFGatewayNameExists && checkIFGatewayNameExists == "0") {
      let insertPaymentGatewayQuery = `insert into paymentgateway (
            GatewayName,
            Account,
            ClientID,
            ClientSecret,
            EndPoint,
            Rate,
            PerTransaction,
            BusinessEmail,
            BusinessPhone,
            BusinessURL,
            CurrencyCode,
            Active,
            AdminNote) values (?,?,?,?,?,?,?,?,?,?,?,?,?)`;
      let insertPaymentGateway = await connection.query(
        insertPaymentGatewayQuery, {
        replacements: [
          GatewayName,
          Account,
          ClientID,
          ClientSecret,
          EndPoint,
          Rate,
          PerTransaction,
          BusinessEmail,
          BusinessPhone,
          BusinessURL,
          CurrencyCode,
          Active,
          AdminNote,
        ],
      }
      );
      if (insertPaymentGateway) {
        res.status(200).json({
          status: true,
          message: "Payment Gateway details added successfully",
        });
      } else {
        res.status(200).json({
          status: false,
          message: "Error while adding Payment Gateway Details",
        });
      }
    } else if (checkIFGatewayNameExists && checkIFGatewayNameExists == "1") {
      res.status(200).json({
        status: false,
        message: "Gateway name already exists",
        PaymentGateway: [],
      });
    }
  } catch (err) {
    next(err);
    res.status(200).json({
      status: false,
      message: err.message,
      PaymentGateway: [],
    });
  }
};
let GatewayNameCheck = async (GatewayName) => {
  try {
    let checkCityNameExists = await connection.query(
      `select * from paymentgateway where GatewayName = '${GatewayName}'`, {
      type: QueryTypes.SELECT,
    }
    );
    if (checkCityNameExists && checkCityNameExists.length > 0) {
      return "1";
    } else {
      return "0";
    }
  } catch (err) {
    console.log(err.message);
    return null;
  }
};
exports.getPaymentGateway = async (req, res, next) => {
  try {
    let paymentGateway = await connection.query(
      `SELECT p.* ,c.CountryID,c.Country
      FROM paymentgateway p
      LEFT JOIN country c ON c.GatewayID=p.GatewayID
      GROUP BY p.GatewayID`, {
      type: QueryTypes.SELECT,
    }
    );

    if (paymentGateway && paymentGateway.length > 0) {
      res.status(200).json({
        status: true,
        PaymentGateway: paymentGateway,
      });
    } else {
      res.status(200).json({
        status: false,
        message: "cannot show payment gateway",
        PaymentGateway: [],
      });
    }
  } catch (err) {
    next(err);
    res.status(200).json({
      status: false,
      message: err.message,
      PaymentGateway: [],
    });
    console.log(err.message);
  }
};
exports.getPaymentGatewayByID = async (req, res, next) => {
  try {
    const CountryID = req.params.id;
    let paymentGateway = await connection.query(
      `SELECT c.GatewayID,pg.GatewayName
      FROM paymentgateway pg
      INNER JOIN country c ON c.GatewayID=pg.GatewayID
      WHERE c.CountryID="${CountryID}" `, {
      type: QueryTypes.SELECT,
    }
    );

    if (paymentGateway && paymentGateway.length > 0) {
      res.status(200).json({
        status: true,
        PaymentGateway: paymentGateway[0],
      });
    } else {
      res.status(200).json({
        status: true,
        PaymentGateway: [],
      });
    }
  } catch (err) {
    console.log(err);
    res.status(200).json({
      status: false,
      message: err.message,
      PaymentGateway: [],
    });
    console.log(err.message);
  }
};
exports.updatePaymentGatewayById = async (req, res, next) => {
  try {
    const id = req.params.id;
    console.log(id);
    const {
      GatewayName,
      Account,
      ClientID,
      ClientSecret,
      EndPoint,
      Rate,
      PerTransaction,
      BusinessEmail,
      BusinessPhone,
      BusinessURL,
      CurrencyCode,
      Active,
      AdminNote,
    } = req.body;

    let LastUpdate = new Date().toISOString().slice(0, 19).replace("T", " ");

    let checkPaymentGateway = await connection.query(
      `select * from paymentgateway where GatewayID = '${id}' `, {
      type: QueryTypes.SELECT,
    }
    );
    if (checkPaymentGateway && checkPaymentGateway.length > 0) {
      console.log(GatewayName);
      console.log(checkPaymentGateway[0].GatewayName);
      if (GatewayName == checkPaymentGateway[0].GatewayName) {
        let updatePaymentGatewayQuery = `UPDATE paymentgateway SET GatewayName=?,
        Account=?,
        ClientID=?,
        ClientSecret=?,
        EndPoint=?,
        Rate=?,
        PerTransaction=?,
        BusinessEmail=?,
        BusinessPhone=?,
        BusinessURL=?,
        CurrencyCode=?,
        Active=?,
        LastUpdate=?,
        AdminNote=? WHERE GatewayID = "${id}"   `;
        let updatePaymentGateway = await connection.query(
          updatePaymentGatewayQuery, {
          replacements: [
            GatewayName,
            Account,
            ClientID,
            ClientSecret,
            EndPoint,
            Rate,
            PerTransaction,
            BusinessEmail,
            BusinessPhone,
            BusinessURL,
            CurrencyCode,
            Active,
            LastUpdate,
            AdminNote,
          ],
        }
        );
        if (updatePaymentGateway) {
          res.status(200).json({
            status: true,
            message: `Payment Gateway updated successfully`,
          });
        } else {
          res.status(200).json({
            status: false,
            message: `Error while updating Payment Gateway`,
          });
        }
      } else {
        let checkIFGatewayNameAlreadyExists = await connection.query(
          `select * from paymentgateway where GatewayName = '${GatewayName}' `, {
          type: QueryTypes.SELECT,
        }
        );
        console.log(checkIFGatewayNameAlreadyExists);
        if (
          checkIFGatewayNameAlreadyExists &&
          checkIFGatewayNameAlreadyExists.length > 0
        ) {
          res.status(200).json({
            status: false,
            PaymentGateway: {},
            message: `Gateway Name already taken, please select another one`,
          });
        } else {
          let updatePaymentGatewayQuery = `UPDATE paymentgateway SET GatewayName=?,
          Account=?,
          ClientID=?,
          ClientSecret=?,
          EndPoint=?,
          Rate=?,
          PerTransaction=?,
          BusinessEmail=?,
          BusinessPhone=?,
          BusinessURL=?,
          CurrencyCode=?,
          Active=?,
          LastUpdate=?,
          AdminNote=? WHERE GatewayID = "${id}"   `;
          let updatePaymentGateway = await connection.query(
            updatePaymentGatewayQuery, {
            replacements: [
              GatewayName,
              Account,
              ClientID,
              ClientSecret,
              EndPoint,
              Rate,
              PerTransaction,
              BusinessEmail,
              BusinessPhone,
              BusinessURL,
              CurrencyCode,
              Active,
              LastUpdate,
              AdminNote,
            ],
          }
          );
          if (updatePaymentGateway) {
            res.status(200).json({
              status: true,
              message: `Payment Gateway updated successfully`,
            });
          } else {
            res.status(200).json({
              status: false,
              message: `Error while updating Payment Gateway`,
            });
          }
        }
      }
    } else {
      res.status(200).json({
        status: false,
        message: `Payment Gateway does not exist`,
        PaymentGateway: [],
      });
    }
  } catch (err) {
    next(err);
    console.log(err.message);
    res.status(200).json({
      status: false,
      message: err.message,
      PaymentGateway: [],
    });
  }
};
exports.deletePaymentGatewayById = async (req, res, next) => {
  try {
    const id = req.params.id;
    console.log(id);

    let checkPaymentGateway = await connection.query(
      `select * from paymentgateway where GatewayID = "${id}" `, {
      type: QueryTypes.SELECT,
    }
    );
    if (checkPaymentGateway && checkPaymentGateway.length > 0) {
      let checkIfGatewayIDExistsInCountry =
        await checkPaymentGatewayExistsInCountry(id); //!see if paymentgateway used in country table
      console.log(checkIfGatewayIDExistsInCountry);
      if (
        checkIfGatewayIDExistsInCountry &&
        checkIfGatewayIDExistsInCountry == "0"
      ) {
        let deletePaymentGateway = await connection.query(
          `DELETE FROM paymentgateway WHERE GatewayID="${id}" `, {}
        );
        res.status(200).json({
          status: true,
          message: `PaymentGateway deleted successfully`,
        });
      } else if (
        checkIfGatewayIDExistsInCountry &&
        checkIfGatewayIDExistsInCountry == "1"
      ) {
        res.status(200).json({
          status: false,
          message: `Payment Gateway is being used in Country Table it cannot be deleted`,
          PaymentGateway: [],
        });
      }
    } else {
      console.log("*********");
      res.status(200).json({
        status: false,
        message: `Payment Gateway does not exist`,
        PaymentGateway: [],
      });
    }
  } catch (err) {
    next(err);
    res.status(200).json({
      status: false,
      message: err.message,
      PaymentGateway: [],
    });
    console.log(err.message);
  }
};
let checkPaymentGatewayExistsInCountry = async (GatewayID) => {
  try {
    let gatewayIDCheck = await connection.query(
      `select * from country where GatewayID  = '${GatewayID}'`, {
      type: QueryTypes.SELECT,
    }
    );
    if (gatewayIDCheck && gatewayIDCheck.length > 0) {
      return "1";
    } else {
      return "0";
    }
  } catch (err) {
    console.log(err.message);
    return null;
  }
};
//! cod order generation
exports.insertProcessPayment = async (req, res, next) => {
  let transaction;
  try {
    transaction = await connection.transaction();
    let UserID = req.UserID;
    let OrderNumber;
    let OrderNumbers = [];
    let OrderDate = new Date().toISOString().slice(0, 19).replace("T", " ");
    //generating unique tran_id each time
    function random_ID() {
      var bytes = crypto.randomBytes(6);
      var base36String = parseInt(bytes.toString("hex"), 16).toString(36);
      return base36String.padStart(8, "0").toUpperCase();
    }
    const {
      SessionID,
      GatewayID,
      GetawayConfirmation,
      currency,
      ItemsPrice,
      ShippingHandling,
      TotalBeforeTax,
      EstimatedTax,
      OrderTotal,
      cus_country,
      DeliveryName,
      DeliveryPhoneNumber,
      DeliveryAddress1,
      DeliveryAddress2,
      DeliveryCity,
      DeliveryState,
      DeliveryZipCode,
      DesireDeliveryDate,
      DeliveryUserNote,
      DeliveryCityID,
      DeliveryZoneID,
      DeliveryAreaID,
      homeAddress,
      AddressLabel,
      DeliveryZone,
      DeliveryArea,
      DefaultAddress,
      ProductDetail,
      ProcessStatus,
      VendorPaymentStatus,
      AllowStorePickup,
      AllowAdminPickup,
      DeliveryStatus,
      PaymentType,
    } = req.body;
    const currentDate = new Date();

    // Add 5 days to the current date
    const fiveDaysLater = new Date(
      currentDate.getTime() + 10 * 24 * 60 * 60 * 1000
    );

    // Format the date string in the desired format (YYYY-MM-DD)
    const ShippingDate = fiveDaysLater.toISOString().slice(0, 10);
    let TransactionID = random_ID();
    let ShippingByVendorOrder = [];
    let ShippingByBanglaBazarOrder = [];
    let VendorItemsTotalPrice = 0;
    let AdminItemsTotalPrice = 0;
    let TotalItemsPrice = 0;
    let uniqueAdminVendorStoreIds = [];
    let uniqueVendorStoreIds = [];
    for (let i = 0; i < ProductDetail.length; i++) {
      let getProductVariantCombinationID = [];
      let ProductIDs;
      let VendorStoreID;
      let ShippingByAdmin;
      let itemsPrice;
      let Quantity;
      let itemsShippingHandling;
      let itemsBeforeTax;
      let itemsEstimatedTax;
      let itemsTotal;
      let shippingByVendor = 0;
      let variantsLength =
        ProductDetail[i].ProductVariantCombinationDetail.length;
      let variants = ProductDetail[i].ProductVariantCombinationDetail;
      if (ProductDetail[i].ShippingByVendor == "Y") {
        ProductIDs = ProductDetail[i].ProductID;
        VendorStoreID = ProductDetail[i].VendorStoreID;
        shippingByVendor = ProductDetail[i].ShippingByVendor;
        ShippingByAdmin = ProductDetail[i].ShippingByAdmin;
        itemsPrice = ProductDetail[i].itemsPrice;
        Quantity = ProductDetail[i].Quantity;
        itemsShippingHandling = ProductDetail[i].itemsShippingHandling;
        itemsBeforeTax = ProductDetail[i].itemsBeforeTax;
        itemsEstimatedTax = ProductDetail[i].itemsEstimatedTax;
        itemsTotal = ProductDetail[i].itemsTotal;
        for (let j = 0; j < variantsLength; j++) {
          let obj = {
            ProductVariantCombinationID: variants[j].ProductVariantCombinationID,
          };
          getProductVariantCombinationID.push(obj);
          if (!uniqueVendorStoreIds.includes(ProductDetail[i].VendorStoreID)) {
            uniqueVendorStoreIds.push(ProductDetail[i].VendorStoreID);
          }
        }
        let obj = {
          ProductID: ProductIDs,
          VendorStoreID: VendorStoreID,
          ShippingByVendor: shippingByVendor,
          ShippingByAdmin: ShippingByAdmin,
          itemsPrice: itemsPrice,
          Quantity: Quantity,
          itemsShippingHandling: itemsShippingHandling,
          itemsBeforeTax: itemsBeforeTax,
          itemsEstimatedTax: itemsEstimatedTax,
          itemsTotal: itemsTotal,
          ProductVariantCombinationDetail: getProductVariantCombinationID,
        };
        VendorItemsTotalPrice += parseFloat(itemsTotal);
        ShippingByVendorOrder.push(obj);
      }
      if (ProductDetail[i].ShippingByAdmin == "Y") {
        ProductIDs = ProductDetail[i].ProductID;
        VendorStoreID = ProductDetail[i].VendorStoreID;
        shippingByVendor = ProductDetail[i].ShippingByVendor;
        ShippingByAdmin = ProductDetail[i].ShippingByAdmin;
        itemsPrice = ProductDetail[i].itemsPrice;
        Quantity = ProductDetail[i].Quantity;
        itemsShippingHandling = ProductDetail[i].itemsShippingHandling;
        itemsBeforeTax = ProductDetail[i].itemsBeforeTax;
        itemsEstimatedTax = ProductDetail[i].itemsEstimatedTax;
        itemsTotal = ProductDetail[i].itemsTotal;
        for (let j = 0; j < variantsLength; j++) {
          let obj = {
            ProductVariantCombinationID: variants[j].ProductVariantCombinationID,
          };
          getProductVariantCombinationID.push(obj);
          if (
            !uniqueAdminVendorStoreIds.includes(ProductDetail[i].VendorStoreID)
          ) {
            uniqueAdminVendorStoreIds.push(ProductDetail[i].VendorStoreID);
          }
        }
        let obj = {
          ProductID: ProductIDs,
          VendorStoreID: VendorStoreID,
          ShippingByVendor: shippingByVendor,
          ShippingByAdmin: ShippingByAdmin,
          itemsPrice: itemsPrice,
          Quantity: Quantity,
          itemsShippingHandling: itemsShippingHandling,
          itemsBeforeTax: itemsBeforeTax,
          itemsEstimatedTax: itemsEstimatedTax,
          itemsTotal: itemsTotal,
          ProductVariantCombinationDetail: getProductVariantCombinationID,
        };
        AdminItemsTotalPrice += parseFloat(itemsTotal);
        ShippingByBanglaBazarOrder.push(obj);
      }
    }
    console.log(ShippingByVendorOrder, "ShippingByVendorOrder");
    console.log(ShippingByBanglaBazarOrder, "ShippingByBanglaBazarOrder");
    TotalItemsPrice = AdminItemsTotalPrice + VendorItemsTotalPrice; //total to be sent to SSL cOMMERZ FOR SINGE PAYMENT AGAINST THESE 2 ORDERS
    if (ShippingByVendorOrder.length == 0) {
      console.log("Only BanglaBazar delivery case");
      let adressesResponse = false;
      let saveAddress = false;
      // below this
      if (homeAddress) {
        let saveResponse = await addUserPaymentAndAddress(
          UserID,
          "",
          "",
          "",
          "",
          "",
          "",
          "",
          "",
          "",
          "",
          "",
          GatewayID,
          "",
          DefaultAddress,
          DeliveryName,
          DeliveryPhoneNumber,
          DeliveryAddress1,
          DeliveryAddress2,
          DeliveryState,
          DeliveryCity,
          DeliveryZoneID,
          cus_country,
          DeliveryAreaID,
          DeliveryZipCode,
          DeliveryUserNote,
          AddressLabel,
          DeliveryCityID,
          DeliveryZone,
          DeliveryArea,
          saveAddress,
          homeAddress,
          transaction
        );
        console.log(saveResponse, "saveResponse");
        if (saveResponse) {
          adressesResponse = true;
        } else {
          adressesResponse = false;
        }
      } else {
        adressesResponse = true;
      }
      if (adressesResponse) {
        for (let index = 0; index < uniqueAdminVendorStoreIds.length; index++) {
          let getLastOrderNumber = await connection.query(
            `SELECT * from processpayment
                 ORDER BY OrderNumber DESC
     `, {
            type: QueryTypes.SELECT,
            transaction,
          }
          );
          if (getLastOrderNumber && getLastOrderNumber.length > 0) {
            let saveOrderNumber = getLastOrderNumber[0].OrderNumber;
            OrderNumber = invNum.InvoiceNumber.next(saveOrderNumber);
          } else {
            OrderNumber = invNum.InvoiceNumber.next("000");
          }

          let UserPaymentID = null;
          let insertPaymentGatewayQuery = `insert into processpayment (
          OrderNumber ,
          SessionID,
          UserID,
          GetawayConfirmation,
          UserPaymentID,
          Name,
          Address1,
          Address2,
          CardNumber,
          ExpirationDate,
          City,
          State,
          ZipCode,
          CountryID,
          OrderDate,
          ItemsPrice,
          ShippingHandling,
          TotalBeforeTax,
          EstimatedTax,
          OrderTotal,
          Currency,
          TransactionID) values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`;
          let insertPaymentGateway = await connection.query(
            insertPaymentGatewayQuery, {
            replacements: [
              OrderNumber,
              SessionID,
              UserID,
              GetawayConfirmation,
              UserPaymentID,
              DeliveryName,
              DeliveryAddress1,
              DeliveryAddress2,
              "NULL",
              "NULL",
              DeliveryCity,
              DeliveryState,
              DeliveryZipCode,
              cus_country,
              OrderDate,
              ItemsPrice,
              ShippingHandling,
              TotalBeforeTax,
              EstimatedTax,
              OrderTotal,
              currency,
              TransactionID,
            ],
            transaction,
          }
          );
          if (insertPaymentGateway) {
            let insertDeliveryAddressQuery = `insert into orderdeliveryaddress (
          OrderNumber, 
          Name,
          PhoneNumber,
          Address1,
          Address2,
          City,
          State,
          ZipCode,
          CountryID,
          DesireDate,
          UserNote,
          CityID,
          ZoneID,
          AreaID) values (?,?,?,?,?,?,?,?,?,?,?,?,?,?)`;
            let insertDeliveryAddress = await connection.query(
              insertDeliveryAddressQuery, {
              replacements: [
                OrderNumber,
                DeliveryName,
                DeliveryPhoneNumber,
                DeliveryAddress1,
                DeliveryAddress2,
                DeliveryCity,
                DeliveryState,
                DeliveryZipCode,
                cus_country,
                DesireDeliveryDate,
                DeliveryUserNote,
                DeliveryCityID,
                DeliveryZoneID,
                DeliveryAreaID,
              ],
              transaction,
            }
            );
            if (insertDeliveryAddress) {
              //!below this
              const ProcessPaymentID = insertPaymentGateway[0];
              let UserID = req.UserID;
              let OrderDate = new Date()
                .toISOString()
                .slice(0, 19)
                .replace("T", " ");
              let ReadyPickupForUser = "N";
              let ReadyPickupForAdmin = "N";
              let ProductVariantCombinationIDs = [];
              let insertProcessOrderQuery = [];
              let ProductVariantCombinationID = [];
              let saveProductVariantCombinationID = [];
              let saveProductID = [];
              let tempArray = [];
              //${DesireDeliveryDate ? `${DesireDeliveryDate},`:'' }
              for (let i = 0; i < ShippingByBanglaBazarOrder.length; i++) {
                let array = [];
                let VendorStoreID = ShippingByBanglaBazarOrder[i].VendorStoreID;
                console.log(VendorStoreID, "VendorStoreID");
                console.log(
                  uniqueAdminVendorStoreIds[index],
                  " uniqueAdminVendorStoreIds[index]",
                  index
                );
                if (VendorStoreID === uniqueAdminVendorStoreIds[index]) {
                  //!compare unique store id i index(outer loop at start) with ShippingByBanglaBazarOrder i index(this loop) store id
                  saveProductID.push(ShippingByBanglaBazarOrder[i].ProductID);
                  let ProductID = ShippingByBanglaBazarOrder[i].ProductID;
                  let Quantity = ShippingByBanglaBazarOrder[i].Quantity;
                  let ItemsPrice = ShippingByBanglaBazarOrder[i].itemsPrice;
                  let ItemsShippingHandling =
                    ShippingByBanglaBazarOrder[i].itemsShippingHandling;
                  let ItemsBeforeTax =
                    ShippingByBanglaBazarOrder[i].itemsBeforeTax;
                  let ItemsEstimatedTax =
                    ShippingByBanglaBazarOrder[i].itemsEstimatedTax;
                  let ItemsTotal = ShippingByBanglaBazarOrder[i].itemsTotal;
                  let variantsLength =
                    ShippingByBanglaBazarOrder[i]
                      .ProductVariantCombinationDetail.length;
                  let variants =
                    ShippingByBanglaBazarOrder[i]
                      .ProductVariantCombinationDetail;
                  for (j = 0; j < variantsLength; j++) {
                    array.push(variants[j].ProductVariantCombinationID);
                    tempArray.push(variants[j].ProductVariantCombinationID);
                  }

                  ProductVariantCombinationID = `${array.join(",")}`;
                  insertProcessOrderQuery.push(`('${ProcessPaymentID}', '${OrderNumber}','${ProductID}',
                  '${VendorStoreID}','${ProductVariantCombinationID}','${UserID}',
                  '${Quantity}',
                  '${ItemsPrice}','${ItemsShippingHandling}','${ItemsBeforeTax}', '${ItemsEstimatedTax}','${ItemsTotal}',
                  '${OrderDate}','${ShippingDate}','${AllowStorePickup}','${ReadyPickupForUser}', 
                  '${ReadyPickupForAdmin}','${ProcessStatus}',
                  '${VendorPaymentStatus}','${DeliveryUserNote}','${AllowAdminPickup}','${DeliveryStatus}','${PaymentType}')`);

                  ProductVariantCombinationIDs = `(${array.join(",")})`;
                  console.log(
                    ProductVariantCombinationIDs,
                    "ProductVariantCombinationIDs"
                  );
                }
              }
              let _insertProcessOrderQuery = `insert into processorder (
                ProcessPaymentID,
                OrderNumber,
                 ProductID,
                 VendorStoreID,
                 ProductVariantCombinationDetail,
                 UserID,
                 Quantity,
                 ItemsPrice,
                 ItemsShippingHandling,
                 ItemsBeforeTax,
                 ItemsEstimatedTax,
                 ItemsTotal,
                 OrderDate,
                 ShippingDate,
                 AllowStorePickup,
                 ReadyPickupForUser,
                 ReadyPickupForAdmin,
                 ProcessStatus,
                 VendorPaymentStatus,
                 Note,
                 AllowAdminPickup,
                 DeliveryStatus,
                 PaymentType) values ${insertProcessOrderQuery.join(",")}`;
              console.log(_insertProcessOrderQuery, "insertProcessOrderQuery");
              let insertProcessOrder = await connection.query(
                _insertProcessOrderQuery, {
                transaction,
              }
              );
              let ProductID = `(${saveProductID.join(",")})`;
              saveProductVariantCombinationID = `(${tempArray.join(",")})`;
              console.log(saveProductVariantCombinationID);
              if (insertProcessOrder) {
                let checkIfProductExists = await connection.query(
                  ` select * from shoppingcart where ProductID IN ${ProductID} AND ProductVariantCombinationDetail IN ${saveProductVariantCombinationID} AND UserID = "${UserID}"
                              `, {
                  type: QueryTypes.SELECT,
                  transaction,
                }
                );
                if (checkIfProductExists && checkIfProductExists.length > 0) {
                  //!below this
                  let deleteShoppingCartList = await connection.query(
                    ` DELETE FROM shoppingcart WHERE ProductID IN ${ProductID} AND ProductVariantCombinationDetail IN ${saveProductVariantCombinationID} AND UserID = "${UserID}"`, {
                    transaction,
                  }
                  );
                  if (deleteShoppingCartList) {
                    OrderNumbers.push(OrderNumber);
                    let TypeID = "6";
                    let CreaterID = "1";
                    let Body = {
                      OrderNumber: OrderNumber,
                      body: `Your OrderNumber ${OrderNumber} is placed`,
                    };
                    let Message = `You OrderNumber ${Body.OrderNumber} is placed `;
                    let email = [];
                    if (index === 0) {
                      let getDeviceIDQuery = ` SELECT DeviceID,EmailAddress
                   FROM profile 
                   WHERE UserID=${UserID}`;
                      let getDeviceID = await connection.query(
                        getDeviceIDQuery, {
                        type: QueryTypes.SELECT,
                        transaction,
                      }
                      );
                      email.push(getDeviceID[0].EmailAddress);
                    }
                    const EmailAddress = email[0];
                    //! Email Method
                    let ReceiverID = UserID;
                    let sendNotification = await Notification(
                      TypeID,
                      Body,
                      CreaterID,
                      ReceiverID,
                      transaction
                    );
                    console.log(sendNotification, "sendNotification");
                    if (sendNotification) {
                      sendEmail(EmailAddress, Message, TypeID);
                      if (index === uniqueAdminVendorStoreIds.length - 1) {
                        if (transaction) await transaction.commit(); //!final commit
                        res.status(200).json({
                          status: true,
                          message: "Successfully Order Created and Product removed from shopping cart",
                          OrderNumber: OrderNumbers.toString(),
                        });
                      } else {
                        continue;
                      }
                    } else {
                      if (transaction) await transaction.rollback();
                      res.status(200).json({
                        status: false,
                        message: "Error while sending notification to user ",
                        OrderNumber: [],
                      });
                    }
                  } else {
                    if (transaction) await transaction.rollback();
                    res.status(200).json({
                      status: false,
                      message: " Error while deleting from cart ",
                      OrderNumber: [],
                    });
                  }
                  //!above this
                } else {
                  if (transaction) await transaction.rollback();
                  res.status(200).json({
                    status: false,
                    message: "Product does not exist in Shopping Cart ",
                    OrderNumber: [],
                  });
                }
              } else {
                if (transaction) await transaction.rollback();
                res.status(200).json({
                  status: false,
                  message: `Errror while adding to Process Order table `,
                  OrderNumber: [],
                });
              }
            } else {
              if (transaction) await transaction.rollback();
              res.status(200).json({
                status: false,
                message: "Error while adding delivery Address ",
                OrderNumber: [],
              });
            }
          } else {
            if (transaction) await transaction.rollback();
            res.status(200).json({
              status: false,
              message: "Error while adding  Process Payment  ",
              OrderNumber: [],
            });
          }
        }
      } else {
        if (transaction) await transaction.rollback();
        res.status(200).json({
          status: false,
          message: "Error while internal Api response ",
          OrderNumber: [],
        });
      }
    } else if (ShippingByBanglaBazarOrder.length == 0) {
      console.log("Only vendor deivery case");
      let adressesResponse = false;
      let saveAddress = false;
      // below this
      if (homeAddress) {
        let saveResponse = await addUserPaymentAndAddress(
          UserID,
          "",
          "",
          "",
          "",
          "",
          "",
          "",
          "",
          "",
          "",
          "",
          GatewayID,
          "",
          DefaultAddress,
          DeliveryName,
          DeliveryPhoneNumber,
          DeliveryAddress1,
          DeliveryAddress2,
          DeliveryState,
          DeliveryCity,
          DeliveryZoneID,
          cus_country,
          DeliveryAreaID,
          DeliveryZipCode,
          DeliveryUserNote,
          AddressLabel,
          DeliveryCityID,
          DeliveryZone,
          DeliveryArea,
          saveAddress,
          homeAddress,
          transaction
        );
        console.log(saveResponse, "saveResponse");
        if (saveResponse) {
          adressesResponse = true;
        } else {
          adressesResponse = false;
        }
      } else {
        adressesResponse = true;
      }
      if (adressesResponse) {
        for (let index = 0; index < uniqueVendorStoreIds.length; index++) {
          let getLastOrderNumber = await connection.query(
            `SELECT * from processpayment
                 ORDER BY OrderNumber DESC
     `, {
            type: QueryTypes.SELECT,
            transaction,
          }
          );
          if (getLastOrderNumber && getLastOrderNumber.length > 0) {
            let saveOrderNumber = getLastOrderNumber[0].OrderNumber;
            OrderNumber = invNum.InvoiceNumber.next(saveOrderNumber);
          } else {
            OrderNumber = invNum.InvoiceNumber.next("000");
          }
          let UserPaymentID = null;
          let insertPaymentGatewayQuery = `insert into processpayment (
          OrderNumber ,
          SessionID,
          UserID,
          GetawayConfirmation,
          UserPaymentID,
          Name,
          Address1,
          Address2,
          CardNumber,
          ExpirationDate,
          City,
          State,
          ZipCode,
          CountryID,
          OrderDate,
          ItemsPrice,
          ShippingHandling,
          TotalBeforeTax,
          EstimatedTax,
          OrderTotal,
          Currency,
          TransactionID) values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`;
          let insertPaymentGateway = await connection.query(
            insertPaymentGatewayQuery, {
            replacements: [
              OrderNumber,
              SessionID,
              UserID,
              GetawayConfirmation,
              UserPaymentID,
              DeliveryName,
              DeliveryAddress1,
              DeliveryAddress2,
              "NULL",
              "NULL",
              DeliveryCity,
              DeliveryState,
              DeliveryZipCode,
              cus_country,
              OrderDate,
              ItemsPrice,
              ShippingHandling,
              TotalBeforeTax,
              EstimatedTax,
              OrderTotal,
              currency,
              TransactionID,
            ],
            transaction,
          }
          );
          if (insertPaymentGateway) {
            let insertDeliveryAddressQuery = `insert into orderdeliveryaddress (
          OrderNumber, 
          Name,
          PhoneNumber,
          Address1,
          Address2,
          City,
          State,
          ZipCode,
          CountryID,
          DesireDate,
          UserNote,
          CityID,
          ZoneID,
          AreaID) values (?,?,?,?,?,?,?,?,?,?,?,?,?,?)`;
            let insertDeliveryAddress = await connection.query(
              insertDeliveryAddressQuery, {
              replacements: [
                OrderNumber,
                DeliveryName,
                DeliveryPhoneNumber,
                DeliveryAddress1,
                DeliveryAddress2,
                DeliveryCity,
                DeliveryState,
                DeliveryZipCode,
                cus_country,
                DesireDeliveryDate,
                DeliveryUserNote,
                DeliveryCityID,
                DeliveryZoneID,
                DeliveryAreaID,
              ],
              transaction,
            }
            );
            if (insertDeliveryAddress) {
              //!below this
              const ProcessPaymentID = insertPaymentGateway[0];
              let UserID = req.UserID;
              let OrderDate = new Date()
                .toISOString()
                .slice(0, 19)
                .replace("T", " ");
              let ReadyPickupForUser = "N";
              let ReadyPickupForAdmin = "N";
              let ProductVariantCombinationIDs = [];
              let insertProcessOrderQuery_ = [];
              let ProductVariantCombinationID = [];
              let saveProductVariantCombinationID = [];
              let saveProductID = [];
              let tempArray = [];
              for (let i = 0; i < ShippingByVendorOrder.length; i++) {
                let array = [];
                let VendorStoreID = ShippingByVendorOrder[i].VendorStoreID;
                console.log(VendorStoreID, "VendorStoreID");
                console.log(
                  uniqueVendorStoreIds[index],
                  " uniqueAdminVendorStoreIds[index]",
                  index
                );
                if (VendorStoreID === uniqueVendorStoreIds[index]) {
                  //!compare unique store id i index(outer loop at start) with ShippingByVendorOrder i index(this loop) store id
                  saveProductID.push(ShippingByVendorOrder[i].ProductID);
                  let ProductID = ShippingByVendorOrder[i].ProductID;
                  let Quantity = ShippingByVendorOrder[i].Quantity;
                  let ItemsPrice = ShippingByVendorOrder[i].itemsPrice;
                  console.log(ItemsPrice, "ItemsPrice");
                  let ItemsShippingHandling =
                    ShippingByVendorOrder[i].itemsShippingHandling;
                  console.log(ItemsShippingHandling, "ItemsShippingHandling");
                  let ItemsBeforeTax = ShippingByVendorOrder[i].itemsBeforeTax;
                  let ItemsEstimatedTax =
                    ShippingByVendorOrder[i].itemsEstimatedTax;
                  let ItemsTotal = ShippingByVendorOrder[i].itemsTotal;
                  console.log(ItemsEstimatedTax, "ItemsEstimatedTax");
                  console.log(ItemsTotal, "ItemsTotal");
                  let variantsLength =
                    ShippingByVendorOrder[i].ProductVariantCombinationDetail
                      .length;
                  let variants =
                    ShippingByVendorOrder[i].ProductVariantCombinationDetail;
                  for (j = 0; j < variantsLength; j++) {
                    array.push(variants[j].ProductVariantCombinationID);
                    tempArray.push(variants[j].ProductVariantCombinationID);
                  }
                  ProductVariantCombinationID = `${array.join(",")}`;
                  insertProcessOrderQuery_.push(`('${ProcessPaymentID}', '${OrderNumber}','${ProductID}',
                   '${VendorStoreID}','${ProductVariantCombinationID}','${UserID}',
                   '${Quantity}',
                   '${ItemsPrice}','${ItemsShippingHandling}','${ItemsBeforeTax}', '${ItemsEstimatedTax}','${ItemsTotal}',
                   '${OrderDate}','${ShippingDate}','${AllowStorePickup}','${ReadyPickupForUser}', 
                   '${ReadyPickupForAdmin}','${ProcessStatus}',
                   '${VendorPaymentStatus}','${DeliveryUserNote}','${AllowAdminPickup}','VS','${PaymentType}')`);

                  ProductVariantCombinationIDs = `(${array.join(",")})`;
                  console.log(
                    ProductVariantCombinationIDs,
                    "ProductVariantCombinationIDs"
                  );
                }
              }
              let _insertProcessOrderQuery = `insert into processorder (
              ProcessPaymentID,
               OrderNumber,
                ProductID,
                VendorStoreID,
                ProductVariantCombinationDetail,
                UserID,
                Quantity,
                ItemsPrice,
                ItemsShippingHandling,
                ItemsBeforeTax,
                ItemsEstimatedTax,
                ItemsTotal,
                OrderDate,
                ShippingDate,
                AllowStorePickup,
                ReadyPickupForUser,
                ReadyPickupForAdmin,
                ProcessStatus,
                VendorPaymentStatus,
                Note,
                AllowAdminPickup,
                DeliveryStatus,
                PaymentType) values ${insertProcessOrderQuery_.join(",")}`;
              console.log(_insertProcessOrderQuery, "insertProcessOrderQuery");
              let insertProcessOrder = await connection.query(
                _insertProcessOrderQuery, {
                transaction,
              }
              );
              let ProductID = `(${saveProductID.join(",")})`;
              saveProductVariantCombinationID = `(${tempArray.join(",")})`;
              if (insertProcessOrder) {
                let checkIfProductExists = await connection.query(
                  ` select * from shoppingcart where ProductID IN ${ProductID} AND ProductVariantCombinationDetail IN ${saveProductVariantCombinationID} AND UserID = "${UserID}"
                              `, {
                  type: QueryTypes.SELECT,
                  transaction,
                }
                );
                if (checkIfProductExists && checkIfProductExists.length > 0) {
                  //!below this

                  let deleteShoppingCartList = await connection.query(
                    ` DELETE FROM shoppingcart WHERE ProductID IN ${ProductID} AND ProductVariantCombinationDetail IN ${saveProductVariantCombinationID} AND UserID = "${UserID}"`, {
                    transaction,
                  }
                  );
                  if (deleteShoppingCartList) {
                    OrderNumbers.push(OrderNumber);
                    let TypeID = "6";
                    let CreaterID = "1";
                    let Body = {
                      OrderNumber: OrderNumber,
                      body: `Your OrderNumber ${OrderNumber} is placed`,
                    };
                    let Message = `You OrderNumber ${Body.OrderNumber} is placed `;
                    let email = [];
                    if (index === 0) {
                      let getDeviceIDQuery = ` SELECT DeviceID,EmailAddress
                   FROM profile 
                   WHERE UserID=${UserID}`;
                      let getDeviceID = await connection.query(
                        getDeviceIDQuery, {
                        type: QueryTypes.SELECT,
                        transaction,
                      }
                      );
                      email.push(getDeviceID[0].EmailAddress);
                    }
                    const EmailAddress = email[0];
                    //! Email Method
                    let ReceiverID = UserID;
                    let sendNotification = await Notification(
                      TypeID,
                      Body,
                      CreaterID,
                      ReceiverID,
                      transaction
                    );
                    console.log(sendNotification, "sendNotification");
                    if (sendNotification) {
                      sendEmail(EmailAddress, Message, TypeID);
                      if (index === uniqueVendorStoreIds.length - 1) {
                        if (transaction) await transaction.commit(); //!final commit
                        res.status(200).json({
                          status: true,
                          message: "Successfully Order Created and Product removed from shopping cart",
                          OrderNumber: OrderNumbers.toString(),
                        });
                      } else {
                        continue;
                      }
                    } else {
                      if (transaction) await transaction.rollback();
                      res.status(200).json({
                        status: false,
                        message: "Error while sending notification to user ",
                        OrderNumber: [],
                      });
                    }
                  } else {
                    if (transaction) await transaction.rollback();
                    res.status(200).json({
                      status: false,
                      message: " Error while deleting from cart ",
                      OrderNumber: [],
                    });
                  }
                  //!above this
                } else {
                  if (transaction) await transaction.rollback();
                  res.status(200).json({
                    status: false,
                    message: "Product does not exist in Shopping Cart ",
                    OrderNumber: [],
                  });
                }
              } else {
                if (transaction) await transaction.rollback();
                res.status(200).json({
                  status: false,
                  message: `Errror while adding to Process Order table `,
                  OrderNumber: [],
                });
              }
            } else {
              if (transaction) await transaction.rollback();
              res.status(200).json({
                status: false,
                message: "Error while adding delivery Address ",
                OrderNumber: [],
              });
            }
          } else {
            if (transaction) await transaction.rollback();
            res.status(200).json({
              status: false,
              message: "Error while adding  Process Payment  ",
              OrderNumber: [],
            });
          }
        }
      } else {
        if (transaction) await transaction.rollback();
        res.status(200).json({
          status: false,
          message: "Error while internal Api response ",
          OrderNumber: [],
        });
      }
    } else {
      console.log("both delivery case ---------------------------");
      let adressesResponse = false;
      let saveAddress = false;
      // below this
      if (homeAddress) {
        let saveResponse = await addUserPaymentAndAddress(
          UserID,
          "",
          "",
          "",
          "",
          "",
          "",
          "",
          "",
          "",
          "",
          "",
          GatewayID,
          "",
          DefaultAddress,
          DeliveryName,
          DeliveryPhoneNumber,
          DeliveryAddress1,
          DeliveryAddress2,
          DeliveryState,
          DeliveryCity,
          DeliveryZoneID,
          cus_country,
          DeliveryAreaID,
          DeliveryZipCode,
          DeliveryUserNote,
          AddressLabel,
          DeliveryCityID,
          DeliveryZone,
          DeliveryArea,
          saveAddress,
          homeAddress,
          transaction
        );
        console.log(saveResponse, "saveResponse");
        if (saveResponse) {
          adressesResponse = true;
        } else {
          adressesResponse = false;
        }
      } else {
        adressesResponse = true;
      }
      if (adressesResponse) {
        for (let i = 0; i < 2; i++) {
          if (i === 0) {
            //Bnaglabbazar shipping case
            for (
              let index = 0; index < uniqueAdminVendorStoreIds.length; index++
            ) {
              let getLastOrderNumber = await connection.query(
                `SELECT * from processpayment
                   ORDER BY OrderNumber DESC
       `, {
                type: QueryTypes.SELECT,
                transaction,
              }
              );
              if (getLastOrderNumber && getLastOrderNumber.length > 0) {
                let saveOrderNumber = getLastOrderNumber[0].OrderNumber;
                OrderNumber = invNum.InvoiceNumber.next(saveOrderNumber);
              } else {
                OrderNumber = invNum.InvoiceNumber.next("000");
              }

              let UserPaymentID = null;
              let insertPaymentGatewayQuery = `insert into processpayment (
            OrderNumber ,
            SessionID,
            UserID,
            GetawayConfirmation,
            UserPaymentID,
            Name,
            Address1,
            Address2,
            CardNumber,
            ExpirationDate,
            City,
            State,
            ZipCode,
            CountryID,
            OrderDate,
            ItemsPrice,
            ShippingHandling,
            TotalBeforeTax,
            EstimatedTax,
            OrderTotal,
            Currency,
            TransactionID) values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`;
              let insertPaymentGateway = await connection.query(
                insertPaymentGatewayQuery, {
                replacements: [
                  OrderNumber,
                  SessionID,
                  UserID,
                  GetawayConfirmation,
                  UserPaymentID,
                  DeliveryName,
                  DeliveryAddress1,
                  DeliveryAddress2,
                  "NULL",
                  "NULL",
                  DeliveryCity,
                  DeliveryState,
                  DeliveryZipCode,
                  cus_country,
                  OrderDate,
                  ItemsPrice,
                  ShippingHandling,
                  TotalBeforeTax,
                  EstimatedTax,
                  OrderTotal,
                  currency,
                  TransactionID,
                ],
                transaction,
              }
              );
              if (insertPaymentGateway) {
                let insertDeliveryAddressQuery = `insert into orderdeliveryaddress (
            OrderNumber, 
            Name,
            PhoneNumber,
            Address1,
            Address2,
            City,
            State,
            ZipCode,
            CountryID,
            DesireDate,
            UserNote,
            CityID,
            ZoneID,
            AreaID) values (?,?,?,?,?,?,?,?,?,?,?,?,?,?)`;
                let insertDeliveryAddress = await connection.query(
                  insertDeliveryAddressQuery, {
                  replacements: [
                    OrderNumber,
                    DeliveryName,
                    DeliveryPhoneNumber,
                    DeliveryAddress1,
                    DeliveryAddress2,
                    DeliveryCity,
                    DeliveryState,
                    DeliveryZipCode,
                    cus_country,
                    DesireDeliveryDate,
                    DeliveryUserNote,
                    DeliveryCityID,
                    DeliveryZoneID,
                    DeliveryAreaID,
                  ],
                  transaction,
                }
                );
                if (insertDeliveryAddress) {
                  //!below this
                  const ProcessPaymentID = insertPaymentGateway[0];
                  let UserID = req.UserID;
                  let OrderDate = new Date()
                    .toISOString()
                    .slice(0, 19)
                    .replace("T", " ");
                  let ReadyPickupForUser = "N";
                  let ReadyPickupForAdmin = "N";
                  let ProductVariantCombinationIDs = [];
                  let insertProcessOrderQuery = [];
                  let ProductVariantCombinationID = [];
                  let saveProductVariantCombinationID = [];
                  let saveProductID = [];
                  let tempArray = [];
                  //${DesireDeliveryDate ? `${DesireDeliveryDate},`:'' }
                  for (let i = 0; i < ShippingByBanglaBazarOrder.length; i++) {
                    let array = [];
                    let VendorStoreID =
                      ShippingByBanglaBazarOrder[i].VendorStoreID;
                    console.log(VendorStoreID, "VendorStoreID");
                    console.log(
                      uniqueAdminVendorStoreIds[index],
                      " uniqueAdminVendorStoreIds[index]",
                      index
                    );
                    if (VendorStoreID === uniqueAdminVendorStoreIds[index]) {
                      //!compare unique store id i index(outer loop at start) with ShippingByBanglaBazarOrder i index(this loop) store id
                      saveProductID.push(
                        ShippingByBanglaBazarOrder[i].ProductID
                      );
                      let ProductID = ShippingByBanglaBazarOrder[i].ProductID;
                      let Quantity = ShippingByBanglaBazarOrder[i].Quantity;
                      let ItemsPrice = ShippingByBanglaBazarOrder[i].itemsPrice;
                      let ItemsShippingHandling =
                        ShippingByBanglaBazarOrder[i].itemsShippingHandling;
                      let ItemsBeforeTax =
                        ShippingByBanglaBazarOrder[i].itemsBeforeTax;
                      let ItemsEstimatedTax =
                        ShippingByBanglaBazarOrder[i].itemsEstimatedTax;
                      let ItemsTotal = ShippingByBanglaBazarOrder[i].itemsTotal;
                      let variantsLength =
                        ShippingByBanglaBazarOrder[i]
                          .ProductVariantCombinationDetail.length;
                      let variants =
                        ShippingByBanglaBazarOrder[i]
                          .ProductVariantCombinationDetail;
                      for (j = 0; j < variantsLength; j++) {
                        array.push(variants[j].ProductVariantCombinationID);
                        tempArray.push(variants[j].ProductVariantCombinationID);
                      }

                      ProductVariantCombinationID = `${array.join(",")}`;
                      insertProcessOrderQuery.push(`('${ProcessPaymentID}', '${OrderNumber}','${ProductID}',
                    '${VendorStoreID}','${ProductVariantCombinationID}','${UserID}',
                    '${Quantity}',
                    '${ItemsPrice}','${ItemsShippingHandling}','${ItemsBeforeTax}', '${ItemsEstimatedTax}','${ItemsTotal}',
                    '${OrderDate}','${ShippingDate}','${AllowStorePickup}','${ReadyPickupForUser}', 
                    '${ReadyPickupForAdmin}','${ProcessStatus}',
                    '${VendorPaymentStatus}','${DeliveryUserNote}','${AllowAdminPickup}','${DeliveryStatus}','${PaymentType}')`);

                      ProductVariantCombinationIDs = `(${array.join(",")})`;
                      console.log(
                        ProductVariantCombinationIDs,
                        "ProductVariantCombinationIDs"
                      );
                    }
                  }
                  let _insertProcessOrderQuery = `insert into processorder (
                  ProcessPaymentID,
                  OrderNumber,
                   ProductID,
                   VendorStoreID,
                   ProductVariantCombinationDetail,
                   UserID,
                   Quantity,
                   ItemsPrice,
                   ItemsShippingHandling,
                   ItemsBeforeTax,
                   ItemsEstimatedTax,
                   ItemsTotal,
                   OrderDate,
                   ShippingDate,
                   AllowStorePickup,
                   ReadyPickupForUser,
                   ReadyPickupForAdmin,
                   ProcessStatus,
                   VendorPaymentStatus,
                   Note,
                   AllowAdminPickup,
                   DeliveryStatus,
                   PaymentType) values ${insertProcessOrderQuery.join(",")}`;
                  console.log(
                    _insertProcessOrderQuery,
                    "insertProcessOrderQuery"
                  );
                  let insertProcessOrder = await connection.query(
                    _insertProcessOrderQuery, {
                    transaction,
                  }
                  );
                  let ProductID = `(${saveProductID.join(",")})`;
                  saveProductVariantCombinationID = `(${tempArray.join(",")})`;
                  console.log(saveProductVariantCombinationID);
                  if (insertProcessOrder) {
                    let checkIfProductExists = await connection.query(
                      ` select * from shoppingcart where ProductID IN ${ProductID} AND ProductVariantCombinationDetail IN ${saveProductVariantCombinationID} AND UserID = "${UserID}"
                                `, {
                      type: QueryTypes.SELECT,
                      transaction,
                    }
                    );
                    if (
                      checkIfProductExists &&
                      checkIfProductExists.length > 0
                    ) {
                      //!below this
                      let deleteShoppingCartList = await connection.query(
                        ` DELETE FROM shoppingcart WHERE ProductID IN ${ProductID} AND ProductVariantCombinationDetail IN ${saveProductVariantCombinationID} AND UserID = "${UserID}"`, {
                        transaction,
                      }
                      );
                      if (deleteShoppingCartList) {
                        OrderNumbers.push(OrderNumber);
                        let TypeID = "6";
                        let CreaterID = "1";
                        let Body = {
                          OrderNumber: OrderNumber,
                          body: `Your OrderNumber ${OrderNumber} is placed`,
                        };
                        let Message = `You OrderNumber ${Body.OrderNumber} is placed `;
                        let email = [];
                        if (index === 0) {
                          let getDeviceIDQuery = ` SELECT DeviceID,EmailAddress
                     FROM profile 
                     WHERE UserID=${UserID}`;
                          let getDeviceID = await connection.query(
                            getDeviceIDQuery, {
                            type: QueryTypes.SELECT,
                            transaction,
                          }
                          );
                          email.push(getDeviceID[0].EmailAddress);
                        }
                        const EmailAddress = email[0];
                        //! Email Method
                        let ReceiverID = UserID;
                        let sendNotification = await Notification(
                          TypeID,
                          Body,
                          CreaterID,
                          ReceiverID,
                          transaction
                        );
                        console.log(sendNotification, "sendNotification");
                        if (sendNotification) {
                          sendEmail(EmailAddress, Message, TypeID);
                          if (index === uniqueAdminVendorStoreIds.length - 1) {
                            break;
                          } else {
                            continue;
                          }
                        } else {
                          if (transaction) await transaction.rollback();
                          res.status(200).json({
                            status: false,
                            message: "Error while sending notification to user ",
                            OrderNumber: [],
                          });
                        }
                      } else {
                        if (transaction) await transaction.rollback();
                        res.status(200).json({
                          status: false,
                          message: " Error while deleting from cart ",
                          OrderNumber: [],
                        });
                      }
                      //!above this
                    } else {
                      if (transaction) await transaction.rollback();
                      res.status(200).json({
                        status: false,
                        message: "Product does not exist in Shopping Cart ",
                        OrderNumber: [],
                      });
                    }
                  } else {
                    if (transaction) await transaction.rollback();
                    res.status(200).json({
                      status: false,
                      message: `Errror while adding to Process Order table `,
                      OrderNumber: [],
                    });
                  }
                } else {
                  if (transaction) await transaction.rollback();
                  res.status(200).json({
                    status: false,
                    message: "Error while adding delivery Address ",
                    OrderNumber: [],
                  });
                }
              } else {
                if (transaction) await transaction.rollback();
                res.status(200).json({
                  status: false,
                  message: "Error while adding  Process Payment  ",
                  OrderNumber: [],
                });
              }
            }
          }
          if (i === 1) {
            //Vendor Own Shipping Case
            for (let index = 0; index < uniqueVendorStoreIds.length; index++) {
              let getLastOrderNumber = await connection.query(
                `SELECT * from processpayment
                   ORDER BY OrderNumber DESC
       `, {
                type: QueryTypes.SELECT,
                transaction,
              }
              );
              if (getLastOrderNumber && getLastOrderNumber.length > 0) {
                let saveOrderNumber = getLastOrderNumber[0].OrderNumber;
                OrderNumber = invNum.InvoiceNumber.next(saveOrderNumber);
              } else {
                OrderNumber = invNum.InvoiceNumber.next("000");
              }
              let UserPaymentID = null;
              let insertPaymentGatewayQuery = `insert into processpayment (
            OrderNumber ,
            SessionID,
            UserID,
            GetawayConfirmation,
            UserPaymentID,
            Name,
            Address1,
            Address2,
            CardNumber,
            ExpirationDate,
            City,
            State,
            ZipCode,
            CountryID,
            OrderDate,
            ItemsPrice,
            ShippingHandling,
            TotalBeforeTax,
            EstimatedTax,
            OrderTotal,
            Currency,
            TransactionID) values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`;
              let insertPaymentGateway = await connection.query(
                insertPaymentGatewayQuery, {
                replacements: [
                  OrderNumber,
                  SessionID,
                  UserID,
                  GetawayConfirmation,
                  UserPaymentID,
                  DeliveryName,
                  DeliveryAddress1,
                  DeliveryAddress2,
                  "NULL",
                  "NULL",
                  DeliveryCity,
                  DeliveryState,
                  DeliveryZipCode,
                  cus_country,
                  OrderDate,
                  ItemsPrice,
                  ShippingHandling,
                  TotalBeforeTax,
                  EstimatedTax,
                  OrderTotal,
                  currency,
                  TransactionID,
                ],
                transaction,
              }
              );
              if (insertPaymentGateway) {
                let insertDeliveryAddressQuery = `insert into orderdeliveryaddress (
            OrderNumber, 
            Name,
            PhoneNumber,
            Address1,
            Address2,
            City,
            State,
            ZipCode,
            CountryID,
            DesireDate,
            UserNote,
            CityID,
            ZoneID,
            AreaID) values (?,?,?,?,?,?,?,?,?,?,?,?,?,?)`;
                let insertDeliveryAddress = await connection.query(
                  insertDeliveryAddressQuery, {
                  replacements: [
                    OrderNumber,
                    DeliveryName,
                    DeliveryPhoneNumber,
                    DeliveryAddress1,
                    DeliveryAddress2,
                    DeliveryCity,
                    DeliveryState,
                    DeliveryZipCode,
                    cus_country,
                    DesireDeliveryDate,
                    DeliveryUserNote,
                    DeliveryCityID,
                    DeliveryZoneID,
                    DeliveryAreaID,
                  ],
                  transaction,
                }
                );
                if (insertDeliveryAddress) {
                  //!below this
                  const ProcessPaymentID = insertPaymentGateway[0];
                  let UserID = req.UserID;
                  let OrderDate = new Date()
                    .toISOString()
                    .slice(0, 19)
                    .replace("T", " ");
                  let ReadyPickupForUser = "N";
                  let ReadyPickupForAdmin = "N";
                  let ProductVariantCombinationIDs = [];
                  let insertProcessOrderQuery_ = [];
                  let ProductVariantCombinationID = [];
                  let saveProductVariantCombinationID = [];
                  let saveProductID = [];
                  let tempArray = [];
                  for (let i = 0; i < ShippingByVendorOrder.length; i++) {
                    let array = [];
                    let VendorStoreID = ShippingByVendorOrder[i].VendorStoreID;
                    console.log(VendorStoreID, "VendorStoreID");
                    console.log(
                      uniqueVendorStoreIds[index],
                      " uniqueAdminVendorStoreIds[index]",
                      index
                    );
                    if (VendorStoreID === uniqueVendorStoreIds[index]) {
                      //!compare unique store id i index(outer loop at start) with ShippingByVendorOrder i index(this loop) store id
                      saveProductID.push(ShippingByVendorOrder[i].ProductID);
                      let ProductID = ShippingByVendorOrder[i].ProductID;
                      let Quantity = ShippingByVendorOrder[i].Quantity;
                      let ItemsPrice = ShippingByVendorOrder[i].itemsPrice;
                      console.log(ItemsPrice, "ItemsPrice");
                      let ItemsShippingHandling =
                        ShippingByVendorOrder[i].itemsShippingHandling;
                      console.log(
                        ItemsShippingHandling,
                        "ItemsShippingHandling"
                      );
                      let ItemsBeforeTax =
                        ShippingByVendorOrder[i].itemsBeforeTax;
                      let ItemsEstimatedTax =
                        ShippingByVendorOrder[i].itemsEstimatedTax;
                      let ItemsTotal = ShippingByVendorOrder[i].itemsTotal;
                      console.log(ItemsEstimatedTax, "ItemsEstimatedTax");
                      console.log(ItemsTotal, "ItemsTotal");
                      let variantsLength =
                        ShippingByVendorOrder[i].ProductVariantCombinationDetail
                          .length;
                      let variants =
                        ShippingByVendorOrder[i]
                          .ProductVariantCombinationDetail;
                      for (j = 0; j < variantsLength; j++) {
                        array.push(variants[j].ProductVariantCombinationID);
                        tempArray.push(variants[j].ProductVariantCombinationID);
                      }
                      ProductVariantCombinationID = `${array.join(",")}`;
                      insertProcessOrderQuery_.push(`('${ProcessPaymentID}', '${OrderNumber}','${ProductID}',
                     '${VendorStoreID}','${ProductVariantCombinationID}','${UserID}',
                     '${Quantity}',
                     '${ItemsPrice}','${ItemsShippingHandling}','${ItemsBeforeTax}', '${ItemsEstimatedTax}','${ItemsTotal}',
                     '${OrderDate}','${ShippingDate}','${AllowStorePickup}','${ReadyPickupForUser}', 
                     '${ReadyPickupForAdmin}','${ProcessStatus}',
                     '${VendorPaymentStatus}','${DeliveryUserNote}','${AllowAdminPickup}','VS','${PaymentType}')`);

                      ProductVariantCombinationIDs = `(${array.join(",")})`;
                      console.log(
                        ProductVariantCombinationIDs,
                        "ProductVariantCombinationIDs"
                      );
                    }
                  }
                  let _insertProcessOrderQuery = `insert into processorder (
                ProcessPaymentID,
                 OrderNumber,
                  ProductID,
                  VendorStoreID,
                  ProductVariantCombinationDetail,
                  UserID,
                  Quantity,
                  ItemsPrice,
                  ItemsShippingHandling,
                  ItemsBeforeTax,
                  ItemsEstimatedTax,
                  ItemsTotal,
                  OrderDate,
                  ShippingDate,
                  AllowStorePickup,
                  ReadyPickupForUser,
                  ReadyPickupForAdmin,
                  ProcessStatus,
                  VendorPaymentStatus,
                  Note,
                  AllowAdminPickup,
                  DeliveryStatus,
                  PaymentType) values ${insertProcessOrderQuery_.join(",")}`;
                  console.log(
                    _insertProcessOrderQuery,
                    "insertProcessOrderQuery"
                  );
                  let insertProcessOrder = await connection.query(
                    _insertProcessOrderQuery, {
                    transaction,
                  }
                  );
                  let ProductID = `(${saveProductID.join(",")})`;
                  saveProductVariantCombinationID = `(${tempArray.join(",")})`;
                  if (insertProcessOrder) {
                    let checkIfProductExists = await connection.query(
                      ` select * from shoppingcart where ProductID IN ${ProductID} AND ProductVariantCombinationDetail IN ${saveProductVariantCombinationID} AND UserID = "${UserID}"
                                `, {
                      type: QueryTypes.SELECT,
                      transaction,
                    }
                    );
                    if (
                      checkIfProductExists &&
                      checkIfProductExists.length > 0
                    ) {
                      //!below this

                      let deleteShoppingCartList = await connection.query(
                        ` DELETE FROM shoppingcart WHERE ProductID IN ${ProductID} AND ProductVariantCombinationDetail IN ${saveProductVariantCombinationID} AND UserID = "${UserID}"`, {
                        transaction,
                      }
                      );
                      if (deleteShoppingCartList) {
                        OrderNumbers.push(OrderNumber);
                        let TypeID = "6";
                        let CreaterID = "1";
                        let Body = {
                          OrderNumber: OrderNumber,
                          body: `Your OrderNumber ${OrderNumber} is placed`,
                        };
                        let Message = `You OrderNumber ${Body.OrderNumber} is placed `;
                        let email = [];
                        if (index === 0) {
                          let getDeviceIDQuery = ` SELECT DeviceID,EmailAddress
                     FROM profile 
                     WHERE UserID=${UserID}`;
                          let getDeviceID = await connection.query(
                            getDeviceIDQuery, {
                            type: QueryTypes.SELECT,
                            transaction,
                          }
                          );
                          email.push(getDeviceID[0].EmailAddress);
                        }
                        const EmailAddress = email[0];
                        //! Email Method
                        let ReceiverID = UserID;
                        let sendNotification = await Notification(
                          TypeID,
                          Body,
                          CreaterID,
                          ReceiverID,
                          transaction
                        );
                        console.log(sendNotification, "sendNotification");
                        if (sendNotification) {
                          sendEmail(EmailAddress, Message, TypeID);
                          if (index === uniqueVendorStoreIds.length - 1) {
                            if (transaction) await transaction.commit(); //!final commit
                            res.status(200).json({
                              status: true,
                              message: "Successfully Order Created and Product removed from shopping cart",
                              OrderNumber: OrderNumbers.toString(),
                            });
                          } else {
                            continue;
                          }
                        } else {
                          if (transaction) await transaction.rollback();
                          res.status(200).json({
                            status: false,
                            message: "Error while sending notification to user ",
                            OrderNumber: [],
                          });
                        }
                      } else {
                        if (transaction) await transaction.rollback();
                        res.status(200).json({
                          status: false,
                          message: " Error while deleting from cart ",
                          OrderNumber: [],
                        });
                      }
                      //!above this
                    } else {
                      if (transaction) await transaction.rollback();
                      res.status(200).json({
                        status: false,
                        message: "Product does not exist in Shopping Cart ",
                        OrderNumber: [],
                      });
                    }
                  } else {
                    if (transaction) await transaction.rollback();
                    res.status(200).json({
                      status: false,
                      message: `Errror while adding to Process Order table `,
                      OrderNumber: [],
                    });
                  }
                } else {
                  if (transaction) await transaction.rollback();
                  res.status(200).json({
                    status: false,
                    message: "Error while adding delivery Address ",
                    OrderNumber: [],
                  });
                }
              } else {
                if (transaction) await transaction.rollback();
                res.status(200).json({
                  status: false,
                  message: "Error while adding  Process Payment  ",
                  OrderNumber: [],
                });
              }
            }
          }
        }
      } else {
        if (transaction) await transaction.rollback();
        res.status(200).json({
          status: false,
          message: "Error while internal Api response ",
          OrderNumber: [],
        });
      }
    }
  } catch (err) {
    console.log(err.message);
    if (transaction) await transaction.rollback();
    next(err);
    res.status(200).json({
      status: false,
      OrderNumber: [],
      message: err.message,
    });
  }
};
exports.addProcessPaymentDetails = async (req, res, next) => {
  try {
    UserID = req.UserID;
    const {
      OrderNumber,
      SessionID,
      GatewayID,
      GetawayConfirmation,
      UserPaymentID,
      Name,
      CardNumber,
      ExpirationDate,
      Address1,
      Address2,
      City,
      State,
      ZipCode,
      CountryID,
      PaymentAccount,
      PaymentRouting,
      OrderDate,
      ItemsPrice,
      ShippingHandling,
      TotalBeforeTax,
      EstimatedTax,
      OrderTotal,
      Currency,
    } = req.body;
    let insertPaymentGatewayQuery = `insert into processpayment (
        OrderNumber ,
        SessionID,
        UserID,
        GatewayID,
        GetawayConfirmation,
        UserPaymentID,
        Name,
        CardNumber,
        ExpirationDate,
        Address1,
        Address2,
        City,
        State,
        ZipCode,
        CountryID,
        PaymentAccount,
        PaymentRouting,
        OrderDate,
        ItemsPrice,
        ShippingHandling,
        TotalBeforeTax,
        EstimatedTax,
        OrderTotal,
        Currency) values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`;
    let insertPaymentGateway = await connection.query(
      insertPaymentGatewayQuery, {
      replacements: [
        OrderNumber,
        SessionID,
        UserID,
        GatewayID,
        GetawayConfirmation,
        UserPaymentID,
        Name,
        CardNumber,
        ExpirationDate,
        Address1,
        Address2,
        City,
        State,
        ZipCode,
        CountryID,
        PaymentAccount,
        PaymentRouting,
        OrderDate,
        ItemsPrice,
        ShippingHandling,
        TotalBeforeTax,
        EstimatedTax,
        OrderTotal,
        Currency,
      ],
    }
    );
    if (insertPaymentGateway) {
      res.status(200).json({
        status: true,
        message: "Process Payment details added successfully",
      });
    } else {
      res.status(200).json({
        status: false,
        message: "Error while adding Process Payment Details",
      });
    }
  } catch (err) {
    next(err);
    res.status(200).json({
      status: false,
      message: err.message,
    });
  }
};
exports.updatePaymentStatus = async (req, res, next) => {
  try {
    let OrderNumber = req.params.id;
    let PaymentStatus = req.params.status;
    let updatePayentStatus = await connection.query(
      `UPDATE processpayment SET PaymentStatus="${PaymentStatus}" WHERE OrderNumber="${OrderNumber}" `
    );
    if (updatePayentStatus) {
      res.status(200).json({
        status: true,
        message: "Payment Status Updated Successfully",
      });
    } else {
      res.status(200).json({
        status: false,
        message: "Error while updating Payment Status",
      });
    }
  } catch (err) {
    next(err);
    res.status(200).json({
      status: false,
      message: err.message,
    });
  }
};
exports.getUserPaymentDeliveryHistory = async (req, res, next) => {
  try {
    // let UserID = req.UserID;
    let UserID = 100;
    let getUserPaymentHistory;
    try {
      getUserPaymentHistory = await connection.query(
        `SELECT o.PaymentType,c.Country,u.*
       FROM userpayment u
       INNER JOIN processpayment p ON p.UserPaymentID=u.UserPaymentID
       INNER JOIN processorder o ON o.OrderNumber=p.OrderNumber
       LEFT JOIN country c ON c.CountryID=p.CountryID
       WHERE u.UserID="${UserID}"
       GROUP BY u.UserPaymentID  `, {
        type: QueryTypes.SELECT,
      }
      );
      console.log(
        getUserPaymentHistory,
        "getUserPaymentHistory-----------------------------"
      );
    } catch (err) {
      next(err);
      res.status(200).json({
        status: false,
        message: err.message,
      });
      console.log(err.message);
    }

    let getUserAddressHistory;
    try {
      getUserAddressHistory = await connection.query(
        `SELECT u.*,o.ProcessPaymentID,c.PathaoCityID,c.PathaoCityName
      from processorder o 
      LEFT JOIN processpayment p ON p.OrderNumber=o.OrderNumber
      LEFT JOIN orderdeliveryaddress d ON d.OrderNumber=p.OrderNumber
      LEFT JOIN useraddress u ON u.PhoneNumber=d.PhoneNumber
      LEFT JOIN pathaocities c ON c.DBCityID=u.CityID 
      WHERE u.UserID="${UserID}" 
      GROUP BY u.PhoneNumber `, {
        type: QueryTypes.SELECT,
      }
      ); //here check on c.DBCITYID in case of USA
      console.log(
        getUserAddressHistory,
        "getUserAddressHistory--------------------------------------"
      );
    } catch (err) {
      next(err);
      res.status(200).json({
        status: false,
        message: err.message,
      });
      console.log(err.message);
    }
    res.status(200).json({
      status: true,
      userPaymentHistory: getUserPaymentHistory,
      userAddressHistory: getUserAddressHistory,
    });
  } catch (err) {
    next(err);
    res.status(200).json({
      status: false,
      message: err.message,
    });
    console.log(err.message);
  }
};


exports.removeAdress = async (req, res) => {
  try {

    const userAddressID = req.params.UserAddressID;
    let deleteUserAddress = await connection.query(
      `DELETE FROM useraddress WHERE UserAddressID="${userAddressID}"`, {}
    );

    res.send('Record deleted successfully.');
  } catch (err) {
    res.status(200).json({
      status: false,
      message: err.message,
    });
  }
}
//! UserPayment crud
let addUserPaymentAndAddress = async (
  UserID,
  Name,
  CardNumber,
  ExpirationDate,
  Address1,
  Address2,
  City,
  State,
  ZipCode,
  CountryID,
  PaymentAccount,
  PaymentRouting,
  GatewayID,
  DefaultPayment,
  DefaultAddress,
  DeliveryName,
  DeliveryPhoneNumber,
  DeliveryAddress1,
  DeliveryAddress2,
  DeliveryState,
  DeliveryCity,
  DeliveryZoneID,
  cus_country,
  DeliveryAreaID,
  DeliveryZipCode,
  DeliveryUserNote,
  AddressLabel,
  DeliveryCityID,
  DeliveryZone,
  DeliveryArea,
  saveAddress,
  homeAddress,
  transaction
) => {
  try {
    console.log(saveAddress, "saveAddress");
    console.log(homeAddress, "homeAddress");
    let paymentQuery = false;
    let deliveryQuery = false;
    let insertUserAddressPayment;
    let insertUserPayment;
    let UserPaymentID;
    let UserAddressID;
    let LastUpdate = new Date().toISOString().slice(0, 19).replace("T", " ");
    if (saveAddress) {

      console.log("_____________+++++++++++++++++++++++++++++++++++++++", UserID,
        Name,
        CardNumber,
        ExpirationDate,
        Address1,
        Address2,
        City,
        State,
        ZipCode,
        CountryID,
        PaymentAccount,
        PaymentRouting,
        GatewayID,
        LastUpdate,
        DefaultPayment)
      let insertUserPaymentQuery = `insert into userpayment (
        UserID, 
        Name,
        CardNumber,
        ExpirationDate,
        Address1,
        Address2,
        City,
        State,
        ZipCode,
        CountryID,
        PaymentAccount,
        PaymentRouting,
        GatewayID,
        LastUpdate,
        DefaultPayment) values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`;
      insertUserPaymentQuery += ` ON DUPLICATE KEY UPDATE LastUpdate=VALUES(LastUpdate)`;
      insertUserPayment = await connection.query(insertUserPaymentQuery, {
        replacements: [
          UserID,
          Name,
          CardNumber,
          ExpirationDate ? ExpirationDate : null,
          Address1 ? Address1 : null,
          Address2 ? Address2 : null,
          City,
          State,
          ZipCode,
          CountryID ? CountryID : null,
          PaymentAccount ? PaymentAccount : null,
          PaymentRouting ? PaymentRouting : null,
          GatewayID ? GatewayID : null,
          LastUpdate ? LastUpdate : null,
          DefaultPayment ? DefaultPayment : null,
        ],
        transaction,
      });
      if (insertUserPayment) {
        console.log("here =------------------------------------");
        paymentQuery = true;
        UserPaymentID = insertUserPayment[0];
        console.log(UserPaymentID, "UserPaymentID");
      } else {
        console.log("Error while adding User Address Details inside");
        paymentQuery = false;
      }
    }
    if (!saveAddress) {
      paymentQuery = true;
      UserPaymentID = null;
    }
    //delivery scanerio below
    if (paymentQuery) {
      if (!homeAddress) {
        (deliveryQuery = true), (UserAddressID = null);
      }
      if (homeAddress) {
        console.log("++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++", UserID,
          DeliveryName,
          DeliveryPhoneNumber,
          DeliveryAddress1,
          DeliveryAddress2,
          DeliveryCity,
          DeliveryState,
          DeliveryZipCode,
          cus_country,
          LastUpdate,
          DefaultAddress,
          DeliveryUserNote,
          AddressLabel,
          DeliveryCityID,
          DeliveryZoneID,
          DeliveryAreaID,
          DeliveryZone,
          DeliveryArea)
        let insertUserAddressQuery = `insert into useraddress (
        UserID, 
        Name,
        PhoneNumber,
        Address1,
        Address2,
        City,
        State,
        ZipCode,
        CountryID,
        LastUpdate,
        DefaultAddress,
        UserNote,
        AddressLabel,
        CityID,
        ZoneID,
        AreaID,
        DeliveryZone,
        DeliveryArea) values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`;
        insertUserAddressQuery += ` ON DUPLICATE KEY UPDATE LastUpdate=VALUES(LastUpdate)`;
        insertUserAddressPayment = await connection.query(
          insertUserAddressQuery, {
          replacements: [
            UserID,
            DeliveryName,
            DeliveryPhoneNumber,
            DeliveryAddress1,
            DeliveryAddress2 !== undefined ? DeliveryAddress2 : null,
            DeliveryCity !== undefined ? DeliveryCity : null,
            DeliveryState !== undefined ? DeliveryState : null,
            DeliveryZipCode !== undefined ? DeliveryZipCode : null,
            cus_country !== undefined ? cus_country : null,
            LastUpdate,
            DefaultAddress !== undefined ? DefaultAddress : null,
            DeliveryUserNote !== undefined ? DeliveryUserNote : null,
            AddressLabel !== undefined ? AddressLabel : null,
            DeliveryCityID !== undefined ? DeliveryCityID : null,
            DeliveryZoneID !== undefined ? DeliveryZoneID : null,
            DeliveryAreaID !== undefined ? DeliveryAreaID : null,
            DeliveryZone !== undefined ? DeliveryZone : null,
            DeliveryArea !== undefined ? DeliveryArea : null,
          ],
          transaction,
        }
        );
        if (insertUserAddressPayment) {
          (UserAddressID = insertUserAddressPayment[0]), (deliveryQuery = true);
        } else {
          console.log("Error while adding User Address Details inside");
          deliveryQuery = false;
        }
      }
      if (deliveryQuery) {
        console.log(UserPaymentID, "UserPaymentID");
        console.log(UserAddressID, "UserAddressID");
        return {
          UserPaymentID: UserPaymentID,
          UserAddressID: UserAddressID,
        };
      } else {
        console.log("Error while adding User Address Details");
        if (transaction) await transaction.rollback();
        return null;
      }
    } else {
      console.log("Error while adding User Payment Details");
      if (transaction) await transaction.rollback();
      return null;
    }
  } catch (err) {
    console.log(err.message, "-----------------");
    if (transaction) await transaction.rollback();
    return null;
  }
};
//! ProcessOrder crud
exports.addProcessOrder = async (req, res, next) => {
  let transaction;
  try {
    let UserID = req.UserID;
    let OrderDate = new Date().toISOString().slice(0, 19).replace("T", " ");
    let CurrentDate = new Date().toISOString().slice(0, 19).replace("T", " ");
    let ReadyPickupForUser = "N";
    let ReadyPickupForAdmin = "N";
    let ReceiverID = UserID;
    let updateInventory = null;
    let ProductVariantCombinationIDs = [];
    const {
      PaymentStatus,
      ProcessPaymentID,
      OrderNumber,
      ProductDetail,
      ProcessStatus,
      VendorPaymentStatus,
      Note,
      AllowStorePickup,
      AllowAdminPickup,
      DeliveryStatus,
      PaymentType,
      DesireDeliveryDate,
    } = req.body;
    transaction = await connection.transaction();
    let insertProcessOrderQuery = `insert into processorder (
      ProcessPaymentID,
      OrderNumber,
       ProductID,
       VendorStoreID,
       ProductVariantCombinationDetail,
       UserID,
       Quantity,
       ItemsPrice,
       ItemsShippingHandling,
       ItemsBeforeTax,
       ItemsEstimatedTax,
       ItemsTotal,
       OrderDate,
       ShippingDate,
       AllowStorePickup,
       ReadyPickupForUser,
       ReadyPickupForAdmin,
       ProcessStatus,
       VendorPaymentStatus,
       Note,
       AllowAdminPickup,
       DeliveryStatus,
       PaymentType) values `;
    let ProductVariantCombinationID = [];
    let saveProductVariantCombinationID = [];
    let saveProductID = [];
    let tempArray = [];
    //${DesireDeliveryDate ? `${DesireDeliveryDate},`:'' }
    for (let i = 0; i < ProductDetail.length; i++) {
      let array = [];

      saveProductID.push(ProductDetail[i].ProductID);
      let ProductID = ProductDetail[i].ProductID;
      let Quantity = ProductDetail[i].Quantity;
      let VendorStoreID = ProductDetail[i].VendorStoreID;
      let ItemsPrice = ProductDetail[i].ItemsPrice;
      let ItemsShippingHandling = ProductDetail[i].ItemsShippingHandling;
      let ItemsBeforeTax = ProductDetail[i].ItemsBeforeTax;
      let ItemsEstimatedTax = ProductDetail[i].ItemsEstimatedTax;
      let ItemsTotal = ProductDetail[i].ItemsTotal;
      let variantsLength =
        ProductDetail[i].ProductVariantCombinationDetail.length;
      let variants = ProductDetail[i].ProductVariantCombinationDetail;
      for (j = 0; j < variantsLength; j++) {
        array.push(variants[j].ProductVariantCombinationID);
        tempArray.push(variants[j].ProductVariantCombinationID);
      }

      ProductVariantCombinationID = `${array.join(",")}`;
      if (i == ProductDetail.length - 1) {
        insertProcessOrderQuery += `('${ProcessPaymentID}', '${OrderNumber}','${ProductID}',
        '${VendorStoreID}','${ProductVariantCombinationID}','${UserID}',
        '${Quantity}',
        '${ItemsPrice}','${ItemsShippingHandling}','${ItemsBeforeTax}', '${ItemsEstimatedTax}','${ItemsTotal}',
        '${OrderDate}','${AllowStorePickup}','${ReadyPickupForUser}', 
        '${ReadyPickupForAdmin}','${ProcessStatus}',
        '${VendorPaymentStatus}','${Note}','${AllowAdminPickup}','${DeliveryStatus}','${PaymentType}')`;
      } else {
        insertProcessOrderQuery += `('${ProcessPaymentID}', '${OrderNumber}','${ProductID}',
        '${VendorStoreID}','${ProductVariantCombinationID}','${UserID}',
        '${Quantity}',
        '${ItemsPrice}','${ItemsShippingHandling}','${ItemsBeforeTax}', '${ItemsEstimatedTax}','${ItemsTotal}',
        '${OrderDate}','${AllowStorePickup}','${ReadyPickupForUser}', 
        '${ReadyPickupForAdmin}','${ProcessStatus}',
        '${VendorPaymentStatus}','${Note}','${AllowAdminPickup}','${DeliveryStatus}','${PaymentType}'),`;
      }

      //update inventory count (no need to check for negative count condition as it wont reach here to place order on sold out items )
      ProductVariantCombinationIDs = `(${array.join(",")})`;
      console.log(ProductVariantCombinationIDs, "ProductVariantCombinationIDs");
      let quantityCount = -Math.abs(Quantity);
      updateInventory = await connection.query(
        `UPDATE productinventory SET Inventory=Inventory+${quantityCount} WHERE ProductVariantCombinationID IN ${ProductVariantCombinationIDs} `, {
        transaction,
      }
      );
    }
    if (updateInventory) {
      let insertProcessOrder = await connection.query(insertProcessOrderQuery, {
        transaction,
      });
      let ProductID = `(${saveProductID.join(",")})`;
      saveProductVariantCombinationID = `(${tempArray.join(",")})`;
      console.log(saveProductVariantCombinationID);
      if (insertProcessOrder) {
        let updatePayentStatus = await connection.query(
          `UPDATE processpayment SET PaymentStatus="${PaymentStatus}" WHERE OrderNumber="${OrderNumber}" `, {
          transaction,
        }
        );
        if (updatePayentStatus) {
          let TypeID = "6";
          let CreaterID = "1";
          let Body = {
            OrderNumber: OrderNumber,
            body: "Your order is placed",
          };
          let Message = `You Order # ${Body.OrderNumber} is placed `;
          let getDeviceIDQuery = ` SELECT DeviceID,EmailAddress
        FROM profile 
        WHERE UserID=${UserID}`;
          let getDeviceID = await connection.query(getDeviceIDQuery, {
            type: QueryTypes.SELECT,
            transaction,
          });
          let DeviceID = getDeviceID[0].DeviceID;
          let EmailAddress = getDeviceID[0].EmailAddress;
          console.log(DeviceID);
          if (DeviceID == null || DeviceID == "NULL" || DeviceID == "null") {
            console.log("NULL CONDITION -----------------");
            let checkIfProductExists = await connection.query(
              ` select * from shoppingcart where ProductID IN ${ProductID} AND ProductVariantCombinationDetail IN ${saveProductVariantCombinationID} AND UserID = "${UserID}"
                        `, {
              type: QueryTypes.SELECT,
              transaction,
            }
            );
            if (checkIfProductExists && checkIfProductExists.length > 0) {
              let deleteShoppingCartList = await connection.query(
                ` DELETE FROM shoppingcart WHERE ProductID IN ${ProductID} AND ProductVariantCombinationDetail IN ${saveProductVariantCombinationID} AND UserID = "${UserID}"`, {
                transaction,
              }
              );
              if (deleteShoppingCartList) {
                sendEmail(EmailAddress, Message, TypeID);
                console.log(
                  " 1st EMAIL METHOD ------------------------------------"
                ); //! Email Method
                if (transaction) await transaction.commit(); //!final commit
                res.status(200).json({
                  status: true,
                  message: "Process Order details added & Product removed & Payment Status Updated",
                });
              } else {
                if (transaction) await transaction.rollback();
                res.status(200).json({
                  status: false,
                  message: `Error while deleting from Shopping Cart `,
                });
              }
            } else {
              if (transaction) await transaction.rollback();
              res.status(200).json({
                status: false,
                message: "Product does not exist in Shopping Cart ",
              });
            }
          } else if (DeviceID && DeviceID.length > 0) {
            console.log("DEVICE ID EXIST CONDITION -----------------");
            console.log(
              " 2nd EMAIL METHOD ------------------------------------"
            ); //! Email Method
            let sendNotification = await Notification(
              TypeID,
              Body,
              CreaterID,
              ReceiverID,
              transaction
            );
            console.log(sendNotification, "sendNotification");
            if (sendNotification) {
              let checkIfProductExists = await connection.query(
                ` select * from shoppingcart where ProductID IN ${ProductID} AND ProductVariantCombinationDetail IN ${saveProductVariantCombinationID} AND UserID = "${UserID}"
                      `, {
                type: QueryTypes.SELECT,
                transaction,
              }
              );
              if (checkIfProductExists && checkIfProductExists.length > 0) {
                let deleteShoppingCartList = await connection.query(
                  ` DELETE FROM shoppingcart WHERE ProductID IN ${ProductID} AND ProductVariantCombinationDetail IN ${saveProductVariantCombinationID} AND UserID = "${UserID}"`, {
                  transaction,
                }
                );
                console.log(
                  saveProductVariantCombinationID,
                  "saveProductVariantCombinationID"
                );

                if (deleteShoppingCartList) {
                  sendEmail(EmailAddress, Message, TypeID);
                  if (transaction) await transaction.commit(); //!final commit
                  res.status(200).json({
                    status: true,
                    message: "Process Order details added & Product removed & Payment Status Updated",
                  });
                } else {
                  if (transaction) await transaction.rollback();
                  res.status(200).json({
                    status: false,
                    message: `Error while deleting from Shopping Cart `,
                  });
                }
              } else {
                if (transaction) await transaction.rollback();
                res.status(200).json({
                  status: false,
                  message: "Product does not exist in Shopping Cart ",
                });
              }
            } else {
              if (transaction) await transaction.rollback();
              res.status(200).json({
                status: false,
                message: "Error while sending Notification to User ",
              });
            }
          }
        } else {
          if (transaction) await transaction.rollback();
          res.status(200).json({
            status: false,
            message: `Error while updating Payment Status `,
          });
        }
      } else {
        if (transaction) await transaction.rollback();
        res.status(200).json({
          status: false,
          message: `Errror while adding to Process Order table `,
        });
      }
    } else {
      if (transaction) await transaction.rollback();
      res.status(200).json({
        status: false,
        message: `Errror while updating Product Inventory count`,
      });
    }
  } catch (err) {
    console.log(err.message);
    if (transaction) await transaction.rollback();
    next(err);
    res.status(200).json({
      status: false,
      message: err.message,
    });
  }
};
exports.emptyCart = async (req, res, next) => {
  try {
    const {
      UserID,
      ProductDetail
    } = req.body;
    let saveProductID = [];
    let array = [];
    let ProductVariantCombinationID = [];
    for (let i = 0; i < ProductDetail.length; i++) {
      saveProductID.push(ProductDetail[i].ProductID);
      let variantsLength =
        ProductDetail[i].ProductVariantCombinationDetail.length;
      let variants = ProductDetail[i].ProductVariantCombinationDetail;
      for (j = 0; j < variantsLength; j++) {
        array.push(variants[j].ProductVariantCombinationID);
      }
    }
    ProductVariantCombinationID = `"${ProductVariantCombinationID.join(",")}"`;
    let ProductID = `"${saveProductID.join(",")}"`;
    console.log(ProductID);
    console.log(ProductVariantCombinationID);
    let checkIfProductExists = await connection.query(
      `
          select * from shoppingcart where ProductID= ${ProductID} AND ProductVariantCombinationDetail =${ProductVariantCombinationID} AND UserID = "${UserID}"
          `, {
      type: QueryTypes.SELECT,
    }
    );
    if (checkIfProductExists && checkIfProductExists.length > 0) {
      let deleteShoppingCartList = await connection.query(
        ` DELETE FROM shoppingcart WHERE ProductID= ${ProductID} AND ProductVariantCombinationDetail =${ProductVariantCombinationID} AND UserID = "${UserID}"`
      );
      res.status(200).json({
        status: true,
        message: `Product removed from Shopping Cart List successfully `,
      });
    } else {
      res.status(200).json({
        status: false,
        message: `Product does not exist in Shopping Cart `,
      });
    }
  } catch (err) {
    next(err);
    res.status(200).json({
      status: false,
      message: err.message,
    });
    console.log(err.message);
  }
};


exports.getOrdersDetails = async (req, res, next) => {
  try {
    let { limit, offset, search, sort } = req.body;

    console.log("updated inside order deatils function____-------------------")
    limit = parseInt(limit);
    offset = parseInt(offset);
    offset = limit * offset;
    const currencyRate = req.currency_rate;
    let UserID = req.UserID;
    let productCombinationPriceDetail = [];
    let getOrderCount = await connection.query(
      `SELECT COUNT(DISTINCT(OrderNumber)) as total_records from processorder
      WHERE UserID='${UserID}'
     `,
      {
        type: QueryTypes.SELECT,
      }
    );

    if (getOrderCount[0].total_records && getOrderCount[0].total_records > 0) {
      console.log(
        "inside ------------------------------------------------------------------------"
      );
      let viewOrderListQuery = `SELECT p.ProductID,p.Title,m.TransactionID,s.OrderNumber,s.OrderDate,s.ProcessStatus,m.PaymentStatus,p. Price AS BasePrice,m.Currency,s.UserID,g.Small,g.Medium,g.Large,i.MainImage,m.OrderTotal,s.ItemsPrice,s.ItemsEstimatedTax,s.ItemsShippingHandling,s.ProductVariantCombinationDetail,s.DeliveryDate,s.DeliveryStatus,m.EstimatedTax,m.ShippingHandling,
          (SELECT COUNT(t.ProductID)
          from productreviewrating t WHERE t.ProductID = p.ProductID) AS REVIEW_COUNT,
          (SELECT AVG(t.Rating) from productreviewrating t WHERE t.ProductID = p.ProductID) AS  AVG_Rating
          FROM (((((( product p
          LEFT JOIN productvariantoption o ON o.ProductID IN( p.ProductID))
          LEFT JOIN productvariantoptionvalue v  ON  v.OptionID IN (o.OptionID))
          LEFT JOIN productimage i  ON  i.OptionValueID IN (v.OptionValueID))
          LEFT JOIN imagegallery g  ON  g.ImageGalleryID IN (i.ImageGalleryID))
          LEFT JOIN processorder s ON s.ProductID IN(p.ProductID))
          LEFT JOIN processpayment m ON m.OrderNumber IN(s.OrderNumber))
          WHERE i.MainImage='Y' AND s.OrderNumber IN (select * from (SELECT OrderNumber from processorder WHERE UserID='${UserID}' AND OrderNumber LIKE "%${search}%"  GROUP BY OrderNumber  ORDER BY ProcessOrderID ${sort} LIMIT ${limit} OFFSET ${offset} ) OrderNumber)
          GROUP BY s.ProcessOrderID
          ORDER BY s.ProcessOrderID ${sort}`;
      let viewOrderList = await connection.query(viewOrderListQuery, {
        type: QueryTypes.SELECT,
      });
      
      console.log(
        viewOrderList,
        "viewOrderList-----------------------------------------------"
      );

      let productCombinationDetail;
      if (viewOrderList && viewOrderList.length > 0) {
        for (let i = 0; i < viewOrderList.length; i++) {
          let ProductVariantCombinationDetail = [];
          ProductVariantCombinationDetail.push(
            viewOrderList[i].ProductVariantCombinationDetail
          );
          ProductVariantCombinationDetail = `(${ProductVariantCombinationDetail.join(
            ","
          )})`;
          productCombinationDetail = await connection.query(
            `SELECT p.ProductID,c.ProductVariantCombinationID,c.VendorStoreID,c.Price AS ProductCombinationPrice,c.AvailableInventory,o.OptionID,o.OptionName,v.OptionValue,v.OptionValueID,p.Currency
              FROM ((((product p
              LEFT JOIN productvariantoption o ON o.ProductID IN( p.ProductID))
              LEFT JOIN productvariantoptionvalue v  ON  v.OptionID IN (o.OptionID))
              LEFT JOIN productvariantcombination c  ON  c.OptionValueID IN (v.OptionValueID))
              LEFT JOIN processorder s ON s.ProductID IN(c.ProductID))
              WHERE s.UserID='${UserID}' AND c.ProductVariantCombinationID IN ${ProductVariantCombinationDetail}
              GROUP BY c.OptionValueID
             `,
            {
              type: QueryTypes.SELECT,
            }
          );
          productCombinationPriceDetail.push(productCombinationDetail);


        }
        // return res.send(productCombinationPriceDetail)
        let orderName = [];
        let orderTotal = [];
        let orderDate = [];
        let paymentStatus = [];
        let transactionID = [];
        let tempPC = productCombinationPriceDetail;
        let tempProd = viewOrderList;
        let tempArray = [];
        let processStatus = [];
        let deliveryStatus = [];
        let tempAOrderDetails = [];
        let deliveryDate = [];
        let estimatedTax = [];
        let shippingHandling = [];
   
        for (let i = 0; i < tempProd.length; i++) {
          let tempTotal = parseFloat(currencyRate * tempProd[i].OrderTotal).toFixed(2);

          console.log("tempTotaltempTotaltempTotaltempTotal", tempTotal);

          var obj = {
            ...tempProd[i],
          };
          let variantsLength = tempPC[i].length;

          obj["ProductCombinations"] = tempPC[i];
          tempArray.push(obj);
        }
        for (let i = 0; i < tempArray.length; i++) {
          if (!orderName.includes(tempArray[i].OrderNumber)) {
            orderName.push(tempArray[i].OrderNumber);
            orderDate.push(tempArray[i].OrderDate);
            paymentStatus.push(tempArray[i].PaymentStatus);
            transactionID.push(tempArray[i].TransactionID);
            processStatus.push(tempArray[i].ProcessStatus);
            orderTotal.push(tempArray[i].OrderTotal);
            deliveryDate.push(tempArray[i].DeliveryDate);
            deliveryStatus.push(tempArray[i].DeliveryStatus);
            estimatedTax.push(tempArray[i].EstimatedTax);
            shippingHandling.push(tempArray[i].ShippingHandling);
          }
        }

        console.log("orderNameorderNameorderNameorderNameorderNameorderNameorderNameorderNameorderNameorderName", orderName);
        for (let i = 0; i < orderName.length; i++) {
          var obj = {
            OrderNumber: orderName[i],
            OrderDate: orderDate[i],
            PaymentStatus: paymentStatus[i],
            TransactionID: transactionID[i],
            ProcessStatus: processStatus[i],
            OrderTotal: orderTotal[i],
            DeliveryDate: deliveryDate[i],
            DeliveryStatus: deliveryStatus[i],
            EstimatedTax: estimatedTax[i],
            ShippingHandling: shippingHandling[i],
            ProductDetail: [],
          };
          for (let j = 0; j < tempArray.length; j++) {
            if (orderName[i] === tempArray[j].OrderNumber) {
              obj.ProductDetail.push(tempArray[j]);
            }
          }
          tempAOrderDetails.push(obj);
        }
        console.log(tempAOrderDetails, "__________+++++++++================");
        if (productCombinationDetail && productCombinationDetail.length > 0) {
          res.status(200).json({
            status: true,
            total_records: getOrderCount[0].total_records,
            orderDetails: tempAOrderDetails,
          });
        } else {
          res.status(200).json({
            status: false,
            total_records: getOrderCount[0].total_records,
            orderDetails: [],
          });
        }
      } else {
        res.status(200).json({
          status: true,
          total_records: getOrderCount[0].total_records,
          orderDetails: [],
        });
      }
    } else {
      res.status(200).json({
        status: true,
        total_records: getOrderCount[0].total_records,
        orderDetails: [],
      });
    }
  } catch (err) {
    console.log(err.message);
    next(err);
    res.status(200).json({
      status: false,
      orderDetails: [],
    });
  }
}

//old 12/28/2023
// exports.getOrdersDetails = async (req, res, next) => {
//   try {
//     let { limit, offset, search, sort } = req.body;

//     console.log("inside order deatils function____-------------------")
//     let Region = req.region;
//     limit = parseInt(limit);
//     offset = parseInt(offset);
//     offset = limit * offset;
//     const currencyRate = req.currency_rate;
//     let UserID = req.UserID;
//     let productCombinationPriceDetail = [];
//     let getOrderCount = await connection.query(
//       `SELECT COUNT(DISTINCT(OrderNumber)) as total_records from processorder
//       WHERE UserID='${UserID}'
//      `,
//       {
//         type: QueryTypes.SELECT,
//       }
//     );

//     if (getOrderCount[0].total_records && getOrderCount[0].total_records > 0) {
//       console.log(
//         "inside ------------------------------------------------------------------------"
//       );
//       let viewOrderListQuery = `SELECT p.ProductID,p.Title,m.TransactionID,s.OrderNumber,s.OrderDate,s.ProcessStatus,m.PaymentStatus,p. Price AS BasePrice,p.Currency,s.UserID,g.Small,g.Medium,g.Large,i.MainImage,m.OrderTotal,s.ItemsPrice,s.ItemsEstimatedTax,s.ItemsShippingHandling,s.ProductVariantCombinationDetail,s.DeliveryDate,s.DeliveryStatus,m.EstimatedTax,m.ShippingHandling,
//           (SELECT COUNT(t.ProductID)
//           from productreviewrating t WHERE t.ProductID = p.ProductID) AS REVIEW_COUNT,
//           (SELECT AVG(t.Rating) from productreviewrating t WHERE t.ProductID = p.ProductID) AS  AVG_Rating
//           FROM (((((( product p
//           LEFT JOIN productvariantoption o ON o.ProductID IN( p.ProductID))
//           LEFT JOIN productvariantoptionvalue v  ON  v.OptionID IN (o.OptionID))
//           LEFT JOIN productimage i  ON  i.OptionValueID IN (v.OptionValueID))
//           LEFT JOIN imagegallery g  ON  g.ImageGalleryID IN (i.ImageGalleryID))
//           LEFT JOIN processorder s ON s.ProductID IN(p.ProductID))
//           LEFT JOIN processpayment m ON m.OrderNumber IN(s.OrderNumber))
//           WHERE i.MainImage='Y' AND s.OrderNumber IN (select * from (SELECT OrderNumber from processorder WHERE UserID='${UserID}' AND OrderNumber LIKE "%${search}%"  GROUP BY OrderNumber  ORDER BY ProcessOrderID ${sort} LIMIT ${limit} OFFSET ${offset} ) OrderNumber)
//           GROUP BY s.ProcessOrderID
//           ORDER BY s.ProcessOrderID ${sort}`;
//       let viewOrderList = await connection.query(viewOrderListQuery, {
//         type: QueryTypes.SELECT,
//       });
//       console.log(
//         viewOrderList,
//         "viewOrderList-----------------------------------------------"
//       );




//       let productCombinationDetail;
//       if (viewOrderList && viewOrderList.length > 0) {
//         for (let i = 0; i < viewOrderList.length; i++) {
//           let ProductVariantCombinationDetail = [];
//           ProductVariantCombinationDetail.push(
//             viewOrderList[i].ProductVariantCombinationDetail
//           );
//           ProductVariantCombinationDetail = `(${ProductVariantCombinationDetail.join(
//             ","
//           )})`;
//           productCombinationDetail = await connection.query(
//             `SELECT p.ProductID,c.ProductVariantCombinationID,c.VendorStoreID,c.Price AS ProductCombinationPrice,c.AvailableInventory,o.OptionID,o.OptionName,v.OptionValue,v.OptionValueID,p.Currency
//               FROM ((((product p
//               LEFT JOIN productvariantoption o ON o.ProductID IN( p.ProductID))
//               LEFT JOIN productvariantoptionvalue v  ON  v.OptionID IN (o.OptionID))
//               LEFT JOIN productvariantcombination c  ON  c.OptionValueID IN (v.OptionValueID))
//               LEFT JOIN processorder s ON s.ProductID IN(c.ProductID))
//               WHERE s.UserID='${UserID}' AND c.ProductVariantCombinationID IN ${ProductVariantCombinationDetail}
//               GROUP BY c.OptionValueID
//              `,
//             {
//               type: QueryTypes.SELECT,
//             }
//           );
//           productCombinationPriceDetail.push(productCombinationDetail);


//         }
//         // return res.send(productCombinationPriceDetail)
//         let orderName = [];
//         let orderTotal = [];
//         let orderDate = [];
//         let paymentStatus = [];
//         let transactionID = [];
//         let tempPC = productCombinationPriceDetail;
//         let tempProd = viewOrderList;
//         let tempArray = [];
//         let processStatus = [];
//         let deliveryStatus = [];
//         let tempAOrderDetails = [];
//         let deliveryDate = [];
//         let estimatedTax = [];
//         let shippingHandling = [];
//         console.log("_______________________________________", Region);
//         for (let i = 0; i < tempProd.length; i++) {
//           let tempTotal = parseFloat(currencyRate * tempProd[i].OrderTotal).toFixed(2);

//           console.log("tempTotaltempTotaltempTotaltempTotal", tempTotal);

//           if (Region == "Bangladesh") {

//             let EstimatedTax = tempProd[i].EstimatedTax;
//             let ShippingHandling = tempProd[i].ShippingHandling;
//             let Price = tempProd[i].BasePrice;
//             if (tempProd[i].Currency == "USD") {
//               tempProd[i]["Currency"] = "BDT";
//               tempProd[i]["BasePrice"] = parseFloat(
//                 currencyRate * Price
//               ).toFixed(2);
//               tempProd[i]["EstimatedTax"] = parseFloat(
//                 currencyRate * EstimatedTax
//               ).toFixed(2);
//               tempProd[i]["ShippingHandling"] = parseFloat(
//                 currencyRate * ShippingHandling
//               ).toFixed(2);

//               tempProd[i]["OrderTotal"] = parseFloat(
//                 currencyRate * Price
//               ).toFixed(2);

//               // if (Region !== 'United States') {


//               // }

//             }
//           }
//           else if (Region == "USA") {



//             if (tempProd[i].Currency == "BDT") {
//               console.log("THIS IS THE CASE");
//               let Price = tempProd[i].BasePrice;
//               let EstimatedTax = tempProd[i].EstimatedTax;
//               let ShippingHandling = tempProd[i].ShippingHandling;

//               tempProd[i]["Currency"] = "USD";
//               tempProd[i]["OrderTotal"] = tempTotal;
//               tempProd[i]["BasePrice"] = parseFloat(
//                 currencyRate * Price
//               ).toFixed(2);


//               tempProd[i]["EstimatedTax"] = parseFloat(currencyRate * EstimatedTax).toFixed(
//                 2
//               );
//               tempProd[i]["ShippingHandling"] = parseFloat(currencyRate * ShippingHandling).toFixed(
//                 2
//               );

//             }
//           }
//           else {
//             console.log("THIS IS THE CASE 2");

//             let Price = tempProd[i].BasePrice;
//             let EstimatedTax = tempProd[i].EstimatedTax;
//             let ShippingHandling = tempProd[i].ShippingHandling;
//             if (tempProd[i].Currency == "BDT") {
//               tempProd[i]["OrderTotal"] = tempTotal;

//               tempProd[i]["Currency"] = "USD";
//               tempProd[i]["BasePrice"] = parseFloat(
//                 currencyRate * Price
//               ).toFixed(2);




//               tempProd[i]["EstimatedTax"] = parseFloat(currencyRate * EstimatedTax).toFixed(
//                 2
//               );
//               tempProd[i]["ShippingHandling"] = parseFloat(currencyRate * ShippingHandling).toFixed(
//                 2
//               );
//             }

//           }
//           var obj = {
//             ...tempProd[i],
//           };
//           let variantsLength = tempPC[i].length;
//           if (Region == "Bangladesh") {
//             for (let j = 0; j < variantsLength; j++) {
//               let Price = tempPC[i][j].ProductCombinationPrice;
//               if (tempPC[i][j].Currency == "USD") {
//                 tempPC[i][j]["Currency"] = "BDT";
//                 tempPC[i][j]["ProductCombinationPrice"] = parseFloat(
//                   currencyRate * Price
//                 ).toFixed(2);
//               }
//             }
//           }
//           else if (Region == "USA") {
//             for (let j = 0; j < variantsLength; j++) {
//               let Price = tempPC[i][j].ProductCombinationPrice;
//               if (tempPC[i][j].Currency == "BDT") {
//                 tempPC[i][j]["Currency"] = "USD";
//                 tempPC[i][j]["ProductCombinationPrice"] = parseFloat(
//                   currencyRate * Price
//                 ).toFixed(2);
//               }
//             }
//           }
//           else {
//             for (let j = 0; j < variantsLength; j++) {
//               let Price = tempPC[i][j].ProductCombinationPrice;
//               tempPC[i][j]["Currency"] = "USD";
//               tempPC[i][j]["ProductCombinationPrice"] = parseFloat(
//                 currencyRate * Price
//               ).toFixed(2);
//             }
//           }

//           obj["ProductCombinations"] = tempPC[i];
//           tempArray.push(obj);
//         }
//         for (let i = 0; i < tempArray.length; i++) {
//           if (!orderName.includes(tempArray[i].OrderNumber)) {
//             orderName.push(tempArray[i].OrderNumber);
//             orderDate.push(tempArray[i].OrderDate);
//             paymentStatus.push(tempArray[i].PaymentStatus);
//             transactionID.push(tempArray[i].TransactionID);
//             processStatus.push(tempArray[i].ProcessStatus);
//             orderTotal.push(tempArray[i].OrderTotal);
//             deliveryDate.push(tempArray[i].DeliveryDate);
//             deliveryStatus.push(tempArray[i].DeliveryStatus);
//             estimatedTax.push(tempArray[i].EstimatedTax);
//             shippingHandling.push(tempArray[i].ShippingHandling);
//           }
//         }

//         console.log("orderNameorderNameorderNameorderNameorderNameorderNameorderNameorderNameorderNameorderName", orderName);
//         for (let i = 0; i < orderName.length; i++) {
//           var obj = {
//             OrderNumber: orderName[i],
//             OrderDate: orderDate[i],
//             PaymentStatus: paymentStatus[i],
//             TransactionID: transactionID[i],
//             ProcessStatus: processStatus[i],
//             OrderTotal: orderTotal[i],
//             DeliveryDate: deliveryDate[i],
//             DeliveryStatus: deliveryStatus[i],
//             EstimatedTax: estimatedTax[i],
//             ShippingHandling: shippingHandling[i],
//             ProductDetail: [],
//           };
//           for (let j = 0; j < tempArray.length; j++) {
//             if (orderName[i] === tempArray[j].OrderNumber) {
//               obj.ProductDetail.push(tempArray[j]);
//             }
//           }
//           tempAOrderDetails.push(obj);
//         }
//         console.log(tempAOrderDetails, "__________+++++++++================");
//         if (productCombinationDetail && productCombinationDetail.length > 0) {
//           res.status(200).json({
//             status: true,
//             total_records: getOrderCount[0].total_records,
//             orderDetails: tempAOrderDetails,
//           });
//         } else {
//           res.status(200).json({
//             status: false,
//             total_records: getOrderCount[0].total_records,
//             orderDetails: [],
//           });
//         }
//       } else {
//         res.status(200).json({
//           status: true,
//           total_records: getOrderCount[0].total_records,
//           orderDetails: [],
//         });
//       }
//     } else {
//       res.status(200).json({
//         status: true,
//         total_records: getOrderCount[0].total_records,
//         orderDetails: [],
//       });
//     }
//   } catch (err) {
//     console.log(err.message);
//     next(err);
//     res.status(200).json({
//       status: false,
//       orderDetails: [],
//     });
//   }
// }

//remove order where status is pending

exports.removePendingOrders = async (req, res, next) => {
  try {

    const { orderNumber } = req.body
    if (orderNumber !== undefined && orderNumber !== null && orderNumber){

    }else{
      res.status(400).json({
        status: false,
        message: "Bad request invalid format for order number"
      })
    }

  } catch (err) {
    console.log(err.message);
    next(err);
    res.status(200).json({
      status: false,
      error: err.message
    });
  }
}


exports.adOld1etOrdersDetails = async (req, res, next) => {
  try {
    let {
      limit,
      offset,
      search,
      sort
    } = req.body;
    let Region = req.region;
    limit = parseInt(limit);
    offset = parseInt(offset);
    offset = limit * offset;
    const currencyRate = req.currency_rate;
    let UserID = req.UserID;
    let productCombinationPriceDetail = [];
    let getOrderCount = await connection.query(
      `SELECT COUNT(DISTINCT(OrderNumber)) as total_records from processorder
      WHERE UserID='${UserID}'
     `, {
      type: QueryTypes.SELECT,
    }
    );

    if (getOrderCount[0].total_records && getOrderCount[0].total_records > 0) {
      console.log(
        "inside ------------------------------------------------------------------------"
      );
      let viewOrderListQuery = `SELECT p.ProductID,p.Title,m.TransactionID,s.OrderNumber,s.OrderDate,s.ProcessStatus,m.PaymentStatus,p. Price AS BasePrice,p.Currency,s.UserID,g.Small,g.Medium,g.Large,i.MainImage,m.OrderTotal,s.ItemsPrice,s.ItemsEstimatedTax,s.ItemsShippingHandling,s.ProductVariantCombinationDetail,s.DeliveryDate,s.DeliveryStatus,m.EstimatedTax,m.ShippingHandling,
          (SELECT COUNT(t.ProductID)
          from productreviewrating t WHERE t.ProductID = p.ProductID) AS REVIEW_COUNT,
          (SELECT AVG(t.Rating) from productreviewrating t WHERE t.ProductID = p.ProductID) AS  AVG_Rating
          FROM ((((((( product p      
          LEFT JOIN productvariantoption o ON o.ProductID IN( p.ProductID))
          LEFT JOIN productvariantoptionvalue v  ON  v.OptionID IN (o.OptionID))  
          LEFT JOIN productimage i  ON  i.OptionValueID IN (v.OptionValueID))
          LEFT JOIN imagegallery g  ON  g.ImageGalleryID IN (i.ImageGalleryID))
          LEFT JOIN productvariantcombination c  ON  c.OptionValueID IN (v.OptionValueID))
          LEFT JOIN processorder s ON s.ProductID IN(c.ProductID))
          LEFT JOIN processpayment m ON m.OrderNumber IN(s.OrderNumber))
          WHERE i.MainImage='Y' AND s.OrderNumber IN (select * from (SELECT OrderNumber from processorder WHERE UserID='${UserID}' AND OrderNumber LIKE "%${search}%"  GROUP BY OrderNumber  ORDER BY ProcessOrderID ${sort} LIMIT ${limit} OFFSET ${offset} ) OrderNumber)
          GROUP BY s.ProcessOrderID
          ORDER BY s.ProcessOrderID ${sort}`;
      let viewOrderList = await connection.query(viewOrderListQuery, {
        type: QueryTypes.SELECT,
      });
      console.log(
        viewOrderList,
        "viewOrderList-----------------------------------------------"
      );
      let productCombinationDetail;
      if (viewOrderList && viewOrderList.length > 0) {
        for (let i = 0; i < viewOrderList.length; i++) {
          let ProductVariantCombinationDetail = [];
          ProductVariantCombinationDetail.push(
            viewOrderList[i].ProductVariantCombinationDetail
          );
          ProductVariantCombinationDetail = `(${ProductVariantCombinationDetail.join(
            ","
          )})`;
          productCombinationDetail = await connection.query(
            `SELECT p.ProductID,c.ProductVariantCombinationID,c.VendorStoreID,c.Price AS ProductCombinationPrice,c.AvailableInventory,o.OptionID,o.OptionName,v.OptionValue,v.OptionValueID,p.Currency
              FROM ((((product p
              LEFT JOIN productvariantoption o ON o.ProductID IN( p.ProductID))
              LEFT JOIN productvariantoptionvalue v  ON  v.OptionID IN (o.OptionID)) 
              LEFT JOIN productvariantcombination c  ON  c.OptionValueID IN (v.OptionValueID))
              LEFT JOIN processorder s ON s.ProductID IN(c.ProductID))
              WHERE s.UserID='${UserID}' AND c.ProductVariantCombinationID IN ${ProductVariantCombinationDetail}
              GROUP BY c.OptionValueID
             `, {
            type: QueryTypes.SELECT,
          }
          );
          productCombinationPriceDetail.push(productCombinationDetail);
        }
        let orderName = [];
        let orderTotal = [];
        let orderDate = [];
        let paymentStatus = [];
        let transactionID = [];
        let tempPC = productCombinationPriceDetail;
        let tempProd = viewOrderList;
        let tempArray = [];
        let processStatus = [];
        let deliveryStatus = [];
        let tempAOrderDetails = [];
        let deliveryDate = [];
        let estimatedTax = [];
        let shippingHandling = [];
        for (let i = 0; i < tempProd.length; i++) {
          if (Region == "Bangladesh") {
            let Price = tempProd[i].BasePrice;
            if (tempProd[i].Currency == "USD") {
              tempProd[i]["Currency"] = "BDT";
              tempProd[i]["BasePrice"] = parseFloat(
                currencyRate * Price
              ).toFixed(2);
            }
          } else if (Region == "USA") {
            let Price = tempProd[i].BasePrice;
            if (tempProd[i].Currency == "BDT") {
              tempProd[i]["Currency"] = "USD";
              tempProd[i]["BasePrice"] = parseFloat(
                currencyRate * Price
              ).toFixed(2);
            }
          } else {
            let Price = tempProd[i].BasePrice;
            if (tempProd[i].Currency == "BDT") {
              tempProd[i]["Currency"] = "USD";
              tempProd[i]["BasePrice"] = parseFloat(
                currencyRate * Price
              ).toFixed(2);
            }
          }
          var obj = {
            ...tempProd[i],
          };
          let variantsLength = tempPC[i].length;
          if (Region == "Bangladesh") {
            for (let j = 0; j < variantsLength; j++) {
              let Price = tempPC[i][j].ProductCombinationPrice;
              if (tempPC[i][j].Currency == "USD") {
                tempPC[i][j]["Currency"] = "BDT";
                tempPC[i][j]["ProductCombinationPrice"] = parseFloat(
                  currencyRate * Price
                ).toFixed(2);
              }
            }
          } else if (Region == "USA") {
            for (let j = 0; j < variantsLength; j++) {
              let Price = tempPC[i][j].ProductCombinationPrice;
              if (tempPC[i][j].Currency == "BDT") {
                tempPC[i][j]["Currency"] = "USD";
                tempPC[i][j]["ProductCombinationPrice"] = parseFloat(
                  currencyRate * Price
                ).toFixed(2);
              }
            }
          } else {
            for (let j = 0; j < variantsLength; j++) {
              let Price = tempPC[i][j].ProductCombinationPrice;
              tempPC[i][j]["Currency"] = "USD";
              tempPC[i][j]["ProductCombinationPrice"] = parseFloat(
                currencyRate * Price
              ).toFixed(2);
            }
          }

          obj["ProductCombinations"] = tempPC[i];
          tempArray.push(obj);
        }
        for (let i = 0; i < tempArray.length; i++) {
          if (!orderName.includes(tempArray[i].OrderNumber)) {
            orderName.push(tempArray[i].OrderNumber);
            orderDate.push(tempArray[i].OrderDate);
            paymentStatus.push(tempArray[i].PaymentStatus);
            transactionID.push(tempArray[i].TransactionID);
            processStatus.push(tempArray[i].ProcessStatus);
            orderTotal.push(tempArray[i].OrderTotal);
            deliveryDate.push(tempArray[i].DeliveryDate);
            deliveryStatus.push(tempArray[i].DeliveryStatus);
            estimatedTax.push(tempArray[i].EstimatedTax);
            shippingHandling.push(tempArray[i].ShippingHandling);
          }
        }
        for (let i = 0; i < orderName.length; i++) {
          var obj = {
            OrderNumber: orderName[i],
            OrderDate: orderDate[i],
            PaymentStatus: paymentStatus[i],
            TransactionID: transactionID[i],
            ProcessStatus: processStatus[i],
            OrderTotal: orderTotal[i],
            DeliveryDate: deliveryDate[i],
            DeliveryStatus: deliveryStatus[i],
            EstimatedTax: estimatedTax[i],
            ShippingHandling: shippingHandling[i],
            ProductDetail: [],
          };
          for (let j = 0; j < tempArray.length; j++) {
            if (orderName[i] === tempArray[j].OrderNumber) {
              obj.ProductDetail.push(tempArray[j]);
            }
          }
          tempAOrderDetails.push(obj);
        }
        if (productCombinationDetail && productCombinationDetail.length > 0) {
          res.status(200).json({
            status: true,
            total_records: getOrderCount[0].total_records,
            orderDetails: tempAOrderDetails,
          });
        } else {
          res.status(200).json({
            status: false,
            total_records: getOrderCount[0].total_records,
            orderDetails: [],
          });
        }
      } else {
        res.status(200).json({
          status: true,
          total_records: getOrderCount[0].total_records,
          orderDetails: [],
        });
      }
    } else {
      res.status(200).json({
        status: true,
        total_records: getOrderCount[0].total_records,
        orderDetails: [],
      });
    }
  } catch (err) {
    console.log(err.message);
    next(err);
    res.status(200).json({
      status: false,
      orderDetails: [],
    });
  }
};
exports.getShippingStatus = async (req, res, next) => {
  try {
    const {
      ProductDetail
    } = req.body;
    let ShippingByAdmin = [];
    let ShippingByVendor = [];
    let AllowStorePickup = [];
    let CityID = [];
    let banglaBazarPickup = true;
    let pickupUser = true;
    let sameCity;
    let ProductID = [];
    let array = [];
    for (let i = 0; i < ProductDetail.length; i++) {
      array.push(ProductDetail[i].ProductID);
    }
    ProductID = `(${array.join(",")})`;
    let getShippingStatus = await connection.query(
      `  select p.ProductID,p.Title,p.ShippingByAdmin,p.ShippingByVendor,p.ShippingCostAdmin,p.ShippingCostVendor,p.AllowStorePickup,c.CityID
       from product p
       INNER JOIN productcity c ON c.ProductID=p.ProductID
       where p.ProductID IN ${ProductID}  `, {
      type: QueryTypes.SELECT,
    }
    );
    for (let i = 0; i < getShippingStatus.length; i++) {
      ShippingByAdmin[i] = getShippingStatus[i].ShippingByAdmin;
      ShippingByVendor[i] = getShippingStatus[i].ShippingByVendor;
      AllowStorePickup[i] = getShippingStatus[i].AllowStorePickup;
      CityID.push(getShippingStatus[i].CityID);
      if (ShippingByAdmin[i] !== ShippingByVendor[i]) {
        banglaBazarPickup = false;
      }
      if (AllowStorePickup[i] === "N") {
        pickupUser = false;
      }
    }

    function sameValues(CityID) {
      return CityID.every((v, i, a) => v === a[0]);
    }
    sameCity = sameValues(CityID);
    if (getShippingStatus && getShippingStatus.length > 0) {
      res.status(200).json({
        status: true,
        banglaBazarPickup,
        pickUpByUser: pickupUser,
        sameCity,
      });
    } else {
      res.status(200).json({
        status: false,
        message: `Error while displaying Shipping Status `,
      });
    }
  } catch (err) {
    next(err);
    res.status(200).json({
      status: false,
      message: err.message,
    });
    console.log(err.message);
  }
};
exports.refundForm = async (req, res, next) => {
  let transaction;
  try {
    transaction = await connection.transaction();
    let path = req.file.path;
    let str = "\\";
    let RefandItemsPic = path.split(str).join("//");
    let {
      OrderNumber,
      ProductDetail,
      RefundReason,
      AccountNumber,
      AccountTitle,
      DeliveryStatus,
      UserID,
      type,
    } = req.body;
    console.log(req.body);
    const Product = JSON.parse(ProductDetail);
    console.log(JSON.parse(ProductDetail).length);
    console.log(Product);
    let addReturnReason = false;
    let ProductVariantCombinationID = [];
    let currentdateAndTime = [];
    let LastUpdate = new Date().toISOString().slice(0, 19).replace("T", " ");
    currentdateAndTime[0] = LastUpdate;

    const TrackingNumber = function () {
      return crypto.randomBytes(8).toString("base64");
    };
    const RefandTrackingNumber = TrackingNumber();
    const RefandRequestDate = new Date()
      .toISOString()
      .slice(0, 19)
      .replace("T", " ");
    let insertProcessRefandQuery;
    insertProcessRefandQuery = `insert into processrefand (
                  ProcessOrderID,
                  RefandReason,
                  DeliveryDriverID,
                  CourierID,
                  AccountNumber,
                  AccountTitle,
                  RefandTrackingNumber,
                  RefandRequestDate,
                  RefandAmount,
                  RefandShippingCost,
                  GatewayID, 
                  VendorPaymentStatus) values
                   `;
    for (let i = 0; i < Product.length; i++) {
      let ProcessOrderID = Product[i].ProcessOrderID;
      let DeliveryDriverID = Product[i].DeliveryDriverID;
      if (
        DeliveryDriverID === "NULL" ||
        DeliveryDriverID === "null" ||
        DeliveryDriverID === null
      ) {
        DeliveryDriverID = 0;
      }
      let RefandAmount = Product[i].RefandAmount;
      let GatewayID = Product[i].GatewayID;
      let CourierID = Product[i].CourierID;
      if (CourierID === "NULL" || CourierID === "null" || CourierID === null) {
        CourierID = 0;
      }
      let VendorPaymentStatus = Product[i].VendorPaymentStatus;
      let RefandShippingCost = Product[i].RefandShippingCost;
      if (i == Product.length - 1) {
        insertProcessRefandQuery += `('${ProcessOrderID}', '${RefundReason}','${DeliveryDriverID}',
                                '${CourierID}','${AccountNumber}','${AccountTitle}',
                                '${RefandTrackingNumber}',
                                '${RefandRequestDate}','${RefandAmount}','${RefandShippingCost}','${GatewayID}',
                                '${VendorPaymentStatus}')`;
      } else {
        insertProcessRefandQuery += `('${ProcessOrderID}', '${RefundReason}','${DeliveryDriverID}',
          '${CourierID}','${AccountNumber}','${AccountTitle}',
          '${RefandTrackingNumber}',
          '${RefandRequestDate}','${RefandAmount}','${RefandShippingCost}','${GatewayID}',
          '${VendorPaymentStatus}'),`;
      }
    }
    let insertProcessRefand = await connection.query(insertProcessRefandQuery, {
      transaction,
    });
    if (insertProcessRefand) {
      for (let i = 0; i < Product.length; i++) {
        let array = [];
        let ProductID = Product[i].ProductID;
        let ProcessOrderID = Product[i].ProcessOrderID;
        let variantsLength = Product[i].ProductCombinations.length;
        let variants = Product[i].ProductCombinations;
        for (j = 0; j < variantsLength; j++) {
          array.push(variants[j].ProductVariantCombinationID);
        }
        ProductVariantCombinationID = `"${array.join(",")}"`;
        //! here VendorPaymentStatus is in check and Y because if the vendor recieved payment for that product (not really possible but if it happens we are not returning and allowing that product)
        let checkReturnReasonExists = await connection.query(
          `  SELECT * FROM processorder
            WHERE OrderNumber="${OrderNumber}" AND ProductID="${ProductID}" AND ProductVariantCombinationDetail =${ProductVariantCombinationID} AND (NOT (ReturnReason="NULL" || ReturnReason="null" || ReturnReason="undefined" )) AND  (NOT (RefundStatus="NULL" || RefundStatus="null" || RefundStatus="undefined" )) OR VendorPaymentStatus = "Y" `, {
          type: QueryTypes.SELECT,
          transaction,
        }
        );
        console.log(checkReturnReasonExists, "checkReturnReasonExists");
        if (checkReturnReasonExists && checkReturnReasonExists.length > 0) {
          break;
        } else {
          try {
            addReturnReason = true;
            addReturnReason = await connection.query(
              `UPDATE processorder,processrefand
                 SET processorder.ReturnReason="${RefundReason}",processorder.RefundStatus='Initiated', processorder.RefundStatusHistory='${JSON.stringify(
                currentdateAndTime
              )}',processrefand.RefandItemsPic="${RefandItemsPic}" WHERE processorder.OrderNumber="${OrderNumber}" AND processorder.ProductID="${ProductID}" AND processorder.ProductVariantCombinationDetail =${ProductVariantCombinationID} AND processrefand.ProcessOrderID="${ProcessOrderID}"`, {
              transaction,
            }
            );
          } catch (e) {
            console.log(e.message);
            addReturnReason = false;
          }
        }
      }
      if (addReturnReason) {
        let ReceiverID = "1";
        let TypeID = "7";
        let CreaterID = UserID;
        let tempBody;
        if (type === "Y") {
          tempBody =
            DeliveryStatus == "usps" ?
              `You have new free refund request of USPS order.Go to XPS Panel and create return label against OrderNumber ${OrderNumber}` :
              `You have new refund request of pathao OrderNumber ${OrderNumber}.Kindly review it so it can be proceeded`;
        }
        if (type === "N") {
          tempBody =
            DeliveryStatus == "usps" ?
              `You have new paid refund request of USPS order against OrderNumber ${OrderNumber}.Kindly review it so it can be proceeded` :
              `You have new refund request of pathao OrderNumber ${OrderNumber}.Kindly review it so it can be proceeded`;
        }
        let Body = {
          OrderNumber: OrderNumber,
          body: tempBody,
          type: type,
          status: "Initiated",
        };

        let sendNotification = await Notification(
          TypeID,
          Body,
          CreaterID,
          ReceiverID,
          transaction
        );

        console.log("_________________________________", sendNotification);

        console.log(sendNotification, "sendNotification");
        if (sendNotification) {
          if (transaction) await transaction.commit(); //!final commit
          res.status(200).json({
            status: true,
            message: "Successfully added process refund request in db",
          });
        } else {
          if (transaction) await transaction.rollback();
          res.status(200).json({
            status: false,
            message: "Error while sending notification to admin",
          });
        }
      } else {
        if (transaction) await transaction.rollback();
        res.status(200).json({
          status: false,
          message: "Error ! Either already refund initated or error while updating refund status",
        });
      }
    } else {
      if (transaction) await transaction.rollback();
      res.status(200).json({
        status: false,
        message: "Error while adding details in process refund",
      });
    }
  } catch (err) {
    console.log(err.message);
    if (transaction) await transaction.rollback();
    next(err);
    res.status(200).json({
      status: false,
      message: err.message,
    });
  }
};
exports.refundCancel = async (req, res, next) => {
  try {
    const {
      ProcessOrders
    } = req.body;
    let ProcessOrderID = [];
    for (let i = 0; i < ProcessOrders.length; i++) {
      ProcessOrderID.push(ProcessOrders[i]);
    }
    ProcessOrderID = `(${ProcessOrderID.join(",")})`;
    let deleteRefundRequest = await connection.query(
      `DELETE FROM processrefand WHERE ProcessOrderID IN ${ProcessOrderID} `
    );
    if (deleteRefundRequest && deleteRefundRequest.length > 0) {
      let updateRefundRequestStatus = await connection.query(
        `UPDATE processorder SET ReturnReason = "Cancelled" WHERE ProcessOrderID IN ${ProcessOrderID} `
      );
      if (updateRefundRequestStatus) {
        res.status(200).json({
          status: true,
          message: "Successfully updated cancelled status",
        });
      } else {
        res.status(200).json({
          status: false,
          message: "Error while updating status",
        });
      }
    } else {
      res.status(200).json({
        status: false,
        message: "Error while deleting process refund ",
      });
    }
  } catch (err) {
    next(err);
    console.log(
      err.message,
      "-----------------------------------------------------"
    );
    res.status(200).json({
      status: false,
      message: err.message,
    });
    console.log(err.message);
  }
};
exports.getRefundOrdersByUser = async (req, res, next) => {
  try {
    // let Region = req.region;
    // const currencyRate = req.currency_rate;
    const UserID = req.UserID;
    let {
      limit,
      offset,
      status
    } = req.body;
    let productCombinationPriceDetail = [];
    limit = parseInt(limit);
    offset = parseInt(offset);
    offset = limit * offset;
    let getCount = await connection.query(
      `SELECT COUNT(DISTINCT OrderNumber) as total_records from processorder WHERE UserID = "${UserID}" AND processStatus = "Delivered" AND ReturnOrder = "Y" AND RefundStatus = "Refunded" `, {
      type: QueryTypes.SELECT,
    }
    );
    console.log(getCount);
    if (getCount[0].total_records && getCount[0].total_records > 0) {
      let viewOrderListQuery = `SELECT p.ProductID, p.Title, m.TransactionID, s.OrderNumber, s.AllowStorePickup, s.AllowAdminPickup, s.ReadyPickupForUser, s.ReadyPickupForAdmin, s.OrderDate, m.PaymentStatus, p.Price AS BasePrice, s.Quantity, p.Currency, s.UserID, g.Small, g.Medium, g.Large, i.MainImage, s.StatusHistory, s.ProcessStatus, s.DeliveryDriverID, s.ConsignmentId, s.*, r.CountryID AS VendorCountry, pr.*, s.RefundStatus, s.RefundStatusHistory
        FROM(((((((((product p      
          LEFT JOIN productvariantoption o ON o.ProductID IN(p.ProductID))
          LEFT JOIN productvariantoptionvalue v  ON  v.OptionID IN(o.OptionID))  
          LEFT JOIN productimage i  ON  i.OptionValueID IN(v.OptionValueID))
          LEFT JOIN imagegallery g  ON  g.ImageGalleryID IN(i.ImageGalleryID))
          LEFT JOIN productvariantcombination c  ON  c.OptionValueID IN(v.OptionValueID))
          LEFT JOIN processorder s ON s.ProductID IN(c.ProductID))
          LEFT JOIN processrefand pr ON pr.ProcessOrderID IN(s.ProcessOrderID))
          LEFT JOIN vendor r ON(r.VendorID = p.VendorID))
          LEFT JOIN processpayment m ON m.OrderNumber IN(s.OrderNumber))
          WHERE i.MainImage = 'Y' AND s.UserID = "${UserID}" AND s.processStatus = "Delivered" AND s.ReturnOrder = "Y" AND s.RefundStatus = "Refunded" AND s.OrderNumber IN(select * from(SELECT OrderNumber from processorder WHERE UserID = '${UserID}' AND RefundStatus = "Refunded" AND ReturnOrder = "Y" GROUP BY OrderNumber ORDER BY ProcessOrderID DESC LIMIT ${limit} OFFSET ${offset}) OrderNumber) 
          ORDER BY s.ProcessOrderID DESC`; //! here note that i am getting result from only where clause conditions not need of ordernumber it is only because of limit because if limit 2 it will only get 2 rows could be of same order but 2 should means 2 orders/records not two rows so inner query we select which whole order will come as group by is there so only those reocrds are included
      let viewOrderList = await connection.query(viewOrderListQuery, {
        type: QueryTypes.SELECT,
      });
      console.log(viewOrderList);
      let productCombinationDetail;
      if (viewOrderList && viewOrderList.length > 0) {
        for (let i = 0; i < viewOrderList.length; i++) {
          let ProductVariantCombinationDetail = [];
          ProductVariantCombinationDetail.push(
            viewOrderList[i].ProductVariantCombinationDetail
          );
          ProductVariantCombinationDetail = `(${ProductVariantCombinationDetail.join(
            ","
          )})`;
          productCombinationDetail = await connection.query(
            `SELECT p.ProductID, c.ProductVariantCombinationID, c.VendorStoreID, c.Price AS ProductCombinationPrice, c.AvailableInventory, o.OptionID, o.OptionName, v.OptionValue, v.OptionValueID, p.Currency
        FROM((((product p
              LEFT JOIN productvariantoption o ON o.ProductID IN(p.ProductID))
              LEFT JOIN productvariantoptionvalue v  ON  v.OptionID IN(o.OptionID)) 
              LEFT JOIN productvariantcombination c  ON  c.OptionValueID IN(v.OptionValueID))
              LEFT JOIN processorder s ON s.ProductID IN(c.ProductID))
              WHERE  c.ProductVariantCombinationID IN ${ProductVariantCombinationDetail} 
              GROUP BY c.OptionValueID
              ORDER BY s.ProcessOrderID ASC
             `, {
            type: QueryTypes.SELECT,
          }
          );
          productCombinationPriceDetail.push(productCombinationDetail);
        }

        let getCurrencyRates = await connection.query(
          "SELECT * FROM currencyrate", {
          type: QueryTypes.SELECT,
        }
        );
        let VendorCountry = viewOrderList[0].VendorCountry;
        let currencyRate;
        if (VendorCountry == "16") {
          currencyRate = getCurrencyRates[1].Rate;
        } else {
          currencyRate = getCurrencyRates[0].Rate;
        }
        let orderName = [];
        let orderDate = [];
        let paymentStatus = [];
        let transactionID = [];
        let tempPC = productCombinationPriceDetail;
        let tempProd = viewOrderList;
        let tempArray = [];
        let allowStorePickup = [];
        let readyPickupForUser = [];
        let readyPickupForAdmin = [];
        let allowAdminPickup = [];
        let statusHistory = [];
        let processStatus = [];
        let tempAOrderDetails = [];

        for (let i = 0; i < tempProd.length; i++) {
          //!cuurency conversion
          if (VendorCountry == "16") {
            let Price = tempProd[i].BasePrice;
            if (tempProd[i].Currency == "USD") {
              tempProd[i]["Currency"] = "BDT";
              tempProd[i]["BasePrice"] = parseFloat(
                currencyRate * Price
              ).toFixed(2);
            }
          } else if (VendorCountry == "226") {
            let Price = tempProd[i].BasePrice;
            if (tempProd[i].Currency == "BDT") {
              tempProd[i]["Currency"] = "USD";
              tempProd[i]["BasePrice"] = parseFloat(
                currencyRate * Price
              ).toFixed(2);
            }
          } else {
            let Price = tempProd[i].BasePrice;
            tempProd[i]["Currency"] = "USD";
            tempProd[i]["BasePrice"] = parseFloat(currencyRate * Price).toFixed(
              2
            );
          }
          var obj = {
            ...tempProd[i],
          };
          let variantsLength = tempPC[i].length;
          if (VendorCountry == "16") {
            for (let j = 0; j < variantsLength; j++) {
              let Price = tempPC[i][j].ProductCombinationPrice;
              if (tempPC[i][j].Currency == "USD") {
                tempPC[i][j]["Currency"] = "BDT";
                tempPC[i][j]["ProductCombinationPrice"] = parseFloat(
                  currencyRate * Price
                ).toFixed(2);
              }
            }
          } else if (VendorCountry == "226") {
            for (let j = 0; j < variantsLength; j++) {
              let Price = tempPC[i][j].ProductCombinationPrice;
              if (tempPC[i][j].Currency == "BDT") {
                tempPC[i][j]["Currency"] = "USD";
                tempPC[i][j]["ProductCombinationPrice"] = parseFloat(
                  currencyRate * Price
                ).toFixed(2);
              }
            }
          } else {
            for (let j = 0; j < variantsLength; j++) {
              let Price = tempPC[i][j].ProductCombinationPrice;
              tempPC[i][j]["Currency"] = "USD";
              tempPC[i][j]["ProductCombinationPrice"] = parseFloat(
                currencyRate * Price
              ).toFixed(2);
            }
          }
          obj["ProductCombinations"] = tempPC[i];
          tempArray.push(obj);
        }
        for (let i = 0; i < tempArray.length; i++) {
          if (!orderName.includes(tempArray[i].OrderNumber)) {
            orderName.push(tempArray[i].OrderNumber);
            orderDate.push(tempArray[i].OrderDate);
            paymentStatus.push(tempArray[i].PaymentStatus);
            transactionID.push(tempArray[i].TransactionID);
            allowStorePickup.push(tempArray[i].AllowStorePickup);
            readyPickupForUser.push(tempArray[i].ReadyPickupForUser);
            readyPickupForAdmin.push(tempArray[i].ReadyPickupForAdmin);
            allowAdminPickup.push(tempArray[i].AllowAdminPickup);
            statusHistory.push(tempArray[i].StatusHistory);
            processStatus.push(tempArray[i].ProcessStatus);
          }
        }
        for (let i = 0; i < orderName.length; i++) {
          var obj = {
            OrderNumber: orderName[i],
            OrderDate: orderDate[i],
            PaymentStatus: paymentStatus[i],
            TransactionID: transactionID[i],
            AllowStorePickup: allowStorePickup[i],
            ReadyPickupForUser: readyPickupForUser[i],
            ReadyPickupForAdmin: readyPickupForAdmin[i],
            AllowAdminPickup: allowAdminPickup[i],
            StatusHistory: statusHistory[i],
            ProcessStatus: processStatus[i],
            ProductDetail: [],
          };
          for (let j = 0; j < tempArray.length; j++) {
            if (orderName[i] === tempArray[j].OrderNumber) {
              obj.ProductDetail.push(tempArray[j]);
            }
          }
          tempAOrderDetails.push(obj);
        }
        if (productCombinationDetail && productCombinationDetail.length > 0) {
          res.status(200).json({
            status: true,
            total_records: getCount[0].total_records,
            orderDetails: tempAOrderDetails,
          });
        } else {
          res.status(200).json({
            status: false,
            orderDetails: [],
          });
        }
      } else {
        res.status(200).json({
          status: true,
          total_records: getCount[0].total_records,
          orderDetails: [],
        });
      }
    } else {
      res.status(200).json({
        status: true,
        total_records: getCount[0].total_records,
        orderDetails: [],
      });
    }
  } catch (err) {
    console.log(err.message);
    next(err);
    res.status(200).json({
      status: false,
      orderDetails: [],
    });
  }
};
exports.getOrdersDetailsBackup = async (req, res, next) => {
  try {
    let Region = req.region;
    const currencyRate = req.currency_rate;
    let UserID = req.UserID;
    let productCombinationPriceDetail = [];
    let getProcessOrderDetails = await connection.query(
      `SELECT * from processorder
      WHERE UserID = '${UserID}'
          `, {
      type: QueryTypes.SELECT,
    }
    );
    let viewOrderListQuery = `SELECT p.ProductID, p.Title, m.TransactionID, s.OrderNumber, s.OrderDate, s.ProcessStatus, m.PaymentStatus, p.Price AS BasePrice, p.Currency, s.UserID, g.Small, g.Medium, g.Large, i.MainImage, m.OrderTotal,
          (SELECT COUNT(t.ProductID)
      from productreviewrating t WHERE t.ProductID = p.ProductID) AS REVIEW_COUNT,
          (SELECT AVG(t.Rating) from productreviewrating t WHERE t.ProductID = p.ProductID) AS  AVG_Rating
        FROM(((((((product p      
          LEFT JOIN productvariantoption o ON o.ProductID IN(p.ProductID))
          LEFT JOIN productvariantoptionvalue v  ON  v.OptionID IN(o.OptionID))  
          LEFT JOIN productimage i  ON  i.OptionValueID IN(v.OptionValueID))
          LEFT JOIN imagegallery g  ON  g.ImageGalleryID IN(i.ImageGalleryID))
          LEFT JOIN productvariantcombination c  ON  c.OptionValueID IN(v.OptionValueID))
          LEFT JOIN processorder s ON s.ProductID IN(c.ProductID))
          LEFT JOIN processpayment m ON m.OrderNumber IN(s.OrderNumber))
          WHERE s.UserID = '${UserID}' AND i.MainImage = 'Y'
          GROUP BY s.ProcessOrderID
          ORDER BY s.ProcessOrderID DESC
          `;
    let viewOrderList = await connection.query(viewOrderListQuery, {
      type: QueryTypes.SELECT,
    });
    let productCombinationDetail;
    if (viewOrderList && viewOrderList.length > 0) {
      for (let i = 0; i < getProcessOrderDetails.length; i++) {
        let ProductVariantCombinationDetail = [];
        ProductVariantCombinationDetail.push(
          getProcessOrderDetails[i].ProductVariantCombinationDetail
        );
        ProductVariantCombinationDetail = `(${ProductVariantCombinationDetail.join(
          ","
        )})`;
        productCombinationDetail = await connection.query(
          `SELECT p.ProductID, c.ProductVariantCombinationID, c.VendorStoreID, c.Price AS ProductCombinationPrice, c.AvailableInventory, o.OptionID, o.OptionName, v.OptionValue, v.OptionValueID, p.Currency
        FROM((((product p
              LEFT JOIN productvariantoption o ON o.ProductID IN(p.ProductID))
              LEFT JOIN productvariantoptionvalue v  ON  v.OptionID IN(o.OptionID)) 
              LEFT JOIN productvariantcombination c  ON  c.OptionValueID IN(v.OptionValueID))
              LEFT JOIN processorder s ON s.ProductID IN(c.ProductID))
              WHERE s.UserID = '${UserID}' AND c.ProductVariantCombinationID IN ${ProductVariantCombinationDetail}
              GROUP BY c.OptionValueID
             `, {
          type: QueryTypes.SELECT,
        }
        );
        productCombinationPriceDetail.push(productCombinationDetail);
      }
      let orderName = [];
      let orderTotal = [];
      let orderDate = [];
      let paymentStatus = [];
      let transactionID = [];
      let tempPC = productCombinationPriceDetail;
      let tempProd = viewOrderList;
      let tempArray = [];
      let processStatus = [];
      var arr = [];
      let tempAOrderDetails = [];
      for (let i = 0; i < tempProd.length; i++) {
        if (Region == "Bangladesh") {
          let Price = tempProd[i].BasePrice;
          if (tempProd[i].Currency == "USD") {
            tempProd[i]["Currency"] = "BDT";
            tempProd[i]["BasePrice"] = parseFloat(currencyRate * Price).toFixed(
              2
            );
          }
        } else if (Region == "USA") {
          let Price = tempProd[i].BasePrice;
          if (tempProd[i].Currency == "BDT") {
            tempProd[i]["Currency"] = "USD";
            tempProd[i]["BasePrice"] = parseFloat(currencyRate * Price).toFixed(
              2
            );
          }
        } else {
          let Price = tempProd[i].BasePrice;
          if (tempProd[i].Currency == "BDT") {
            tempProd[i]["Currency"] = "USD";
            tempProd[i]["BasePrice"] = parseFloat(currencyRate * Price).toFixed(
              2
            );
          }
        }
        var obj = {
          ...tempProd[i],
        };
        let variantsLength = tempPC[i].length;
        if (Region == "Bangladesh") {
          for (let j = 0; j < variantsLength; j++) {
            let Price = tempPC[i][j].ProductCombinationPrice;
            if (tempPC[i][j].Currency == "USD") {
              tempPC[i][j]["Currency"] = "BDT";
              tempPC[i][j]["ProductCombinationPrice"] = parseFloat(
                currencyRate * Price
              ).toFixed(2);
            }
          }
        } else if (Region == "USA") {
          for (let j = 0; j < variantsLength; j++) {
            let Price = tempPC[i][j].ProductCombinationPrice;
            if (tempPC[i][j].Currency == "BDT") {
              tempPC[i][j]["Currency"] = "USD";
              tempPC[i][j]["ProductCombinationPrice"] = parseFloat(
                currencyRate * Price
              ).toFixed(2);
            }
          }
        } else {
          for (let j = 0; j < variantsLength; j++) {
            let Price = tempPC[i][j].ProductCombinationPrice;
            tempPC[i][j]["Currency"] = "USD";
            tempPC[i][j]["ProductCombinationPrice"] = parseFloat(
              currencyRate * Price
            ).toFixed(2);
          }
        }

        obj["ProductCombinations"] = tempPC[i];
        tempArray.push(obj);
      }
      for (let i = 0; i < tempArray.length; i++) {
        if (!orderName.includes(tempArray[i].OrderNumber)) {
          orderName.push(tempArray[i].OrderNumber);
          orderDate.push(tempArray[i].OrderDate);
          paymentStatus.push(tempArray[i].PaymentStatus);
          transactionID.push(tempArray[i].TransactionID);
          processStatus.push(tempArray[i].ProcessStatus);
          orderTotal.push(tempArray[i].OrderTotal);
        }
      }
      for (let i = 0; i < orderName.length; i++) {
        var obj = {
          OrderNumber: orderName[i],
          OrderDate: orderDate[i],
          PaymentStatus: paymentStatus[i],
          TransactionID: transactionID[i],
          ProcessStatus: processStatus[i],
          OrderTotal: orderTotal[i],
          ProductDetail: [],
        };
        for (let j = 0; j < tempArray.length; j++) {
          if (orderName[i] === tempArray[j].OrderNumber) {
            obj.ProductDetail.push(tempArray[j]);
          }
        }
        tempAOrderDetails.push(obj);
      }
      if (productCombinationDetail && productCombinationDetail.length > 0) {
        res.status(200).json({
          status: true,
          orderDetails: tempAOrderDetails,
        });
      } else {
        res.status(200).json({
          status: true,
          orderDetails: [],
        });
      }
    } else {
      res.status(200).json({
        status: true,
        orderDetails: [],
      });
    }
  } catch (err) {
    console.log(err.message);
    next(err);
    res.status(200).json({
      status: false,
      orderDetails: [],
    });
  }
};
exports.refundNotification = async (req, res, next) => {
  let transaction;
  try {
    transaction = await connection.transaction();
    const {
      UserName,
      OrderNumber,
      UserEmailAddress,
      UserID,
      ProductDetail,
      type,
    } = req.body;
    let ProcessOrderID = [];
    let ProductCombinationsID = [];

    for (let i = 0; i < ProductDetail.length; i++) {
      ProcessOrderID.push(ProductDetail[i].ProcessOrderID);
    }
    const ProductidsWrappedInQuotes = ProcessOrderID.map(
      (ProcessOrderID) => `'${ProcessOrderID}'`
    );
    ProcessOrderID = `(${ProductidsWrappedInQuotes.join(",")})`;
    let uniqueVendorID = [];
    let uniqueVendorEmail = [];
    let uniqueStoreName = [];
    let uniqueStoreEmail = [];
    const getVendorsDetails = await connection.query(
      `SELECT po.ProcessOrderID, po.OrderNumber, po.VendorStoreID, v.VendorID, p.ProductID, v.BusinessEmail, vs.StoreEmail, vs.StoreName, po.RefundStatusHistory
       FROM processorder po
       LEFT JOIN product p ON  p.ProductID = po.ProductID
       LEFT JOIN vendorstore vs ON  vs.VendorStoreID = po.VendorStoreID
       LEFT JOIN vendor v ON  v.VendorID = p.VendorID
       where po.OrderNumber = "${OrderNumber}" AND po.ProcessOrderID IN ${ProcessOrderID} `, {
      type: QueryTypes.SELECT,
      transaction
    }
    );
    console.log(getVendorsDetails, "getVendorsDetails");
    for (let i = 0; i < getVendorsDetails.length; i++) {
      if (!uniqueVendorID.includes(getVendorsDetails[i].StoreName)) {
        uniqueVendorID.push(getVendorsDetails[i].VendorID);
        uniqueVendorEmail.push(getVendorsDetails[i].BusinessEmail);
        uniqueStoreName.push(getVendorsDetails[i].StoreName);
        uniqueStoreEmail.push(getVendorsDetails[i].StoreEmail);
      }
    }
    if (getVendorsDetails && getVendorsDetails.length > 0) {
      let parsePreviousStatusHistory = [];
      // const getPreviousRefundHistory = await connection.query(
      //   `SELECT StatusHistory FROM processorder WHERE OrderNumber = "${OrderNumber}" AND ProductID IN ${ ProductID } AND ProductVariantCombinationDetail IN ${ ProductCombinationsID } `,
      //   { type: QueryTypes.SELECT, transaction }
      // );
      // console.log(getPreviousRefundHistory,"getPreviousRefundHistory")
      // if (getPreviousRefundHistory && getPreviousRefundHistory.length > 0) {
      let LastUpdate = new Date().toISOString().slice(0, 19).replace("T", " ");
      parsePreviousStatusHistory = JSON.parse(
        getVendorsDetails[0].RefundStatusHistory
      );
      parsePreviousStatusHistory.push(LastUpdate);
      const getOrderDetails = await connection.query(
        `UPDATE processorder SET RefundStatus = "Processing", RefundStatusHistory = '${JSON.stringify(
          parsePreviousStatusHistory
        )} ' where OrderNumber="${OrderNumber}" AND ProcessOrderID IN ${ProcessOrderID}  `, {
        transaction
      }
      );
      if (getOrderDetails) {
        //! User Case
        const TypeID = "7";
        const CreaterID = "1";
        let Message = `Your Order # ${OrderNumber} refund receipt has been generated click to get details`;
        const userMailResponse = sendEmail(UserEmailAddress, Message, TypeID);
        if (userMailResponse) {
          let Body = {
            OrderNumber: OrderNumber,
            body: `Your Order # ${OrderNumber} refund receipt has been generated click to get details`,
            status: "Processing",
            type: type,
          };
          let ReceiverID = UserID;
          let sendNotification = await Notification(
            TypeID,
            Body,
            CreaterID,
            ReceiverID,
            transaction
          );
          console.log(sendNotification, "sendNotification");
          if (sendNotification) {
            for (let i = 0; i < uniqueStoreName.length; i++) {
              //! Vendor Case
              let ReceiverMailAdress = [];
              const VendorEmailAddress = uniqueVendorEmail[i];
              const VendorStoreEmailAddress = uniqueStoreEmail[i];
              if (
                VendorStoreEmailAddress === "NULL" ||
                VendorStoreEmailAddress === "null" ||
                VendorStoreEmailAddress === null ||
                VendorStoreEmailAddress === undefined
              ) {
                ReceiverMailAdress = uniqueVendorEmail[i];
              } else if (VendorEmailAddress == VendorStoreEmailAddress) {
                ReceiverMailAdress = uniqueVendorEmail[i];
              } else {
                ReceiverMailAdress = `${VendorEmailAddress},${VendorStoreEmailAddress}`;
              }
              console.log(ReceiverMailAdress, "ReceiverMailAdress at index", i);
              let Message = `Refund Request generated against Order # ${OrderNumber}  of Customer ${UserName} from Store ${uniqueStoreName[i]} click to get details`;
              const vendorMailResponse = sendEmail(
                ReceiverMailAdress,
                Message,
                TypeID
              );
              if (vendorMailResponse) {
                let Body = {
                  OrderNumber: OrderNumber,
                  body: `Refund Request generated against Order # ${OrderNumber} of Customer ${UserName} from Store ${uniqueStoreName[i]} click to get details`,
                  status: "Processing",
                  type: type,
                };
                let ReceiverID = uniqueVendorID[i];
                let sendNotificationToVendor = await Notification(
                  TypeID,
                  Body,
                  CreaterID,
                  ReceiverID,
                  transaction
                );
                if (sendNotificationToVendor) {
                  if (i === uniqueStoreName.length - 1) {
                    if (transaction) await transaction.commit();
                    res.status(200).json({
                      status: true,
                      message: "Successfully notified user and vendor about refund request",
                    });
                  } else {
                    continue;
                  }
                } else {
                  if (transaction) await transaction.rollback();
                  res.status(200).json({
                    status: false,
                    message: "Error while sending notifications to vendor",
                  });
                }
              } else {
                if (transaction) await transaction.rollback();
                res.status(200).json({
                  status: false,
                  message: "Error while sending mail to vendor",
                });
              }
            }
          } else {
            if (transaction) await transaction.rollback();
            res.status(200).json({
              status: false,
              message: "Error while sending notification to user",
            });
          }
        } else {
          if (transaction) await transaction.rollback();
          res.status(200).json({
            status: false,
            message: "Error while sending mail to user",
          });
        }
      } else {
        if (transaction) await transaction.rollback();
        res.status(200).json({
          status: false,
          message: "Error while updating process refund status to Processing",
        });
      }
      // } else {
      //   if (transaction) await transaction.rollback();
      //   res.status(200).json({
      //     status: false,
      //     message: "Error while getting detail from db",
      //   });
      // }
    } else {
      if (transaction) await transaction.rollback();
      res.status(200).json({
        status: false,
        message: "Error while getting detail from db",
      });
    }
  } catch (err) {
    if (transaction) await transaction.rollback();
    console.log(err.message, "-----------------------------");
    next(err);
    res.status(200).json({
      status: false,
      message: err.message,
    });
  }
};
exports.getRefundOrderDetailsByOrderID = async (req, res, next) => {
  try {
    const {
      status,
      type
    } = req.body;
    // let Region = req.region;
    // const currencyRate = req.currency_rate;
    let OrderNumber = req.params.id;
    let productCombinationPriceDetail = [];
    let viewOrderListQuery = `SELECT p.ProductID,p.Title,m.TransactionID,s.OrderNumber,s.AllowStorePickup,s.AllowAdminPickup,s.ReadyPickupForUser,s.ReadyPickupForAdmin,s.OrderDate,m.PaymentStatus,p.Price AS BasePrice,s.Quantity,p.Currency,s.UserID,g.Small,g.Medium,g.Large,i.MainImage,s.StatusHistory,s.ProcessStatus,s.DeliveryDriverID,s.ConsignmentId,m.OrderTotal,m.ShippingHandling,e.StoreName,e.Address1 AS StoreAddress,e.StorePhone,s.DeliveryStatus,s.TrackingNumber,s.ConsignmentId,s.ItemsPrice,s.ItemsEstimatedTax,s.ItemsShippingHandling,s.ProcessOrderID,s.DeliveryDriverID,m.GatewayID,s.VendorPaymentStatus,s.CourierID,s.ProductVariantCombinationDetail,pr.*,s.ReturnReason,s.RefundStatus,pf.UserName,pf.EmailAddress AS UserEmailAddress,pf.PhoneNumber AS UserPhoneNumber,od.Name AS DeliveryUserName,od.PhoneNumber AS DeliveryPhoneNumber,od.Address1 AS DeliveryAddress,od.Address2 AS DeliveryAddress2,e.City AS StoreCity,od.City AS DeliveryCity,e.StoreEmail,r.BusinessEmail,s.ReturnOrderStatus,s.PaymentType
        FROM ((((((((((((product p
          LEFT JOIN productvariantoption o ON o.ProductID IN( p.ProductID))
          LEFT JOIN productvariantoptionvalue v  ON  v.OptionID IN (o.OptionID))  
          LEFT JOIN productimage i  ON  i.OptionValueID IN (v.OptionValueID))
          LEFT JOIN imagegallery g  ON  g.ImageGalleryID IN (i.ImageGalleryID))
          LEFT JOIN productvariantcombination c  ON  c.OptionValueID IN (v.OptionValueID))
          LEFT JOIN processorder s ON s.ProductID IN(c.ProductID))
          LEFT JOIN orderdeliveryaddress od ON od.OrderNumber IN(s.OrderNumber))
          LEFT JOIN profile pf ON pf.UserID IN(s.UserID))
          LEFT JOIN processrefand pr ON pr.ProcessOrderID IN(s .ProcessOrderID))
          LEFT JOIN processpayment m ON m.OrderNumber IN(s.OrderNumber))
          LEFT JOIN vendorstore e ON (e.VendorStoreID=c.VendorStoreID))
          LEFT JOIN vendor r ON (r.VendorID=p.VendorID))
          WHERE i.MainImage='Y' AND s.OrderNumber="${OrderNumber}" AND s.RefundStatus ="${status}" AND p.FreeProductReturn="${type}"
          GROUP BY s.ProcessOrderID `;
    let viewOrderList = await connection.query(viewOrderListQuery, {
      type: QueryTypes.SELECT,
    });

    let productCombinationDetail;
    if (viewOrderList && viewOrderList.length > 0) {
      for (let i = 0; i < viewOrderList.length; i++) {
        let ProductVariantCombinationDetail = [];
        ProductVariantCombinationDetail.push(
          viewOrderList[i].ProductVariantCombinationDetail
        );
        ProductVariantCombinationDetail = `(${ProductVariantCombinationDetail.join(
          ","
        )})`;
        productCombinationDetail = await connection.query(
          `SELECT p.ProductID,c.ProductVariantCombinationID,c.VendorStoreID,c.Price AS ProductCombinationPrice,c.AvailableInventory,o.OptionID,o.OptionName,v.OptionValue,v.OptionValueID,p.Currency
              FROM ((((product p
              LEFT JOIN productvariantoption o ON o.ProductID IN( p.ProductID))
              LEFT JOIN productvariantoptionvalue v  ON  v.OptionID IN (o.OptionID)) 
              LEFT JOIN productvariantcombination c  ON  c.OptionValueID IN (v.OptionValueID))
              LEFT JOIN processorder s ON s.ProductID IN(c.ProductID))
              WHERE  c.ProductVariantCombinationID IN ${ProductVariantCombinationDetail}
              GROUP BY c.OptionValueID
             `, {
          type: QueryTypes.SELECT,
        }
        );
        productCombinationPriceDetail.push(productCombinationDetail);
      }
      let orderName = [];
      let orderDate = [];
      let paymentStatus = [];
      let transactionID = [];
      let tempPC = productCombinationPriceDetail;
      let tempProd = viewOrderList;
      let tempArray = [];
      let allowStorePickup = [];
      let readyPickupForUser = [];
      let readyPickupForAdmin = [];
      let allowAdminPickup = [];
      let statusHistory = [];
      let processStatus = [];
      let orderTotal = [];
      let shippingHandling = [];
      let tempAOrderDetails = [];
      let trackingNumber = [];
      let deliveryStatus = [];
      let consignmentId = [];
      for (let i = 0; i < tempProd.length; i++) {
        //!cuurency conversion
        var obj = {
          ...tempProd[i],
        };
        obj["ProductCombinations"] = tempPC[i];
        tempArray.push(obj);
      }
      for (let i = 0; i < tempArray.length; i++) {
        if (!orderName.includes(tempArray[i].OrderNumber)) {
          orderName.push(tempArray[i].OrderNumber);
          orderDate.push(tempArray[i].OrderDate);
          paymentStatus.push(tempArray[i].PaymentStatus);
          transactionID.push(tempArray[i].TransactionID);
          allowStorePickup.push(tempArray[i].AllowStorePickup);
          readyPickupForUser.push(tempArray[i].ReadyPickupForUser);
          readyPickupForAdmin.push(tempArray[i].ReadyPickupForAdmin);
          allowAdminPickup.push(tempArray[i].AllowAdminPickup);
          statusHistory.push(tempArray[i].StatusHistory);
          processStatus.push(tempArray[i].ProcessStatus);
          orderTotal.push(tempArray[i].OrderTotal);
          shippingHandling.push(tempArray[i].ShippingHandling);
          trackingNumber.push(tempArray[i].TrackingNumber);
          deliveryStatus.push(tempArray[i].DeliveryStatus);
          consignmentId.push(tempArray[i].ConsignmentId);
        }
      }

      for (let i = 0; i < orderName.length; i++) {
        var obj = {
          OrderNumber: orderName[i],
          OrderDate: orderDate[i],
          PaymentStatus: paymentStatus[i],
          TransactionID: transactionID[i],
          AllowStorePickup: allowStorePickup[i],
          ReadyPickupForUser: readyPickupForUser[i],
          ReadyPickupForAdmin: readyPickupForAdmin[i],
          AllowAdminPickup: allowAdminPickup[i],
          StatusHistory: statusHistory[i],
          ProcessStatus: processStatus[i],
          OrderTotal: orderTotal[i],
          ShippingHandling: shippingHandling[i],
          TrackingNumber: trackingNumber[i],
          DeliveryStatus: deliveryStatus[i],
          ConsignmentId: consignmentId[i],
          ProductDetail: [],
        };
        for (let j = 0; j < tempArray.length; j++) {
          if (orderName[i] === tempArray[j].OrderNumber) {
            obj.ProductDetail.push(tempArray[j]);
          }
        }
        tempAOrderDetails.push(obj);
      }
      if (productCombinationDetail && productCombinationDetail.length > 0) {
        res.status(200).json({
          status: true,
          refundOrderDetails: tempAOrderDetails[0],
        });
      } else {
        res.status(200).json({
          status: false,
          message: "Error whlile getting product combiation details",
        });
      }
    } else {
      res.status(200).json({
        status: true,
        refundOrderDetails: [],
      });
    }
  } catch (err) {
    console.log(err.message);
    next(err);
    res.status(200).json({
      status: false,
      refundOrderDetails: [],
      message: err.message,
    });
  }
};


exports.addUserPaymentAndAddress = addUserPaymentAndAddress;
