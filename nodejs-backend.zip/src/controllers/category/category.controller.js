const connection = require("../../db/db.connection");
const { QueryTypes } = require("sequelize");
const csvtojson = require("csvtojson");
//!Category CRUD
exports.addCategory = async (req, res, next) => {
  try {
    const { DepartmentID, Category, Description, ShippingGlobal, Active,ExpressDelivery } =
      req.body;
    CategoryPic = req.file.path;

    let checkIfDepartmentIDExists = await departmentIDCheck(DepartmentID);

    if (checkIfDepartmentIDExists && checkIfDepartmentIDExists == "1") {
      let checkIfCategoryNameExists = await CategoryNameCheck(Category);
      console.log(checkIfCategoryNameExists);
      if (checkIfCategoryNameExists && checkIfCategoryNameExists == "0") {
        let insertCategory = `insert into category ( DepartmentID , Category , Description,CategoryPic,ShippingGlobal, Active,ExpressDelivery) values (?,?,?,?,?,?,?)`;
        let addCategory = await connection.query(insertCategory, {
          replacements: [
            DepartmentID,
            Category,
            Description,
            CategoryPic,
            ShippingGlobal,
            Active,
	   ExpressDelivery
          ],
        });
        if (addCategory) {
          res.status(200).json({
            status: true,
            message: "Category added successfully",
          });
        } else {
          res.status(200).json({
            status: false,
            message: "Error while adding Category",
          });
        }
      } else if (
        checkIfCategoryNameExists &&
        checkIfCategoryNameExists == "1"
      ) {
        res.status(200).json({
          status: false,
          message: "Category Name already exists,Choose another",
          Category: [],
        });
      }
    } else if (checkIfDepartmentIDExists && checkIfDepartmentIDExists == "0") {
      res.status(200).json({
        status: false,
        message: "Department does not exist",
        Department: [],
      });
    }
  } catch (err) {
    console.log(err);
    res.status(200).json({
      status: false,
      Category: {},
      error: err.message,
    });
  }
};
let CategoryNameCheck = async (Category) => {
  try {
    let checkCategory = await connection.query(
      `select * from category where Category = '${Category}'`,
      {
        type: QueryTypes.SELECT,
      }
    );
    if (checkCategory && checkCategory.length > 0) {
      return "1";
    } else {
      return "0";
    }
  } catch (err) {
    console.log(err.message);
    return null;
  }
};
exports.viewCategoryById = async (req, res, next) => {
  try {
    let { limit, offset, DepartmentID } = req.body;
    limit = parseInt(limit);
    offset = parseInt(offset);
    offset = limit * offset;
    let CategoryCount = await connection.query(
      `SELECT COUNT(DepartmentID ) as total_records FROM category WHERE DepartmentID="${DepartmentID}"   `,
      {
        type: QueryTypes.SELECT,
      }
    );
    if (CategoryCount && CategoryCount.length > 0) {
      let data =
        `SELECT *  FROM category WHERE DepartmentID="${DepartmentID}" order by DepartmentID desc limit ` +
        limit +
        " offset " +
        offset;
      let allCategories = await connection.query(data, {
        type: QueryTypes.SELECT,
      });
      if (allCategories && allCategories.length > 0) {
        res.status(200).json({
          status: true,
          total_records: CategoryCount[0].total_records,
          Category: allCategories,
        });
      } else {
        res.status(200).json({
          status: true,
          total_records: CategoryCount[0].total_records,
          Category: [],
        });
      }
    }
  } catch (err) {
    next(err);
    res.status(200).json({
      status: false,
      profile: {},
      error: err.message,
    });
    console.log(err.message);
  }
};
exports.viewAllCategory = async (req, res, next) => {
  try {
    const { DepartmentID } = req.body;
    let viewAllCategory = await connection.query(
      `SELECT * FROM  category WHERE DepartmentID="${DepartmentID}" `,
      {
        type: QueryTypes.SELECT,
      }
    );
    if (viewAllCategory && viewAllCategory.length > 0) {
      res.status(200).json({
        status: true,
        Category: viewAllCategory,
      });
    } else {
      res.status(200).json({
        status: false,
        message: "No Category existss",
        Category: [],
      });
    }
  } catch (err) {
    next(err);
    res.status(200).json({
      status: false,
      profile: {},
      error: err.message,
    });
    console.log(err.message);
  }
};
exports.viewAllCategories = async (req, res, next) => {
  try {
    let viewAllCategory = await connection.query(`SELECT * FROM  category  `, {
      type: QueryTypes.SELECT,
    });
    if (viewAllCategory && viewAllCategory.length > 0) {
      res.status(200).json({
        status: true,
        Category: viewAllCategory,
      });
    } else {
      res.status(200).json({
        status: false,
        message: "No Category existss",
        Category: [],
      });
    }
  } catch (err) {
    next(err);
    res.status(200).json({
      status: false,
      profile: {},
      error: err.message,
    });
    console.log(err.message);
  }
};
let departmentIDCheck = async (DepartmentID) => {
  try {
    let departmentID = await connection.query(
      `select * from department where DepartmentID  = '${DepartmentID}'`,
      {
        type: QueryTypes.SELECT,
      }
    );
    if (departmentID && departmentID.length > 0) {
      return "1";
    } else {
      return "0";
    }
  } catch (err) {
    console.log(err.message);
    return null;
  }
};
exports.deleteCategoryById = async (req, res, next) => {
  try {
    const id = req.params.id;

    let checkCategory = await connection.query(
      `select * from category where CategoryID = "${id}" `,
      {
        type: QueryTypes.SELECT,
      }
    );
    if (checkCategory && checkCategory.length > 0) {
      let checkIfCategoryIDExists = await checkCateoryIDExistsInSubCategory(id);
      console.log(checkIfCategoryIDExists);
      if (checkIfCategoryIDExists && checkIfCategoryIDExists == "0") {
        let deleteCategory = await connection.query(
          `DELETE FROM category WHERE CategoryID="${id}" `,
          {
            type: QueryTypes.DELETE,
          }
        );
        res.status(200).json({
          status: true,
          message: `Category deleted successfully`,
        });
      } else if (checkIfCategoryIDExists && checkIfCategoryIDExists == "1") {
        console.log("*********");
        res.status(200).json({
          status: false,
          message: `SubCategory exists in this Category it cannot be deleted`,
        });
      }
    } else {
      console.log("*********");
      res.status(200).json({
        status: false,
        message: `Category does not exist`,
      });
    }
  } catch (err) {
    next(err);
    res.status(200).json({
      status: false,
      data: {},
      error: err.message,
    });
    console.log(err.message);
  }
};
let checkCateoryIDExistsInSubCategory = async (CategoryID) => {
  try {
    let category = await connection.query(
      `select * from subcategory where CategoryID  = '${CategoryID}'`,
      {
        type: QueryTypes.SELECT,
      }
    );
    if (category && category.length > 0) {
      return "1";
    } else {
      return "0";
    }
  } catch (err) {
    console.log(err.message);
    return null;
  }
};
exports.updateCategoryById = async (req, res, next) => {
  try {
    const id = req.params.id;
    console.log(id);
    const { DepartmentID, Category, Description, ShippingGlobal, Active,expressDelivery } =
      req.body;

    let LastUpdate = new Date().toISOString().slice(0, 19).replace("T", " ");

    var checkCategory = await connection.query(
      `select * from category where CategoryID = '${id}' `,
      {
        type: QueryTypes.SELECT,
      }
    );
    if (checkCategory && checkCategory.length > 0) {
      let checkIfDepartmentIDExists = await departmentIDCheck(DepartmentID);
      if (checkIfDepartmentIDExists && checkIfDepartmentIDExists == "1") {
        console.log(req.file);
        if (req.file && Object.keys(req.file).length > 0) {
          if (req.file.path && req.file.path.length > 0) {
            CategoryPic = req.file.path;
          } else {
            CategoryPic = checkCategory[0].CategoryPic;
          }
        } else {
          CategoryPic = checkCategory[0].CategoryPic;
        }
        //check for unique Category Name
        console.log(Category);
        console.log(checkCategory[0].Category);
        if (
          Category == checkCategory[0].Category &&
          DepartmentID == checkCategory[0].DepartmentID
        ) {
          let updateCategoryquery = `UPDATE category  SET DepartmentID = ?,Category=?,  Description = ?,CategoryPic=?, ShippingGlobal=?,ExpressDelivery=?, Active = ?,LastUpdate=? WHERE CategoryID  = "${checkCategory[0].CategoryID}"   `;
          let updateCategory = await connection.query(updateCategoryquery, {
            replacements: [
              DepartmentID,
              Category,
              Description,
              CategoryPic,
              ShippingGlobal,
	      expressDelivery,
              Active,
              LastUpdate,
            ],
          });
          if (updateCategory) {
            res.status(200).json({
              status: true,
              message: `Category updated successfully`,
            });
          } else {
            res.status(200).json({
              status: false,
              message: `Error while updating Category`,
            });
          }
        } else {
          let checkIFCategoryNameAlreadyExists = await connection.query(
            `select * from category  where Category  = "${Category}" AND DepartmentID ='${DepartmentID}'  `,
            {
              type: QueryTypes.SELECT,
            }
          );
          console.log(checkIFCategoryNameAlreadyExists);
          if (
            checkIFCategoryNameAlreadyExists &&
            checkIFCategoryNameAlreadyExists.length > 0
          ) {
            res.status(200).json({
              status: false,
              Category: {},
              message: `Category Name already taken, please select another one`,
            });
          } else {
            let updateCategoryquery = `UPDATE category  SET DepartmentID = ?,Category=?,  Description = ?,CategoryPic=?, ShippingGlobal=?, Active = ?,LastUpdate=? WHERE CategoryID  = "${checkCategory[0].CategoryID}"   `;
            let updateCategory = await connection.query(updateCategoryquery, {
              replacements: [
                DepartmentID,
                Category,
                Description,
                CategoryPic,
                ShippingGlobal,
                Active,
                LastUpdate,
              ],
            });
            if (updateCategory && updateCategory.length > 0) {
              res.status(200).json({
                status: true,
                message: `Category updated successfully`,
              });
            } else {
              res.status(200).json({
                status: false,
                message: `Error while updating Category `,
              });
            }
          }
        }
      } else if (
        checkIfDepartmentIDExists &&
        checkIfDepartmentIDExists == "0"
      ) {
        res.status(200).json({
          status: false,
          message: "Department does not exist",
          Department: [],
        });
      }
    } else {
      res.status(200).json({
        status: false,
        message: `Category does not exist`,
      });
    }
  } catch (err) {
    next(err);
    console.log(err.message);
    res.status(200).json({
      status: false,
      profile: {},
      error: err.message,
    });
  }
};
//!Subcategory CRUD
exports.addSubCategory = async (req, res, next) => {
  try {
    const { CategoryID, SubCategory, Description, ShippingGlobal, Active } =
      req.body;
    console.log(CategoryID);
    SubCategoryPic = req.file.path;
    console.log(SubCategoryPic);

    let checkIfCategoryIDExists = await categoryIDCheck(CategoryID);
    console.log(checkIfCategoryIDExists);

    if (checkIfCategoryIDExists && checkIfCategoryIDExists == "1") {
      let checkIfSubCategoryNameExists = await subCategoryNameCheck(
        SubCategory,
        CategoryID
      );
      console.log(checkIfSubCategoryNameExists);
      if (checkIfSubCategoryNameExists && checkIfSubCategoryNameExists == "0") {
        let insertCategory = `insert into subcategory ( CategoryID , SubCategory , Description,SubCategoryPic,ShippingGlobal,Active) values (?,?,?,?,?,?)`;
        let addCategory = await connection.query(insertCategory, {
          replacements: [
            CategoryID,
            SubCategory,
            Description,
            SubCategoryPic,
            ShippingGlobal,
            Active,
          ],
        });
        if (addCategory && addCategory.length > 0) {
          res.status(200).json({
            status: true,
            message: "SubCategory added successfully",
          });
        } else {
          res.status(200).json({
            status: false,
            message: "Error while adding SubCategory",
          });
        }
      } else if (
        checkIfSubCategoryNameExists &&
        checkIfSubCategoryNameExists == "1"
      ) {
        res.status(200).json({
          status: false,
          message:
            "SubCategory Name already exists against this Category,Choose another category",
          SubCategory: [],
        });
      }
    } else if (checkIfCategoryIDExists && checkIfCategoryIDExists == "0") {
      res.status(200).json({
        status: false,
        message: "Category does not exist",
        Category: [],
      });
    }
  } catch (err) {
    console.log(err);
    res.status(200).json({
      status: false,
      Category: {},
      error: err.message,
    });
  }
};
let subCategoryNameCheck = async (SubCategory, CategoryID) => {
  try {
    let checkSubCategory = await connection.query(
      `select * from subcategory where SubCategory = '${SubCategory}' AND CategoryID='${CategoryID}'`,
      {
        type: QueryTypes.SELECT,
      }
    );
    if (checkSubCategory && checkSubCategory.length > 0) {
      return "1";
    } else {
      return "0";
    }
  } catch (err) {
    console.log(err.message);
    return null;
  }
};
let categoryIDCheck = async (CategoryID) => {
  try {
    let CategoryIDcheck = await connection.query(
      `select * from category where CategoryID  = '${CategoryID}'`,
      {
        type: QueryTypes.SELECT,
      }
    );
    if (CategoryIDcheck && CategoryIDcheck.length > 0) {
      return "1";
    } else {
      return "0";
    }
  } catch (err) {
    console.log(err.message);
    return null;
  }
};
exports.viewSubCategoryById = async (req, res, next) => {
  try {
    let { limit, offset, CategoryID } = req.body;
    limit = parseInt(limit);
    offset = parseInt(offset);
    offset = limit * offset;
    let SubCategoryCount = await connection.query(
      `SELECT COUNT(CategoryID) as total_records FROM subcategory WHERE CategoryID="${CategoryID}"   `,
      {
        type: QueryTypes.SELECT,
      }
    );
    if (SubCategoryCount && SubCategoryCount.length > 0) {
      let data =
        `SELECT *  FROM subcategory WHERE CategoryID="${CategoryID}"  order by CategoryID desc limit ` +
        limit +
        " offset " +
        offset;
      let allSubCategories = await connection.query(data, {
        type: QueryTypes.SELECT,
      });
      if (allSubCategories && allSubCategories.length > 0) {
        res.status(200).json({
          status: true,
          total_records: SubCategoryCount[0].total_records,
          SubCategory: allSubCategories,
        });
      } else {
        res.status(200).json({
          status: true,
          total_records: SubCategoryCount[0].total_records,
          SubCategory: [],
        });
      }
    }
  } catch (err) {
    next(err);
    res.status(200).json({
      status: false,
      profile: {},
      error: err.message,
    });
    console.log(err.message);
  }
};
exports.viewAllSubCategoryById = async (req, res, next) => {
  try {
    let subCategoryDetails = await connection.query(
      `SELECT *  FROM subcategory WHERE CategoryID='${req.params.id}' `,
      {
        type: QueryTypes.SELECT,
      }
    );

    if (subCategoryDetails && subCategoryDetails.length > 0) {
      res.status(200).json({
        status: true,
        SubCategory: subCategoryDetails,
      });
    } else {
      res.status(200).json({
        status: false,
        message: "SubCategory does not exist against this Category",
        SubCategory: [],
      });
    }
  } catch (err) {
    next(err);
    res.status(200).json({
      status: false,
      profile: {},
      error: err.message,
    });
    console.log(err.message);
  }
};
exports.getVendorSubcategoryUpdated = async (req, res, next) => {
  try {
    let viewVendorSubCategory = await connection.query(
      `
          SELECT  s.SubCategoryPic,CONCAT(c.Category, ' -> ', s.SubCategory) AS SubCategory,s.SubCategoryID
          FROM category c 
          INNER JOIN subcategory s ON s.CategoryID = c.CategoryID
          ORDER BY c.Category,s.Subcategory`,
      {
        type: QueryTypes.SELECT,
      }
    );
    //console.log(viewVendorSubCategory, "viewVendorSubCategory");
    if (viewVendorSubCategory && viewVendorSubCategory.length > 0) {
      res.status(200).json({
        status: true,
        SubCategory: viewVendorSubCategory,
      });
    } else {
      res.status(200).json({
        status: false,
        message: "Vendor SubCategory does not exist for this Vendor",
        SubCategory: [],
      });
    }
  } catch (err) {
    console.log(err);
    res.status(200).json({
      status: false,
      SubCategory: [],
      error: err.message,
    });
  }
};
exports.viewAllSubCategory = async (req, res, next) => {
  try {
    let subCategoryDetails = await connection.query(
      `SELECT *  FROM subcategory  `,
      {
        type: QueryTypes.SELECT,
      }
    );

    if (subCategoryDetails && subCategoryDetails.length > 0) {
      res.status(200).json({
        status: true,
        SubCategory: subCategoryDetails,
      });
    } else {
      res.status(200).json({
        status: false,
        message: "SubCategory does not exist",
        SubCategory: [],
      });
    }
  } catch (err) {
    next(err);
    res.status(200).json({
      status: false,
      profile: {},
      error: err.message,
    });
    console.log(err.message);
  }
};
//!here two checks are yet to be added one check if subcategory exists in products and second for exists in vendorsubcategory in deletesubcategory api
exports.deleteSubCategoryById = async (req, res, next) => {
  try {
    const id = req.params.id;
    console.log(id);

    let checkSubCategory = await connection.query(
      `select * from subcategory where SubCategoryID = "${id}" `,
      {
        type: QueryTypes.SELECT,
      }
    );
    if (checkSubCategory && checkSubCategory.length > 0) {
      console.log("--------------");
      let checkIfSubCategoryExistsinVariant = await checkSubCategoryIDInVariant(
        id
      );
      console.log(checkIfSubCategoryExistsinVariant);
      if (
        checkIfSubCategoryExistsinVariant &&
        checkIfSubCategoryExistsinVariant == "0"
      ) {
        let deleteSubCategory = await connection.query(
          `DELETE FROM subcategory WHERE SubCategoryID="${id}" `,
          {
            type: QueryTypes.DELETE,
          }
        );
        res.status(200).json({
          status: true,
          message: `Subcategory deleted successfully`,
        });
      } else if (
        checkIfSubCategoryExistsinVariant &&
        checkIfSubCategoryExistsinVariant == "1"
      ) {
        console.log("*********");
        res.status(200).json({
          status: false,
          message: `SubCategoryVariant exists in this SubCategory it cannot be deleted`,
        });
      }
    } else {
      console.log("*********");
      res.status(200).json({
        status: false,
        message: `Subcategory does not exist`,
      });
    }
  } catch (err) {
    next(err);
    res.status(200).json({
      status: false,
      data: {},
      error: err.message,
    });
    console.log(err.message);
  }
};
let checkSubCategoryIDInVariant = async (SubCategoryID) => {
  try {
    let user = await connection.query(
      `select * from subcategoryvariant where SubCategoryID  = '${SubCategoryID}'`,
      {
        type: QueryTypes.SELECT,
      }
    );
    console.log(user);
    if (user && user.length > 0) {
      return "1";
    } else {
      return "0";
    }
  } catch (error) {
    return null;
  }
};
exports.updateSubCategoryById = async (req, res, next) => {
  try {
    const id = req.params.id;
    console.log(id);
    const { CategoryID, SubCategory, Description, ShippingGlobal, Active } =
      req.body;

    let LastUpdate = new Date().toISOString().slice(0, 19).replace("T", " ");

    var checkSubCategory = await connection.query(
      `select * from subcategory where SubCategoryID = '${id}' `,
      {
        type: QueryTypes.SELECT,
      }
    );
    if (checkSubCategory && checkSubCategory.length > 0) {
      let checkIfCategoryIDExists = await categoryIDCheck(CategoryID);
      console.log(checkIfCategoryIDExists);
      if (checkIfCategoryIDExists && checkIfCategoryIDExists == "1") {
        console.log(req.file);
        if (req.file && Object.keys(req.file).length > 0) {
          if (req.file.path && req.file.path.length > 0) {
            SubCategoryPic = req.file.path;
          } else {
            SubCategoryPic = checkSubCategory[0].SubCategoryPic;
          }
        } else {
          SubCategoryPic = checkSubCategory[0].SubCategoryPic;
        }
        //check for unique Category Name
        console.log(SubCategory);
        console.log(checkSubCategory[0].SubCategory);
        console.log(CategoryID);
        console.log(checkSubCategory[0].CategoryID);
        if (
          SubCategory == checkSubCategory[0].SubCategory &&
          CategoryID == checkSubCategory[0].CategoryID
        ) {
          let updateSubCategoryquery = `UPDATE subcategory  SET CategoryID = ?,SubCategory=?,  Description = ?,SubCategoryPic=?, ShippingGlobal=?, Active = ?,LastUpdate=? WHERE SubCategoryID  = "${checkSubCategory[0].SubCategoryID}"   `;
          let updateSubCategory = await connection.query(
            updateSubCategoryquery,
            {
              replacements: [
                CategoryID,
                SubCategory,
                Description,
                SubCategoryPic,
                ShippingGlobal,
                Active,
                LastUpdate,
              ],
            }
          );
          if (updateSubCategory && updateSubCategory.length > 0) {
            res.status(200).json({
              status: true,
              message: `SubCategory updated successfully`,
            });
          } else {
            res.status(200).json({
              status: false,
              message: `Error while updating SubCategory`,
            });
          }
        } else {
          let checkIFSubCategoryNameAlreadyExists = await connection.query(
            `select * from subcategory  where SubCategory  = '${SubCategory}' AND CategoryID='${CategoryID}'`,
            {
              type: QueryTypes.SELECT,
            }
          );
          console.log(checkIFSubCategoryNameAlreadyExists);
          if (
            checkIFSubCategoryNameAlreadyExists &&
            checkIFSubCategoryNameAlreadyExists.length > 0
          ) {
            res.status(200).json({
              status: false,
              Category: {},
              message: `SubCategory Name already exists against this Category,Choose another category`,
            });
          } else {
            let updateSubCategoryquery = `UPDATE subcategory  SET CategoryID = ?,SubCategory=?,  Description = ?,SubCategoryPic=?, ShippingGlobal=?, Active = ?,LastUpdate=? WHERE SubCategoryID  = "${checkSubCategory[0].SubCategoryID}"   `;
            let updateSubCategory = await connection.query(
              updateSubCategoryquery,
              {
                replacements: [
                  CategoryID,
                  SubCategory,
                  Description,
                  SubCategoryPic,
                  ShippingGlobal,
                  Active,
                  LastUpdate,
                ],
              }
            );
            if (updateSubCategory && updateSubCategory.length > 0) {
              res.status(200).json({
                status: true,
                message: `SubCategory updated successfully`,
              });
            } else {
              res.status(200).json({
                status: false,
                message: `Error while updating SubCategory `,
              });
            }
          }
        }
      } else if (checkIfCategoryIDExists && checkIfCategoryIDExists == "0") {
        res.status(200).json({
          status: false,
          message: "Category does not exist",
          Category: [],
        });
      }
    } else {
      res.status(200).json({
        status: false,
        message: `SubCategory does not exist`,
        SubCategory: [],
      });
    }
  } catch (err) {
    next(err);
    console.log(err.message);
    res.status(200).json({
      status: false,
      profile: {},
      error: err.message,
    });
  }
};
//!GET All Categories And SubCategories Api

exports.viewAllCategoriesANDSubcategories = async (req, res, next) => {
  try {
    let viewActiveCategoryAndSubCategoryQuery = `
      SELECT c.*, s.SubCategoryID, s.SubCategory, s.Description AS SubCategory_Description, s.SubCategoryPic,
             s.ShippingGlobal AS SubCategory_ShippingGlobal, s.Active AS SubCategory_Active, s.LastUpdate AS SubCategory_LastUpdate
      FROM category c
      INNER JOIN subcategory s ON s.CategoryID = c.CategoryID
      WHERE c.Active = 'Y'
      ORDER BY c.Category ASC
    `;

    let viewActiveCategoryAndSubCategory = await connection.query(
      viewActiveCategoryAndSubCategoryQuery,
      {
        type: QueryTypes.SELECT,
      }
    );

    let categoriesMap = new Map();

    for (const row of viewActiveCategoryAndSubCategory) {
      let {
        CategoryID,
        DepartmentID,
        Category,
        Description,
        CategoryPic,
        ShippingGlobal,
        Active,
        LastUpdate,
        SubCategoryID,
        SubCategory,
        SubCategory_Description,
        SubCategoryPic,
        SubCategory_ShippingGlobal,
        SubCategory_Active,
        SubCategory_LastUpdate,
      } = row;

      if (!categoriesMap.has(CategoryID)) {
        categoriesMap.set(CategoryID, {
          CategoryID,
          DepartmentID,
          Category,
          Description,
          CategoryPic,
          ShippingGlobal,
          Active,
          LastUpdate,
          SubCategories: [],
        });
      }

      categoriesMap.get(CategoryID).SubCategories.push({
        SubCategoryID,
        SubCategory,
        SubCategory_Description,
        SubCategoryPic,
        SubCategory_ShippingGlobal,
        SubCategory_Active,
        SubCategory_LastUpdate,
      });
    }

    const activeCategoriesAndSubCategories = [...categoriesMap.values()];


    if (activeCategoriesAndSubCategories.length > 0) {
      res.status(200).json({
        status: true,
        categoriesAndSubCategories: activeCategoriesAndSubCategories,
      });
    } else {
      res.status(200).json({
        status: true,
        categoriesAndSubCategories: [],
      });
    }
  } catch (err) {
    console.log(err.message);
    res.status(500).json({
      status: false,
      error: err.message,
    });
  }
};
exports.adOldviewAllCategoriesANDSubcategories = async (req, res, next) => {
  try {
    let viewAllCategoryAndSubCategoryQuery = `SELECT c.*,s.SubCategoryID,s.SubCategory,s.Description AS SubCategory_Description,s.SubCategoryPic,s.ShippingGlobal AS SubCategory_ShippingGlobal,s.Active AS SubCategory_Active,s.LastUpdate AS SubCategory_LastUpdate
        FROM (category c
        INNER JOIN subcategory s ON  s.CategoryID IN (c.CategoryID))
        order by c.CategoryID desc
         `;
    let viewAllCategoryAndSubCategory = await connection.query(
      viewAllCategoryAndSubCategoryQuery,
      {
        type: QueryTypes.SELECT,
      }
    );
    let tempSubCategoryDetails = [];
    let CategoryData = [];
    let SubCategoryValues = [];
    for (let i = 0; i < viewAllCategoryAndSubCategory.length; i++) {
      let {
        CategoryID,
        DepartmentID,
        Category,
        Description,
        CategoryPic,
        ShippingGlobal,
        Active,
        LastUpdate,
      } = viewAllCategoryAndSubCategory[i];
      CategoryData[i] = {
        CategoryID,
        DepartmentID,
        Category,
        Description,
        CategoryPic,
        ShippingGlobal,
        Active,
        LastUpdate,
      };
    }
    let CategoriesData = [];
    let CategoriesDetails = [];
    /* let CategoriesDepartment = []
    let CategoriesName = []
    let CategoriesDescription = []
    let CategoriesPic = [] */
    for (let i = 0; i < viewAllCategoryAndSubCategory.length; i++) {
      if (!CategoriesData.includes(CategoryData[i].CategoryID)) {
        CategoriesData.push(CategoryData[i].CategoryID);
        CategoriesDetails.push(CategoryData[i]);
        /*  CategoriesDepartment.push(CategoryData[i].DepartmentID)
        CategoriesName.push(CategoryData[i].Category)
        CategoriesDescription.push(CategoryData[i].Description)
        CategoriesPic.push(CategoryData[i].CategoriesPic)
         */
      }
    }
    for (let i = 0; i < CategoriesData.length; i++) {
      var obj = {
        CategoryDetails: CategoriesDetails[i],
        /*   DepartmentID: CategoriesDepartment[i],
          Category: CategoriesName[i],
          Description: CategoriesDescription[i],
          CategoryPic: CategoriesPic[i], */
        SubCategoryDetails: [],
      };
      let tempArray = [];
      for (let j = 0; j < viewAllCategoryAndSubCategory.length; j++) {
        let {
          CategoryID,
          SubCategoryID,
          SubCategory,
          SubCategory_Description,
          SubCategoryPic,
          SubCategory_ShippingGlobal,
          SubCategory_Active,
          SubCategory_LastUpdate,
        } = viewAllCategoryAndSubCategory[j];
        SubCategoryValues[i] = {
          SubCategoryID,
          SubCategory,
          SubCategory_Description,
          SubCategoryPic,
          SubCategory_ShippingGlobal,
          SubCategory_Active,
          SubCategory_LastUpdate,
        };
        if (CategoryID === CategoriesData[i]) {
          tempArray.push(SubCategoryValues[i]);
        }
      }
      obj.SubCategoryDetails = tempArray;
      tempSubCategoryDetails.push(obj);
    }
    if (
      viewAllCategoryAndSubCategory &&
      viewAllCategoryAndSubCategory.length > 0
    ) {
      res.status(200).json({
        status: true,
        categoriesAndSubCategories: tempSubCategoryDetails,
      });
    } else {
      res.status(200).json({
        status: true,
        Categories: [],
      });
    }
  } catch (err) {
    console.log(err.message);
    res.status(200).json({
      status: false,
      Categories: {},
      error: err.message,
    });
    console.log(err.message);
  }
};
exports.viewDepartmentsAllCategoriesANDSubcategories = async (req, res, next) => {
  try {
    let viewAllCategoryAndSubCategoryQuery = `
      SELECT
        d.DepartmentID,
        d.Department,
        c.CategoryID,
        c.Category,
        c.*,
        s.SubCategoryID,
        s.SubCategory,
        s.Description AS SubCategory_Description,
        s.SubCategoryPic,
        s.ShippingGlobal AS SubCategory_ShippingGlobal,
        s.Active AS SubCategory_Active,
        s.LastUpdate AS SubCategory_LastUpdate
      FROM
        department d
        INNER JOIN category c ON d.DepartmentID = c.DepartmentID
        INNER JOIN subcategory s ON c.CategoryID = s.CategoryID
      WHERE
        d.Active = 'Y' AND
        c.Active = 'Y' AND
        s.Active = 'Y'
      ORDER BY
        d.Department ASC, c.Category ASC, s.SubCategory ASC;
    `;

    let rawResults = await connection.query(
      viewAllCategoryAndSubCategoryQuery,
      {
        type: QueryTypes.SELECT,
      }
    );

    // Process the raw results to structure the data
    let structuredResults = [];
    let currentDepartment = null;
    let currentCategory = null;

    for (let row of rawResults) {
      if (!currentDepartment || currentDepartment.DepartmentID !== row.DepartmentID) {
        currentDepartment = {
          DepartmentID: row.DepartmentID,
          Department: row.Department,
          Categories: [],
        };
        structuredResults.push(currentDepartment);
      }

      if (!currentCategory || currentCategory.CategoryID !== row.CategoryID) {
        currentCategory = {
          CategoryID: row.CategoryID,
          Category: row.Category,
          Category_Details: { ...row }, // Include all category columns
          SubCategories: [],
        };
        currentDepartment.Categories.push(currentCategory);
      }

      if (row.SubCategory_Active === 'Y') { // Filter for active subcategories
        currentCategory.SubCategories.push({
          SubCategoryID: row.SubCategoryID,
          SubCategory: row.SubCategory,
          SubCategory_Description: row.SubCategory_Description,
          SubCategoryPic: row.SubCategoryPic,
          SubCategory_ShippingGlobal: row.SubCategory_ShippingGlobal,
          SubCategory_Active: row.SubCategory_Active,
          SubCategory_LastUpdate: row.SubCategory_LastUpdate,
        });
      }
    }

    // Send the response with the structured data
    res.json({
      status: true,
      departmentsDetails: structuredResults,
    });
  } catch (err) {
    console.log(err.message);
    res.status(500).json({
      status: false,
      error: err.message,
    });
  }
};
//!Subcategory Variant CRUD
exports.insertSubCategoryVariant = async (req, res, next) => {
  try {
    const { SubCategoryID, Variant } = req.body;
    let checkIfSubCategoryExists = await SubcategoryIDCheck(SubCategoryID);
    console.log(checkIfSubCategoryExists);
    if (checkIfSubCategoryExists && checkIfSubCategoryExists == "1") {
      let checkIfVariantNameExists = await checkSubCategoryVariantName(
        SubCategoryID,
        Variant
      );
      console.log(checkIfVariantNameExists);
      if (checkIfVariantNameExists && checkIfVariantNameExists == "0") {
        let insertSubCategoryVariantQuery = `insert into subcategoryvariant ( SubCategoryID ,Variant) values (?,?)`;
        let insertSubCategoryVariant = await connection.query(
          insertSubCategoryVariantQuery,
          {
            replacements: [SubCategoryID, Variant],
          }
        );
        if (insertSubCategoryVariant) {
          res.status(200).json({
            status: true,
            message: "SubCategory Variant added successfully",
          });
        } else {
          res.status(200).json({
            status: false,
            message: "Error while SubCategory Variant Option",
          });
        }
      } else if (checkIfVariantNameExists && checkIfVariantNameExists == "1") {
        res.status(200).json({
          status: false,
          message: "Variant Name already exist",
          Variant: [],
        });
      }
    } else if (checkIfSubCategoryExists && checkIfSubCategoryExists == "0") {
      res.status(200).json({
        status: false,
        message: "SubCategory does not exist",
        SubCategory: [],
      });
    }
  } catch (err) {
    next(err);
    res.status(200).json({
      status: false,
      Category: {},
      error: err.message,
    });
  }
};
let checkSubCategoryVariantName = async (SubCategoryID, Variant) => {
  try {
    let checkSubCategoryVariantNameExist = await connection.query(
      `select * from subcategoryvariant where SubCategoryID  = '${SubCategoryID}' AND Variant = '${Variant}'`,
      {
        type: QueryTypes.SELECT,
      }
    );
    console.log(checkSubCategoryVariantNameExist);
    if (
      checkSubCategoryVariantNameExist &&
      checkSubCategoryVariantNameExist.length > 0
    ) {
      return "1";
    } else {
      return "0";
    }
  } catch (error) {
    console.log(error);
    return null;
  }
};
let SubcategoryIDCheck = async (SubCategoryID) => {
  try {
    let subCategoryIDcheck = await connection.query(
      `select * from subcategory where SubCategoryID  = '${SubCategoryID}'`,
      {
        type: QueryTypes.SELECT,
      }
    );
    if (subCategoryIDcheck && subCategoryIDcheck.length > 0) {
      return "1";
    } else {
      return "0";
    }
  } catch (err) {
    console.log(err.message);
    return null;
  }
};
exports.viewSubCategoryVariantById = async (req, res, next) => {
  try {
    const id = req.params.id;
    console.log("---------------", id);
    let viewSubCategoryVariantQuery = `SELECT  c.*,s.SubCategory AS SubCategoryName
                FROM ( subcategoryvariant c
                INNER JOIN subcategory  s ON c.SubCategoryID  = s.SubCategoryID )
                WHERE c.SubCategoryID=${id}`;
    let viewSubCategoryVariant = await connection.query(
      viewSubCategoryVariantQuery,
      {
        type: QueryTypes.SELECT,
      }
    );
    if (viewSubCategoryVariant && viewSubCategoryVariant.length > 0) {
      res.status(200).json({
        status: true,
        SubCategoryVariant: viewSubCategoryVariant,
      });
    } else {
      res.status(200).json({
        status: false,
        message: "No SubCategory Variant found",
        SubCategoryVariant: [],
      });
    }
  } catch (err) {
    console.log(err)
    res.status(200).json({
      status: false,
      profile: {},
      error: err.message,
    });
  }
};
exports.deleteSubCategoryVariantById = async (req, res, next) => {
  try {
    const id = req.params.id;
    console.log(id);

    let CheckSubCategoryVariant = await connection.query(
      `select * from subcategoryvariant where SubCategoryVariantID = "${id}" `,
      {
        type: QueryTypes.SELECT,
      }
    );
    if (CheckSubCategoryVariant && CheckSubCategoryVariant.length > 0) {
      console.log("--------------");

      let deleteSubCategoryVariant = await connection.query(
        `DELETE FROM subcategoryvariant WHERE SubCategoryVariantID="${id}" `,
        {
          type: QueryTypes.DELETE,
        }
      );
      res.status(200).json({
        status: true,
        message: `SubCategory variant deleted successfully`,
      });
    } else {
      console.log("*********");
      res.status(200).json({
        status: false,
        message: `SubCategory variant does not exist`,
      });
    }
  } catch (err) {
    next(err);
    res.status(200).json({
      status: false,
      data: {},
      error: err.message,
    });
    console.log(err.message);
  }
};
exports.updateSubCategoryVariantById = async (req, res, next) => {
  try {
    var SubCategoryVariantID = req.params.id;
    console.log(SubCategoryVariantID);
    const { SubCategoryID, Variant } = req.body;

    var checkSubCategoryVariant = await connection.query(
      `select * from subcategoryvariant where SubCategoryVariantID = '${SubCategoryVariantID}' `,
      {
        type: QueryTypes.SELECT,
      }
    );
    if (checkSubCategoryVariant && checkSubCategoryVariant.length > 0) {
      let checkIfSubCategoryIDExists = await SubcategoryIDCheck(SubCategoryID);
      if (checkIfSubCategoryIDExists && checkIfSubCategoryIDExists == "1") {
        //check for unique variant Name

        if (
          Variant == checkSubCategoryVariant[0].Variant &&
          SubCategoryID == checkSubCategoryVariant[0].SubCategoryID
        ) {
          let upateSubCategoryVariantQuery = `UPDATE subcategoryvariant  SET SubCategoryID = ?,Variant=?  WHERE SubCategoryVariantID  = "${checkSubCategoryVariant[0].SubCategoryVariantID}"   `;
          let upateSubCategoryVariant = await connection.query(
            upateSubCategoryVariantQuery,
            {
              replacements: [SubCategoryID, Variant],
            }
          );
          if (upateSubCategoryVariant && upateSubCategoryVariant.length > 0) {
            res.status(200).json({
              status: true,
              message: `SubCategory Variant  updated successfully`,
            });
          } else {
            res.status(200).json({
              status: false,
              message: `Error while updating SubCategory Variant `,
            });
          }
        } else {
          let checkIFVariantNameAlreadyExists = await connection.query(
            `select * from subcategoryvariant  where Variant  = "${Variant}" AND SubCategoryID ='${SubCategoryID}'  `,
            {
              type: QueryTypes.SELECT,
            }
          );
          console.log(checkIFVariantNameAlreadyExists);
          if (
            checkIFVariantNameAlreadyExists &&
            checkIFVariantNameAlreadyExists.length > 0
          ) {
            res.status(200).json({
              status: false,
              Category: {},
              message: `Variant Name already taken, please select another one`,
            });
          } else {
            let upateSubCategoryVariantQuery = `UPDATE subcategoryvariant  SET SubCategoryID = ?,Variant=?  WHERE SubCategoryVariantID  = "${checkSubCategoryVariant[0].SubCategoryVariantID}"   `;
            let upateSubCategoryVariant = await connection.query(
              upateSubCategoryVariantQuery,
              {
                replacements: [SubCategoryID, Variant],
              }
            );
            if (upateSubCategoryVariant && upateSubCategoryVariant.length > 0) {
              res.status(200).json({
                status: true,
                message: `SubCategory Variant updated successfully`,
              });
            } else {
              res.status(200).json({
                status: false,
                message: `Error while updating SubCategory Variant  `,
              });
            }
          }
        }
      } else if (
        checkIfSubCategoryIDExists &&
        checkIfSubCategoryIDExists == "0"
      ) {
        res.status(200).json({
          status: false,
          message: "SubCategory does not exist",
          SubCategory: [],
        });
      }
    } else {
      res.status(200).json({
        status: false,
        message: `Sub Category Variant does not exist`,
        SubCategoryVariant: [],
      });
    }
  } catch (err) {
    next(err);
    console.log(err.message);
    res.status(200).json({
      status: false,
      profile: {},
      error: err.message,
    });
  }
};
//!Subcategory Variant Value CRUD
exports.insertSubCategoryVariantValue = async (req, res, next) => {
  try {
    var { SubCategoryVariantID, VariantValue } = req.body;

    let checkSubCategoryVariantIDExists = await checkSubCategoryVariantID(
      SubCategoryVariantID
    );
    console.log(checkSubCategoryVariantIDExists);
    if (
      checkSubCategoryVariantIDExists &&
      checkSubCategoryVariantIDExists == "1"
    ) {
      let checkSubCategoryVariantValueExists =
        await checkIfSubCategoryVariantValue(
          SubCategoryVariantID,
          VariantValue
        );
      console.log(checkSubCategoryVariantValueExists);
      if (
        checkSubCategoryVariantValueExists &&
        checkSubCategoryVariantValueExists == "0"
      ) {
        let insertProductVariantOptionQuery = `insert into subcategoryvariantvalue ( SubCategoryVariantID  ,VariantValue ) values (?,?)`;
        let insertProductVariantOption = await connection.query(
          insertProductVariantOptionQuery,
          {
            replacements: [SubCategoryVariantID, VariantValue],
          }
        );
        if (insertProductVariantOption) {
          res.status(200).json({
            status: true,
            message: "SubCategory Variant value added successfully",
          });
        } else {
          res.status(200).json({
            status: false,
            message: "Error while adding SubCategory Variant value Option",
          });
        }
      } else if (
        checkSubCategoryVariantValueExists &&
        checkSubCategoryVariantValueExists == "1"
      ) {
        res.status(200).json({
          status: false,
          message:
            "SubCategory Variant Value already exist against this Variant",
          SubCategoryVariant: [],
        });
      }
    } else if (
      checkSubCategoryVariantIDExists &&
      checkSubCategoryVariantIDExists == "0"
    ) {
      res.status(200).json({
        status: false,
        message: "SubCategory Variant does not exist",
        SubCategoryVariant: [],
      });
    }
  } catch (err) {
    next(err);
    res.status(200).json({
      status: false,
      Category: {},
      error: err.message,
    });
  }
};
let checkIfSubCategoryVariantValue = async (
  SubCategoryVariantID,
  VariantValue
) => {
  try {
    let checkSubCategoryVariantValueExists = await connection.query(
      `select * from subcategoryvariantvalue where SubCategoryVariantID  = '${SubCategoryVariantID}' AND VariantValue = '${VariantValue}'`,
      {
        type: QueryTypes.SELECT,
      }
    );
    console.log(checkSubCategoryVariantValueExists);
    if (
      checkSubCategoryVariantValueExists &&
      checkSubCategoryVariantValueExists.length > 0
    ) {
      return "1";
    } else {
      return "0";
    }
  } catch (error) {
    console.log(error);
    return null;
  }
};
let checkSubCategoryVariantID = async (SubCategoryVariantID) => {
  try {
    let user = await connection.query(
      `select * from subcategoryvariant where SubCategoryVariantID = '${SubCategoryVariantID}'`,
      {
        type: QueryTypes.SELECT,
      }
    );
    console.log(user);
    if (user && user.length > 0) {
      return "1";
    } else {
      return "0";
    }
  } catch (error) {
    return null;
  }
};
exports.viewSubCategoryVariantValueById = async (req, res, next) => {
  try {
    const id = req.params.id;
    console.log("---------------", id);
    let viewCategoryVariantValueQuery = `SELECT  p.*,d.Variant AS VariantName
                FROM ( subcategoryvariantvalue p
                INNER JOIN subcategoryvariant d ON p.SubCategoryVariantID = d.SubCategoryVariantID)
                WHERE p.SubCategoryVariantID =${id}`;

    let viewCategoryVariantValue = await connection.query(
      viewCategoryVariantValueQuery,
      {
        type: QueryTypes.SELECT,
      }
    );
    console.log(viewCategoryVariantValue);
    if (viewCategoryVariantValue && viewCategoryVariantValue.length > 0) {
      res.status(200).json({
        status: true,
        SubCategoryVariantValue: viewCategoryVariantValue,
      });
    } else {
      res.status(200).json({
        status: false,
        message: "SubCategory Varint does not found",
        SubCategoryVariantValue: [],
      });
    }
  } catch (err) {
    next(err);
    res.status(200).json({
      status: false,
      profile: {},
      error: err.message,
    });
  }
};
exports.deleteSubCategoryVariantValueById = async (req, res, next) => {
  try {
    const id = req.params.id;
    console.log(id);

    let CheckSubCategoryVariantValue = await connection.query(
      `select * from subcategoryvariantvalue where SubCategoryVariantValueID  = "${id}" `,
      {
        type: QueryTypes.SELECT,
      }
    );
    if (
      CheckSubCategoryVariantValue &&
      CheckSubCategoryVariantValue.length > 0
    ) {
      console.log("--------------");
      let deleteSubCategoryVariantValue = await connection.query(
        `DELETE FROM subcategoryvariantvalue WHERE SubCategoryVariantValueID ="${id}" `,
        {
          type: QueryTypes.DELETE,
        }
      );
      res.status(200).json({
        status: true,
        message: `SubCategory variant value deleted successfully`,
      });
    } else {
      console.log("*********");
      res.status(200).json({
        status: false,
        message: `SubCategory variant value does not exist`,
      });
    }
  } catch (err) {
    next(err);
    res.status(200).json({
      status: false,
      data: {},
      error: err.message,
    });
    console.log(err.message);
  }
};
exports.updateSubCategoryVariantValueById = async (req, res, next) => {
  try {
    const SubCategoryVariantValueID = req.params.id;
    console.log(SubCategoryVariantValueID);
    const { VariantValue, SubCategoryVariantID } = req.body;

    var checkSubCategoryVariantValue = await connection.query(
      `select * from subcategoryvariantvalue where SubCategoryVariantValueID  = '${SubCategoryVariantValueID}' `,
      {
        type: QueryTypes.SELECT,
      }
    );
    if (
      checkSubCategoryVariantValue &&
      checkSubCategoryVariantValue.length > 0
    ) {
      console.log("----------------");
      //check for unique variant Name

      if (
        VariantValue == checkSubCategoryVariantValue[0].VariantValue &&
        SubCategoryVariantID ==
        checkSubCategoryVariantValue[0].SubCategoryVariantID
      ) {
        let upateSubCategoryVariantValueQuery = `UPDATE subcategoryvariantvalue  SET VariantValue = ? WHERE SubCategoryVariantValueID  = "${SubCategoryVariantValueID}"   `;
        let upateSubCategoryVariantValue = await connection.query(
          upateSubCategoryVariantValueQuery,
          {
            replacements: [VariantValue],
          }
        );
        if (
          upateSubCategoryVariantValue &&
          upateSubCategoryVariantValue.length > 0
        ) {
          res.status(200).json({
            status: true,
            message: `SubCategory Variant value updated successfully`,
          });
        } else {
          res.status(200).json({
            status: false,
            message: `Error while updating SubCategory Variant `,
          });
        }
      } else {
        let checkIFVariantValueAlreadyExists = await connection.query(
          `select * from subcategoryvariantvalue  where VariantValue  = "${VariantValue}" AND SubCategoryVariantID ='${SubCategoryVariantID}'  `,
          {
            type: QueryTypes.SELECT,
          }
        );
        console.log(checkIFVariantValueAlreadyExists);
        if (
          checkIFVariantValueAlreadyExists &&
          checkIFVariantValueAlreadyExists.length > 0
        ) {
          res.status(200).json({
            status: false,
            Category: {},
            message: `Variant Value already taken, please select another one`,
          });
        } else {
          let upateSubCategoryVariantValueQuery = `UPDATE subcategoryvariantvalue  SET VariantValue = ? WHERE SubCategoryVariantValueID  = "${SubCategoryVariantValueID}"   `;
          let upateSubCategoryVariantValue = await connection.query(
            upateSubCategoryVariantValueQuery,
            {
              replacements: [VariantValue],
            }
          );
          if (
            upateSubCategoryVariantValue &&
            upateSubCategoryVariantValue.length > 0
          ) {
            res.status(200).json({
              status: true,
              message: `SubCategory Variant value updated successfully`,
            });
          } else {
            res.status(200).json({
              status: false,
              message: `Error while updating SubCategory Variant `,
            });
          }
        }
      }
    } else {
      res.status(200).json({
        status: false,
        message: `Sub Category Variant does not exist`,
        SubCategoryVariant: [],
      });
    }
  } catch (err) {
    next(err);
    console.log(err.message);
    res.status(200).json({
      status: false,
      profile: {},
      error: err.message,
    });
  }
};
//!INSERT Categories And SubCategories list by CSV file APi's
exports.insertCategoriesListByCSV = async (req, res, next) => {
  try {
    // CSV file name
    const fileName = "out.csv";
    let insertCategoryTable;
    csvtojson()
      .fromFile(fileName)
      .then(async (source) => {
        // Fetching the data from each row
        // and inserting to the table "sample"
        console.log(source.length);
        for (var i = 0; i < source.length; i++) {
          (PathaoCityID = source[i]["Pathao_cityID"]),
            (PathaoCityName = source[i]["Pathao_cityName"]);

          // Inserting data of current row
          // into database
          var insertCategoryTableQuery = `INSERT INTO pathaocities( PathaoCityID,
            PathaoCityName) values(?,?)`;
          insertCategoryTable = await connection.query(
            insertCategoryTableQuery,
            {
              replacements: [PathaoCityID, PathaoCityName],
            }
          );
        }
      });
    if (insertCategoryTable) {
      console.log("All items stored into database successfully");
      res.status(200).json({
        status: true,
        message: "successfully upload data in pathao table",
      });
    } else {
      console.log("Unable to insert item ");
      res.status(200).json({
        status: false,
      });
    }
  } catch (err) {
    next(err);
    res.status(200).json({
      status: false,
      Category: {},
      error: err.message,
    });
  }
};
exports.insertSubCategoriesListByCSV = async (req, res, next) => {
  try {
    // CSV file name
    const fileName = "AllSubCatogories.csv";

    csvtojson()
      .fromFile(fileName)
      .then(async (source) => {
        // Fetching the data from each row
        // and inserting to the table "sample"
        console.log(source.length);
        for (var i = 0; i < source.length; i++) {
          (CategoryID = source[i]["CategoryID"]),
            (SubCategory = source[i]["SubCategory"]),
            (Description = source[i]["Description"]),
            (SubCategoryPic = source[i]["SubCategoryPic"]),
            (ShippingGlobal = source[i]["ShippingGlobal"]),
            (Active = source[i]["Active"]),
            (LastUpdate = source[i]["LastUpdate"]);

          // Inserting data of current row
          // into database
          var insertCategoryTableQuery = `INSERT INTO subcategory( CategoryID,
            SubCategory,
            Description,
            SubCategoryPic,
            ShippingGlobal,
            Active,
            LastUpdate) values(?,?,?,?,?,?,?)`;
          let insertCategoryTable = await connection.query(
            insertCategoryTableQuery,
            {
              replacements: [
                CategoryID,
                SubCategory,
                Description,
                SubCategoryPic,
                ShippingGlobal,
                Active,
                LastUpdate,
              ],
            }
          );
          if (insertCategoryTable) {
            console.log("All items stored into database successfully");
          } else {
            console.log("Unable to insert item at row ", i + 1);
          }
        }
      });
    res.status(200).json({
      status: true,
      message: "successfully upload data in SubCategory table",
    });
  } catch (err) {
    next(err);
    res.status(200).json({
      status: false,
      SubCategory: {},
      error: err.message,
    });
  }
};
