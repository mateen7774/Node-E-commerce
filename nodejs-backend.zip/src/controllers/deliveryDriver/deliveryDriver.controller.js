const axios = require("axios");
const moment = require("moment");
const crypto = require('crypto');

const {
  QueryTypes
} = require("sequelize");

const {
  createOrder
} = require("../../controllers/pathao/pathao.controller");

const connection = require("../../db/db.connection");
const {
  Notification,
} = require("../../controllers/usersControllers/users.controller");
const {
  sendEmail
} = require("../../utils/notificationsMail");

const dhl_username =
  process.env.DHL_LIVE_CRED === "true" ? "true" : "apI7vQ4oG4vU2z";
const dhl_password =
  process.env.DHL_LIVE_CRED === "true" ? "false" : "Z@5bR@5tH$7jS^1g";
let dhl_url =
  process.env.DHL_LIVE === "true" ?
    "https://express.api.dhl.com/mydhlapi" :
    "https://express.api.dhl.com/mydhlapi/test";


exports.registerDeliveryDriver = async (req, res, next) => {
  let transaction;
  try {
    let DeliveryDriverID = req.UserID;
    const {
      GovernmentID,
      Address1,
      Address2,
      CityID,
      City,
      State,
      ZipCode,
      CountryID,
      PaymentAccount,
      PaymentRouting,
      BusinessEmail,
      BusinessPhone,
      BusinessURL,
      GatewayID,
      bankName,
      branchName,
      accountTitle,
      paymentAccount,

    } = req.body;

    const GovernmentIDPicBackSide = req.files.GovernmentIDPicBackSide[0].path;


    const GovernmentIDPic = req.files.GovernmentIDPic[0].path;

    transaction = await connection.transaction();
    let checkIfDriverAlreadyRegistered = await connection.query(
      `SELECT * FROM deliverydriver WHERE DeliveryDriverID="${DeliveryDriverID}"`,
      {
        type: QueryTypes.SELECT,
        transaction,
      }
    );

    if (
      checkIfDriverAlreadyRegistered &&
      checkIfDriverAlreadyRegistered.length > 0
    ) 
    {
      if (transaction) await transaction.rollback();
      res.status(200).json({
        status: false,
        message: `This User is already Registered as Delivery Driver `,
      });
    } else {
      // if (req.file && Object.keys(req.file).length > 0) {
      //   if (req.file.path && req.file.path.length > 0) {
      //     // GovernmentIDPic = req.file.path;
      //   } else {
      //     GovernmentIDPic = null;
      //   }
      // } else {
      //   GovernmentIDPic = null;
      // }
      let CreatedDate = new Date().toISOString().slice(0, 19).replace("T", " ");
      /*  let checkEmail = await connection.query(
               `SELECT * FROM profile where EmailAddress = '${EmailAddress}'`, {
                 type: QueryTypes.SELECT
               }
             ); */
      let registerDeliverDriverQuery = `insert into deliverydriver (DeliveryDriverID,GovernmentID, GovernmentIDPic,GovernmentIDPicBackSide, Address1,Address2 , CityID, City,State,ZipCode,CountryID,PaymentAccount,PaymentRouting,BusinessEmail,BusinessPhone,BusinessURL,GatewayID,CreatedDate,bankName,branchName,accountTitle)  values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) `;
      let registerDeliverDriver = await connection.query(
        registerDeliverDriverQuery,
        {
          replacements: [
            DeliveryDriverID,
            GovernmentID,
            GovernmentIDPic,
            GovernmentIDPicBackSide,
            Address1,
            Address2,
            CityID,
            City,
            State,
            ZipCode,
            CountryID,
            paymentAccount,
            PaymentRouting,
            BusinessEmail,
            BusinessPhone,
            BusinessURL,
            GatewayID,
            CreatedDate,
            bankName,
            branchName,
            accountTitle,

          ],
          transaction,
        }
      );

      if (registerDeliverDriver) {
        let LastUpdate = new Date()
          .toISOString()
          .slice(0, 19)
          .replace("T", " ");
        let addNewUserNotificationQuery = `insert into notification (TypeID,Body,CreaterID,ReceiverID,LastUpdate)  `;
        addNewUserNotificationQuery += ` values ("4","Your role has been changed to DeliverDriver","1","${DeliveryDriverID}","${LastUpdate}") `;

        let addNewUserNotification = await connection.query(
          addNewUserNotificationQuery
        );
        if (addNewUserNotification) {
          let ReceiverID = DeliveryDriverID;
          let TypeID = "5";
          let CreaterID = "1";
          let Body = {
            body: "Your Registration request is sent to Admin for Approval",
          };
          let Message = Body.body;
          let getDeviceIDQuery = ` SELECT DeviceID,EmailAddress,UserID
                FROM profile 
                WHERE UserID=${DeliveryDriverID}`;
          let getDeviceID = await connection.query(getDeviceIDQuery, {
            type: QueryTypes.SELECT,
            transaction,
          });
          if (getDeviceID && getDeviceID.length > 0) {
            let DeviceID = getDeviceID[0].DeviceID;
            let EmailAddress = getDeviceID[0].EmailAddress;
            console.log(DeviceID);
            let sendNotification = await Notification(
              TypeID,
              Body,
              CreaterID,
              ReceiverID,
              transaction
            );

            console.log(sendNotification, "sendNotification");

            if (sendNotification) {
              sendEmail(EmailAddress, Message, TypeID);
              if (transaction) await transaction.commit(); //!final commit
              res.status(200).json({
                status: true,
                message: `Delivery Driver register successfully`,
              });
            }
             else {
              if (transaction) await transaction.rollback();
              res.status(200).json({
                status: false,
                message: "Error while sending Notification to User ",
              });
            }
          } 
          else {
            res.status(200).json({
              status: false,
              message: `error while getting user data from database`,
            });
          }
        }
         else {
          res.status(200).json({
            status: false,
            message: `error while adding notification into database`,
          });
        }
      } 
      else {
        if (transaction) await transaction.rollback();
        res.status(200).json({
          status: false,
          message: `Something went wrong while registering Delivery Driver `,
          message: err.message,
        });
      }
    }
  } 
  
  catch (err) {
    if (transaction) await transaction.rollback();
    next(err);
    res.status(200).json({
      status: false,
      error: err.message,
    });
  }
};


exports.updateDeliveryDriverDetails = async (req, res, next) => {
  try {
    let DeliveryDriverID = req.UserID;
    const {
      GovernmentID,
      Address1,
      Address2,
      CityID,
      City,
      State,
      ZipCode,
      CountryID,
      PaymentAccount,
      PaymentRouting,
      BusinessEmail,
      BusinessPhone,
      BusinessURL,
      GatewayID,
    } = req.body;
    let GovernmentIDPic;
    let findGovermentIDPic = await connection.query(
      `select * from deliverydriver where DeliveryDriverID = "${DeliveryDriverID}" `, {
      type: QueryTypes.SELECT,
    }
    );
    if (findGovermentIDPic && findGovermentIDPic.length > 0) {
      let checkIfImageExists = findGovermentIDPic[0].GovernmentIDPic;
      if (req.file && Object.keys(req.file).length > 0) {
        if (req.file.path && req.file.path.length > 0) {
          GovernmentIDPic = req.file.path;
        } else if (checkIfImageExists && checkIfImageExists.length > 0) {
          GovernmentIDPic = checkIfImageExists[0].GovernmentIDPic;
        }
      } else if (checkIfImageExists && checkIfImageExists.length > 0) {
        GovernmentIDPic = checkIfImageExists[0].GovernmentIDPic;
      } else {
        GovernmentIDPic = null;
      }

      let LastUpdate = new Date().toISOString().slice(0, 19).replace("T", " ");
      /*  let checkEmail = await connection.query(
               `SELECT * FROM profile where EmailAddress = '${EmailAddress}'`, {
                 type: QueryTypes.SELECT
               }
             ); */
      let registerDeliverDriverQuery = `UPDATE deliverydriver SET GovernmentID=?, GovernmentIDPic=?, Address1=?,Address2=? , CityID=?, City=?,State=?,ZipCode=?,PaymentAccount=?,PaymentRouting=?,BusinessEmail=?,BusinessPhone=?,BusinessURL=?,GatewayID=?,LastUpdate=? WHERE DeliveryDriverID = "${DeliveryDriverID}"`;
      let registerDeliverDriver = await connection.query(
        registerDeliverDriverQuery, {
        replacements: [
          GovernmentID,
          GovernmentIDPic,
          Address1,
          Address2,
          CityID,
          City,
          State,
          ZipCode,
          PaymentAccount,
          PaymentRouting,
          BusinessEmail,
          BusinessPhone,
          BusinessURL,
          GatewayID,
          LastUpdate,
        ],
      }
      );
      if (registerDeliverDriver) {
        res.status(200).json({
          status: true,
          message: `Delivery Driver deltails updated successfully`,
        });
      } else {
        res.status(200).json({
          status: false,
          message: `Something went wrong while updating Delivery Driver details `,
        });
      }
    } else {
      res.status(200).json({
        status: false,
        message: ` Delivery Driver does not have an account `,
      });
    }
  } catch (err) {
    next(err);
    res.status(200).json({
      status: false,
      error: err.message,
    });
  }
};


exports.deleteDeliveryDriverById = async (req, res, next) => {
  try {
    let DeliveryDriverID = req.UserID;
    let getDeliveryDriverProfile = await connection.query(
      `select * from deliverydriver where DeliveryDriverID = "${DeliveryDriverID}" `, {
      type: QueryTypes.SELECT,
    }
    );
    if (getDeliveryDriverProfile && getDeliveryDriverProfile.length > 0) {
      let deleteDeliveryDriverProfile = await connection.query(
        `DELETE from deliverydriver where DeliveryDriverID = "${DeliveryDriverID}" `
      );
      if (deleteDeliveryDriverProfile) {
        res.status(200).json({
          status: true,
          message: `Delivery Driver deleted successfully`,
        });
      } else {
        res.status(200).json({
          status: false,
          message: `Error while deleting Delivery Driver successfully`,
        });
      }
    } else {
      res.status(200).json({
        status: false,
        message: `Delivery Driver does not exist`,
      });
    }
  } catch (error) {
    next(err);
    res.status(200).json({
      status: false,
      data: {},
      error: err.message,
    });
    console.log(err.message);
  }
};

exports.getDeliveryDriverByCity = async (req, res, next) => {
  try {
    let City = req.params.name;
    let getDriversByCityID = await connection.query(
      `SELECT * FROM  deliverydriver WHERE City="${City}"  `, {
      type: QueryTypes.SELECT,
    }
    );
    if (getDriversByCityID && getDriversByCityID.length > 0) {
      res.status(200).json({
        status: true,
        driverDetails: getDriversByCityID,
      });
    } else {
      res.status(200).json({
        status: false,
        message: "No Delivery Driver exists in this city",
        driverDetails: [],
      });
    }
  } catch (err) {
    next(err);
    res.status(200).json({
      status: false,
      driverDetails: [],
      message: err.message,
    });
    console.log(err.message);
  }
};


exports.assignDeliveryDriver = async (req, res, next) => {
  let transaction;
  try {
    transaction = await connection.transaction();
    const { OrderNumber } = req.body;
    let LastUpdate = new Date().toISOString().slice(0, 19).replace("T", " ");
    let ConsignmentId = null;
    let item_array = [];
    let getDeliveryStatus = await connection.query(
      `SELECT  p.OrderNumber,p.Quantity AS ProductQuantity,pt.ProductID,pt.Title,p.ItemsPrice,pt.Weight AS ProductWeight,IF(vs.CountryID=16,"BD","US")AS countryOfOrigin,p.DeliveryStatus,c.CityID,p.UserID,o.Name as recipient_name,o.Address1 as recipient_address,o.UserNote,p.ItemsTotal,m.OrderTotal AS totalSum,o.PhoneNumber as recipient_phone,o.ZoneID,o.AreaID,o.CityID AS recipient_city,o.City AS CityName,o.State AS State,o.ZipCode AS ZIP4,o.PhoneNumber AS Phone,o.Address2 as Address2,y.Country AS CountryName,p.PaymentType,t.PathaoCityID,p.OrderDate,o.PhoneNumber,vs.StoreName ,vs.Address1 AS fromAddress1,vs.Address2 AS fromAddress2,vs.City AS fromCity,vs.State AS fromState,vs.StorePhone,v.BusinessPhone,IFNULL(vs.StorePhone ,v.BusinessPhone)AS fromPhone,IFNULL(vs.StoreEmail,v.BusinessEmail) AS fromEmail,v.CompanyName,vs.ZipCode AS fromZip,p.ShippingDate,pf.EmailAddress AS UserEmailAddress,

            (SELECT SUM(p.Weight) AS item_weight
            FROM processorder o
            INNER JOIN product p ON p.ProductID=o.ProductID
            WHERE o.OrderNumber="${OrderNumber}"
            GROUP BY OrderNumber) AS item_weight,

            (SELECT SUM(p.Height) AS item_height
            FROM processorder o
            INNER JOIN product p ON p.ProductID=o.ProductID
            WHERE o.OrderNumber="${OrderNumber}"
            GROUP BY OrderNumber) AS item_height,

            (SELECT SUM(p.Length) AS item_length
            FROM processorder o
            INNER JOIN product p ON p.ProductID=o.ProductID
            WHERE o.OrderNumber="${OrderNumber}"
            GROUP BY OrderNumber) AS item_length,

            (SELECT SUM(p.Width) AS item_width
            FROM processorder o
            INNER JOIN product p ON p.ProductID=o.ProductID
            WHERE o.OrderNumber="${OrderNumber}"
            GROUP BY OrderNumber) AS item_width,

            (SELECT SUM(Quantity) AS item_quantity
            FROM processorder o
            WHERE o.OrderNumber="${OrderNumber}") AS item_quantity,

            (SELECT SUM(ItemsShippingHandling) AS shippingTotal
            FROM processorder o
            WHERE o.OrderNumber="${OrderNumber}") AS shippingTotal

            FROM processorder p
            LEFT JOIN product pt ON pt.ProductID=p.ProductID
            LEFT JOIN orderdeliveryaddress o ON o.OrderNumber=p.OrderNumber
            LEFT JOIN pathaocities t ON t.DBCityID=o.CityID
            INNER JOIN productcity c ON c.ProductID=p.ProductID
            INNER JOIN processpayment m ON m.OrderNumber=p.OrderNumber
            LEFT JOIN country y ON y.CountryID=o.CountryID
            LEFT JOIN vendorstore vs ON vs.VendorStoreID=p.VendorStoreID
            LEFT JOIN vendor v ON v.VendorID=vs.VendorID

            INNER JOIN profile pf ON pf.UserID=p.UserID
            WHERE p.OrderNumber="${OrderNumber}"
       `,
      {
        type: QueryTypes.SELECT,
        transaction,
      }
    );
    console.log("getDeliveryStatus getDeliveryStatus", getDeliveryStatus);

    let UserID = getDeliveryStatus[0].UserID;
    let ReceiverID = UserID;
    let DeliveryStatus = getDeliveryStatus[0].DeliveryStatus;
    let CityID = getDeliveryStatus[0].CityID;
    let uspsItemWeight = parseFloat(getDeliveryStatus[0].item_weight * 2.20462)
      .toFixed(2)
      .toString();
    let uspsItemHeight = (getDeliveryStatus[0].item_height * 0.393701).toFixed(
      2
    );
    let uspsItemLength = (getDeliveryStatus[0].item_length * 0.393701).toFixed(
      2
    );
    let uspsItemWidth = (getDeliveryStatus[0].item_width * 0.393701).toFixed(2);

    if (DeliveryStatus == "dd") {
      console.log("Delivery Driver");
      let getDriverCity = await connection.query(
        `   SELECT d.DeliveryDriverID,t.CityID AS DeliveryDriverCityID
                FROM deliverydriver d
                INNER JOIN city t ON t.City=d.City
                WHERE d.ReviewedByAdmin="Y" AND d.CityID="${CityID}"
                ORDER BY d.DeliveryDriverID DESC
       `,
        {
          type: QueryTypes.SELECT,
          transaction,
        }
      );
      console.log(getDriverCity);
      let DriverIds = [];
      for (let i = 0; i < getDriverCity.length; i++) {
        DriverIds.push(getDriverCity[i].DeliveryDriverID);
      }
      let saveDriverIds = `(${DriverIds.join(",")})`;
      console.log(saveDriverIds);

      //below this
      let getDriversOrdersCount = await connection.query(
        `Select COUNT(d.DeliveryDriverID) as count,
            d.DeliveryDriverID as DeliveryDriverID, d.OrderNumber as orderNumber
            from (
            Select DeliveryDriverID, OrderNumber
            from processorder
            where DeliveryDriverID IN ${saveDriverIds} and ProcessStatus = "Delivered"
            GROUP BY OrderNumber
        ) d GROUP BY DeliveryDriverID
        `,
        {
          type: QueryTypes.SELECT,
          transaction,
        }
      );

      let countOfOrders = [];
      let minCountOfOrders;
      let countOfMinOrders = [];
      let storeMinimumIdIndex = [];
      let currentdateAndTime = [];

      console.log(getDriversOrdersCount, "getDriversOrdersCount");

      // if no record exist already
      if (getDriversOrdersCount.length === 0) {
        console.log("if no record exist already");
        let saveDriverID = getDriverCity[0].DeliveryDriverID;
        let getDriverDetails = await connection.query(
          `SELECT *
                FROM deliverydriver d
                INNER JOIN profile p ON p.UserID=d.DeliveryDriverID
                WHERE DeliveryDriverID="${saveDriverID}"`,
          {
            type: QueryTypes.SELECT,
            transaction,
          }
        );
        if (getDriverDetails && getDriverDetails.length > 0) {
          currentdateAndTime[0] = LastUpdate;
          let StatusHistory = JSON.stringify(currentdateAndTime);
          let assignDriverToCurrentOrder = await connection.query(
            `UPDATE processorder SET DeliveryDriverID="${saveDriverID}", ProcessStatus="Assigned",StatusHistory='${StatusHistory}',LastUpdate="${LastUpdate}"
                WHERE OrderNumber="${OrderNumber}"`,
            {
              transaction,
            }
          );
          if (assignDriverToCurrentOrder) {

            let TypeID = "6";
            let CreaterID = "1";

            let Body = {
              OrderNumber: OrderNumber,
              body: `Your Order ${OrderNumber} is Assigned to Banglabazar Delivery Person`,
            };
            let Message = `You Order # ${Body.OrderNumber} is Assigned to Banglabazar Delivery Person`;
            let getDeviceIDQuery = ` SELECT DeviceID,EmailAddress
                        FROM profile
                        WHERE UserID=${UserID}`;
            let getDeviceID = await connection.query(getDeviceIDQuery, {
              type: QueryTypes.SELECT,
              transaction,
            });
            if (getDeviceID && getDeviceID.length > 0) {
              let DeviceID = getDeviceID[0].DeviceID;
              let EmailAddress = getDeviceID[0].EmailAddress;
              console.log(DeviceID);
              sendEmail(EmailAddress, Message, TypeID);
              let sendNotification = await Notification(
                TypeID,
                Body,
                CreaterID,
                ReceiverID,
                transaction
              );
              console.log(sendNotification, "sendNotification");
              if (sendNotification) {
                if (transaction) await transaction.commit();
                res.status(200).json({
                  status: true,
                  message: "Following Driver is assigned to OrderNumber ",
                  driverDetails: getDriverDetails,
                });
              } else {
                if (transaction) await transaction.rollback();
                res.status(200).json({
                  status: false,
                  message: "Error while sending Notification to User ",
                  driverDetails: [],
                });
              }
            } else {
              if (transaction) await transaction.rollback();
              res.status(200).json({
                status: false,
                message: "Error While getting User data from Database ",
                driverDetails: [],
              });
            }
          }
        } else {
          if (transaction) await transaction.rollback();
          res.status(200).json({
            status: false,
            message: "Error While assigning driver to OrderNumber  ",
            driverDetails: [],
          });
        }
      }
      // if some record exist already
      else if (getDriversOrdersCount && getDriversOrdersCount.length > 0) {
        console.log("if some record exist already");
        for (let i = 0; i < DriverIds.length; i++) {
          let count = 0;
          let d_id = DriverIds[i];
          let o_number = null;
          for (let j = 0; j < getDriversOrdersCount.length; j++) {
            if (DriverIds[i] == getDriversOrdersCount[j].DeliveryDriverID) {
              count = getDriversOrdersCount[j].count;
              d_id = getDriversOrdersCount[j].DeliveryDriverID;
              o_number = getDriversOrdersCount[j].orderNumber;
            }
          }
          countOfOrders.push({
            count: count,
            DeliveryDriverID: d_id,
            OrderNumber: o_number,
          });
          countOfMinOrders.push(countOfOrders[i].count);
        }
        countOfMinOrders.sort((a, b) => {
          return a - b;
        });
        minCountOfOrders = Math.min(...countOfMinOrders);
        for (let i = 0; i < countOfMinOrders.length; i++) {
          if (countOfMinOrders[i] === minCountOfOrders) {
            storeMinimumIdIndex.push(i);
          }
        }

        countOfOrders.sort((a, b) => {
          return a.count - b.count;
        });
        console.log(countOfOrders, "countOfOrders");
        console.log(countOfMinOrders, "countOfMinOrders");
        console.log(minCountOfOrders, "minCountOfOrders");
        console.log(storeMinimumIdIndex, "storeMinimumIdIndex");
        let notdeliveredIds = [];
        let currentDeliveryDriverID = countOfOrders[0].DeliveryDriverID;

        if (storeMinimumIdIndex && storeMinimumIdIndex.length > 1) {
          for (let i = 0; i < storeMinimumIdIndex.length; i++) {
            let checkIFDriverAlreadyDeliveredToUser = await connection.query(
              `SELECT * FROM processorder WHERE DeliveryDriverID="${countOfOrders[i].DeliveryDriverID}" AND ProcessStatus="Delivered" AND UserID="${UserID}" AND DeliveryDate> now() -  interval 7 day
                    ORDER BY LastUpdate DESC`,
              {
                type: QueryTypes.SELECT,
                transaction,
              }
            );
            if (
              !(
                checkIFDriverAlreadyDeliveredToUser &&
                checkIFDriverAlreadyDeliveredToUser.length > 0
              )
            ) {
              notdeliveredIds.push(countOfOrders[i].DeliveryDriverID);
            }
          }
        }
        console.log(notdeliveredIds.length, "notdeliveredIds");
        console.log(notdeliveredIds);
        let saveDriverID = null;
        console.log(storeMinimumIdIndex.length, "storeMinimumIdIndex");

        if (notdeliveredIds.length == storeMinimumIdIndex.length) {
          console.log(" first query");
          saveDriverID = currentDeliveryDriverID;
          getDriverDetails = await connection.query(
            `SELECT *
            FROM deliverydriver d
            INNER JOIN profile p ON p.UserID=d.DeliveryDriverID
            WHERE DeliveryDriverID="${saveDriverID}"`,
            {
              type: QueryTypes.SELECT,
              transaction,
            }
          );
        } else {
          if (notdeliveredIds && notdeliveredIds.length > 0) {
            saveDriverID = notdeliveredIds[0];
          } else {
            saveDriverID = currentDeliveryDriverID;
          }
          console.log(" 2nd query");
          getDriverDetails = await connection.query(
            `SELECT *
            FROM deliverydriver d
            INNER JOIN profile p ON p.UserID=d.DeliveryDriverID
            WHERE DeliveryDriverID="${saveDriverID}"`,
            {
              type: QueryTypes.SELECT,
              transaction,
            }
          );
        }
        if (getDriverDetails && getDriverDetails.length > 0) {
          currentdateAndTime[0] = LastUpdate;
          let StatusHistory = JSON.stringify(currentdateAndTime);
          let assignDriverToCurrentOrder = await connection.query(
            `UPDATE processorder SET DeliveryDriverID="${saveDriverID}", ProcessStatus="Assigned",StatusHistory='${StatusHistory}',LastUpdate="${LastUpdate}"
                WHERE OrderNumber="${OrderNumber}"`,
            {
              transaction,
            }
          );
          if (assignDriverToCurrentOrder) {
            let TypeID = "6";
            let CreaterID = "1";
            let Body = {
              OrderNumber: OrderNumber,
              body: `Your Order ${OrderNumber} is Assigned to Banglabazar Delivery Person`,
            };
            let Message = `You Order # ${Body.OrderNumber} is Assigned to Banglabazar Delivery Person`;
            let getDeviceIDQuery = ` SELECT DeviceID,EmailAddress
                       FROM profile
                       WHERE UserID=${UserID}`;
            let getDeviceID = await connection.query(getDeviceIDQuery, {
              type: QueryTypes.SELECT,
              transaction,
            });
            if (getDeviceID && getDeviceID.length > 0) {
              let DeviceID = getDeviceID[0].DeviceID;
              let EmailAddress = getDeviceID[0].EmailAddress;
              console.log(DeviceID);
              sendEmail(EmailAddress, Message, TypeID);
              let sendNotification = await Notification(
                TypeID,
                Body,
                CreaterID,
                ReceiverID,
                transaction
              );
              console.log(sendNotification, "sendNotification");
              if (sendNotification) {
                if (transaction) await transaction.commit();
                res.status(200).json({
                  status: true,
                  message: "Following Driver is assigned to OrderNumber ",
                  driverDetails: getDriverDetails,
                });
              } else {
                if (transaction) await transaction.rollback();
                res.status(200).json({
                  status: false,
                  message: "Error while sending Notification to User ",
                  driverDetails: [],
                });
              }
            } else {
              if (transaction) await transaction.rollback();
              res.status(200).json({
                status: false,
                message: "Error While getting User data from Database ",
                driverDetails: [],
              });
            }
          } else {
            if (transaction) await transaction.rollback();
            res.status(200).json({
              status: false,
              message: "Error While assigning driver to OrderNumber  ",
              driverDetails: [],
            });
          }
        } else {
          if (transaction) await transaction.rollback();
          res.status(200).json({
            status: false,
            message: "Error while getting driver detials",
            driverDetails: [],
          });
        }
      }
    }
    if (DeliveryStatus == "pathao") {
      console.log("Pathao Assignment ......");
      let VendorID = req.UserID;
      // let VendorID = 100;
      let currentdateAndTime = [];
      currentdateAndTime[0] = LastUpdate;
      let StatusHistory = JSON.stringify(currentdateAndTime);
      let amount_to_collect = "0";
      let PaymentType = getDeliveryStatus[0].PaymentType;
      if (PaymentType && PaymentType === "cod") {
        amount_to_collect = Math.round(
          getDeliveryStatus[0].totalSum
        ).toString();
      }
      console.log(
        amount_to_collect,
        "amount_to_collect ----------------------"
      );
      console.log("Pathao Case");

      let item_description = "This is product ";
      let getProductsPthaoStoreID = await connection.query(
        `SELECT  p.OrderNumber,p.ProductID,v.VendorStoreID,v.PthaoStoreID,v.StoreName,p.Quantity,t.Weight,c.ExpressDelivery,c.Category,c.CategoryID
                FROM processorder p
                INNER JOIN vendorstore v ON v.VendorStoreID=p.VendorStoreID
                LEFT JOIN product t ON t.ProductID=p.ProductID
                LEFT JOIN subcategory s ON s.SubCategoryID= t.SubCategoryID
                LEFT JOIN category c ON c.CategoryID=s.CategoryID
                WHERE p.OrderNumber="${OrderNumber}" AND t.VendorID="${VendorID}"
           `,
        {
          type: QueryTypes.SELECT,
          transaction,
        }
      );
      console.log("__________________________________", getProductsPthaoStoreID);

      let uniquePthaoStoreID = [];
      let uniquePthaoIDIndex = [];
      let VendorStoreID = [];

      let totalwieght = 0
      let totalquantity = 0
      for (let i = 0; i < getProductsPthaoStoreID.length; i++) {
        if (
          !uniquePthaoStoreID.includes(getProductsPthaoStoreID[i].PthaoStoreID)
        ) {
          uniquePthaoStoreID.push(getProductsPthaoStoreID[i].PthaoStoreID);
          VendorStoreID.push(getProductsPthaoStoreID[i].VendorStoreID);



          uniquePthaoIDIndex.push(i);
        }

        totalwieght = parseFloat(getProductsPthaoStoreID[i].Weight) + totalwieght
        totalquantity = parseFloat(getProductsPthaoStoreID[i].Quantity) + totalquantity
      }
      console.log("uniquePthaoStoreID================>", uniquePthaoStoreID, getDeliveryStatus);
      console.log("_______________________________", totalwieght, totalquantity);


      let pathaoOrder;
      let recipient_phone = getDeliveryStatus[0].recipient_phone;
      console.log(recipient_phone, "recipient_phone---------------------");
      let recipient_name = getDeliveryStatus[0].recipient_name;
      let recipient_address = getDeliveryStatus[0].recipient_address;
      let recipient_city = getDeliveryStatus[0].PathaoCityID;
      let recipient_zone = getDeliveryStatus[0].ZoneID;
      let recipient_area = getDeliveryStatus[0].AreaID;
      let special_instruction = getDeliveryStatus[0].UserNote;

      //promises
      const pathaoResponse = [];
      console.log("uniquePthaoStoreID================>", uniquePthaoStoreID, getDeliveryStatus);






      const promises = uniquePthaoStoreID.map(async (item, i) => {
        console.log(getProductsPthaoStoreID[i].Weight);
        let item_weight = totalwieght
        let item_quantity = totalquantity
        let currentPthaoID = uniquePthaoStoreID[i];
        //     let item_weight = getProductsPthaoStoreID[i].Weight;
        //        let item_quantity = getProductsPthaoStoreID[i].Quantity;
        let delivery_type = getProductsPthaoStoreID[i].ExpressDelivery
        console.log("Starting creating order......");
        try {
          pathaoOrder = await createOrder(
            OrderNumber,
            recipient_name,
            recipient_phone,
            recipient_address,
            recipient_city,
            recipient_zone,
            recipient_area,
            special_instruction,
            item_quantity,
            item_weight,
            item_description,
            amount_to_collect,
            currentPthaoID,
            delivery_type
          );
          console.log(pathaoOrder, " at index", i)
          pathaoResponse.push(pathaoOrder);
        } catch (e) {
          console.log(e);
          if (transaction) await transaction.rollback();
        }
      });



      await Promise.all(promises);
      if (pathaoResponse && pathaoResponse.length > 0) {
        let assignOrderToPathao = false;
        try {
          for (let i = 0; i < pathaoResponse.length; i++) {
            let ConsignmentId = pathaoResponse[0].data.data.consignment_id;
            assignOrderToPathao = await connection.query(
              `UPDATE processorder SET  ProcessStatus="Assigned",ConsignmentId="${ConsignmentId}",StatusHistory='${StatusHistory}',LastUpdate="${LastUpdate}"
                    WHERE OrderNumber="${OrderNumber}" AND VendorStoreID="${VendorStoreID[i]}" `,
              {
                transaction,
              }
            );
          }
          assignOrderToPathao = true;
        } catch (e) {
          console.log(e);
          assignOrderToPathao = false;
          if (transaction) await transaction.rollback();
        }
        if (assignOrderToPathao) {
          let TypeID = "6";
          let CreaterID = "1";
          let Body = {
            OrderNumber: OrderNumber,
            body: `Your Order ${OrderNumber} is Assigned to Pathao`,
          };
          let Message = `You Order # ${Body.OrderNumber} is Assigned to Pathao`;
          let getDeviceIDQuery = ` SELECT DeviceID,EmailAddress,UserID
                    FROM profile
                    WHERE UserID=${UserID}`;
          let getDeviceID = await connection.query(getDeviceIDQuery, {
            type: QueryTypes.SELECT,
            transaction,
          });
          if (getDeviceID && getDeviceID.length > 0) {
            let DeviceID = getDeviceID[0].DeviceID;
            let EmailAddress = getDeviceID[0].EmailAddress;
            let UserID = getDeviceID[0].UserID;
            console.log(DeviceID);
            sendEmail(EmailAddress, Message, TypeID);
            console.log("DEVICE ID EXIST CONDITION -----------------");
            let sendNotification = await Notification(
              TypeID,
              Body,
              CreaterID,
              UserID,
              transaction
            );
            console.log(sendNotification, "sendNotification");
            if (sendNotification) {
              if (transaction) await transaction.commit();
              res.status(200).json({
                status: true,
                message: " Order is Assigned to Pathao Successfully",
              });
            } else {
              if (transaction) await transaction.rollback();
              res.status(200).json({
                status: false,
                message: "Error while sending Notification to User ",
              });
            }
          } else {
            if (transaction) await transaction.rollback();
            res.status(200).json({
              status: false,
              message: "Error While getting user data from Database ",
            });
          }
        } else {
          if (transaction) await transaction.rollback();
          res.status(200).json({
            status: false,
            message: "Error While assigning Pathao the given Order  ",
          });
        }
      } else {
        if (transaction) await transaction.rollback();
        res.status(200).json({
          status: false,
          message: "Error While getting Pthao Api Response  ",
        });
      }
    }
    if (DeliveryStatus == "usps") {
      for (let i = 0; i < getDeliveryStatus.length; i++) {
        const items = {
          productId: getDeliveryStatus[i].ProductID.toString(),
          sku: null,
          title: getDeliveryStatus[i].Title,
          price: getDeliveryStatus[i].ItemsPrice.toString(),
          quantity: getDeliveryStatus[i].ProductQuantity,
          weight: parseFloat(getDeliveryStatus[i].ProductWeight * 2.20462)
            .toFixed(2)
            .toString(),
          imgUrl: null,
          htsNumber: null,
          countryOfOrigin: getDeliveryStatus[i].countryOfOrigin,
          lineId: null,
        };
        item_array.push(items);
      }
      let currentdateAndTime = [];
      currentdateAndTime[0] = LastUpdate;
      let StatusHistory = JSON.stringify(currentdateAndTime);
      let userName = getDeliveryStatus[0].recipient_name;
      let userAddress1 = getDeliveryStatus[0].recipient_address;
      let userAddress2 = getDeliveryStatus[0].Address2;
      let ToCity = getDeliveryStatus[0].CityName;
      let ToState = getDeliveryStatus[0].State;
      let ShippingDate = getDeliveryStatus[0].ShippingDate;
      let shippingTotal = getDeliveryStatus[0].shippingTotal;
      let OrderDate = getDeliveryStatus[0].OrderDate;
      let userZip = getDeliveryStatus[0].ZIP4;
      let PhoneNumber = getDeliveryStatus[0].PhoneNumber;
      let FromAddress1 = getDeliveryStatus[0].fromAddress1;
      let FromAddress2 = getDeliveryStatus[0].fromAddress2;
      let FromCity = getDeliveryStatus[0].fromCity;
      let FromState = getDeliveryStatus[0].fromState;
      let FromZip = getDeliveryStatus[0].fromZip;
      let FromPhone = getDeliveryStatus[0].fromPhone;
      let FromEmail = getDeliveryStatus[0].fromEmail;
      let StoreName = getDeliveryStatus[0].StoreName;
      let CompanyName = getDeliveryStatus[0].CompanyName;
      console.log(
        moment(OrderDate).format("YYYY-MM-DD"),
        "date-------------------------"
      );
      var options = {
        orderId: OrderNumber.toString(),
        orderDate: moment(OrderDate).format("YYYY-MM-DD"),
        orderNumber: OrderNumber.toString(),
        fulfillmentStatus: "pending", //One of "pending", "fulfilled", or "partial"
        shippingService: "Standard", // for urgent delivery
        shippingTotal: shippingTotal.toString(),
        weightUnit: "lb", //Either "lb" for pounds or "kg" for kilograms
        dimUnit: "in", //Either "in" for inches or "cm" for centimeters
        dueByDate: moment(ShippingDate).format("YYYY-MM-DD"), //! yet to be added column on backend
        orderGroup: "Workstation", //May be set to allow multiple users to ship at the same time without overlapping
        contentDescription: null,
        sender: {
          name: StoreName,
          company: CompanyName,
          address1: FromAddress1,
          address2: FromAddress2,
          city: FromCity,
          state: FromState,
          zip: FromZip.toString(),
          country: "US",
          phone: FromPhone.toString(),
          email: FromEmail,
        },
        returnTo: {
          name: StoreName,
          company: CompanyName,
          address1: FromAddress1,
          address2: FromAddress2,
          city: FromCity,
          state: FromState,
          zip: FromZip.toString(),
          country: "US",
          phone: FromPhone.toString(),
          email: FromEmail,
        },
        receiver: {
          name: userName,
          company: userName,
          address1: userAddress1,
          address2: userAddress2 ? userAddress2 : "null",
          city: ToCity ? ToCity : "null",
          state: ToState,
          zip: userZip,
          country: "US",
          phone: PhoneNumber,
          email: getDeliveryStatus[0].UserEmailAddress,
        },
        //items:null,
        items: item_array,
        packages: [
          {
            weight: uspsItemWeight.toString(),
            length: uspsItemLength.toString(),
            width: uspsItemWidth.toString(),
            height: uspsItemHeight.toString(),
            insuranceAmount: null,
            declaredValue: null,
          },
        ],
      };
      console.log(options);
      console.log(
        `https://xpsshipper.com/restapi/v1/customers/${process.env.CustomerID}/integrations/${process.env.IntegrationId}/orders/${OrderNumber}`
      );
      let response = await axios.put(
        `https://xpsshipper.com/restapi/v1/customers/${process.env.CustomerID}/integrations/${process.env.IntegrationId}/orders/${OrderNumber}`,
        options,
        {
          headers: {
            Authorization: "RSIS " + process.env.APIKey,
          },
        }
      );
      console.log(response.data);
      if (response.data.ok === true) {
        const updateUSPSOrderPanelStatus = await connection.query(
          `UPDATE processorder SET UspsOrderStatus="On Panel" WHERE OrderNumber=${OrderNumber}`
        );
        if (updateUSPSOrderPanelStatus) {
          if (transaction) await transaction.commit();
          res.status(200).json({
            status: true,
            message: "Order request is successfully placed on XPS panel",
          });
        } else {
          if (transaction) await transaction.rollback();
          res.status(200).json({
            status: false,
            message: "Error while saving updates in DB",
          });
        }
      } else {
        if (transaction) await transaction.rollback();
        res.status(200).json({
          status: false,
          message: response.data,
        });
      }
    }
    if (DeliveryStatus == "usps_intl") {
      for (let i = 0; i < getDeliveryStatus.length; i++) {
        const items = {
          productId: getDeliveryStatus[i].ProductID.toString(),
          sku: null,
          title: getDeliveryStatus[i].Title,
          price: getDeliveryStatus[i].ItemsPrice.toString(),
          quantity: getDeliveryStatus[i].ProductQuantity,
          weight: parseFloat(getDeliveryStatus[i].ProductWeight * 2.20462)
            .toFixed(2)
            .toString(),
          imgUrl: null,
          htsNumber: null,
          countryOfOrigin: getDeliveryStatus[i].countryOfOrigin,
          lineId: null,
        };
        item_array.push(items);
      }
      let currentdateAndTime = [];
      currentdateAndTime[0] = LastUpdate;
      let StatusHistory = JSON.stringify(currentdateAndTime);
      let userName = getDeliveryStatus[0].recipient_name;
      let userAddress1 = getDeliveryStatus[0].recipient_address;
      let userAddress2 = getDeliveryStatus[0].Address2;
      let ToCity = getDeliveryStatus[0].CityName;
      let ToState = getDeliveryStatus[0].State;
      let ShippingDate = getDeliveryStatus[0].ShippingDate;
      let shippingTotal = getDeliveryStatus[0].shippingTotal;
      let OrderDate = getDeliveryStatus[0].OrderDate;
      let userZip = getDeliveryStatus[0].ZIP4;
      let PhoneNumber = getDeliveryStatus[0].PhoneNumber;
      let FromAddress1 = getDeliveryStatus[0].fromAddress1;
      let FromAddress2 = getDeliveryStatus[0].fromAddress2;
      let FromCity = getDeliveryStatus[0].fromCity;
      let FromState = getDeliveryStatus[0].fromState;
      let FromZip = getDeliveryStatus[0].fromZip;
      let FromPhone = getDeliveryStatus[0].fromPhone;
      let FromEmail = getDeliveryStatus[0].fromEmail;
      let StoreName = getDeliveryStatus[0].StoreName;
      let CompanyName = getDeliveryStatus[0].CompanyName;
      let declaredValue = Math.round(getDeliveryStatus[0].totalSum).toString();

      console.log(
        moment(OrderDate).format("YYYY-MM-DD"),
        "date-------------------------"
      );
      var options = {
        orderId: OrderNumber.toString(),
        orderDate: moment(OrderDate).format("YYYY-MM-DD"),
        orderNumber: OrderNumber.toString(),
        fulfillmentStatus: "pending", //One of "pending", "fulfilled", or "partial"
        shippingService: "Standard", // for urgent delivery
        shippingTotal: shippingTotal.toString(),
        weightUnit: "lb", //Either "lb" for pounds or "kg" for kilograms
        dimUnit: "in", //Either "in" for inches or "cm" for centimeters
        dueByDate: moment(ShippingDate).format("YYYY-MM-DD"), //! yet to be added column on backend
        orderGroup: "Workstation", //May be set to allow multiple users to ship at the same time without overlapping
        contentDescription: null,
        sender: {
          name: StoreName,
          company: CompanyName,
          address1: FromAddress1,
          address2: FromAddress2,
          city: FromCity,
          state: FromState,
          zip: FromZip.toString(),
          country: "US",
          phone: FromPhone.toString(),
          email: FromEmail,
        },
        returnTo: {
          name: StoreName,
          company: CompanyName,
          address1: FromAddress1,
          address2: FromAddress2,
          city: FromCity,
          state: FromState,
          zip: FromZip.toString(),
          country: "US",
          phone: FromPhone.toString(),
          email: FromEmail,
        },
        receiver: {
          name: userName,
          company: userName,
          address1: userAddress1,
          address2: userAddress2 ? userAddress2 : "null",
          city: ToCity ? ToCity : "null",
          state: ToState,
          zip: userZip,
          country: "BD",
          phone: PhoneNumber,
          email: getDeliveryStatus[0].UserEmailAddress,
        },
        //items:null,
        items: item_array,
        packages: [
          {
            weight: uspsItemWeight.toString(),
            length: uspsItemLength.toString(),
            width: uspsItemWidth.toString(),
            height: uspsItemHeight.toString(),
            insuranceAmount: null,
            declaredValue: null,
          },
        ],
      };
      console.log(options);
      console.log(
        `https://xpsshipper.com/restapi/v1/customers/${process.env.CustomerID}/integrations/${process.env.IntegrationId}/orders/${OrderNumber}`
      );
      let response = await axios.put(
        `https://xpsshipper.com/restapi/v1/customers/${process.env.CustomerID}/integrations/${process.env.IntegrationId}/orders/${OrderNumber}`,
        options,
        {
          headers: {
            Authorization: "RSIS " + process.env.APIKey,
          },
        }
      );
      console.log(response.data);
      if (response.data.ok === true) {
        const updateUSPSOrderPanelStatus = await connection.query(
          `UPDATE processorder SET UspsOrderStatus="On Panel" WHERE OrderNumber=${OrderNumber}`
        );
        if (updateUSPSOrderPanelStatus) {
          if (transaction) await transaction.commit();
          res.status(200).json({
            status: true,
            message: "Order request is successfully placed on XPS panel",
          });
        } else {
          if (transaction) await transaction.rollback();
          res.status(200).json({
            status: false,
            message: "Error while saving updates in DB",
          });
        }
      } else {
        if (transaction) await transaction.rollback();
        res.status(200).json({
          status: false,
          message: response.data,
        });
      }
    }
    if (DeliveryStatus == "dhl") {
      // prints something like '2023-03-14T13:30:45+0100'
      let today = new Date();
      let plannedShippingDate = new Date(
        today.getFullYear(),
        today.getMonth(),
        today.getDate() + 5
      );

      const getUserAndStoreDetails = await connection.query(
        `SELECT vs.*,pf.EmailAddress AS UserEmail,v.CompanyName,od.ZipCode AS PostalCode,od.PhoneNumber,od.City AS DeliveryCity,od.Address1 AS  userAddress1,od.Address2 AS userAddress2,od.Name AS UserName,SUM(p.Weight) AS totalWeight,SUM(p.Height) AS totalHeight,SUM(p.Length) AS totalLength,SUM(p.Width) AS totalWidth,po.UserID,c.ISO2 AS CountryCode,c.Country AS CountryName
      FROM processorder po
      INNER JOIN vendorstore vs ON vs.VendorStoreID=po.VendorStoreID
      INNER JOIN profile pf ON pf.UserID=po.UserID
      INNER JOIN vendor v ON v.VendorID=vs.VendorID
      INNER JOIN orderdeliveryaddress od ON od.OrderNumber=po.OrderNumber
      INNER JOIN country c ON c.CountryID=od.CountryID
      INNER JOIN product p ON p.ProductID=po.ProductID
      WHERE po.OrderNumber="${OrderNumber}"
      GROUP BY p.StoreName
     `,
        {
          type: QueryTypes.SELECT,
          transaction,
        }
      );
      //console.log(getUserAndStoreDetails, "getUserAndStoreDetails");
      if (getUserAndStoreDetails && getUserAndStoreDetails.length > 0) {
        let storePostalCode = getUserAndStoreDetails[0].ZipCode;
        let storeCityName = getUserAndStoreDetails[0].City;
        let storeAddress1 = getUserAndStoreDetails[0].Address1;
        let storeAddress2 = getUserAndStoreDetails[0].Address2;
        let storeEmail = getUserAndStoreDetails[0].StoreEmail;
        let storePhone = getUserAndStoreDetails[0].StorePhone;
        let storeName = getUserAndStoreDetails[0].StoreName;
        let companyName = getUserAndStoreDetails[0].CompanyName;
        let userPostalCode = getUserAndStoreDetails[0].PostalCode;
        let userAddress1 = getUserAndStoreDetails[0].userAddress1;
        let userAddress2 = getUserAndStoreDetails[0].userAddress2;
        let userPhone = getUserAndStoreDetails[0].PhoneNumber;
        let deliveryCity = getUserAndStoreDetails[0].DeliveryCity;
        let userName = getUserAndStoreDetails[0].UserName;
        let EmailAddress = getUserAndStoreDetails[0].UserEmail;
        let UserID = getUserAndStoreDetails[0].UserID;
        let deliveryCountryCode = getUserAndStoreDetails[0].CountryCode;
        let deliveryCountryName = getUserAndStoreDetails[0].CountryName;
        let totalWeight = getUserAndStoreDetails[0].totalWeight;
        let totalLength = getUserAndStoreDetails[0].totalLength;
        let totalWidth = getUserAndStoreDetails[0].totalWidth;
        let totalHeight = getUserAndStoreDetails[0].totalHeight;

        var data = {
          plannedShippingDateAndTime: "2023-03-12T17:10:09 GMT+01:00", //YYYY-MM-DD;
          pickup: {
            isRequested: false,
          },
          // pickup: {
          //   isRequested: true,
          //   pickupDetails: {
          //     postalAddress: {
          //       postalCode: storePostalCode.toString(),
          //       cityName: storeCityName,
          //       countryCode: "BD",
          //       addressLine1: storeAddress1,
          //       addressLine2: storeAddress2,
          //     },
          //     contactInformation: {
          //       email: String(storeEmail),
          //       phone: String(storePhone),
          //       companyName: companyName,
          //       fullName: storeName,
          //     },
          //   },
          //   pickupRequestorDetails: {
          //     postalAddress: {
          //       postalCode: storePostalCode.toString(),
          //       cityName: storeCityName,
          //       countryCode: "BD",
          //       addressLine1: storeAddress1,
          //       addressLine2: storeAddress2,
          //     },
          //     contactInformation: {
          //       email: String(storeEmail),
          //       phone: String(storePhone),
          //       companyName: companyName,
          //       fullName: storeName,
          //     },
          //   },
          // },
          productCode: "D", //Please enter DHL Express Global Product code max:6
          accounts: [{ typeCode: "shipper", number: "525078203" }],
          customerDetails: {
            shipperDetails: {
              postalAddress: {
                postalCode: storePostalCode.toString(),
                cityName: storeCityName,
                countryCode: "BD",
                addressLine1: storeAddress1,
                addressLine2: storeAddress2,
              },
              contactInformation: {
                email: String(storeEmail),
                phone: String(storePhone),
                companyName: companyName,
                fullName: storeName,
              },
            },
            receiverDetails: {
              postalAddress: {
                postalCode: userPostalCode.toString(),
                cityName: deliveryCity,
                countryCode: deliveryCountryCode,
                addressLine1: userAddress1,
                addressLine2: userAddress2,
                countryName: deliveryCountryName,
              },
              contactInformation: {
                phone: userPhone,
                companyName: userName,
                fullName: userName,
              },
            },
          },
          content: {
            packages: [
              {
                weight: parseFloat(totalWeight),
                dimensions: {
                  length: parseFloat(totalLength),
                  width: parseFloat(totalWidth),
                  height: parseFloat(totalHeight),
                },
                customerReferences: [
                  {
                    value: "Customer reference", //req
                  },
                ],
              },
            ],
            isCustomsDeclarable: false, //req
            // declaredValue:"",
            // declaredValueCurrency:"",
            description: "shipment description", //req
            incoterm: "DAP", //req
            unitOfMeasurement: "metric", //req
          },
          shipmentNotification: [
            {
              typeCode: "email", //req
              receiverId: EmailAddress, //req
              // bespokeMessage: "Your order is assigned to DHL courier service",
            },
          ],
        };
        const response = await axios.post(`${dhl_url}/shipments`, data, {
          auth: {
            username: dhl_username,
            password: dhl_password,
          },
        });
        console.log(response, "response");

        if (response.data) {
          let DhlTrackingNumber = response.data.shipmentTrackingNumber;
          let DhlTrackingUrl = response.data.trackingUrl;

          let currentdateAndTime = [];
          let LastUpdate = new Date()
            .toISOString()
            .slice(0, 19)
            .replace("T", " ");
          currentdateAndTime[0] = LastUpdate;
          let StatusHistory = JSON.stringify(currentdateAndTime);
          assignOrderToDHL = await connection.query(
            `UPDATE processorder SET  ProcessStatus="Assigned",DhlTrackingNumber="${DhlTrackingNumber}",DhlTrackingUrl="${DhlTrackingUrl}",
            StatusHistory='${StatusHistory}',LastUpdate="${LastUpdate}" WHERE OrderNumber="${OrderNumber}" `,
            {
              transaction,
            }
          );
          if (assignOrderToDHL) {
            let TypeID = "6";
            let CreaterID = "1";
            let Body = {
              OrderNumber: OrderNumber,
              body: `Your Order ${OrderNumber} is Assigned to DHL `,
            };
            let Message = `You Order # ${Body.OrderNumber} is Assigned to DHL`;

            sendEmail(EmailAddress, Message, TypeID);

            let sendNotification = await Notification(
              TypeID,
              Body,
              CreaterID,
              UserID,
              transaction
            );
            console.log(sendNotification, "sendNotification");

            if (sendNotification) {
              if (transaction) await transaction.commit();
              return res.status(200).json({
                status: true,
                message: " Order is Assigned to DHL Successfully",
              });
            } else {
              if (transaction) await transaction.rollback();
              res.status(200).json({
                status: false,
                message: "Error while sending Notification to User ",
              });
            }
          } else {
            if (transaction) await transaction.rollback();
            res.status(200).json({
              status: false,
              message: "Error While assigning DHL the given Order  ",
            });
          }
        } else {
          if (transaction) await transaction.rollback();
          res.status(200).json({
            status: false,
            message: "Error while getting DHL api response",
          });
        }
      } else {
        if (transaction) await transaction.rollback();
        res.status(200).json({
          status: false,
          message: "Error while getting user and store details from db",
        });
      }
    }
    if (
      DeliveryStatus == "null" ||
      DeliveryStatus == "NULL" ||
      DeliveryStatus == " " ||
      DeliveryStatus == null
    ) {
      console.log(" Deliery Status cannot be NULL || null or Invalid ");
      if (transaction) await transaction.rollback();
      res.status(200).json({
        status: false,
        message: "Deliery Status cannot be NULL || null or Invalid",
      });
    }
  } catch (e) {
    console.log(e.response.data);
    if (transaction) await transaction.rollback();
    res.status(200).json({
      status: false,
      message: e,
    });
  }
};



exports.adOldassignDeliveryDriver = async (req, res, next) => {
  let transaction;
  try {
    transaction = await connection.transaction();
    const {
      OrderNumber
    } = req.body;
    let LastUpdate = new Date().toISOString().slice(0, 19).replace("T", " ");
    let ConsignmentId = null;
    let item_array = [];
    let getDeliveryStatus = await connection.query(
      `SELECT  p.OrderNumber,p.Quantity AS ProductQuantity,pt.ProductID,pt.Title,p.ItemsPrice,pt.Weight AS ProductWeight,IF(vs.CountryID=16,"BD","US")AS countryOfOrigin,p.DeliveryStatus,c.CityID,p.UserID,o.Name as recipient_name,o.Address1 as recipient_address,o.UserNote,p.ItemsTotal,m.OrderTotal AS totalSum,o.PhoneNumber as recipient_phone,o.ZoneID,o.AreaID,o.CityID AS recipient_city,o.City AS CityName,o.State AS State,o.ZipCode AS ZIP4,o.PhoneNumber AS Phone,o.Address2 as Address2,y.Country AS CountryName,p.PaymentType,t.PathaoCityID,p.OrderDate,o.PhoneNumber,vs.StoreName ,vs.Address1 AS fromAddress1,vs.Address2 AS fromAddress2,vs.City AS fromCity,vs.State AS fromState,vs.StorePhone,v.BusinessPhone,IFNULL(vs.StorePhone ,v.BusinessPhone)AS fromPhone,IFNULL(vs.StoreEmail,v.BusinessEmail) AS fromEmail,v.CompanyName,vs.ZipCode AS fromZip,p.ShippingDate,pf.EmailAddress AS UserEmailAddress,

            (SELECT SUM(p.Weight) AS item_weight
            FROM processorder o
            INNER JOIN product p ON p.ProductID=o.ProductID
            WHERE o.OrderNumber="${OrderNumber}"
            GROUP BY OrderNumber) AS item_weight,

            (SELECT SUM(p.Height) AS item_height
            FROM processorder o
            INNER JOIN product p ON p.ProductID=o.ProductID
            WHERE o.OrderNumber="${OrderNumber}"
            GROUP BY OrderNumber) AS item_height,

            (SELECT SUM(p.Length) AS item_length
            FROM processorder o
            INNER JOIN product p ON p.ProductID=o.ProductID
            WHERE o.OrderNumber="${OrderNumber}"
            GROUP BY OrderNumber) AS item_length,

            (SELECT SUM(p.Width) AS item_width
            FROM processorder o
            INNER JOIN product p ON p.ProductID=o.ProductID
            WHERE o.OrderNumber="${OrderNumber}"
            GROUP BY OrderNumber) AS item_width,

            (SELECT SUM(Quantity) AS item_quantity
            FROM processorder o
            WHERE o.OrderNumber="${OrderNumber}") AS item_quantity,

            (SELECT SUM(ItemsShippingHandling) AS shippingTotal
            FROM processorder o
            WHERE o.OrderNumber="${OrderNumber}") AS shippingTotal
            
            FROM processorder p
            LEFT JOIN product pt ON pt.ProductID=p.ProductID
            LEFT JOIN orderdeliveryaddress o ON o.OrderNumber=p.OrderNumber
            LEFT JOIN pathaocities t ON t.DBCityID=o.CityID
            INNER JOIN productcity c ON c.ProductID=p.ProductID
            INNER JOIN processpayment m ON m.OrderNumber=p.OrderNumber
            LEFT JOIN country y ON y.CountryID=o.CountryID
            LEFT JOIN vendorstore vs ON vs.VendorStoreID=p.VendorStoreID
            LEFT JOIN vendor v ON v.VendorID=vs.VendorID
            INNER JOIN profile pf ON pf.UserID=p.UserID
            WHERE p.OrderNumber="${OrderNumber}"
       `, {
      type: QueryTypes.SELECT,
      transaction,
    }
    );
    console.log("getDeliveryStatus getDeliveryStatus", getDeliveryStatus);
    let UserID = getDeliveryStatus[0].UserID;
    let ReceiverID = UserID;
    let DeliveryStatus = getDeliveryStatus[0].DeliveryStatus;
    let CityID = getDeliveryStatus[0].CityID;
    let uspsItemWeight = parseFloat(getDeliveryStatus[0].item_weight * 2.20462)
      .toFixed(2)
      .toString();
    let uspsItemHeight = (getDeliveryStatus[0].item_height * 0.393701).toFixed(
      2
    );
    let uspsItemLength = (getDeliveryStatus[0].item_length * 0.393701).toFixed(
      2
    );
    let uspsItemWidth = (getDeliveryStatus[0].item_width * 0.393701).toFixed(2);

    if (DeliveryStatus == "dd") {
      console.log("Delivery Driver");
      let getDriverCity = await connection.query(
        `   SELECT d.DeliveryDriverID,t.CityID AS DeliveryDriverCityID
                FROM deliverydriver d
                INNER JOIN city t ON t.City=d.City
                WHERE d.ReviewedByAdmin="Y" AND d.CityID="${CityID}"
                ORDER BY d.DeliveryDriverID DESC
       `, {
        type: QueryTypes.SELECT,
        transaction,
      }
      );
      console.log(getDriverCity);
      let DriverIds = [];
      for (let i = 0; i < getDriverCity.length; i++) {
        DriverIds.push(getDriverCity[i].DeliveryDriverID);
      }
      let saveDriverIds = `(${DriverIds.join(",")})`;
      console.log(saveDriverIds);

      //below this
      let getDriversOrdersCount = await connection.query(
        `Select COUNT(d.DeliveryDriverID) as count, 
            d.DeliveryDriverID as DeliveryDriverID, d.OrderNumber as orderNumber  
            from (
            Select DeliveryDriverID, OrderNumber 
            from processorder 
            where DeliveryDriverID IN ${saveDriverIds} and ProcessStatus = "Delivered" 
            GROUP BY OrderNumber 
        ) d GROUP BY DeliveryDriverID   
        `, {
        type: QueryTypes.SELECT,
        transaction,
      }
      );
      let countOfOrders = [];
      let minCountOfOrders;
      let countOfMinOrders = [];
      let storeMinimumIdIndex = [];
      let currentdateAndTime = [];
      console.log(getDriversOrdersCount, "getDriversOrdersCount");

      // if no record exist already
      if (getDriversOrdersCount.length === 0) {
        console.log("if no record exist already");
        let saveDriverID = getDriverCity[0].DeliveryDriverID;
        let getDriverDetails = await connection.query(
          `SELECT * 
                FROM deliverydriver d
                INNER JOIN profile p ON p.UserID=d.DeliveryDriverID
                WHERE DeliveryDriverID="${saveDriverID}"`, {
          type: QueryTypes.SELECT,
          transaction,
        }
        );
        if (getDriverDetails && getDriverDetails.length > 0) {
          currentdateAndTime[0] = LastUpdate;
          let StatusHistory = JSON.stringify(currentdateAndTime);
          let assignDriverToCurrentOrder = await connection.query(
            `UPDATE processorder SET DeliveryDriverID="${saveDriverID}", ProcessStatus="Assigned",StatusHistory='${StatusHistory}',LastUpdate="${LastUpdate}"
                WHERE OrderNumber="${OrderNumber}"`, {
            transaction,
          }
          );
          if (assignDriverToCurrentOrder) {
            let TypeID = "6";
            let CreaterID = "1";
            let Body = {
              OrderNumber: OrderNumber,
              body: `Your Order ${OrderNumber} is Assigned to Banglabazar Delivery Person`,
            };
            let Message = `You Order # ${Body.OrderNumber} is Assigned to Banglabazar Delivery Person`;
            let getDeviceIDQuery = ` SELECT DeviceID,EmailAddress
                        FROM profile 
                        WHERE UserID=${UserID}`;
            let getDeviceID = await connection.query(getDeviceIDQuery, {
              type: QueryTypes.SELECT,
              transaction,
            });
            if (getDeviceID && getDeviceID.length > 0) {
              let DeviceID = getDeviceID[0].DeviceID;
              let EmailAddress = getDeviceID[0].EmailAddress;
              console.log(DeviceID);
              sendEmail(EmailAddress, Message, TypeID);
              let sendNotification = await Notification(
                TypeID,
                Body,
                CreaterID,
                ReceiverID,
                transaction
              );
              console.log(sendNotification, "sendNotification");
              if (sendNotification) {
                if (transaction) await transaction.commit();
                res.status(200).json({
                  status: true,
                  message: "Following Driver is assigned to OrderNumber ",
                  driverDetails: getDriverDetails,
                });
              } else {
                if (transaction) await transaction.rollback();
                res.status(200).json({
                  status: false,
                  message: "Error while sending Notification to User ",
                  driverDetails: [],
                });
              }
            } else {
              if (transaction) await transaction.rollback();
              res.status(200).json({
                status: false,
                message: "Error While getting User data from Database ",
                driverDetails: [],
              });
            }
          }
        } else {
          if (transaction) await transaction.rollback();
          res.status(200).json({
            status: false,
            message: "Error While assigning driver to OrderNumber  ",
            driverDetails: [],
          });
        }
      }
      // if some record exist already
      else if (getDriversOrdersCount && getDriversOrdersCount.length > 0) {
        console.log("if some record exist already");
        for (let i = 0; i < DriverIds.length; i++) {
          let count = 0;
          let d_id = DriverIds[i];
          let o_number = null;
          for (let j = 0; j < getDriversOrdersCount.length; j++) {
            if (DriverIds[i] == getDriversOrdersCount[j].DeliveryDriverID) {
              count = getDriversOrdersCount[j].count;
              d_id = getDriversOrdersCount[j].DeliveryDriverID;
              o_number = getDriversOrdersCount[j].orderNumber;
            }
          }
          countOfOrders.push({
            count: count,
            DeliveryDriverID: d_id,
            OrderNumber: o_number,
          });
          countOfMinOrders.push(countOfOrders[i].count);
        }
        countOfMinOrders.sort((a, b) => {
          return a - b;
        });
        minCountOfOrders = Math.min(...countOfMinOrders);
        for (let i = 0; i < countOfMinOrders.length; i++) {
          if (countOfMinOrders[i] === minCountOfOrders) {
            storeMinimumIdIndex.push(i);
          }
        }

        countOfOrders.sort((a, b) => {
          return a.count - b.count;
        });
        console.log(countOfOrders, "countOfOrders");
        console.log(countOfMinOrders, "countOfMinOrders");
        console.log(minCountOfOrders, "minCountOfOrders");
        console.log(storeMinimumIdIndex, "storeMinimumIdIndex");
        let notdeliveredIds = [];
        let currentDeliveryDriverID = countOfOrders[0].DeliveryDriverID;

        if (storeMinimumIdIndex && storeMinimumIdIndex.length > 1) {
          for (let i = 0; i < storeMinimumIdIndex.length; i++) {
            let checkIFDriverAlreadyDeliveredToUser = await connection.query(
              `SELECT * FROM processorder WHERE DeliveryDriverID="${countOfOrders[i].DeliveryDriverID}" AND ProcessStatus="Delivered" AND UserID="${UserID}" AND DeliveryDate> now() -  interval 7 day
                    ORDER BY LastUpdate DESC`, {
              type: QueryTypes.SELECT,
              transaction,
            }
            );
            if (
              !(
                checkIFDriverAlreadyDeliveredToUser &&
                checkIFDriverAlreadyDeliveredToUser.length > 0
              )
            ) {
              notdeliveredIds.push(countOfOrders[i].DeliveryDriverID);
            }
          }
        }
        console.log(notdeliveredIds.length, "notdeliveredIds");
        console.log(notdeliveredIds);
        let saveDriverID = null;
        console.log(storeMinimumIdIndex.length, "storeMinimumIdIndex");

        if (notdeliveredIds.length == storeMinimumIdIndex.length) {
          console.log(" first query");
          saveDriverID = currentDeliveryDriverID;
          getDriverDetails = await connection.query(
            `SELECT * 
            FROM deliverydriver d
            INNER JOIN profile p ON p.UserID=d.DeliveryDriverID
            WHERE DeliveryDriverID="${saveDriverID}"`, {
            type: QueryTypes.SELECT,
            transaction,
          }
          );
        } else {
          if (notdeliveredIds && notdeliveredIds.length > 0) {
            saveDriverID = notdeliveredIds[0];
          } else {
            saveDriverID = currentDeliveryDriverID;
          }
          console.log(" 2nd query");
          getDriverDetails = await connection.query(
            `SELECT * 
            FROM deliverydriver d
            INNER JOIN profile p ON p.UserID=d.DeliveryDriverID
            WHERE DeliveryDriverID="${saveDriverID}"`, {
            type: QueryTypes.SELECT,
            transaction,
          }
          );
        }
        if (getDriverDetails && getDriverDetails.length > 0) {
          currentdateAndTime[0] = LastUpdate;
          let StatusHistory = JSON.stringify(currentdateAndTime);
          let assignDriverToCurrentOrder = await connection.query(
            `UPDATE processorder SET DeliveryDriverID="${saveDriverID}", ProcessStatus="Assigned",StatusHistory='${StatusHistory}',LastUpdate="${LastUpdate}"
                WHERE OrderNumber="${OrderNumber}"`, {
            transaction,
          }
          );
          if (assignDriverToCurrentOrder) {
            let TypeID = "6";
            let CreaterID = "1";
            let Body = {
              OrderNumber: OrderNumber,
              body: `Your Order ${OrderNumber} is Assigned to Banglabazar Delivery Person`,
            };
            let Message = `You Order # ${Body.OrderNumber} is Assigned to Banglabazar Delivery Person`;
            let getDeviceIDQuery = ` SELECT DeviceID,EmailAddress
                       FROM profile 
                       WHERE UserID=${UserID}`;
            let getDeviceID = await connection.query(getDeviceIDQuery, {
              type: QueryTypes.SELECT,
              transaction,
            });
            if (getDeviceID && getDeviceID.length > 0) {
              let DeviceID = getDeviceID[0].DeviceID;
              let EmailAddress = getDeviceID[0].EmailAddress;
              console.log(DeviceID);
              sendEmail(EmailAddress, Message, TypeID);
              let sendNotification = await Notification(
                TypeID,
                Body,
                CreaterID,
                ReceiverID,
                transaction
              );
              console.log(sendNotification, "sendNotification");
              if (sendNotification) {
                if (transaction) await transaction.commit();
                res.status(200).json({
                  status: true,
                  message: "Following Driver is assigned to OrderNumber ",
                  driverDetails: getDriverDetails,
                });
              } else {
                if (transaction) await transaction.rollback();
                res.status(200).json({
                  status: false,
                  message: "Error while sending Notification to User ",
                  driverDetails: [],
                });
              }
            } else {
              if (transaction) await transaction.rollback();
              res.status(200).json({
                status: false,
                message: "Error While getting User data from Database ",
                driverDetails: [],
              });
            }
          } else {
            if (transaction) await transaction.rollback();
            res.status(200).json({
              status: false,
              message: "Error While assigning driver to OrderNumber  ",
              driverDetails: [],
            });
          }
        } else {
          if (transaction) await transaction.rollback();
          res.status(200).json({
            status: false,
            message: "Error while getting driver detials",
            driverDetails: [],
          });
        }
      }
    }
    if (DeliveryStatus == "pathao") {
      console.log("Pathao Assignment ......");
      let VendorID = req.UserID;
      let currentdateAndTime = [];
      currentdateAndTime[0] = LastUpdate;
      let StatusHistory = JSON.stringify(currentdateAndTime);
      let amount_to_collect = "0";
      let PaymentType = getDeliveryStatus[0].PaymentType;
      if (PaymentType && PaymentType === "cod") {
        amount_to_collect = Math.round(
          getDeliveryStatus[0].totalSum
        ).toString();
      }
      console.log(
        amount_to_collect,
        "amount_to_collect ----------------------"
      );
      console.log("Pathao Case");

      let item_description = "This is product ";
      let getProductsPthaoStoreID = await connection.query(
        `SELECT  p.OrderNumber,p.ProductID,v.VendorStoreID,v.PthaoStoreID,v.StoreName,p.Quantity,t.Weight,c.ExpressDelivery,c.Category,c.CategoryID
                FROM processorder p
                INNER JOIN vendorstore v ON v.VendorStoreID=p.VendorStoreID
                LEFT JOIN product t ON t.ProductID=p.ProductID
		LEFT JOIN subcategory s ON s.SubCategoryID= t.SubCategoryID
                LEFT JOIN category c ON c.CategoryID=s.CategoryID
                WHERE p.OrderNumber="${OrderNumber}" AND t.VendorID="${VendorID}"
           `, {
        type: QueryTypes.SELECT,
        transaction,
      }
      );
      console.log("++++++++++++++++++++++++++++++++++++++++++", getProductsPthaoStoreID);
      let uniquePthaoStoreID = [];
      let uniquePthaoIDIndex = [];
      let VendorStoreID = [];
      let totalwieght = 0
      let totalquantity = 0

      for (let i = 0; i < getProductsPthaoStoreID.length; i++) {
        if (
          !uniquePthaoStoreID.includes(getProductsPthaoStoreID[i].PthaoStoreID)
        ) {
          uniquePthaoStoreID.push(getProductsPthaoStoreID[i].PthaoStoreID);
          VendorStoreID.push(getProductsPthaoStoreID[i].VendorStoreID);
          uniquePthaoIDIndex.push(i);
        }
        totalwieght = parseFloat(getProductsPthaoStoreID[i].Weight) + totalwieght
        totalquantity = parseInt(getProductsPthaoStoreID[i].Quantity) + totalquantity
        console.log("_______________________________", totalwieght);

      }
      console.log("uniquePthaoStoreID================>", uniquePthaoStoreID, getDeliveryStatus);

      console.log(uniquePthaoStoreID);
      console.log(uniquePthaoIDIndex);
      let pathaoOrder;
      let recipient_phone = getDeliveryStatus[0].recipient_phone;
      if (recipient_phone.startsWith("+88")) {
        recipient_phone = recipient_phone.replace("+88", "");
      }
      console.log(recipient_phone, "recipient_phone---------------------");

      let recipient_name = getDeliveryStatus[0].recipient_name;
      let recipient_address = getDeliveryStatus[0].recipient_address;
      let recipient_city = getDeliveryStatus[0].PathaoCityID;
      let recipient_zone = getDeliveryStatus[0].ZoneID;
      let recipient_area = getDeliveryStatus[0].AreaID;
      let special_instruction = getDeliveryStatus[0].UserNote;

      //promises
      const pathaoResponse = [];
      const promises = uniquePthaoStoreID.map(async (item, i) => {
        let currentPthaoID = uniquePthaoStoreID[i];
        //  let item_weight = getProductsPthaoStoreID[i].Weight;
        //let item_quantity = getProductsPthaoStoreID[i].Quantity;
        let item_weight = totalwieght;
        let item_quantity = totalquantity
        let delivery_type = getProductsPthaoStoreID[i].ExpressDelivery
        console.log("__________________________________________uniquePthaoStoreID.map", item_weight, item_quantity)


        try {
          pathaoOrder = await createOrder(
            OrderNumber,
            recipient_name,
            recipient_phone,
            recipient_address,
            recipient_city,
            recipient_zone,
            recipient_area,
            special_instruction,
            item_quantity,
            item_weight,
            item_description,
            amount_to_collect,
            currentPthaoID,
            delivery_type
          );
          // console.log(pathaoOrder, " at index", i)
          pathaoResponse.push(pathaoOrder);
        } catch (e) {
          console.log(e);
          if (transaction) await transaction.rollback();
        }
      });


      await Promise.all(promises);
      if (pathaoResponse && pathaoResponse.length > 0) {
        let assignOrderToPathao = false;
        try {
          for (let i = 0; i < pathaoResponse.length; i++) {
            let ConsignmentId = pathaoResponse[0].data.data.consignment_id;
            assignOrderToPathao = await connection.query(
              `UPDATE processorder SET  ProcessStatus="Assigned",ConsignmentId="${ConsignmentId}",StatusHistory='${StatusHistory}',LastUpdate="${LastUpdate}"
                    WHERE OrderNumber="${OrderNumber}" AND VendorStoreID="${VendorStoreID[i]}" `, {
              transaction,
            }
            );
          }
          assignOrderToPathao = true;
        } catch (e) {
          console.log(e);
          assignOrderToPathao = false;
          if (transaction) await transaction.rollback();
        }
        if (assignOrderToPathao) {
          let TypeID = "6";
          let CreaterID = "1";
          let Body = {
            OrderNumber: OrderNumber,
            body: `Your Order ${OrderNumber} is Assigned to Pathao`,
          };
          let Message = `You Order # ${Body.OrderNumber} is Assigned to Pathao`;
          let getDeviceIDQuery = ` SELECT DeviceID,EmailAddress,UserID
                    FROM profile 
                    WHERE UserID=${UserID}`;
          let getDeviceID = await connection.query(getDeviceIDQuery, {
            type: QueryTypes.SELECT,
            transaction,
          });
          if (getDeviceID && getDeviceID.length > 0) {
            let DeviceID = getDeviceID[0].DeviceID;
            let EmailAddress = getDeviceID[0].EmailAddress;
            let UserID = getDeviceID[0].UserID;
            console.log(DeviceID);
            sendEmail(EmailAddress, Message, TypeID);
            console.log("DEVICE ID EXIST CONDITION -----------------");
            let sendNotification = await Notification(
              TypeID,
              Body,
              CreaterID,
              UserID,
              transaction
            );
            console.log(sendNotification, "sendNotification");
            if (sendNotification) {
              if (transaction) await transaction.commit();
              res.status(200).json({
                status: true,
                message: " Order is Assigned to Pathao Successfully",
              });
            } else {
              if (transaction) await transaction.rollback();
              res.status(200).json({
                status: false,
                message: "Error while sending Notification to User ",
              });
            }
          } else {
            if (transaction) await transaction.rollback();
            res.status(200).json({
              status: false,
              message: "Error While getting user data from Database ",
            });
          }
        } else {
          if (transaction) await transaction.rollback();
          res.status(200).json({
            status: false,
            message: "Error While assigning Pathao the given Order  ",
          });
        }
      } else {
        if (transaction) await transaction.rollback();
        res.status(200).json({
          status: false,
          message: "Error While getting Pthao Api Response  ",
        });
      }
    }
    if (DeliveryStatus == "usps") {
      for (let i = 0; i < getDeliveryStatus.length; i++) {
        const items = {
          productId: getDeliveryStatus[i].ProductID.toString(),
          sku: null,
          title: getDeliveryStatus[i].Title,
          price: getDeliveryStatus[i].ItemsPrice.toString(),
          quantity: getDeliveryStatus[i].ProductQuantity,
          weight: parseFloat(getDeliveryStatus[i].ProductWeight * 2.20462)
            .toFixed(2)
            .toString(),
          imgUrl: null,
          htsNumber: null,
          countryOfOrigin: getDeliveryStatus[i].countryOfOrigin,
          lineId: null,
        };
        item_array.push(items);
      }
      let currentdateAndTime = [];
      currentdateAndTime[0] = LastUpdate;
      let StatusHistory = JSON.stringify(currentdateAndTime);
      let userName = getDeliveryStatus[0].recipient_name;
      let userAddress1 = getDeliveryStatus[0].recipient_address;
      let userAddress2 = getDeliveryStatus[0].Address2;
      let ToCity = getDeliveryStatus[0].CityName;
      let ToState = getDeliveryStatus[0].State;
      let ShippingDate = getDeliveryStatus[0].ShippingDate;
      let shippingTotal = getDeliveryStatus[0].shippingTotal;
      let OrderDate = getDeliveryStatus[0].OrderDate;
      let userZip = getDeliveryStatus[0].ZIP4;
      let PhoneNumber = getDeliveryStatus[0].PhoneNumber;
      let FromAddress1 = getDeliveryStatus[0].fromAddress1;
      let FromAddress2 = getDeliveryStatus[0].fromAddress2;
      let FromCity = getDeliveryStatus[0].fromCity;
      let FromState = getDeliveryStatus[0].fromState;
      let FromZip = getDeliveryStatus[0].fromZip;
      let FromPhone = getDeliveryStatus[0].fromPhone;
      let FromEmail = getDeliveryStatus[0].fromEmail;
      let StoreName = getDeliveryStatus[0].StoreName;
      let CompanyName = getDeliveryStatus[0].CompanyName;
      console.log(
        moment(OrderDate).format("YYYY-MM-DD"),
        "date-------------------------"
      );
      var options = {
        orderId: OrderNumber.toString(),
        orderDate: moment(OrderDate).format("YYYY-MM-DD"),
        orderNumber: OrderNumber.toString(),
        fulfillmentStatus: "pending", //One of "pending", "fulfilled", or "partial"
        shippingService: "Standard", // for urgent delivery
        shippingTotal: shippingTotal.toString(),
        weightUnit: "lb", //Either "lb" for pounds or "kg" for kilograms
        dimUnit: "in", //Either "in" for inches or "cm" for centimeters
        dueByDate: moment(ShippingDate).format("YYYY-MM-DD"), //! yet to be added column on backend
        orderGroup: "Workstation", //May be set to allow multiple users to ship at the same time without overlapping
        contentDescription: null,
        sender: {
          name: StoreName,
          company: CompanyName,
          address1: FromAddress1,
          address2: FromAddress2,
          city: FromCity,
          state: FromState,
          zip: FromZip.toString(),
          country: "US",
          phone: FromPhone.toString(),
          email: FromEmail,
        },
        returnTo: {
          name: StoreName,
          company: CompanyName,
          address1: FromAddress1,
          address2: FromAddress2,
          city: FromCity,
          state: FromState,
          zip: FromZip.toString(),
          country: "US",
          phone: FromPhone.toString(),
          email: FromEmail,
        },
        receiver: {
          name: userName,
          company: userName,
          address1: userAddress1,
          address2: userAddress2 ? userAddress2 : "null",
          city: ToCity ? ToCity : "null",
          state: ToState,
          zip: userZip,
          country: "US",
          phone: PhoneNumber,
          email: getDeliveryStatus[0].UserEmailAddress,
        },
        //items:null,
        items: item_array,
        packages: [{
          weight: uspsItemWeight.toString(),
          length: uspsItemLength.toString(),
          width: uspsItemWidth.toString(),
          height: uspsItemHeight.toString(),
          insuranceAmount: null,
          declaredValue: null,
        },],
      };
      console.log(options);
      console.log(
        `https://xpsshipper.com/restapi/v1/customers/${process.env.CustomerID}/integrations/${process.env.IntegrationId}/orders/${OrderNumber}`
      );
      let response = await axios.put(
        `https://xpsshipper.com/restapi/v1/customers/${process.env.CustomerID}/integrations/${process.env.IntegrationId}/orders/${OrderNumber}`,
        options, {
        headers: {
          Authorization: "RSIS " + process.env.APIKey,
        },
      }
      );
      console.log(response.data);
      if (response.data.ok === true) {
        const updateUSPSOrderPanelStatus = await connection.query(
          `UPDATE processorder SET UspsOrderStatus="On Panel" WHERE OrderNumber=${OrderNumber}`
        );
        if (updateUSPSOrderPanelStatus) {
          if (transaction) await transaction.commit();
          res.status(200).json({
            status: true,
            message: "Order request is successfully placed on XPS panel",
          });
        } else {
          if (transaction) await transaction.rollback();
          res.status(200).json({
            status: false,
            message: "Error while saving updates in DB",
          });
        }
      } else {
        if (transaction) await transaction.rollback();
        res.status(200).json({
          status: false,
          message: response.data,
        });
      }
    }
    if (DeliveryStatus == "usps_intl") {
      for (let i = 0; i < getDeliveryStatus.length; i++) {
        const items = {
          productId: getDeliveryStatus[i].ProductID.toString(),
          sku: null,
          title: getDeliveryStatus[i].Title,
          price: getDeliveryStatus[i].ItemsPrice.toString(),
          quantity: getDeliveryStatus[i].ProductQuantity,
          weight: parseFloat(getDeliveryStatus[i].ProductWeight * 2.20462)
            .toFixed(2)
            .toString(),
          imgUrl: null,
          htsNumber: null,
          countryOfOrigin: getDeliveryStatus[i].countryOfOrigin,
          lineId: null,
        };
        item_array.push(items);
      }
      let currentdateAndTime = [];
      currentdateAndTime[0] = LastUpdate;
      let StatusHistory = JSON.stringify(currentdateAndTime);
      let userName = getDeliveryStatus[0].recipient_name;
      let userAddress1 = getDeliveryStatus[0].recipient_address;
      let userAddress2 = getDeliveryStatus[0].Address2;
      let ToCity = getDeliveryStatus[0].CityName;
      let ToState = getDeliveryStatus[0].State;
      let ShippingDate = getDeliveryStatus[0].ShippingDate;
      let shippingTotal = getDeliveryStatus[0].shippingTotal;
      let OrderDate = getDeliveryStatus[0].OrderDate;
      let userZip = getDeliveryStatus[0].ZIP4;
      let PhoneNumber = getDeliveryStatus[0].PhoneNumber;
      let FromAddress1 = getDeliveryStatus[0].fromAddress1;
      let FromAddress2 = getDeliveryStatus[0].fromAddress2;
      let FromCity = getDeliveryStatus[0].fromCity;
      let FromState = getDeliveryStatus[0].fromState;
      let FromZip = getDeliveryStatus[0].fromZip;
      let FromPhone = getDeliveryStatus[0].fromPhone;
      let FromEmail = getDeliveryStatus[0].fromEmail;
      let StoreName = getDeliveryStatus[0].StoreName;
      let CompanyName = getDeliveryStatus[0].CompanyName;
      let declaredValue = Math.round(getDeliveryStatus[0].totalSum).toString();

      console.log(
        moment(OrderDate).format("YYYY-MM-DD"),
        "date-------------------------"
      );
      var options = {
        orderId: OrderNumber.toString(),
        orderDate: moment(OrderDate).format("YYYY-MM-DD"),
        orderNumber: OrderNumber.toString(),
        fulfillmentStatus: "pending", //One of "pending", "fulfilled", or "partial"
        shippingService: "Standard", // for urgent delivery
        shippingTotal: shippingTotal.toString(),
        weightUnit: "lb", //Either "lb" for pounds or "kg" for kilograms
        dimUnit: "in", //Either "in" for inches or "cm" for centimeters
        dueByDate: moment(ShippingDate).format("YYYY-MM-DD"), //! yet to be added column on backend
        orderGroup: "Workstation", //May be set to allow multiple users to ship at the same time without overlapping
        contentDescription: null,
        sender: {
          name: StoreName,
          company: CompanyName,
          address1: FromAddress1,
          address2: FromAddress2,
          city: FromCity,
          state: FromState,
          zip: FromZip.toString(),
          country: "US",
          phone: FromPhone.toString(),
          email: FromEmail,
        },
        returnTo: {
          name: StoreName,
          company: CompanyName,
          address1: FromAddress1,
          address2: FromAddress2,
          city: FromCity,
          state: FromState,
          zip: FromZip.toString(),
          country: "US",
          phone: FromPhone.toString(),
          email: FromEmail,
        },
        receiver: {
          name: userName,
          company: userName,
          address1: userAddress1,
          address2: userAddress2 ? userAddress2 : "null",
          city: ToCity ? ToCity : "null",
          state: ToState,
          zip: userZip,
          country: "BD",
          phone: PhoneNumber,
          email: getDeliveryStatus[0].UserEmailAddress,
        },
        //items:null,
        items: item_array,
        packages: [{
          weight: uspsItemWeight.toString(),
          length: uspsItemLength.toString(),
          width: uspsItemWidth.toString(),
          height: uspsItemHeight.toString(),
          insuranceAmount: null,
          declaredValue: null,
        },],
      };
      console.log(options);
      console.log(
        `https://xpsshipper.com/restapi/v1/customers/${process.env.CustomerID}/integrations/${process.env.IntegrationId}/orders/${OrderNumber}`
      );
      let response = await axios.put(
        `https://xpsshipper.com/restapi/v1/customers/${process.env.CustomerID}/integrations/${process.env.IntegrationId}/orders/${OrderNumber}`,
        options, {
        headers: {
          Authorization: "RSIS " + process.env.APIKey,
        },
      }
      );
      console.log(response.data);
      if (response.data.ok === true) {
        const updateUSPSOrderPanelStatus = await connection.query(
          `UPDATE processorder SET UspsOrderStatus="On Panel" WHERE OrderNumber=${OrderNumber}`
        );
        if (updateUSPSOrderPanelStatus) {
          if (transaction) await transaction.commit();
          res.status(200).json({
            status: true,
            message: "Order request is successfully placed on XPS panel",
          });
        } else {
          if (transaction) await transaction.rollback();
          res.status(200).json({
            status: false,
            message: "Error while saving updates in DB",
          });
        }
      } else {
        if (transaction) await transaction.rollback();
        res.status(200).json({
          status: false,
          message: response.data,
        });
      }
    }
    if (DeliveryStatus == "dhl") {
      // prints something like '2023-03-14T13:30:45+0100'
      let today = new Date();
      let plannedShippingDate = new Date(
        today.getFullYear(),
        today.getMonth(),
        today.getDate() + 5
      );

      const getUserAndStoreDetails = await connection.query(
        `SELECT vs.*,pf.EmailAddress AS UserEmail,v.CompanyName,od.ZipCode AS PostalCode,od.PhoneNumber,od.City AS DeliveryCity,od.Address1 AS  userAddress1,od.Address2 AS userAddress2,od.Name AS UserName,SUM(p.Weight) AS totalWeight,SUM(p.Height) AS totalHeight,SUM(p.Length) AS totalLength,SUM(p.Width) AS totalWidth,po.UserID,c.ISO2 AS CountryCode,c.Country AS CountryName
      FROM processorder po
      INNER JOIN vendorstore vs ON vs.VendorStoreID=po.VendorStoreID
      INNER JOIN profile pf ON pf.UserID=po.UserID
      INNER JOIN vendor v ON v.VendorID=vs.VendorID
      INNER JOIN orderdeliveryaddress od ON od.OrderNumber=po.OrderNumber
      INNER JOIN country c ON c.CountryID=od.CountryID
      INNER JOIN product p ON p.ProductID=po.ProductID
      WHERE po.OrderNumber="${OrderNumber}"
      GROUP BY p.StoreName
     `, {
        type: QueryTypes.SELECT,
        transaction,
      }
      );
      //console.log(getUserAndStoreDetails, "getUserAndStoreDetails");
      if (getUserAndStoreDetails && getUserAndStoreDetails.length > 0) {
        let storePostalCode = getUserAndStoreDetails[0].ZipCode;
        let storeCityName = getUserAndStoreDetails[0].City;
        let storeAddress1 = getUserAndStoreDetails[0].Address1;
        let storeAddress2 = getUserAndStoreDetails[0].Address2;
        let storeEmail = getUserAndStoreDetails[0].StoreEmail;
        let storePhone = getUserAndStoreDetails[0].StorePhone;
        let storeName = getUserAndStoreDetails[0].StoreName;
        let companyName = getUserAndStoreDetails[0].CompanyName;
        let userPostalCode = getUserAndStoreDetails[0].PostalCode;
        let userAddress1 = getUserAndStoreDetails[0].userAddress1;
        let userAddress2 = getUserAndStoreDetails[0].userAddress2;
        let userPhone = getUserAndStoreDetails[0].PhoneNumber;
        let deliveryCity = getUserAndStoreDetails[0].DeliveryCity;
        let userName = getUserAndStoreDetails[0].UserName;
        let EmailAddress = getUserAndStoreDetails[0].UserEmail;
        let UserID = getUserAndStoreDetails[0].UserID;
        let deliveryCountryCode = getUserAndStoreDetails[0].CountryCode;
        let deliveryCountryName = getUserAndStoreDetails[0].CountryName;
        let totalWeight = getUserAndStoreDetails[0].totalWeight;
        let totalLength = getUserAndStoreDetails[0].totalLength;
        let totalWidth = getUserAndStoreDetails[0].totalWidth;
        let totalHeight = getUserAndStoreDetails[0].totalHeight;

        var data = {
          plannedShippingDateAndTime: "2023-03-12T17:10:09 GMT+01:00", //YYYY-MM-DD;
          pickup: {
            isRequested: false,
          },
          // pickup: {
          //   isRequested: true,
          //   pickupDetails: {
          //     postalAddress: {
          //       postalCode: storePostalCode.toString(),
          //       cityName: storeCityName,
          //       countryCode: "BD",
          //       addressLine1: storeAddress1,
          //       addressLine2: storeAddress2,
          //     },
          //     contactInformation: {
          //       email: String(storeEmail),
          //       phone: String(storePhone),
          //       companyName: companyName,
          //       fullName: storeName,
          //     },
          //   },
          //   pickupRequestorDetails: {
          //     postalAddress: {
          //       postalCode: storePostalCode.toString(),
          //       cityName: storeCityName,
          //       countryCode: "BD",
          //       addressLine1: storeAddress1,
          //       addressLine2: storeAddress2,
          //     },
          //     contactInformation: {
          //       email: String(storeEmail),
          //       phone: String(storePhone),
          //       companyName: companyName,
          //       fullName: storeName,
          //     },
          //   },
          // },
          productCode: "D", //Please enter DHL Express Global Product code max:6
          accounts: [{
            typeCode: "shipper",
            number: "525078203"
          }],
          customerDetails: {
            shipperDetails: {
              postalAddress: {
                postalCode: storePostalCode.toString(),
                cityName: storeCityName,
                countryCode: "BD",
                addressLine1: storeAddress1,
                addressLine2: storeAddress2,
              },
              contactInformation: {
                email: String(storeEmail),
                phone: String(storePhone),
                companyName: companyName,
                fullName: storeName,
              },
            },
            receiverDetails: {
              postalAddress: {
                postalCode: userPostalCode.toString(),
                cityName: deliveryCity,
                countryCode: deliveryCountryCode,
                addressLine1: userAddress1,
                addressLine2: userAddress2,
                countryName: deliveryCountryName,
              },
              contactInformation: {
                phone: userPhone,
                companyName: userName,
                fullName: userName,
              },
            },
          },
          content: {
            packages: [{
              weight: parseFloat(totalWeight),
              dimensions: {
                length: parseFloat(totalLength),
                width: parseFloat(totalWidth),
                height: parseFloat(totalHeight),
              },
              customerReferences: [{
                value: "Customer reference", //req
              },],
            },],
            isCustomsDeclarable: false, //req
            // declaredValue:"",
            // declaredValueCurrency:"",
            description: "shipment description", //req
            incoterm: "DAP", //req
            unitOfMeasurement: "metric", //req
          },
          shipmentNotification: [{
            typeCode: "email", //req
            receiverId: EmailAddress, //req
            // bespokeMessage: "Your order is assigned to DHL courier service",
          },],
        };
        const response = await axios.post(`${dhl_url}/shipments`, data, {
          auth: {
            username: dhl_username,
            password: dhl_password,
          },
        });
        console.log(response, "response");

        if (response.data) {
          let DhlTrackingNumber = response.data.shipmentTrackingNumber;
          let DhlTrackingUrl = response.data.trackingUrl;

          let currentdateAndTime = [];
          let LastUpdate = new Date()
            .toISOString()
            .slice(0, 19)
            .replace("T", " ");
          currentdateAndTime[0] = LastUpdate;
          let StatusHistory = JSON.stringify(currentdateAndTime);
          assignOrderToDHL = await connection.query(
            `UPDATE processorder SET  ProcessStatus="Assigned",DhlTrackingNumber="${DhlTrackingNumber}",DhlTrackingUrl="${DhlTrackingUrl}",
            StatusHistory='${StatusHistory}',LastUpdate="${LastUpdate}" WHERE OrderNumber="${OrderNumber}" `, {
            transaction,
          }
          );
          if (assignOrderToDHL) {
            let TypeID = "6";
            let CreaterID = "1";
            let Body = {
              OrderNumber: OrderNumber,
              body: `Your Order ${OrderNumber} is Assigned to DHL `,
            };
            let Message = `You Order # ${Body.OrderNumber} is Assigned to DHL`;

            sendEmail(EmailAddress, Message, TypeID);

            let sendNotification = await Notification(
              TypeID,
              Body,
              CreaterID,
              UserID,
              transaction
            );
            console.log(sendNotification, "sendNotification");

            if (sendNotification) {
              if (transaction) await transaction.commit();
              return res.status(200).json({
                status: true,
                message: " Order is Assigned to DHL Successfully",
              });
            } else {
              if (transaction) await transaction.rollback();
              res.status(200).json({
                status: false,
                message: "Error while sending Notification to User ",
              });
            }
          } else {
            if (transaction) await transaction.rollback();
            res.status(200).json({
              status: false,
              message: "Error While assigning DHL the given Order  ",
            });
          }
        } else {
          if (transaction) await transaction.rollback();
          res.status(200).json({
            status: false,
            message: "Error while getting DHL api response",
          });
        }
      } else {
        if (transaction) await transaction.rollback();
        res.status(200).json({
          status: false,
          message: "Error while getting user and store details from db",
        });
      }
    }
    if (
      DeliveryStatus == "null" ||
      DeliveryStatus == "NULL" ||
      DeliveryStatus == " " ||
      DeliveryStatus == null
    ) {
      console.log(" Deliery Status cannot be NULL || null or Invalid ");
      if (transaction) await transaction.rollback();
      res.status(200).json({
        status: false,
        message: "Deliery Status cannot be NULL || null or Invalid",
      });
    }
  } catch (e) {
    console.log(e.response.data);
    if (transaction) await transaction.rollback();
    res.status(200).json({
      status: false,
      message: e,
    });
  }
};
exports.getDriverOrdersByStatus = async (req, res, next) => {
  try {
    const {
      sort,
      status,
      limit,
      offset,
      DeliveryDriverID
    } = req.body;
    if (status === "All") {
      let productCombinationPriceDetail = [];
      let ordersCount = await connection.query(
        `SELECT COUNT(*) AS total_records
                FROM 
                (SELECT COUNT (OrderNumber)  FROM processorder WHERE DeliveryDriverID="${DeliveryDriverID}"
                 GROUP BY OrderNumber)total_record `, {
        type: QueryTypes.SELECT,
      }
      );
      if (ordersCount && ordersCount.length > 0) {
        let viewOrderListQuery =
          `SELECT p.ProductID,p.Title,m.TransactionID,s.OrderNumber,s.AllowStorePickup,s.AllowAdminPickup,s.ReadyPickupForUser,s.ReadyPickupForAdmin,s.OrderDate,m.PaymentStatus,p.Price AS BasePrice,p.Currency,s.UserID,g.Small,g.Medium,g.Large,i.MainImage,s.ConsignmentId,s.DeliveryDriverID,s.ProcessStatus,s.DeliveryStatus,m.OrderTotal,s.PaymentType,s.ItemsPrice,s.ItemsEstimatedTax,s.ItemsShippingHandling,s.ReturnOrder,s.ProductVariantCombinationDetail,if(s.ReturnOrder="Y",s.OrderNumber,0) AS isReturnOrder
                FROM ((((((( product p      
                LEFT JOIN productvariantoption o ON o.ProductID IN( p.ProductID))
                LEFT JOIN productvariantoptionvalue v  ON  v.OptionID IN (o.OptionID))  
                LEFT JOIN productimage i  ON  i.OptionValueID IN (v.OptionValueID))
                LEFT JOIN imagegallery g  ON  g.ImageGalleryID IN (i.ImageGalleryID))
                LEFT JOIN productvariantcombination c  ON  c.OptionValueID IN (v.OptionValueID))
                LEFT JOIN processorder s ON s.ProductID IN(c.ProductID))
                LEFT JOIN processpayment m ON m.OrderNumber IN(s.OrderNumber))
                WHERE i.MainImage='Y'  AND  s.DeliveryDriverID="${DeliveryDriverID}" 
                GROUP BY s.ProcessOrderID
                ORDER by s.ProcessOrderID ${sort} limit ` +
          limit +
          " offset " +
          offset;
        let viewOrderList = await connection.query(viewOrderListQuery, {
          type: QueryTypes.SELECT,
        });
        console.log(viewOrderList);
        let productCombinationDetail;
        if (viewOrderList && viewOrderList.length > 0) {
          for (let i = 0; i < viewOrderList.length; i++) {
            let ProductVariantCombinationDetail = [];
            ProductVariantCombinationDetail.push(
              viewOrderList[i].ProductVariantCombinationDetail
            );
            ProductVariantCombinationDetail = `(${ProductVariantCombinationDetail.join(
              ","
            )})`;
            productCombinationDetail = await connection.query(
              `SELECT p.ProductID,c.ProductVariantCombinationID,c.VendorStoreID,c.Price AS ProductCombinationPrice,c.AvailableInventory,o.OptionID,o.OptionName,v.OptionValue,v.OptionValueID
                    FROM ((((product p
                    LEFT JOIN productvariantoption o ON o.ProductID IN( p.ProductID))
                    LEFT JOIN productvariantoptionvalue v  ON  v.OptionID IN (o.OptionID)) 
                    LEFT JOIN productvariantcombination c  ON  c.OptionValueID IN (v.OptionValueID))
                    LEFT JOIN processorder s ON s.ProductID IN(c.ProductID))
                    WHERE  c.ProductVariantCombinationID IN ${ProductVariantCombinationDetail}
                    GROUP BY c.OptionValueID
                    ORDER by s.ProcessOrderID ${sort} 
                   `, {
              type: QueryTypes.SELECT,
            }
            );
            productCombinationPriceDetail.push(productCombinationDetail);
          }
          let orderName = [];
          let orderDate = [];
          let paymentStatus = [];
          let transactionID = [];
          let tempPC = productCombinationPriceDetail;
          let tempProd = viewOrderList;
          let tempArray = [];
          let allowStorePickup = [];
          let readyPickupForUser = [];
          let readyPickupForAdmin = [];
          let allowAdminPickup = [];
          var deliveryDriverID = [];
          let tempAOrderDetails = [];
          let consignmentID = [];
          let processStatus = [];
          let returnOrdersArray = [];
          for (let i = 0; i < tempProd.length; i++) {
            var obj = {
              ...tempProd[i],
            };
            obj["ProductCombinations"] = tempPC[i];
            tempArray.push(obj);
          }
          for (let i = 0; i < tempArray.length; i++) {
            if (!orderName.includes(tempArray[i].OrderNumber)) {
              orderName.push(tempArray[i].OrderNumber);
              orderDate.push(tempArray[i].OrderDate);
              paymentStatus.push(tempArray[i].PaymentStatus);
              transactionID.push(tempArray[i].TransactionID);
              allowStorePickup.push(tempArray[i].AllowStorePickup);
              readyPickupForUser.push(tempArray[i].ReadyPickupForUser);
              readyPickupForAdmin.push(tempArray[i].ReadyPickupForAdmin);
              allowAdminPickup.push(tempArray[i].AllowAdminPickup);
              deliveryDriverID.push(tempArray[i].DeliveryDriverID);
              consignmentID.push(tempArray[i].ConsignmentId);
              processStatus.push(tempArray[i].ProcessStatus);
            }
            returnOrdersArray.push(tempArray[i].isReturnOrder);
          }
          console.log(returnOrdersArray);
          for (let i = 0; i < orderName.length; i++) {
            if (returnOrdersArray.includes(orderName[i])) {
              var obj = {
                OrderNumber: orderName[i],
                OrderDate: orderDate[i],
                PaymentStatus: paymentStatus[i],
                TransactionID: transactionID[i],
                AllowStorePickup: allowStorePickup[i],
                ReadyPickupForUser: readyPickupForUser[i],
                ReadyPickupForAdmin: readyPickupForAdmin[i],
                AllowAdminPickup: allowAdminPickup[i],
                DeliveryDriverID: deliveryDriverID[i],
                ConsignmentId: consignmentID[i],
                ProcessStatus: processStatus[i],
                ReturnOrder: true,
                ProductDetail: [],
              };
            } else {
              var obj = {
                OrderNumber: orderName[i],
                OrderDate: orderDate[i],
                PaymentStatus: paymentStatus[i],
                TransactionID: transactionID[i],
                AllowStorePickup: allowStorePickup[i],
                ReadyPickupForUser: readyPickupForUser[i],
                ReadyPickupForAdmin: readyPickupForAdmin[i],
                AllowAdminPickup: allowAdminPickup[i],
                DeliveryDriverID: deliveryDriverID[i],
                ConsignmentId: consignmentID[i],
                ProcessStatus: processStatus[i],
                ReturnOrder: false,
                ProductDetail: [],
              };
            }
            for (let j = 0; j < tempArray.length; j++) {
              if (orderName[i] === tempArray[j].OrderNumber) {
                obj.ProductDetail.push(tempArray[j]);
              }
            }
            tempAOrderDetails.push(obj);
          }
          if (productCombinationDetail && productCombinationDetail.length > 0) {
            res.status(200).json({
              status: true,
              total_records: ordersCount[0].total_records,
              orderDetails: tempAOrderDetails,
            });
          } else {
            res.status(200).json({
              status: true,
              total_records: ordersCount[0].total_records,
              orderDetails: [],
            });
          }
        } else {
          res.status(200).json({
            status: true,
            total_records: ordersCount[0].total_records,
            orderDetails: [],
          });
        }
      } else {
        res.status(200).json({
          status: true,
          total_records: ordersCount[0].total_records,
          orderDetails: [],
        });
      }
    } else {
      let productCombinationPriceDetail = [];
      let ordersCount = await connection.query(
        `SELECT COUNT(*) AS total_records
            FROM 
            (SELECT COUNT (OrderNumber)  FROM processorder WHERE ProcessStatus="${status}" AND DeliveryDriverID="${DeliveryDriverID}"
             GROUP BY OrderNumber)total_record `, {
        type: QueryTypes.SELECT,
      }
      );
      if (ordersCount && ordersCount.length > 0) {
        let viewOrderListQuery =
          `SELECT p.ProductID,p.Title,m.TransactionID,s.OrderNumber,s.AllowStorePickup,s.AllowAdminPickup,s.ReadyPickupForUser,s.ReadyPickupForAdmin,s.OrderDate,m.PaymentStatus,p.Price AS BasePrice,p.Currency,s.UserID,g.Small,g.Medium,g.Large,i.MainImage,s.ConsignmentId,s.DeliveryDriverID,s.ProcessStatus,s.DeliveryStatus,m.OrderTotal,s.PaymentType,s.ItemsPrice,s.ItemsEstimatedTax,s.ItemsShippingHandling,s.ReturnOrder,s.ProductVariantCombinationDetail,if(s.ReturnOrder="Y",s.OrderNumber,0) AS isReturnOrder
            FROM ((((((( product p      
            LEFT JOIN productvariantoption o ON o.ProductID IN( p.ProductID))
            LEFT JOIN productvariantoptionvalue v  ON  v.OptionID IN (o.OptionID))  
            LEFT JOIN productimage i  ON  i.OptionValueID IN (v.OptionValueID))
            LEFT JOIN imagegallery g  ON  g.ImageGalleryID IN (i.ImageGalleryID))
            LEFT JOIN productvariantcombination c  ON  c.OptionValueID IN (v.OptionValueID))
            INNER JOIN processorder s ON s.ProductID IN(c.ProductID))
            LEFT JOIN processpayment m ON m.OrderNumber IN(s.OrderNumber))
            WHERE i.MainImage='Y' AND  s.DeliveryDriverID="${DeliveryDriverID}" AND s.ProcessStatus="${status}" 
            ORDER by s.ProcessOrderID ${sort} limit ` +
          limit +
          " offset " +
          offset;
        let viewOrderList = await connection.query(viewOrderListQuery, {
          type: QueryTypes.SELECT,
        });
        let productCombinationDetail;
        if (viewOrderList && viewOrderList.length > 0) {
          for (let i = 0; i < viewOrderList.length; i++) {
            let ProductVariantCombinationDetail = [];
            ProductVariantCombinationDetail.push(
              viewOrderList[i].ProductVariantCombinationDetail
            );
            ProductVariantCombinationDetail = `(${ProductVariantCombinationDetail.join(
              ","
            )})`;
            productCombinationDetail = await connection.query(
              `SELECT p.ProductID,c.ProductVariantCombinationID,c.VendorStoreID,c.Price AS ProductCombinationPrice,c.AvailableInventory,o.OptionID,o.OptionName,v.OptionValue,v.OptionValueID
                FROM ((((product p
                LEFT JOIN productvariantoption o ON o.ProductID IN( p.ProductID))
                LEFT JOIN productvariantoptionvalue v  ON  v.OptionID IN (o.OptionID)) 
                LEFT JOIN productvariantcombination c  ON  c.OptionValueID IN (v.OptionValueID))
                LEFT JOIN processorder s ON s.ProductID IN(c.ProductID))
                WHERE  c.ProductVariantCombinationID IN ${ProductVariantCombinationDetail}
                GROUP BY c.OptionValueID
                ORDER by s.ProcessOrderID ${sort} 
               `, {
              type: QueryTypes.SELECT,
            }
            );
            productCombinationPriceDetail.push(productCombinationDetail);
          }
          let orderName = [];
          let orderDate = [];
          let paymentStatus = [];
          let transactionID = [];
          let tempPC = productCombinationPriceDetail;
          let tempProd = viewOrderList;
          let tempArray = [];
          let allowStorePickup = [];
          let readyPickupForUser = [];
          let readyPickupForAdmin = [];
          let allowAdminPickup = [];
          var deliveryDriverID = [];
          let tempAOrderDetails = [];
          let consignmentID = [];
          let processStatus = [];
          let returnOrdersArray = [];
          for (let i = 0; i < tempProd.length; i++) {
            var obj = {
              ...tempProd[i],
            };
            obj["ProductCombinations"] = tempPC[i];
            tempArray.push(obj);
          }
          for (let i = 0; i < tempArray.length; i++) {
            if (!orderName.includes(tempArray[i].OrderNumber)) {
              orderName.push(tempArray[i].OrderNumber);
              orderDate.push(tempArray[i].OrderDate);
              paymentStatus.push(tempArray[i].PaymentStatus);
              transactionID.push(tempArray[i].TransactionID);
              allowStorePickup.push(tempArray[i].AllowStorePickup);
              readyPickupForUser.push(tempArray[i].ReadyPickupForUser);
              readyPickupForAdmin.push(tempArray[i].ReadyPickupForAdmin);
              allowAdminPickup.push(tempArray[i].AllowAdminPickup);
              deliveryDriverID.push(tempArray[i].DeliveryDriverID);
              consignmentID.push(tempArray[i].ConsignmentId);
              processStatus.push(tempArray[i].ProcessStatus);
            }
            returnOrdersArray.push(tempArray[i].isReturnOrder);
          }
          for (let i = 0; i < orderName.length; i++) {
            if (returnOrdersArray.includes(orderName[i])) {
              var obj = {
                OrderNumber: orderName[i],
                OrderDate: orderDate[i],
                PaymentStatus: paymentStatus[i],
                TransactionID: transactionID[i],
                AllowStorePickup: allowStorePickup[i],
                ReadyPickupForUser: readyPickupForUser[i],
                ReadyPickupForAdmin: readyPickupForAdmin[i],
                AllowAdminPickup: allowAdminPickup[i],
                DeliveryDriverID: deliveryDriverID[i],
                ConsignmentId: consignmentID[i],
                ProcessStatus: processStatus[i],
                ReturnOrder: true,
                ProductDetail: [],
              };
            } else {
              var obj = {
                OrderNumber: orderName[i],
                OrderDate: orderDate[i],
                PaymentStatus: paymentStatus[i],
                TransactionID: transactionID[i],
                AllowStorePickup: allowStorePickup[i],
                ReadyPickupForUser: readyPickupForUser[i],
                ReadyPickupForAdmin: readyPickupForAdmin[i],
                AllowAdminPickup: allowAdminPickup[i],
                DeliveryDriverID: deliveryDriverID[i],
                ConsignmentId: consignmentID[i],
                ProcessStatus: processStatus[i],
                ReturnOrder: false,
                ProductDetail: [],
              };
            }
            for (let j = 0; j < tempArray.length; j++) {
              if (orderName[i] === tempArray[j].OrderNumber) {
                obj.ProductDetail.push(tempArray[j]);
              }
            }
            tempAOrderDetails.push(obj);
          }
          if (productCombinationDetail && productCombinationDetail.length > 0) {
            res.status(200).json({
              status: true,
              total_records: ordersCount[0].total_records,
              orderDetails: tempAOrderDetails,
            });
          } else {
            res.status(200).json({
              status: true,
              total_records: ordersCount[0].total_records,
              orderDetails: [],
            });
          }
        } else {
          res.status(200).json({
            status: true,
            total_records: ordersCount[0].total_records,
            orderDetails: [],
          });
        }
      } else {
        res.status(200).json({
          status: true,
          total_records: ordersCount[0].total_records,
          orderDetails: [],
        });
      }
    }
  } catch (err) {
    console.log(err.message);
    next(err);
    res.status(200).json({
      status: false,
      orderDetails: [],
    });
  }
};
exports.changeDriverOrderStatus = async (req, res, next) => {
  let transaction;
  try {
    const {
      status,
      OrderNumber,
      DeliveryDriverID
    } = req.body;
    let body;
    transaction = await connection.transaction();
    let changeOrderStatus;
    let LastUpdate = new Date().toISOString().slice(0, 19).replace("T", " ");
    let StatusHistory = [];
    let orderStatus;
    let parsePreviousStatusHistory = [];
    let getOrderDetail = await connection.query(
      `SELECT * from processorder  WHERE  OrderNumber="${OrderNumber}" AND DeliveryDriverID="${DeliveryDriverID}" `, {
      type: QueryTypes.SELECT,
      transaction,
    }
    );


    if (getOrderDetail && getOrderDetail.length > 0) {
      let ReceiverID = getOrderDetail[0].UserID;
      if (status == "Picked") {
        body = `Your order ${OrderNumber} is Picked By Delivery Person`;
        orderStatus = "Picked";
        let retrivePreviousStatusHistory = await connection.query(
          `SELECT * from processorder  WHERE  OrderNumber="${OrderNumber}" AND DeliveryDriverID="${DeliveryDriverID}" `, {
          type: QueryTypes.SELECT,
          transaction,
        }
        );
        console.log(retrivePreviousStatusHistory[0].StatusHistory);
        parsePreviousStatusHistory = JSON.parse(
          retrivePreviousStatusHistory[0].StatusHistory
        );
        parsePreviousStatusHistory.push(LastUpdate);
        //retrive previous
        //JSON.parse
        //push [1]
        //JSON.strigify
        changeOrderStatus = await connection.query(
          `UPDATE processorder SET ProcessStatus="${status}",StatusHistory='${JSON.stringify(
            parsePreviousStatusHistory
          )}',LastUpdate="${LastUpdate}" WHERE OrderNumber="${OrderNumber}" AND DeliveryDriverID="${DeliveryDriverID}"`, {
          transaction,
        }
        );
      }
      if (status == "On the Way") {
        body = `Your order ${OrderNumber} is on the way`;
        orderStatus = "On the Way";
        let retrivePreviousStatusHistory = await connection.query(
          `SELECT * from processorder  WHERE  OrderNumber="${OrderNumber}" AND DeliveryDriverID="${DeliveryDriverID}" `, {
          type: QueryTypes.SELECT,
          transaction,
        }
        );
        console.log(retrivePreviousStatusHistory[0].StatusHistory);
        parsePreviousStatusHistory = JSON.parse(
          retrivePreviousStatusHistory[0].StatusHistory
        );
        parsePreviousStatusHistory.push(LastUpdate);
        changeOrderStatus = await connection.query(
          `UPDATE processorder SET ProcessStatus="${status}",StatusHistory='${JSON.stringify(
            parsePreviousStatusHistory
          )}',LastUpdate="${LastUpdate}" WHERE OrderNumber="${OrderNumber}" AND DeliveryDriverID="${DeliveryDriverID}"`, {
          transaction,
        }
        );
      }
      if (status == "Delivered") {
        body = `Your order ${OrderNumber} is Delivered`;
        orderStatus = "Delivered";
        let DeliveryConfirmationPic;
        if (req.file && Object.keys(req.file).length > 0) {
          if (req.file.path && req.file.path.length > 0) {
            DeliveryConfirmationPic = req.file.path;
          } else {
            DeliveryConfirmationPic = null;
          }
        } else {
          DeliveryConfirmationPic = null;
        }
        let retrivePreviousStatusHistory = await connection.query(
          `SELECT * from processorder  WHERE  OrderNumber="${OrderNumber}" AND DeliveryDriverID="${DeliveryDriverID}" `, {
          type: QueryTypes.SELECT,
          transaction,
        }
        );
        console.log(retrivePreviousStatusHistory[0].StatusHistory);
        parsePreviousStatusHistory = JSON.parse(
          retrivePreviousStatusHistory[0].StatusHistory
        );
        parsePreviousStatusHistory.push(LastUpdate);
        let changeOrderStatusQuery = `UPDATE processorder,processpayment
        SET processorder.ProcessStatus="${status}",processorder.StatusHistory='${JSON.stringify(
          parsePreviousStatusHistory
        )}',processorder.LastUpdate="${LastUpdate}",processorder.DeliveryConfirmationPic=?,processorder.DeliveryDate="${LastUpdate}",processpayment.PaymentStatus = "Paid"
       WHERE processorder.OrderNumber="${OrderNumber}" AND processorder.DeliveryDriverID="${DeliveryDriverID}"
       AND processpayment.OrderNumber="${OrderNumber}"`;
        changeOrderStatus = await connection.query(changeOrderStatusQuery, {
          replacements: [DeliveryConfirmationPic],
          transaction,
        });
      }
      if (changeOrderStatus) {
        let TypeID = "6";
        let CreaterID = "1";
        let Body = {
          OrderNumber: OrderNumber,
          body,
        };
        let Message = `You Order # ${Body.OrderNumber} is ${orderStatus} `;
        let getDeviceIDQuery = ` SELECT DeviceID,EmailAddress,UserID
                FROM profile 
                WHERE UserID=${ReceiverID}`;
        let getDeviceID = await connection.query(getDeviceIDQuery, {
          type: QueryTypes.SELECT,
          transaction,
        });
        if (getDeviceID && getDeviceID.length > 0) {
          let DeviceID = getDeviceID[0].DeviceID;
          let EmailAddress = getDeviceID[0].EmailAddress;
          let ReceiverID = getDeviceID[0].UserID;
          console.log(DeviceID);
          console.log("DEVICE ID EXISTS CONDITION -----------------");
          sendEmail(EmailAddress, Message, TypeID);
          let sendNotification = await Notification(
            TypeID,
            Body,
            CreaterID,
            ReceiverID,
            transaction
          );
          console.log(sendNotification, "sendNotification");
          if (sendNotification) {
            if (transaction) await transaction.commit(); //!final commit
            res.status(200).json({
              status: true,
              message: "Order Status Updated Sucessfully ",
            });
          } else {
            if (transaction) await transaction.rollback();
            res.status(200).json({
              status: false,
              message: "Error while sending Notification to User ",
            });
          }
        } else {
          if (transaction) await transaction.rollback();
          res.status(200).json({
            status: false,
            message: "Error while getting user data from Database ",
          });
        }
      } else {
        if (transaction) await transaction.rollback();
        res.status(200).json({
          status: false,
          message: "Error while updating order status ",
        });
      }
    } else {
      if (transaction) await transaction.rollback();
      res.status(200).json({
        status: false,
        message: "No record found to update against this data ",
      });
    }
  } catch (err) {
    console.log(err.message, "------------------------------");
    if (transaction) await transaction.rollback();
    next(err);
    res.status(200).json({
      status: false,
      error: err.message,
    });
  }
};
exports.updatePathaoOrderStatus = async (req, res, next) => {
  let transaction;
  try {
    const {
      status,
      OrderNumber
    } = req.body;
    let body;
    transaction = await connection.transaction();
    let changeOrderStatus;
    let LastUpdate = new Date().toISOString().slice(0, 19).replace("T", " ");
    let StatusHistory = [];
    let orderStatus;
    let parsePreviousStatusHistory = [];
    let getOrderDetail = await connection.query(
      `SELECT * from processorder  WHERE  OrderNumber="${OrderNumber}" AND DeliveryStatus="pathao" `, {
      type: QueryTypes.SELECT,
      transaction,
    }
    );
    console.log(
      getOrderDetail,
      "getOrderDetail--------------------------------------"
    );
    if (getOrderDetail && getOrderDetail.length > 0) {
      let ReceiverID = getOrderDetail[0].UserID;
      if (status == "Picked") {
        body = `Your order ${OrderNumber} is Picked By Pathao Delivery Person`;
        orderStatus = "Picked";

        console.log(getOrderDetail[0].StatusHistory);
        parsePreviousStatusHistory = JSON.parse(
          getOrderDetail[0].StatusHistory
        );
        parsePreviousStatusHistory.push(LastUpdate);
        //retrive previous
        //JSON.parse
        //push [1]
        //JSON.strigify
        changeOrderStatus = await connection.query(
          `UPDATE processorder SET ProcessStatus="${status}",StatusHistory='${JSON.stringify(
            parsePreviousStatusHistory
          )}',LastUpdate="${LastUpdate}" WHERE OrderNumber="${OrderNumber}" AND DeliveryStatus="pathao" `, {
          transaction,
        }
        );
      }
      if (status == "On the Way") {
        body = `Your order ${OrderNumber} is on the way`;
        orderStatus = "On the Way";

        console.log(getOrderDetail[0].StatusHistory);
        parsePreviousStatusHistory = JSON.parse(
          getOrderDetail[0].StatusHistory
        );
        parsePreviousStatusHistory.push(LastUpdate);
        changeOrderStatus = await connection.query(
          `UPDATE processorder SET ProcessStatus="${status}",StatusHistory='${JSON.stringify(
            parsePreviousStatusHistory
          )}',LastUpdate="${LastUpdate}" WHERE OrderNumber="${OrderNumber}" AND DeliveryStatus="pathao"  `, {
          transaction,
        }
        );
      }
      if (status == "Delivered") {
        body = `Your order ${OrderNumber} is Delivered`;
        orderStatus = "Delivered";
        let DeliveryConfirmationPic;
        if (req.file && Object.keys(req.file).length > 0) {
          if (req.file.path && req.file.path.length > 0) {
            DeliveryConfirmationPic = req.file.path;
          } else {
            DeliveryConfirmationPic = null;
          }
        } else {
          DeliveryConfirmationPic = null;
        }
        console.log(getOrderDetail[0].StatusHistory);
        parsePreviousStatusHistory = JSON.parse(
          getOrderDetail[0].StatusHistory
        );
        parsePreviousStatusHistory.push(LastUpdate);
        changeOrderStatus = await connection.query(
          `UPDATE processorder SET ProcessStatus="${status}",StatusHistory='${JSON.stringify(
            parsePreviousStatusHistory
          )}',LastUpdate="${LastUpdate}",DeliveryConfirmationPic="${DeliveryConfirmationPic}",DeliveryDate="${LastUpdate}" WHERE OrderNumber="${OrderNumber}"  AND DeliveryStatus="pathao" `, {
          transaction,
        }
        );
      }
      if (changeOrderStatus) {
        let TypeID = "6";
        let CreaterID = "1";
        let Body = {
          OrderNumber: OrderNumber,
          body,
        };
        let Message = `You Order # ${Body.OrderNumber} is ${orderStatus} `;
        let getDeviceIDQuery = ` SELECT DeviceID,EmailAddress,UserID
                FROM profile 
                WHERE UserID=${ReceiverID}`;
        let getDeviceID = await connection.query(getDeviceIDQuery, {
          type: QueryTypes.SELECT,
          transaction,
        });
        if (getDeviceID && getDeviceID.length > 0) {
          let DeviceID = getDeviceID[0].DeviceID;
          let EmailAddress = getDeviceID[0].EmailAddress;
          let ReceiverID = getDeviceID[0].UserID;
          console.log(DeviceID);

          sendEmail(EmailAddress, Message, TypeID);

          let sendNotification = await Notification(
            TypeID,
            Body,
            CreaterID,
            ReceiverID,
            transaction
          );
          console.log(sendNotification, "sendNotification");
          if (sendNotification) {
            if (transaction) await transaction.commit(); //!final commit
            res.status(200).json({
              status: true,
              message: "Order Status Updated Sucessfully ",
            });
          } else {
            if (transaction) await transaction.rollback();
            res.status(200).json({
              status: false,
              message: "Error while sending Notification to User ",
            });
          }
        } else {
          if (transaction) await transaction.rollback();
          res.status(200).json({
            status: false,
            message: "Error while getting user data from Database ",
          });
        }
      } else {
        if (transaction) await transaction.rollback();
        res.status(200).json({
          status: false,
          message: "Error while updating order status ",
        });
      }
    } else {
      if (transaction) await transaction.rollback();
      res.status(200).json({
        status: false,
        message: "No record found to update against this data ",
      });
    }
  } catch (err) {
    if (transaction) await transaction.rollback();
    next(err);
    res.status(200).json({
      status: false,
      error: err.message,
    });
  }
};
exports.markReturnedStatus = async (req, res, next) => {
  let transaction;
  try {
    const {
      OrderNumber,
      DeliveryDriverID,
      ReturnReason
    } = req.body;
    transaction = await connection.transaction();
    let LastUpdate = new Date().toISOString().slice(0, 19).replace("T", " ");
    let getOrderDetail = await connection.query(
      `SELECT * from processorder  WHERE  OrderNumber="${OrderNumber}" AND DeliveryDriverID="${DeliveryDriverID}" `, {
      type: QueryTypes.SELECT,
      transaction,
    }
    );
    let ReceiverID = getOrderDetail[0].UserID;
    if (getOrderDetail && getOrderDetail.length > 0) {
      let changeOrderStatus = await connection.query(
        `UPDATE processorder SET ProcessStatus="Returned",ReturnReason="${ReturnReason}" , LastUpdate="${LastUpdate}" WHERE OrderNumber="${OrderNumber}" AND DeliveryDriverID="${DeliveryDriverID}"  `, {
        transaction,
      }
      );
      if (changeOrderStatus) {
        let TypeID = "6";
        let CreaterID = "1";
        let Body = {
          OrderNumber: OrderNumber,
          body: `Your order ${OrderNumber} is Returned`,
        };
        let Message = `You Order # ${Body.OrderNumber} is Returned `;
        let getDeviceIDQuery = ` SELECT DeviceID
                FROM profile 
                WHERE UserID=${UserID}`;
        let getDeviceID = await connection.query(getDeviceIDQuery, {
          type: QueryTypes.SELECT,
          transaction,
        });

        if (getDeviceID && getDeviceID.length > 0) {
          let DeviceID = getDeviceID[0].DeviceID;
          let EmailAddress = getDeviceID[0].EmailAddress;
          console.log(DeviceID);
          sendEmail(EmailAddress, Message, TypeID);
          let sendNotification = await Notification(
            TypeID,
            Body,
            CreaterID,
            ReceiverID,
            transaction
          );
          console.log(sendNotification, "sendNotification");
          if (sendNotification) {
            if (transaction) await transaction.commit();
            res.status(200).json({
              status: true,
              message: "Order Status Updated Sucessfully ",
            });
          } else {
            if (transaction) await transaction.rollback();
            res.status(200).json({
              status: false,
              message: "Error while sending Notification to User ",
            });
          }
        } else {
          if (transaction) await transaction.rollback();
          res.status(200).json({
            status: false,
            message: "Error while getting user data from Database ",
          });
        }
      } else {
        if (transaction) await transaction.rollback();
        res.status(200).json({
          status: false,
          message: "Error while updating order status ",
        });
      }
    } else {
      if (transaction) await transaction.rollback();
      res.status(200).json({
        status: false,
        message: "No record found to update against this data ",
      });
    }
  } catch (err) {
    if (transaction) await transaction.rollback();
    next(err);
    res.status(200).json({
      status: false,
      error: err.message,
    });
  }
};
exports.driverDashBoardApi = async (req, res, next) => {
  try {
    const {
      DeliveryDriverID,
      filter
    } = req.body;
    let getOrderDetail;
    let getDriverCollectedAmout;

    if (filter == "This Week") {
      getOrderDetail = await connection.query(
        `SELECT  
        COUNT(DISTINCT( CASE WHEN ProcessStatus = "Delivered" THEN OrderNumber END)) as DeliveredOrders,
        COUNT(DISTINCT(  CASE WHEN ProcessStatus = "Assigned" THEN OrderNumber END)) as AssignedOrders,
        COUNT(DISTINCT ( CASE WHEN ProcessStatus = "Picked" THEN OrderNumber END)) as PickedOrders,
        COUNT(DISTINCT ( CASE WHEN ProcessStatus = "Cancelled" THEN OrderNumber END)) as CancelledOrders,
        COUNT(DISTINCT ( CASE WHEN ProcessStatus = "On the Way" THEN OrderNumber END)) as OntheWayOrders,
            COUNT( CASE WHEN ReturnOrder = "Y" THEN 1 END) as ReturnOrders
            from processorder  WHERE  DeliveryDriverID="${DeliveryDriverID}" AND
            YEARWEEK(LastUpdate) = YEARWEEK(NOW()); `, {
        type: QueryTypes.SELECT,
      }
      );
      getDriverCollectedAmout = await connection.query(
        `SELECT SUM(ItemsShippingHandling)- SUM(ItemsShippingHandling) * 0.05 AS TotalEarning,
        Sum(Case When PaymentType="cod" AND  PaytoAdminCod="N"
        Then ItemsTotal Else 0 End) TotalCashCollected
                         from processorder  WHERE  DeliveryDriverID="${DeliveryDriverID}" AND ProcessStatus= "Delivered" AND
                         YEARWEEK(LastUpdate) = YEARWEEK(NOW());`, {
        type: QueryTypes.SELECT,
      }
      );
    }
    if (filter == "Last Week") {
      getOrderDetail = await connection.query(
        `SELECT  
        COUNT(DISTINCT( CASE WHEN ProcessStatus = "Delivered" THEN OrderNumber END)) as DeliveredOrders,
        COUNT(DISTINCT(  CASE WHEN ProcessStatus = "Assigned" THEN OrderNumber END)) as AssignedOrders,
        COUNT(DISTINCT ( CASE WHEN ProcessStatus = "Picked" THEN OrderNumber END)) as PickedOrders,
        COUNT(DISTINCT ( CASE WHEN ProcessStatus = "Cancelled" THEN OrderNumber END)) as CancelledOrders,
        COUNT(DISTINCT ( CASE WHEN ProcessStatus = "On the Way" THEN OrderNumber END)) as OntheWayOrders,
        COUNT(DISTINCT(  CASE WHEN ReturnOrder = "Y" THEN OrderNumber END)) as ReturnOrders
                from processorder  WHERE  DeliveryDriverID="${DeliveryDriverID}" AND 
                LastUpdate >= curdate() - INTERVAL DAYOFWEEK(curdate())+6 DAY
                AND LastUpdate < curdate() - INTERVAL DAYOFWEEK(curdate())-1 DAY `, {
        type: QueryTypes.SELECT,
      }
      );
      getDriverCollectedAmout = await connection.query(
        `SELECT SUM(ItemsShippingHandling)- SUM(ItemsShippingHandling) * 0.05 AS TotalEarning,
        Sum(Case When PaymentType="cod" AND  PaytoAdminCod="N" 
        Then ItemsTotal Else 0 End) TotalCashCollected
                             from processorder  WHERE  DeliveryDriverID="${DeliveryDriverID}" AND ProcessStatus= "Delivered"  AND 
                             LastUpdate >= curdate() - INTERVAL DAYOFWEEK(curdate())+6 DAY
                             AND LastUpdate < curdate() - INTERVAL DAYOFWEEK(curdate())-1 DAY`, {
        type: QueryTypes.SELECT,
      }
      );
    }
    if (filter == "Last Month") {
      getOrderDetail = await connection.query(
        `SELECT  
        COUNT(DISTINCT( CASE WHEN ProcessStatus = "Delivered" THEN OrderNumber END)) as DeliveredOrders,
        COUNT(DISTINCT(  CASE WHEN ProcessStatus = "Assigned" THEN OrderNumber END)) as AssignedOrders,
        COUNT(DISTINCT ( CASE WHEN ProcessStatus = "Picked" THEN OrderNumber END)) as PickedOrders,
        COUNT(DISTINCT ( CASE WHEN ProcessStatus = "Cancelled" THEN OrderNumber END)) as CancelledOrders,
        COUNT(DISTINCT ( CASE WHEN ProcessStatus = "On the Way" THEN OrderNumber END)) as OntheWayOrders,
        COUNT(DISTINCT(  CASE WHEN ReturnOrder = "Y" THEN OrderNumber END)) as ReturnOrders
            from processorder  WHERE  DeliveryDriverID="${DeliveryDriverID}" AND
            YEAR(LastUpdate) = YEAR(CURRENT_DATE - INTERVAL 1 MONTH)
            AND MONTH(LastUpdate) = MONTH(CURRENT_DATE - INTERVAL 1 MONTH); `, {
        type: QueryTypes.SELECT,
      }
      );
      getDriverCollectedAmout = await connection.query(
        `SELECT SUM(ItemsShippingHandling)- SUM(ItemsShippingHandling) * 0.05 AS TotalEarning,
        Sum(Case When PaymentType="cod" AND  PaytoAdminCod="N"
        Then ItemsTotal Else 0 End) TotalCashCollected
                                 from processorder  WHERE  DeliveryDriverID="${DeliveryDriverID}" AND ProcessStatus= "Delivered"  AND
                                 YEAR(LastUpdate) = YEAR(CURRENT_DATE - INTERVAL 1 MONTH)
                                 AND MONTH(LastUpdate) = MONTH(CURRENT_DATE - INTERVAL 1 MONTH);`, {
        type: QueryTypes.SELECT,
      }
      );
    }
    if (filter == "This Month") {
      getOrderDetail = await connection.query(
        `SELECT  
        COUNT(DISTINCT( CASE WHEN ProcessStatus = "Delivered" THEN OrderNumber END)) as DeliveredOrders,
        COUNT(DISTINCT(  CASE WHEN ProcessStatus = "Assigned" THEN OrderNumber END)) as AssignedOrders,
        COUNT(DISTINCT ( CASE WHEN ProcessStatus = "Picked" THEN OrderNumber END)) as PickedOrders,
        COUNT(DISTINCT ( CASE WHEN ProcessStatus = "Cancelled" THEN OrderNumber END)) as CancelledOrders,
        COUNT(DISTINCT ( CASE WHEN ProcessStatus = "On the Way" THEN OrderNumber END)) as OntheWayOrders,
        COUNT(DISTINCT(  CASE WHEN ReturnOrder = "Y" THEN OrderNumber END)) as ReturnOrders
            from processorder  WHERE  DeliveryDriverID="${DeliveryDriverID}" AND
             MONTH(LastUpdate)=MONTH(now())
            and YEAR(LastUpdate)=YEAR(now()) `, {
        type: QueryTypes.SELECT,
      }
      );
      getDriverCollectedAmout = await connection.query(
        `SELECT SUM(ItemsShippingHandling)- SUM(ItemsShippingHandling) * 0.05 AS TotalEarning,
        Sum(Case When PaymentType="cod" AND  PaytoAdminCod="N"
        Then ItemsTotal Else 0 End) TotalCashCollected
                                 from processorder  WHERE  DeliveryDriverID="${DeliveryDriverID}" AND ProcessStatus= "Delivered"  AND
                                 MONTH(LastUpdate)=MONTH(now())
                                and YEAR(LastUpdate)=YEAR(now())`, {
        type: QueryTypes.SELECT,
      }
      );
    }
    if (filter == "Last 3 Months") {
      getOrderDetail = await connection.query(
        `SELECT  
        COUNT(DISTINCT( CASE WHEN ProcessStatus = "Delivered" THEN OrderNumber END)) as DeliveredOrders,
        COUNT(DISTINCT(  CASE WHEN ProcessStatus = "Assigned" THEN OrderNumber END)) as AssignedOrders,
        COUNT(DISTINCT ( CASE WHEN ProcessStatus = "Picked" THEN OrderNumber END)) as PickedOrders,
        COUNT(DISTINCT ( CASE WHEN ProcessStatus = "Cancelled" THEN OrderNumber END)) as CancelledOrders,
        COUNT(DISTINCT ( CASE WHEN ProcessStatus = "On the Way" THEN OrderNumber END)) as OntheWayOrders,
        COUNT(DISTINCT(  CASE WHEN ReturnOrder = "Y" THEN OrderNumber END)) as ReturnOrders
                    from processorder  WHERE  DeliveryDriverID="${DeliveryDriverID}" AND 
                    LastUpdate >= now()-interval 3 month;`, {
        type: QueryTypes.SELECT,
      }
      );
      getDriverCollectedAmout = await connection.query(
        `SELECT SUM(ItemsShippingHandling)- SUM(ItemsShippingHandling) * 0.05 AS TotalEarning,
        Sum(Case When PaymentType="cod" AND  PaytoAdminCod="N"
        Then ItemsTotal Else 0 End) TotalCashCollected
                                 from processorder  WHERE  DeliveryDriverID="${DeliveryDriverID}" AND ProcessStatus= "Delivered"  AND 
                                 LastUpdate >= now()-interval 3 month;`, {
        type: QueryTypes.SELECT,
      }
      );
    }
    if (filter == "Last 6 Months") {
      getOrderDetail = await connection.query(
        `SELECT  
        COUNT(DISTINCT( CASE WHEN ProcessStatus = "Delivered" THEN OrderNumber END)) as DeliveredOrders,
        COUNT(DISTINCT(  CASE WHEN ProcessStatus = "Assigned" THEN OrderNumber END)) as AssignedOrders,
        COUNT(DISTINCT ( CASE WHEN ProcessStatus = "Picked" THEN OrderNumber END)) as PickedOrders,
        COUNT(DISTINCT ( CASE WHEN ProcessStatus = "Cancelled" THEN OrderNumber END)) as CancelledOrders,
        COUNT(DISTINCT ( CASE WHEN ProcessStatus = "On the Way" THEN OrderNumber END)) as OntheWayOrders,
        COUNT(DISTINCT(  CASE WHEN ReturnOrder = "Y" THEN OrderNumber END)) as ReturnOrders
                        from processorder  WHERE  DeliveryDriverID="${DeliveryDriverID}" AND
                        LastUpdate >= DATE_SUB(now(), INTERVAL 6 MONTH)`, {
        type: QueryTypes.SELECT,
      }
      );
      getDriverCollectedAmout = await connection.query(
        `SELECT SUM(ItemsShippingHandling)- SUM(ItemsShippingHandling) * 0.05 AS TotalEarning,
        Sum(Case When PaymentType="cod" AND  PaytoAdminCod="N"
        Then ItemsTotal Else 0 End) TotalCashCollected
                                 from processorder  WHERE  DeliveryDriverID="${DeliveryDriverID}" AND ProcessStatus= "Delivered"  AND
                                 LastUpdate >= DATE_SUB(now(), INTERVAL 6 MONTH)`, {
        type: QueryTypes.SELECT,
      }
      );
    }
    if (filter == "All" || filter == " " || filter == "") {
      getOrderDetail = await connection.query(
        `SELECT  
                        COUNT(DISTINCT( CASE WHEN ProcessStatus = "Delivered" OR ReturnOrderStatus="Delivered" THEN OrderNumber END)) as DeliveredOrders,
                        COUNT(DISTINCT(  CASE WHEN ProcessStatus = "Assigned" THEN OrderNumber END)) as AssignedOrders,
                        COUNT(DISTINCT ( CASE WHEN ProcessStatus = "Picked" THEN OrderNumber END)) as PickedOrders,
                        COUNT(DISTINCT ( CASE WHEN ProcessStatus = "Cancelled" THEN OrderNumber END)) as CancelledOrders,
                                        COUNT(DISTINCT ( CASE WHEN ProcessStatus = "On the Way" THEN OrderNumber END)) as OntheWayOrders,
                        COUNT(DISTINCT(  CASE WHEN ReturnOrder = "Y" AND ( ReturnOrderStatus ="NULL" || ReturnOrderStatus ="null" || ReturnOrderStatus <> "Delivered" )THEN OrderNumber END)) as ReturnOrders
                        from processorder  WHERE  DeliveryDriverID="${DeliveryDriverID}"
                        `, {
        type: QueryTypes.SELECT,
      }
      ); //SUM(ItemsShippingHandling)- SUM(ItemsShippingHandling) * 0.05 AS TotalEarning
      //IF(PaymentType="cod",SUM(ItemsTotal),0) AS TotalCashCollected //! don't use this ever in case of sum because it will add individually and faulty data so use conditional sum with case
      getDriverCollectedAmout = await connection.query(
        `SELECT SUM(ItemsShippingHandling)- SUM(ItemsShippingHandling) * 0.05 AS TotalEarning,
        Sum(Case When PaymentType="cod" AND  PaytoAdminCod="N"
        Then ItemsTotal Else 0 End) TotalCashCollected
        from processorder  WHERE  DeliveryDriverID="${DeliveryDriverID}" AND ProcessStatus= "Delivered" 
                           `, {
        type: QueryTypes.SELECT,
      }
      );
    }
    if (getDriverCollectedAmout && getDriverCollectedAmout.length > 0) {
      if (getOrderDetail && getOrderDetail.length > 0) {
        res.status(200).json({
          status: true,
          driverOrderStatusCount: getOrderDetail[0],
          getDriverCollectedAmout: getDriverCollectedAmout[0],
        });
      } else {
        res.status(200).json({
          status: false,
          driverOrderStatusCount: [],
          getDriverCollectedAmout: getDriverCollectedAmout[0],
        });
      }
    } else {
      res.status(200).json({
        status: false,
        driverOrderStatusCount: [],
        getDriverCollectedAmout: [],
      });
    }
  } catch (err) {
    next(err);
    console.log(err.message);
    res.status(200).json({
      status: false,
      driverOrderStatusCount: [],
      error: err.message,
    });
  }
};
exports.checkDriverAvailability = async (req, res, next) => {
  try {
    const {
      CityName
    } = req.body;
    let checkDriverAvailability = await connection.query(
      `SELECT c.CityID,c.City,d.DeliveryDriverID
             FROM city c
             INNER JOIN deliverydriver d ON d.CityID=c.CityID 
             WHERE c.City="${CityName}"`, {
      type: QueryTypes.SELECT,
    }
    );
    console.log(checkDriverAvailability);
    if (checkDriverAvailability && checkDriverAvailability.length > 0) {
      res.status(200).json({
        status: true,
        deliveryDriverStatus: true,
      });
    } else {
      res.status(200).json({
        status: true,
        deliveryDriverStatus: false,
      });
    }
  } catch (err) {
    next(err);
    res.status(200).json({
      status: false,
      error: err.message,
    });
    console.log(err.message);
  }
};


async function verifyWebhookSignature(req) {
  const secret = process.env.PTHAO_WEBHOOK_SECRET || "SERCERT"; // Replace with the actual secret provided by the client

  const headerSignature = req.headers['x-pathao-signature'];

  console.log("===========================>", headerSignature, secret);
  if (!headerSignature) {
    return false;
  }
  const calculatedSignature = crypto
    .createHmac('sha1', secret)
    .update(JSON.stringify(req.body))
    .digest('hex');
  console.log(`sha1=${calculatedSignature}`, "===========jcalculatedSignaturecalculatedSignature");



  return headerSignature === `sha1=${calculatedSignature}`;
}


//!webhook
exports.pathaoStatusUpdateWebhook = async (req, res) => {
  let transaction;

  try {
    const { consignment_id, Order_status } = req.body

    const result = await verifyWebhookSignature(req)

    if (!result) {
      res.status(401).json({
        status: false,
        message: 'Invalid signature. Request not authorized.',
      });
      return;
    }




    let body;
    transaction = await connection.transaction();
    let changeOrderStatus;
    let LastUpdate_1 = new Date().toISOString().slice(0, 19).replace("T", " ");
    let StatusHistory = [];
    let parsePreviousStatusHistory = [];
    let getOrderDetail = await connection.query(
      `SELECT * from processorder  WHERE  ConsignmentId="${consignment_id}" `,
      {
        type: QueryTypes.SELECT,
        transaction,
      }
    );

    if (getOrderDetail && getOrderDetail.length > 0) {
      let ReceiverID = getOrderDetail[0].UserID;
      const OrderNumber = getOrderDetail[0].OrderNumber;
      body = `Your order ${OrderNumber} is Delivered`;
      let DeliveryConfirmationPic;
      if (req.file && Object.keys(req.file).length > 0) {
        if (req.file.path && req.file.path.length > 0) {
          DeliveryConfirmationPic = req.file.path;
        } else {
          DeliveryConfirmationPic = null;
        }
      } else {
        DeliveryConfirmationPic = null;
      }
      console.log(getOrderDetail[0].StatusHistory);


      parsePreviousStatusHistory = JSON.parse(getOrderDetail[0].StatusHistory);
      parsePreviousStatusHistory.push(LastUpdate_1);
      parsePreviousStatusHistory.push(LastUpdate_1);
      parsePreviousStatusHistory.push(LastUpdate_1);

      // return
      changeOrderStatus = await connection.query(
        `UPDATE processorder,processpayment SET processorder.ProcessStatus="${Order_status}",processorder.StatusHistory='${JSON.stringify(
          parsePreviousStatusHistory
        )}',processorder.LastUpdate="${LastUpdate_1}",processorder.DeliveryConfirmationPic="${DeliveryConfirmationPic}",processorder.DeliveryDate="${LastUpdate_1}",processpayment.PaymentStatus="Paid" WHERE processorder.OrderNumber="${OrderNumber}" AND processorder.DeliveryStatus="pathao" AND processpayment.OrderNumber="${OrderNumber}"`,
        {
          transaction,
        }
      );

      console.log("________________________________", changeOrderStatus);

      if (changeOrderStatus) {
        let getDeviceIDQuery = ` SELECT DeviceID,UserID,EmailAddress
                FROM profile
                WHERE UserID=${ReceiverID}`;
        let getDeviceID = await connection.query(getDeviceIDQuery, {
          type: QueryTypes.SELECT,
          transaction,
        });
        if (getDeviceID && getDeviceID.length > 0) {
          let DeviceID = getDeviceID[0].DeviceID;
          let EmailAddress = getDeviceID[0].EmailAddress;
          console.log(DeviceID);
          let TypeID = "6";
          let CreaterID = "1";
          let Body = {
            OrderNumber: OrderNumber,
            body,
          };
          let Message = `You Order # ${OrderNumber} is Delivered `;
          sendEmail(EmailAddress, Message, TypeID);

          let sendNotification = await Notification(
            TypeID,
            Body,
            CreaterID,
            ReceiverID,
            transaction
          );
          console.log(sendNotification, "sendNotification");
          if (sendNotification) {
            if (transaction) await transaction.commit(); //!final commit
            res.status(200).json({
              status: true,
              message: "Order Status Updated Sucessfully ",
            });
          } else {
            if (transaction) await transaction.rollback();
            res.status(200).json({
              status: false,
              message: "Error while sending Notification to User ",
            });
          }
        } else {
          if (transaction) await transaction.rollback();
          res.status(200).json({
            status: false,
            message: "Error while getting user data from Database ",
          });
        }
      } else {
        if (transaction) await transaction.rollback();
        res.status(200).json({
          status: false,
          message: "Error while updating order status ",
        });
      }
    } else {
      if (transaction) await transaction.rollback();
      res.status(200).json({
        status: false,
        message: "No record found to update against this data ",
      });
    }
  } catch (err) {
    if (transaction) await transaction.rollback();
    // next(err);
    console.log(err);
    res.status(200).json({
      status: false,
      message: err.message,
    });
  }
};


exports.adOldpathaoStatusUpdateWebhook = async (req, res, next) => {
  let transaction;
  try {
    const consignment_id = req.params.id;
    let body;
    transaction = await connection.transaction();
    let changeOrderStatus;
    let LastUpdate = new Date().toISOString().slice(0, 19).replace("T", " ");
    let StatusHistory = [];
    let parsePreviousStatusHistory = [];
    let getOrderDetail = await connection.query(
      `SELECT * from processorder  WHERE  ConsignmentId="${consignment_id}" `, {
      type: QueryTypes.SELECT,
      transaction,
    }
    );

    if (getOrderDetail && getOrderDetail.length > 0) {
      let ReceiverID = getOrderDetail[0].UserID;
      const OrderNumber = getOrderDetail[0].OrderNumber;
      body = `Your order ${OrderNumber} is Delivered`;
      let DeliveryConfirmationPic;
      if (req.file && Object.keys(req.file).length > 0) {
        if (req.file.path && req.file.path.length > 0) {
          DeliveryConfirmationPic = req.file.path;
        } else {
          DeliveryConfirmationPic = null;
        }
      } else {
        DeliveryConfirmationPic = null;
      }
      console.log(getOrderDetail[0].StatusHistory);
      parsePreviousStatusHistory = JSON.parse(getOrderDetail[0].StatusHistory);
      parsePreviousStatusHistory.push(LastUpdate);
      changeOrderStatus = await connection.query(
        `UPDATE processorder,processpayment SET processorder.ProcessStatus="Delivered",processorder.StatusHistory='${JSON.stringify(
          parsePreviousStatusHistory
        )}',processorder.LastUpdate="${LastUpdate}",processorder.DeliveryConfirmationPic="${DeliveryConfirmationPic}",processorder.DeliveryDate="${LastUpdate}",processpayment.PaymentStatus="Paid" WHERE processorder.OrderNumber="${OrderNumber}" AND processorder.DeliveryStatus="pathao" AND processpayment.OrderNumber="${OrderNumber}"`, {
        transaction,
      }
      );

      if (changeOrderStatus) {
        let getDeviceIDQuery = ` SELECT DeviceID,UserID,EmailAddress
                FROM profile 
                WHERE UserID=${ReceiverID}`;
        let getDeviceID = await connection.query(getDeviceIDQuery, {
          type: QueryTypes.SELECT,
          transaction,
        });
        if (getDeviceID && getDeviceID.length > 0) {
          let DeviceID = getDeviceID[0].DeviceID;
          let EmailAddress = getDeviceID[0].EmailAddress;
          console.log(DeviceID);
          let TypeID = "6";
          let CreaterID = "1";
          let Body = {
            OrderNumber: OrderNumber,
            body,
          };
          let Message = `You Order # ${OrderNumber} is Delivered `;
          sendEmail(EmailAddress, Message, TypeID);

          let sendNotification = await Notification(
            TypeID,
            Body,
            CreaterID,
            ReceiverID,
            transaction
          );
          console.log(sendNotification, "sendNotification");
          if (sendNotification) {
            if (transaction) await transaction.commit(); //!final commit
            res.status(200).json({
              status: true,
              message: "Order Status Updated Sucessfully ",
            });
          } else {
            if (transaction) await transaction.rollback();
            res.status(200).json({
              status: false,
              message: "Error while sending Notification to User ",
            });
          }
        } else {
          if (transaction) await transaction.rollback();
          res.status(200).json({
            status: false,
            message: "Error while getting user data from Database ",
          });
        }
      } else {
        if (transaction) await transaction.rollback();
        res.status(200).json({
          status: false,
          message: "Error while updating order status ",
        });
      }
    } else {
      if (transaction) await transaction.rollback();
      res.status(200).json({
        status: false,
        message: "No record found to update against this data ",
      });
    }
  } catch (err) {
    if (transaction) await transaction.rollback();
    next(err);
    res.status(200).json({
      status: false,
      message: err.message,
    });
  }
};
exports.getDeliveryDriverDetails = async (req, res, next) => {
  try {
    let DeliveryDriverID = req.params.id;
    let getDeliveryDriverDetailsQuery = await connection.query(
      `SELECT * FROM  deliverydriver WHERE DeliveryDriverID="${DeliveryDriverID}"  AND ReviewedByAdmin="Y" `, {
      type: QueryTypes.SELECT,
    }
    );
    if (
      getDeliveryDriverDetailsQuery &&
      getDeliveryDriverDetailsQuery.length > 0
    ) {
      res.status(200).json({
        status: true,
        driverDetails: getDeliveryDriverDetailsQuery[0],
      });
    } else {
      res.status(200).json({
        status: false,
        message: "No Delivery Driver details found ",
        driverDetails: {},
      });
    }
  } catch (err) {
    next(err);
    res.status(200).json({
      status: false,
      driverDetails: {},
      message: err.message,
    });
    console.log(err.message);
  }
};
exports.ShippingCostVendor = async (req, res, next) => {
  try {
    let Region = req.region;
    const currencyRate = req.currency_rate;
    var {
      ProductIDs
    } = req.body;
    let saveResponse = [];
    const promises = ProductIDs.map(async (item, i) => {
      let ProductID = ProductIDs[i];
      let getProductsPthaoStoreID = await connection.query(
        `SELECT p.Weight,p.ProductID,c.CityID,c.City,c.FlatDeliveryRate,c.FlatDeliveryRateKilo
            FROM product p
            LEFT JOIN productcity t ON t.ProductID=p.ProductID
            LEFT JOIN city c ON c.CityID=t.CityID
            WHERE p.ProductID= "${ProductID}"  `, {
        type: QueryTypes.SELECT,
      }
      );
      let item_weight = getProductsPthaoStoreID[0].Weight;
      console.log(getProductsPthaoStoreID);
      let FlatDeliveryRate = getProductsPthaoStoreID[0].FlatDeliveryRate;
      let obj = {
        message: "Price",
        ProductID: ProductID,
        data: {
          price: item_weight * FlatDeliveryRate,
        },
      };
      saveResponse.push(obj);
    });
    await Promise.all(promises);
    if (saveResponse && saveResponse.length > 0) {
      if (Region !== "Bangladesh") {
        for (let i = 0; i < saveResponse.length; i++) {
          let Price = saveResponse[i].data.price;
          saveResponse[i].data["price"] = parseFloat(
            currencyRate * Price
          ).toFixed(2);
        }
      }
      res.status(200).send({
        status: true,
        saveResponse: saveResponse,
      });
    } else {
      res.status(200).send({
        status: false,
        saveResponse: [],
      });
    }
  } catch (err) {
    next(err);
    res.status(200).json({
      status: false,
      error: err.message,
    });
    console.log(err.message);
  }
};
exports.shippingCostVendorCountry = async (req, res, next) => {
  try {
    const {
      ProductID,
      CountryID,
      ShippingCostVendorCountry,
      ShippingCostKiloVendorCountry,
      ShippingCostVendorInternational,
      ShippingCostKiloVendorInternational,
    } = req.body;
    var insertCountryShippingCostQuery = `INSERT INTO shippingcostvendorcountry( ProductID, CountryID, ShippingCostVendorCountry,ShippingCostKiloVendorCountry,ShippingCostVendorInternational,ShippingCostKiloVendorInternational) values(?,?,?,?,?,?)`;
    let insertCountryShippingCost = await connection.query(
      insertCountryShippingCostQuery, {
      replacements: [
        ProductID,
        CountryID,
        ShippingCostVendorCountry,
        ShippingCostKiloVendorCountry,
        ShippingCostVendorInternational,
        ShippingCostKiloVendorInternational,
      ],
    }
    );
    if (insertCountryShippingCost) {
      res.status(200).json({
        status: true,
        message: "Successfully added Shipping Cost Vendor Country",
      });
    } else {
      res.status(200).json({
        status: false,
        message: "Error while adding shipping cost details",
      });
    }
  } catch (err) {
    next(err);
    res.status(200).json({
      status: false,
      error: err.message,
    });
    console.log(err.message);
  }
};
exports.shippingCostVendorCity = async (req, res, next) => {
  try {
    const {
      ProductID,
      CityID,
      ShippingCostVendorCity,
      ShippingCostKiloVendorCity,
    } = req.body;
    var insertCountryShippingCostQuery = `INSERT INTO shippingcostvendorcity( ProductID, CityID, ShippingCostVendorCity,ShippingCostKiloVendorCity) values(?,?,?,?)`;
    let insertCountryShippingCost = await connection.query(
      insertCountryShippingCostQuery, {
      replacements: [
        ProductID,
        CityID,
        ShippingCostVendorCity,
        ShippingCostKiloVendorCity,
      ],
    }
    );
    if (insertCountryShippingCost) {
      res.status(200).json({
        status: true,
        message: "Successfully added Shipping Cost Vendor City",
      });
    } else {
      res.status(200).json({
        status: false,
        message: "Error while adding shipping cost details",
      });
    }
  } catch (err) {
    next(err);
    res.status(200).json({
      status: false,
      error: err.message,
    });
    console.log(err.message);
  }
};
//! COD Driver Payment Process
exports.deliveryDriverCodOrders = async (req, res, next) => {
  try {
    const {
      sort,
      status,
      limit,
      offset,
      DeliveryDriverID
    } = req.body;
    let productCombinationPriceDetail = [];
    let ordersCount = await connection.query(
      `SELECT COUNT(DISTINCT OrderNumber) AS total_records
      FROM processorder WHERE DeliveryDriverID="${DeliveryDriverID}" AND ProcessStatus="Delivered" AND PaymentType="cod" AND PaytoAdminCod="${status}"  `, {
      type: QueryTypes.SELECT,
    }
    );
    console.log(ordersCount);
    if (ordersCount[0].total_records && ordersCount[0].total_records > 0) {
      let viewOrderListQuery =
        `SELECT p.ProductID,p.Title,m.TransactionID,s.OrderNumber,s.AllowStorePickup,s.AllowAdminPickup,s.ReadyPickupForUser,s.ReadyPickupForAdmin,s.OrderDate,m.PaymentStatus,p.Price AS BasePrice,p.Currency,s.UserID,g.Small,g.Medium,g.Large,i.MainImage,s.ConsignmentId,s.DeliveryDriverID,s.ProcessStatus,s.DeliveryStatus,m.OrderTotal,s.PaymentType,s.ItemsPrice,s.ItemsEstimatedTax,s.ItemsShippingHandling,s.ProductVariantCombinationDetail,
              (SELECT COUNT(t.ProductID)
              from productreviewrating t WHERE t.ProductID = p.ProductID) AS REVIEW_COUNT,
              (SELECT AVG(t.Rating) from productreviewrating t WHERE t.ProductID = p.ProductID) AS  AVG_Rating
                FROM ((((((( product p      
                LEFT JOIN productvariantoption o ON o.ProductID IN( p.ProductID))
                LEFT JOIN productvariantoptionvalue v  ON  v.OptionID IN (o.OptionID))  
                LEFT JOIN productimage i  ON  i.OptionValueID IN (v.OptionValueID))
                LEFT JOIN imagegallery g  ON  g.ImageGalleryID IN (i.ImageGalleryID))
                LEFT JOIN productvariantcombination c  ON  c.OptionValueID IN (v.OptionValueID))
                INNER JOIN processorder s ON s.ProductID IN(c.ProductID))
                LEFT JOIN processpayment m ON m.OrderNumber IN(s.OrderNumber))
                WHERE i.MainImage='Y'  AND  s.DeliveryDriverID="${DeliveryDriverID}" AND ProcessStatus="Delivered" AND PaymentType="cod"
                AND s.PaytoAdminCod="${status}" 
                GROUP BY s.ProcessOrderID
                ORDER by s.ProcessOrderID ${sort} limit ` +
        limit +
        " offset " +
        offset;
      let viewOrderList = await connection.query(viewOrderListQuery, {
        type: QueryTypes.SELECT,
      });
      let productCombinationDetail;
      if (viewOrderList && viewOrderList.length > 0) {
        for (let i = 0; i < viewOrderList.length; i++) {
          let ProductVariantCombinationDetail = [];
          ProductVariantCombinationDetail.push(
            viewOrderList[i].ProductVariantCombinationDetail
          );
          ProductVariantCombinationDetail = `(${ProductVariantCombinationDetail.join(
            ","
          )})`;
          productCombinationDetail = await connection.query(
            `SELECT p.ProductID,c.ProductVariantCombinationID,c.VendorStoreID,c.Price AS ProductCombinationPrice,c.AvailableInventory,o.OptionID,o.OptionName,v.OptionValue,v.OptionValueID
                    FROM ((((product p
                    LEFT JOIN productvariantoption o ON o.ProductID IN( p.ProductID))
                    LEFT JOIN productvariantoptionvalue v  ON  v.OptionID IN (o.OptionID)) 
                    LEFT JOIN productvariantcombination c  ON  c.OptionValueID IN (v.OptionValueID))
                    LEFT JOIN processorder s ON s.ProductID IN(c.ProductID))
                    WHERE  c.ProductVariantCombinationID IN ${ProductVariantCombinationDetail}
                    GROUP BY c.OptionValueID
                    ORDER by s.ProcessOrderID ${sort} 
                   `, {
            type: QueryTypes.SELECT,
          }
          );
          productCombinationPriceDetail.push(productCombinationDetail);
        }
        let orderName = [];
        let orderDate = [];
        let paymentStatus = [];
        let transactionID = [];
        let tempPC = productCombinationPriceDetail;
        let tempProd = viewOrderList;
        let tempArray = [];
        let allowStorePickup = [];
        let readyPickupForUser = [];
        let readyPickupForAdmin = [];
        let allowAdminPickup = [];
        var deliveryDriverID = [];
        let tempAOrderDetails = [];
        let consignmentID = [];
        let processStatus = [];
        for (let i = 0; i < tempProd.length; i++) {
          var obj = {
            ...tempProd[i],
          };
          obj["ProductCombinations"] = tempPC[i];
          tempArray.push(obj);
        }
        for (let i = 0; i < tempArray.length; i++) {
          if (!orderName.includes(tempArray[i].OrderNumber)) {
            orderName.push(tempArray[i].OrderNumber);
            orderDate.push(tempArray[i].OrderDate);
            paymentStatus.push(tempArray[i].PaymentStatus);
            transactionID.push(tempArray[i].TransactionID);
            allowStorePickup.push(tempArray[i].AllowStorePickup);
            readyPickupForUser.push(tempArray[i].ReadyPickupForUser);
            readyPickupForAdmin.push(tempArray[i].ReadyPickupForAdmin);
            allowAdminPickup.push(tempArray[i].AllowAdminPickup);
            deliveryDriverID.push(tempArray[i].DeliveryDriverID);
            consignmentID.push(tempArray[i].ConsignmentId);
            processStatus.push(tempArray[i].ProcessStatus);
          }
        }
        for (let i = 0; i < orderName.length; i++) {
          var obj = {
            OrderNumber: orderName[i],
            OrderDate: orderDate[i],
            PaymentStatus: paymentStatus[i],
            TransactionID: transactionID[i],
            AllowStorePickup: allowStorePickup[i],
            ReadyPickupForUser: readyPickupForUser[i],
            ReadyPickupForAdmin: readyPickupForAdmin[i],
            AllowAdminPickup: allowAdminPickup[i],
            DeliveryDriverID: deliveryDriverID[i],
            ConsignmentId: consignmentID[i],
            ProcessStatus: processStatus[i],
            ProductDetail: [],
          };
          for (let j = 0; j < tempArray.length; j++) {
            if (orderName[i] === tempArray[j].OrderNumber) {
              obj.ProductDetail.push(tempArray[j]);
            }
          }
          tempAOrderDetails.push(obj);
        }
        if (productCombinationDetail && productCombinationDetail.length > 0) {
          res.status(200).json({
            status: true,
            total_records: ordersCount[0].total_records,
            orderDetails: tempAOrderDetails,
          });
        } else {
          res.status(200).json({
            status: false,
            total_records: ordersCount[0].total_records,
            orderDetails: [],
          });
        }
      } else {
        res.status(200).json({
          status: true,
          total_records: ordersCount[0].total_records,
          orderDetails: [],
        });
      }
    } else {
      res.status(200).json({
        status: true,
        total_records: ordersCount[0].total_records,
        orderDetails: [],
      });
    }
  } catch (err) {
    console.log(err.message);
    next(err);
    res.status(200).json({
      status: false,
      orderDetails: [],
    });
  }
};
exports.updateDriverDepositProof = async (req, res, next) => {
  try {
    const {
      OrderDetail,
      DeliveryDriverID
    } = req.body;
    const OrderNumber = `(${OrderDetail.join(",")})`;
    const DriverDepositProof = req.file.path;
    let retrivePreviousStatusHistory = await connection.query(
      `SELECT OrderNumber,StatusHistory from processorder WHERE OrderNumber IN ${OrderNumber} AND DeliveryDriverID="${DeliveryDriverID}" `, {
      type: QueryTypes.SELECT,
    }
    );
    if (
      retrivePreviousStatusHistory &&
      retrivePreviousStatusHistory.length > 0
    ) {
      let LastUpdate = new Date().toISOString().slice(0, 19).replace("T", " ");
      // console.log(retrivePreviousStatusHistory[0].StatusHistory);
      let parsePreviousStatusHistory = [];
      let addPreviousStatusHistory = [];
      let updateDriverCodPaymentStatus = true;
      for (let i = 0; i < retrivePreviousStatusHistory.length; i++) {
        parsePreviousStatusHistory = JSON.parse(
          retrivePreviousStatusHistory[i].StatusHistory
        );
        parsePreviousStatusHistory.push(LastUpdate);
        addPreviousStatusHistory.push(parsePreviousStatusHistory);
        try {
          let updateDriverCodPaymentStatusQuery = `UPDATE processorder SET StatusHistory='${JSON.stringify(
            parsePreviousStatusHistory
          )}',PaytoAdminCod="Y",DriverDepositProof=? WHERE OrderNumber= "${retrivePreviousStatusHistory[i].OrderNumber
            }" AND DeliveryDriverID="${DeliveryDriverID}" `;
          updateDriverCodPaymentStatus = await connection.query(
            updateDriverCodPaymentStatusQuery, {
            replacements: [DriverDepositProof]
          }
          );
        } catch (e) {
          updateDriverCodPaymentStatus = false;
          res.status(200).json({
            status: false,
            message: e.message,
          });
        }
      }
      if (updateDriverCodPaymentStatus) {
        res.status(200).json({
          status: true,
          message: "Successfully Added Driver Deposit proof in DB",
        });
      } else {
        res.status(200).json({
          status: false,
          message: "Error while adding Driver Deposit proof in DB",
        });
      }
    } else {
      res.status(200).json({
        status: false,
        message: "Error while reteriving Status history from DB",
      });
    }
  } catch (err) {
    next(err);
    res.status(200).json({
      status: false,
      error: err.message,
    });
  }
};
//!change return order status
exports.changeDriverReturnOrderStatus = async (req, res, next) => {
  let transaction;
  try {
    transaction = await connection.transaction();
    const {
      status,
      OrderNumber,
      DeliveryDriverID,
      ProcessOrderIDs,
      isLast
    } =
      req.body;
    let body;
    let changeOrderStatus;
    let LastUpdate = new Date().toISOString().slice(0, 19).replace("T", " ");
    let orderStatus;
    let parsePreviousStatusHistory = [];
    const idsWrappedInQuotes = ProcessOrderIDs.map(
      (ProcessOrderIDs) => `'${ProcessOrderIDs}'`
    );
    let ProcessOrderID = `(${idsWrappedInQuotes.join(",")})`;
    let getOrderDetail = await connection.query(
      `SELECT * from processorder  WHERE ProcessOrderID IN ${ProcessOrderID} AND DeliveryDriverID="${DeliveryDriverID}" AND ReturnOrder="Y" AND ReturnOrderStatus NOT IN ('NULL','null','undefined') `, {
      type: QueryTypes.SELECT,
      transaction,
    }
    );
    console.log(getOrderDetail);
    if (getOrderDetail && getOrderDetail.length > 0) {
      let ReceiverID = getOrderDetail[0].UserID;
      if (status == "Picked") {
        body = `Your return order ${OrderNumber} is Picked By Delivery Person`;
        orderStatus = "Picked";
        parsePreviousStatusHistory = JSON.parse(
          getOrderDetail[0].ReturnOrderStatusHistory
        );
        parsePreviousStatusHistory.push(LastUpdate);
        //retrive previous
        //JSON.parse
        //push [1]
        //JSON.strigify
        changeOrderStatus = await connection.query(
          `UPDATE processorder SET ReturnOrderStatus="${status}",ReturnOrderStatusHistory='${JSON.stringify(
            parsePreviousStatusHistory
          )}',LastUpdate="${LastUpdate}" WHERE ProcessOrderID IN ${ProcessOrderID} AND DeliveryDriverID="${DeliveryDriverID}"`, {
          transaction,
        }
        );
        if (changeOrderStatus) {
          let TypeID = "6";
          let CreaterID = "1";
          let Body = {
            OrderNumber: OrderNumber,
            body,
          };
          let Message = `You Order # ${Body.OrderNumber} is ${orderStatus} `;
          let getDeviceIDQuery = ` SELECT EmailAddress,UserID
                  FROM profile 
                  WHERE UserID=${ReceiverID}`;
          let getDeviceID = await connection.query(getDeviceIDQuery, {
            type: QueryTypes.SELECT,
            transaction,
          });
          if (getDeviceID && getDeviceID.length > 0) {
            let EmailAddress = getDeviceID[0].EmailAddress;
            let ReceiverID = getDeviceID[0].UserID;
            sendEmail(EmailAddress, Message, TypeID);
            let sendNotification = await Notification(
              TypeID,
              Body,
              CreaterID,
              ReceiverID,
              transaction
            );
            console.log(sendNotification, "sendNotification");
            if (sendNotification) {
              if (transaction) await transaction.commit(); //!final commit
              res.status(200).json({
                status: true,
                message: "Order Status Updated Sucessfully ",
              });
            } else {
              if (transaction) await transaction.rollback();
              res.status(200).json({
                status: false,
                message: "Error while sending Notification to User ",
              });
            }
          } else {
            if (transaction) await transaction.rollback();
            res.status(200).json({
              status: false,
              message: "Error while getting user data from Database ",
            });
          }
        } else {
          if (transaction) await transaction.rollback();
          res.status(200).json({
            status: false,
            message: "Error while updating status ",
          });
        }
      }
      if (status == "Delivered") {
        body = `Your return order ${OrderNumber} is Delivered`;
        orderStatus = "Delivered";
        let DeliveryConfirmationPic;
        if (req.file && Object.keys(req.file).length > 0) {
          if (req.file.path && req.file.path.length > 0) {
            DeliveryConfirmationPic = req.file.path;
          } else {
            DeliveryConfirmationPic = null;
          }
        } else {
          DeliveryConfirmationPic = null;
        }
        parsePreviousStatusHistory = JSON.parse(
          getOrderDetail[0].ReturnOrderStatusHistory
        );
        parsePreviousStatusHistory.push(LastUpdate);
        (changeOrderStatusQuery = `UPDATE processorder,processrefand
           SET processorder.ReturnOrderStatus="${status}",processorder.ReturnOrderStatusHistory='${JSON.stringify(
          parsePreviousStatusHistory
        )}',processorder.LastUpdate="${LastUpdate}",processrefand.RefandDeliveryPicDriver=?
          WHERE processorder.ProcessOrderID IN ${ProcessOrderID} AND processorder.DeliveryDriverID="${DeliveryDriverID}" AND processrefand.ProcessOrderID IN ${ProcessOrderID} `), {
          transaction,
        };
        changeOrderStatus = await connection.query(changeOrderStatusQuery, {
          replacements: [DeliveryConfirmationPic],
          transaction,
        });
        if (changeOrderStatus) {
          if (isLast === "true") {
            console.log(
              "Inside -----------------------------------------------------------"
            );
            let TypeID = "6";
            let CreaterID = "1";
            let Body = {
              OrderNumber: OrderNumber,
              body,
            };
            let Message = `You Order # ${Body.OrderNumber} is ${orderStatus} `;
            let getDeviceIDQuery = ` SELECT EmailAddress,UserID
                  FROM profile 
                  WHERE UserID=${ReceiverID}`;
            let getDeviceID = await connection.query(getDeviceIDQuery, {
              type: QueryTypes.SELECT,
              transaction,
            });
            if (getDeviceID && getDeviceID.length > 0) {
              let EmailAddress = getDeviceID[0].EmailAddress;
              let ReceiverID = getDeviceID[0].UserID;
              sendEmail(EmailAddress, Message, TypeID);
              let sendNotification = await Notification(
                TypeID,
                Body,
                CreaterID,
                ReceiverID,
                transaction
              );
              console.log(sendNotification, "sendNotification");
              if (sendNotification) {
                if (transaction) await transaction.commit(); //!final commit
                res.status(200).json({
                  status: true,
                  message: "Order Status Updated Sucessfully ",
                });
              } else {
                if (transaction) await transaction.rollback();
                res.status(200).json({
                  status: false,
                  message: "Error while sending Notification to User ",
                });
              }
            } else {
              if (transaction) await transaction.rollback();
              res.status(200).json({
                status: false,
                message: "Error while getting user data from Database ",
              });
            }
          } else {
            console.log(
              "else---------------------------------------------------------"
            );
            if (transaction) await transaction.commit(); //!final commit
            res.status(200).json({
              status: true,
              message: "Order Status Updated Sucessfully",
            });
          }
        } else {
          if (transaction) await transaction.rollback();
          res.status(200).json({
            status: false,
            message: "Error while updating status ",
          });
        }
      }
    } else {
      if (transaction) await transaction.rollback();
      res.status(200).json({
        status: false,
        message: "No record found to update against this data ",
      });
    }
  } 
  catch (err) {
    console.log(err.message, "------------------------------");
    if (transaction) await transaction.rollback();
    next(err);
    res.status(200).json({
      status: false,
      error: err.message,
    });
  }
};
