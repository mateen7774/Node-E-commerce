const connection = require("../../db/db.connection");
const path = require('path');
const fs = require("fs")


const {
  QueryTypes
} = require("sequelize");
//! PRODUCT FORM 1 CRUD
// exports.addProductDetailsForm1OLD = async (req, res, next) => {
//   let transaction; //!transaction variable declare here
//   try {
//     const {
//       VendorID,
//       SubCategoryID,
//       Title,
//       Description,
//       SpecialInstruction,
//       ReturnPolicy,
//       Currency,
//       CostPrice,
//       Price,
//       Quantity1,
//       PriceQuantity1,
//       Quantity2,
//       PriceQuantity2,
//       Quantity3,
//       PriceQuantity3,
//       PromotionPrice,
//       PromotionRate,
//       PromotionStartDate,
//       PromotionEndDate,
//       Weight,
//       Height,
//       Length,
//       Width,
//       AllowStorePickup,
//       ShippingAvailable,
//       ShippingGlobal,
//       ShippingByAdmin,
//       ShippingByVendor,
//       ShippingCostAdmin,
//       ShippingCostVendor,
//       ReviewedByAdmin,
//       TaxVATApply,
//       LockEdit,
//       Active,
//       StoreName,
//       Variations,
//     } = req.body;
//     transaction = await connection.transaction(); //!transaction use here
//     let addProduct;
//     let getCityID;
//     let ProductID;
//     let StoreOptionName = [];
//     let checkIfVendorExists = await vendorIDCheck(VendorID, transaction);
//     console.log(checkIfVendorExists);
//     if (checkIfVendorExists && checkIfVendorExists == "1") {
//       let checkIfSubCategoryExists = await subcategoryIDCheck(
//         SubCategoryID,
//         transaction
//       );
//       if (checkIfSubCategoryExists && checkIfSubCategoryExists == "1") {
//         const checkStoreStatus = await connection.query(
//           `SELECT * FROM vendorstore WHERE VendorID="${VendorID}" AND StoreName="${StoreName}" `,
//           {
//             type: QueryTypes.SELECT,
//             transaction,
//           }
//         );
//         let PthaoStoreID = checkStoreStatus[0].PthaoStoreID;
//         if (PthaoStoreID) {
//           let checkProductTitleExists = await productTitleCheck(
//             Title,
//             VendorID,
//             transaction
//           );
//           if (checkProductTitleExists && checkProductTitleExists == "0") {
//             //!Insert into Product table starts here
//             let insertProductQuery = `insert into product ( VendorID, SubCategoryID,Title,StoreName, Description, SpecialInstruction,ReturnPolicy, Currency,CostPrice, Price ,Quantity1,PriceQuantity1,Quantity2 ,PriceQuantity2, Quantity3,  PriceQuantity3,PromotionPrice,  PromotionRate,  PromotionStartDate,  PromotionEndDate, Weight,Height, Length,  Width,  AllowStorePickup,   ShippingAvailable,  ShippingGlobal,  ShippingByAdmin,  ShippingByVendor,  ShippingCostAdmin, ShippingCostVendor, ReviewedByAdmin,TaxVATApply, LockEdit, Active)`;
//             insertProductQuery += ` values ("${VendorID}","${SubCategoryID}","${Title}","${StoreName}", "${Description}","${SpecialInstruction}","${ReturnPolicy}","${Currency}","${CostPrice}","${Price}","${Quantity1}", "${PriceQuantity1}","${Quantity2}","${PriceQuantity2}","${Quantity3}","${PriceQuantity3}","${PromotionPrice}","${PromotionRate}", "${PromotionStartDate}","${PromotionEndDate}","${Weight}", "${Height}","${Length}","${Width}","${AllowStorePickup}","${ShippingAvailable}","${ShippingGlobal}","${ShippingByAdmin}", "${ShippingByVendor}","${ShippingCostAdmin}","${ShippingCostVendor}","${ReviewedByAdmin}","${TaxVATApply}","${LockEdit}","${Active}") `;

//             addProduct = await connection.query(insertProductQuery, {
//               type: QueryTypes.INSERT,
//               transaction,
//             });
//             console.log(
//               insertProductQuery,
//               "------- ADD PRODUCT Details QUERY"
//             );
//             if (addProduct) {
//               //!Insert into Product City table starts here
//               getCityID = await connection.query(
//                 `SELECT * FROM vendorstore WHERE VendorID="${VendorID}" AND StoreName="${StoreName}" `,
//                 {
//                   type: QueryTypes.SELECT,
//                   transaction,
//                 }
//               );
//               console.log(getCityID);
//               console.log(getCityID[0].CityID);
//               let VendorProductCity = getCityID[0].CityID;
//               console.log(VendorProductCity, "----------------------------");
//               ProductID = addProduct[0];

//               let insertProductCityQuery = `insert into productcity ( ProductID,CityID) values(?,?)`;
//               let insertProductCity = await connection.query(
//                 insertProductCityQuery,
//                 {
//                   replacements: [ProductID, VendorProductCity],
//                   type: QueryTypes.INSERT,
//                   transaction,
//                 }
//               );
//               if (insertProductCity) {
//                 //!Insert into Product Country table starts here
//                 const getCountryID = await connection.query(
//                   `SELECT * FROM vendorstore WHERE VendorID="${VendorID}" AND StoreName="${StoreName}" `,
//                   {
//                     type: QueryTypes.SELECT,
//                     transaction,
//                   }
//                 );
//                 console.log(getCountryID[0].CountryID);
//                 let VendorProductCountry = getCountryID[0].CountryID;
//                 let ProductID = addProduct[0];
//                 let insertProductCountryQuery = `insert into productcountry ( ProductID, CountryID) values(?,?)`;
//                 let insertProductCountry = await connection.query(
//                   insertProductCountryQuery,
//                   {
//                     replacements: [ProductID, VendorProductCountry],
//                     type: QueryTypes.INSERT,
//                     transaction,
//                   }
//                 );

//                 if (insertProductCountry) {
//                   console.log(Variations.length);
//                   //!Insert into Product Variant Option table starts here
//                   for (let i = 0; i < Variations.length; i++) {
//                     StoreOptionName.push(Variations[i]);
//                   }
//                   console.log(StoreOptionName);
//                   let insertProductVariantOptionBulkQuery = `insert into productvariantoption ( ProductID ,OptionName) values  `;
//                   for (let i = 0; i < StoreOptionName.length; i++) {
//                     if (i == StoreOptionName.length - 1) {
//                       insertProductVariantOptionBulkQuery += `('${ProductID}', '${StoreOptionName[i]}')`;
//                     } else {
//                       insertProductVariantOptionBulkQuery += `('${ProductID}', '${StoreOptionName[i]}'),`;
//                     }
//                   }
//                   insertProductVariantOption = await connection.query(
//                     insertProductVariantOptionBulkQuery,
//                     {
//                       type: QueryTypes.INSERT,
//                       transaction,
//                     }
//                   );
//                   console.log(
//                     insertProductVariantOptionBulkQuery,
//                     "------- ADD PRODUCT Variant QUERY"
//                   );
//                   if (insertProductVariantOption) {
//                     const getProductApprovalStatus = await connection.query(
//                       `SELECT * FROM vendor WHERE VendorID="${VendorID}"  `,
//                       {
//                         type: QueryTypes.SELECT,
//                         transaction,
//                       }
//                     );
//                     if (getProductApprovalStatus[0].ProductApproval == "Y") {
//                       const updateProductApprovalStatusInVendorTable =
//                         await connection.query(
//                           `UPDATE vendor SET ProductApproval="N" WHERE VendorID="${VendorID}"  `,
//                           {
//                             transaction,
//                           }
//                         );
//                       const updateProductActiveStatus = await connection.query(
//                         `UPDATE product SET Active="N" WHERE ProductID="${ProductID}"  `,
//                         {
//                           transaction,
//                         }
//                       );
//                     } else if (
//                       getProductApprovalStatus[0].ProductApproval == "N"
//                     ) {
//                       const updateProductActiveStatus = await connection.query(
//                         `UPDATE product SET Active="Y" WHERE ProductID="${ProductID}"  `,
//                         {
//                           transaction,
//                         }
//                       );
//                       const updateProductApprovalStatusInVendorTable =
//                         await connection.query(
//                           `UPDATE vendor SET ProductApproval="Y" WHERE VendorID="${VendorID}"  `,
//                           {
//                             transaction,
//                           }
//                         );
//                     }
//                     if (transaction) await transaction.commit(); //!final commit
//                     res.status(200).json({
//                       status: true,
//                       message: "Product Form 1 Details Added Successfully",
//                       ProductID: ProductID,
//                     });
//                   } else {
//                     if (transaction) await transaction.rollback();
//                     res.status(200).json({
//                       status: false,
//                       message: "Error while adding Product Variant Option",
//                     });
//                   }

//                   //!Insert into Product Variant table ends here
//                 } else {
//                   if (transaction) await transaction.rollback();
//                   res.status(200).json({
//                     status: false,
//                     message: "Error while adding Product country",
//                   });
//                 }
//                 //!Insert into Product Country table ends here
//               } else {
//                 if (transaction) await transaction.rollback();
//                 res.status(200).json({
//                   status: false,
//                   message: "Error while adding Product City",
//                 });
//               }
//               //!Insert into Product City table ends here
//             } else {
//               if (transaction) await transaction.rollback();
//               res.status(200).json({
//                 status: false,
//                 message: "Error while adding Product Details",
//               });
//             }
//           } else if (
//             checkProductTitleExists &&
//             checkProductTitleExists == "1"
//           ) {
//             if (transaction) await transaction.rollback();
//             res.status(200).json({
//               status: false,
//               message: "Product already registered with this Title",
//               Product: [],
//             });
//           }
//         } else {
//           if (transaction) await transaction.rollback();
//           res.status(200).json({
//             status: false,
//             message:
//               "Store is not approved yet !! Please wait until store is approved",
//           });
//         }
//       } else if (checkIfSubCategoryExists && checkIfSubCategoryExists == "0") {
//         if (transaction) await transaction.rollback();
//         res.status(200).json({
//           status: false,
//           message: "SubCategory does not exist",
//           SubCategory: [],
//         });
//       }
//     } else if (checkIfVendorExists && checkIfVendorExists == "0") {
//       if (transaction) await transaction.rollback();
//       res.status(200).json({
//         status: false,
//         message: "Vendor does not have Store",
//         Vendor: [],
//       });
//     }
//   } catch (err) {
//     if (transaction) await transaction.rollback();
//     next(err);
//     res.status(200).json({
//       status: false,
//       Product: {},
//       error: err.message,
//     });
//   }
// };
let vendorIDCheck = async (VendorID, transaction) => {
  try {
    let user = await connection.query(
      `select * from vendorstore where VendorID = '${VendorID}'`, {
      type: QueryTypes.SELECT,
      transaction,
    }
    );
    if (user && user.length > 0) {
      return "1";
    } else {
      return "0";
    }
  } catch (err) {
    console.log(err.message);
    return null;
  }
};
let subcategoryIDCheck = async (SubCategoryID, transaction) => {
  try {
    let SubCategoryIDcheck = await connection.query(
      `select * from subcategory where SubCategoryID  = '${SubCategoryID}'`, {
      type: QueryTypes.SELECT,
      transaction,
    }
    );
    if (SubCategoryIDcheck && SubCategoryIDcheck.length > 0) {
      return "1";
    } else {
      return "0";
    }
  } catch (err) {
    console.log(err.message);
    return null;
  }
};
let productTitleCheck = async (Title, VendorID, transaction) => {
  try {
    let checkProductTitle = await connection.query(
      `select * from product where Title  = "${Title}" AND VendorID="${VendorID}"`, {
      type: QueryTypes.SELECT,
      transaction,
    }
    );
    if (checkProductTitle && checkProductTitle.length > 0) {
      return "1";
    } else {
      return "0";
    }
  } catch (err) {
    console.log(err.message);
    return null;
  }
};
exports.getProductDetailsPaginated = async (req, res, next) => {
  try {
    let Region = req.region;
    const currencyRate = req.currency_rate;
    let {
      limit,
      offset,
      sort
    } = req.body;
    limit = parseInt(limit);
    offset = parseInt(offset);
    offset = limit * offset;
    let productsCount = await connection.query(
      `SELECT COUNT(ProductID) as total_records FROM product `, {
      type: QueryTypes.SELECT,
    }
    );
    if (productsCount && productsCount.length > 0) {
      let viewProductQuery = `
  SELECT t.City AS ProductCity, t.Native AS CityNative, y.Country AS ProductCountry, p.*, v.userName, vn.CompanyName
  FROM ((((((product p
  LEFT JOIN productcity c ON c.ProductID = p.ProductID)
  LEFT JOIN city t ON t.CityID = c.CityID)
  LEFT JOIN productcountry r ON r.ProductID = p.ProductID)
  LEFT JOIN country y ON y.CountryID = r.CountryID)
  LEFT JOIN profile v ON v.UserID = p.VendorID)
  LEFT JOIN vendor vn ON vn.VendorID = p.VendorID)
  ORDER BY p.Title ${sort || 'ASC'}
  LIMIT ${limit} OFFSET ${offset}
`;

      let viewProduct = await connection.query(viewProductQuery, {
        type: QueryTypes.SELECT,
      });
      if (viewProduct && viewProduct.length > 0) {
        //!cuurency conversion
        if (Region == "Bangladesh") {
          for (let i = 0; i < viewProduct.length; i++) {
            let Price = viewProduct[i].Price;
            if (viewProduct[i].Currency == "USD") {
              viewProduct[i]["Currency"] = "BDT";
              viewProduct[i]["Price"] = parseFloat(
                currencyRate * Price
              ).toFixed(2);
            }
          }
        } else {
          for (let i = 0; i < viewProduct.length; i++) {
            let Price = viewProduct[i].Price;
            if (viewProduct[i].Currency == "BDT") {
              viewProduct[i]["Currency"] = "USD";
              viewProduct[i]["Price"] = parseFloat(
                currencyRate * Price
              ).toFixed(2);
            }
          }
        }

        res.status(200).json({
          status: true,
          total_records: productsCount[0].total_records,
          Products: viewProduct,
        });
      } else {
        res.status(200).json({
          status: true,
          total_records: productsCount[0].total_records,
          Products: [],
        });
      }
    }
  } catch (err) {
    next(err);
    res.status(200).json({
      status: false,
      profile: {},
      error: err.message,
    });
    console.log(err.message);
  }
};
exports.getProductDetailsPaginatedByVendorId = async (req, res, next) => {
  try {

    console.log("inisde getProductDetailsPaginatedByVendorId")
    let Region = req.region;
    let VendorID = req.params.id;
    const currencyRate = req.currency_rate;
    let {
      limit,
      offset
      , sort
    } = req.body;
    limit = parseInt(limit);
    offset = parseInt(offset);
    offset = limit * offset; //SELECT COUNT(*)  as total_records from ()total_records
    let productsCount = await connection.query(
      `SELECT COUNT(ProductID) as total_records FROM product WHERE VendorID="${VendorID}" `, {
      type: QueryTypes.SELECT,
    }
    );
    if (productsCount && productsCount.length > 0) {
      //  let viewProductQuery =
      //    ` SELECT t.City AS ProductCity,t.Native AS CityNative,y.country AS ProductCountry,p.*
      //  FROM  ((((product  p
      //  LEFT JOIN productcity c ON c.ProductID = p.ProductID)
      //    LEFT JOIN city t ON t.CityID = c.CityID)
      //   LEFT  JOIN productcountry r ON r.ProductID = p.ProductID)
      //   LEFT JOIN country y ON y.CountryID = r.CountryID)
      //   WHERE p.VendorID="${VendorID}"
      //    order by p.ProductID desc limit ` +
      //        limit +
      // " offset " +
      //   offset;

      let viewProductQuery =
        ` SELECT t.City AS ProductCity,t.Native AS CityNative,y.country AS ProductCountry,p.*
      FROM  ((((product  p
     LEFT JOIN productcity c ON c.ProductID = p.ProductID)
     LEFT JOIN city t ON t.CityID = c.CityID)
     LEFT  JOIN productcountry r ON r.ProductID = p.ProductID)
     LEFT JOIN country y ON y.CountryID = r.CountryID)
     WHERE p.VendorID="${VendorID}"
     ORDER BY p.Title ${sort || 'ASC'}
     LIMIT ${limit} OFFSET ${offset}`

      let viewProduct = await connection.query(viewProductQuery, {
        type: QueryTypes.SELECT,
      });
      if (viewProduct && viewProduct.length > 0) {
        //!cuurency conversion
        // if (Region == "Bangladesh") {
        //   for (let i = 0; i < viewProduct.length; i++) {
        //     let Price = viewProduct[i].Price;
        //     if (viewProduct[i].Currency == "USD") {
        //       viewProduct[i]["Currency"] = "BDT";
        //       viewProduct[i]["Price"] = parseFloat(
        //         currencyRate * Price
        //       ).toFixed(2);
        //     }
        //   }
        // } else {
        //   for (let i = 0; i < viewProduct.length; i++) {
        //     let Price = viewProduct[i].Price;
        //     if (viewProduct[i].Currency == "BDT") {
        //       viewProduct[i]["Currency"] = "USD";
        //       viewProduct[i]["Price"] = parseFloat(
        //         currencyRate * Price
        //       ).toFixed(2);
        //     }
        //   }
        // }
        res.status(200).json({
          status: true,
          total_records: productsCount[0].total_records,
          Products: viewProduct,
        });
      } else {
        res.status(200).json({
          status: true,
          total_records: productsCount[0].total_records,
          Products: [],
        });
      }
    }
  } catch (err) {
    next(err);
    res.status(200).json({
      status: false,
      profile: {},
      error: err.message,
    });
    console.log(err.message);
  }
};
exports.getProductDetailsByProductIdOld = async (req, res, next) => {
  try {
    let Region = req.region;
    const currencyRate = req.currency_rate;
    console.log(currencyRate);
    let ProductDetails = await connection.query(
      `SELECT *  FROM product WHERE ProductID='${req.params.id}' `, {
      type: QueryTypes.SELECT,
    }
    );
    if (ProductDetails && ProductDetails.length > 0) {
      //! cuurency conversion
      let Price = ProductDetails[0].Price;
      if (Region == "Bangladesh") {
        if (ProductDetails[0].Currency == "USD") {
          ProductDetails[0]["Currency"] = "BDT";
          ProductDetails[0]["Price"] = parseFloat(currencyRate * Price).toFixed(
            2
          );
        }
      } else if (Region == "USA") {
        if (ProductDetails[0].Currency == "BDT") {
          ProductDetails[0]["Currency"] = "USD";
          ProductDetails[0]["Price"] = parseFloat(currencyRate * Price).toFixed(
            2
          );
        }
      } else {
        for (let i = 0; i < ProductDetails.length; i++) {
          let Price = ProductDetails[i].Price;
          ProductDetails[i]["Currency"] = "USD";
          ProductDetails[i]["Price"] = parseFloat(currencyRate * Price).toFixed(
            2
          );
        }
      }

      res.status(200).json({
        status: true,
        Product: ProductDetails[0],
      });
    } else {
      res.status(200).json({
        status: false,
        message: "NO Product found",
        Product: [],
      });
    }
  } catch (err) {
    next(err);
    res.status(200).json({
      status: false,
      Product: [],
      error: err.message,
    });
    console.log(err.message);
  }
};
exports.getProductDetailsByProductId = async (req, res, next) => {
  try {
    const currencyRate = req.currency_rate;
    console.log(currencyRate);
    let ProductDetails = await connection.query(
      `SELECT *  FROM product WHERE ProductID='${req.params.id}' `, {
      type: QueryTypes.SELECT,
    }
    );
    if (ProductDetails && ProductDetails.length > 0) {
      res.status(200).json({
        status: true,
        Product: ProductDetails[0],
      });
    } else {
      res.status(200).json({
        status: false,
        message: "NO Product found",
        Product: [],
      });
    }
  } catch (err) {
    next(err);
    res.status(200).json({
      status: false,
      Product: [],
      error: err.message,
    });
    console.log(err.message);
  }
};
exports.updateProductDetailsForm1 = async (req, res, next) => {
  let transaction; //!transaction variable declare here
  try {
    const {
      SubCategoryID,
      StoreName,
      Title,
      Description,
      SpecialInstruction,
      ReturnPolicy,
      Currency,
      CostPrice,
      Price,
      Quantity1,
      PriceQuantity1,
      Quantity2,
      PriceQuantity2,
      Quantity3,
      PriceQuantity3,
      PromotionPrice,
      PromotionRate,
      PromotionStartDate,
      PromotionEndDate,
      Weight,
      Height,
      Length,
      Width,
      AllowStorePickup,
      ShippingAvailable,
      ShippingGlobal,
      ShippingByAdmin,
      ShippingByVendor,
      ShippingCostAdmin,
      ShippingCostVendor,
      ReviewedByAdmin,
      TaxVATApply,
      LockEdit,
      Active,
      Variations,
      OptionID,
      AdminNote,
      Status,
      FreeProductReturn,
      ProductCodStatus
    } = req.body;
    console.log(req.body);
    transaction = await connection.transaction(); //!transaction use here
    let VendorID;
    let ProductVariantCombinationID = [];
    let LastUpdate = new Date().toISOString().slice(0, 19).replace("T", " ");

    var ProductID = req.params.id;
    console.log("Product id is " + ProductID);
    var checkIfProductExists = await connection.query(
      `select * from product  where ProductID  = '${ProductID}' `, {
      type: QueryTypes.SELECT,
      transaction,
    }
    );
    if (checkIfProductExists && checkIfProductExists.length > 0) {
      let checkIfSubCategoryExists = await subCategoryIDCheck(
        SubCategoryID,
        transaction
      );
      console.log(checkIfSubCategoryExists);
      if (checkIfSubCategoryExists && checkIfSubCategoryExists == "1") {
        checkIfSameStoreName = checkIfProductExists[0].StoreName == StoreName; //to check if given storename is same as that of product
        console.log(checkIfSameStoreName);
        VendorID = checkIfProductExists[0].VendorID;
        // const getProductApprovalStatus = await connection.query(
        //   `SELECT * FROM vendor WHERE VendorID="${VendorID}"  `, {
        //     type: QueryTypes.SELECT,
        //     transaction,
        //   }
        // );
        console.log(Active, "Active---------------")
        if (Active == "N") {
          const updateProductActiveStatus = await connection.query(
            `UPDATE product SET Active="N",ReviewedByAdmin="N" WHERE ProductID="${ProductID}"  `, {
            transaction,
          }
          );
        }

        // if (getProductApprovalStatus[0].ProductApproval == "Y") {
        //   const updateProductApprovalStatusInVendorTable =
        //     await connection.query(
        //       `UPDATE vendor SET ProductApproval="N" WHERE VendorID="${VendorID}"  `, {
        //         transaction,
        //       }
        //     );
        //   if (updateProductApprovalStatusInVendorTable) {
        //     const updateProductActiveStatus = await connection.query(
        //       `UPDATE product SET Active="N",ReviewedByAdmin="N" WHERE ProductID="${ProductID}"  `, {
        //         transaction,
        //       }
        //     );
        //     console.log(updateProductActiveStatus, " WHEN STATUS IS Y");
        //   } else {
        //     if (transaction) await transaction.rollback();
        //     res.status(200).json({
        //       status: false,
        //       message: `Error while updating Product Approval Status`,
        //     });
        //   }
        // } else if (getProductApprovalStatus[0].ProductApproval == "N") {
        //   const updateProductActiveStatus = await connection.query(
        //     `UPDATE product SET Active="Y" WHERE ProductID="${ProductID}"  `, {
        //       transaction,
        //     }
        //   );
        //   if (updateProductActiveStatus) {
        //     const updateProductApprovalStatusInVendorTable =
        //       await connection.query(
        //         `UPDATE vendor SET ProductApproval="Y" WHERE VendorID="${VendorID}"  `, {
        //           transaction,
        //         }
        //       );
        //     console.log(
        //       updateProductApprovalStatusInVendorTable,
        //       " WHEN STATUS IS N"
        //     );
        //   } else {
        //     if (transaction) await transaction.rollback();
        //     res.status(200).json({
        //       status: false,
        //       message: `Error while updating Product Approval Status`,
        //     });
        //   }
        // }

        if (Title == checkIfProductExists[0].Title) {
          console.log("FIRST QUERY ", Price);
          //!UPDATE Product table starts here only if product new added  title is same as old
          let updateProductQuery = await connection.query(
            `Update product SET  SubCategoryID="${SubCategoryID}",Title="${Title}",StoreName="${StoreName}",
                              Description="${Description}", SpecialInstruction="${SpecialInstruction}",ReturnPolicy="${ReturnPolicy}",
                              Currency="${Currency}",CostPrice="${CostPrice}", Price="${Price}" ,Quantity1="${Quantity1}",
                              PriceQuantity1="${PriceQuantity1}",Quantity2="${Quantity2}" ,PriceQuantity2="${PriceQuantity2}",
                              Quantity3="${Quantity3}", PriceQuantity3="${PriceQuantity3}",PromotionPrice="${PromotionPrice}",
                              PromotionRate="${PromotionRate}",  PromotionStartDate="${PromotionStartDate}",  PromotionEndDate="${PromotionEndDate}",
                              Weight="${Weight}",Height= "${Height}", Length="${Length}",  Width="${Width}",  AllowStorePickup="${AllowStorePickup}",
                              ShippingAvailable="${ShippingAvailable}",  ShippingGlobal="${ShippingGlobal}",  ShippingByAdmin="${ShippingByAdmin}",
                              ShippingByVendor="${ShippingByVendor}",  ShippingCostAdmin="${ShippingCostAdmin}", ShippingCostVendor="${ShippingCostVendor}",
                              TaxVATApply="${TaxVATApply}", LockEdit="${LockEdit}", Active="${Active}", LastUpdate="${LastUpdate}" , AdminNote="${AdminNote}",ProductCodStatus="${ProductCodStatus}",FreeProductReturn="${FreeProductReturn}" WHERE ProductID="${ProductID}"`, {
            transaction,
          }
          );
          if (updateProductQuery) {
            //!UPDATE Product variant option table starts here
            if (checkIfSameStoreName && checkIfSameStoreName.length > 0) {
              let insertProductVariantOptionBulkQuery = `INSERT INTO productvariantoption (OptionID,ProductID, OptionName ) VALUES `;
              for (let i = 0; i < Variations.length; i++) {
                if (i == Variations.length - 1) {
                  insertProductVariantOptionBulkQuery += `(${OptionID[i]},${ProductID},'${Variations[i]}')`;
                } else {
                  insertProductVariantOptionBulkQuery += `(${OptionID[i]},${ProductID},'${Variations[i]}'),`;
                }
              }
              /*ON DUPLICATE KEY UPDATE
                 <column1> = VALUES(<column1>),
                 <column2> = VALUES(<column2>);*/
              insertProductVariantOptionBulkQuery += ` ON DUPLICATE KEY UPDATE OptionID=VALUES(OptionID),OptionName=VALUES(OptionName)`;
              let updateProductVariantOpion = await connection.query(
                insertProductVariantOptionBulkQuery, {
                transaction,
              }
              );
              if (updateProductVariantOpion) {
                if (transaction) await transaction.commit(); //!final commit
                res.status(200).json({
                  status: true,
                  message: `Product Details Updated Successfully`,
                });
              } else {
                if (transaction) await transaction.rollback();
                res.status(200).json({
                  status: false,
                  message: `Error while updating Product Variant Option`,
                });
              }
            } else {
              //!UPDATE Product city table starts here
              getCityID = await connection.query(
                `SELECT * FROM vendorstore WHERE VendorID="${VendorID}" AND StoreName="${StoreName}" `, {
                type: QueryTypes.SELECT,
                transaction,
              }
              );
              let getCurrentCityID = await connection.query(
                `SELECT * FROM productcity WHERE  ProductID="${ProductID}" `, {
                type: QueryTypes.SELECT,
                transaction,
              }
              );
              let VendorOldCity = getCurrentCityID[0].CityID;
              let VendorProductCity = getCityID[0].CityID;
              let updateProductCityQuery = `UPDATE productcity SET CityID="${VendorProductCity}" WHERE ProductID="${ProductID}" AND CityID="${VendorOldCity}"  `;
              let updateProductCity = await connection.query(
                updateProductCityQuery, {
                transaction,
              }
              );

              if (updateProductCity) {
                //!UPDATE Product country table starts here
                const getCountryID = await connection.query(
                  `SELECT * FROM vendorstore WHERE VendorID="${VendorID}" AND StoreName="${StoreName}" `, {
                  type: QueryTypes.SELECT,
                  transaction,
                }
                );
                let getCurrentCountryID = await connection.query(
                  `SELECT * FROM productcountry WHERE  ProductID="${ProductID}" `, {
                  type: QueryTypes.SELECT,
                  transaction,
                }
                );
                let VendorOldCountry = getCurrentCountryID[0].CountryID;
                let VendorProductCountry = getCountryID[0].CountryID;
                let updateProductCountryQuery = `UPDATE productcountry SET CountryID="${VendorProductCountry}" WHERE ProductID="${ProductID}" AND CountryID="${VendorOldCountry}"  `;
                let updateProductCountry = await connection.query(
                  updateProductCountryQuery, {
                  transaction,
                }
                );
                let getVendorStoreID = await connection.query(
                  `SELECT * FROM vendorstore WHERE StoreName="${StoreName}" `, {
                  type: QueryTypes.SELECT,
                  transaction,
                }
                );
                let VendorStoreID = getVendorStoreID[0].VendorStoreID;
                let checkIFProductExistsINProductInventory =
                  await connection.query(
                    `SELECT * FROM productvariantcombination WHERE  ProductID="${ProductID}" `, {
                    type: QueryTypes.SELECT,
                    transaction,
                  }
                  );
                //! here we are updating vendorstore in Porduct variant combination and product inventory as it is changed in product city and product country
                console.log(checkIFProductExistsINProductInventory);
                if (
                  checkIFProductExistsINProductInventory &&
                  checkIFProductExistsINProductInventory.length > 0
                ) {
                  let updateProductVariantCombinationQuery = `UPDATE productvariantcombination SET VendorStoreID="${VendorStoreID}" WHERE  ProductID="${ProductID}" `;
                  let updateProductVariantCombination = await connection.query(
                    updateProductVariantCombinationQuery, {
                    transaction,
                  }
                  );
                  for (
                    let i = 0; i < checkIFProductExistsINProductInventory.length; i++
                  ) {
                    if (
                      checkIFProductExistsINProductInventory[i]
                        .ProductVariantCombinationID ==
                      checkIFProductExistsINProductInventory[0]
                        .ProductVariantCombinationID
                    ) {
                      ProductVariantCombinationID += `(`;
                    }
                    if (i < checkIFProductExistsINProductInventory.length - 1) {
                      ProductVariantCombinationID += ` '${checkIFProductExistsINProductInventory[i].ProductVariantCombinationID}' ,`;
                    } else if (
                      i ==
                      checkIFProductExistsINProductInventory.length - 1
                    ) {
                      ProductVariantCombinationID += `'${checkIFProductExistsINProductInventory[i].ProductVariantCombinationID}')`;
                    }
                  }
                  let updateProductVariantInventoryQuery = `UPDATE productinventory SET VendorStoreID="${VendorStoreID}" WHERE  ProductVariantCombinationID IN ${ProductVariantCombinationID} `;
                  let updateProductVariantInventory = await connection.query(
                    updateProductVariantInventoryQuery, {
                    transaction,
                  }
                  );
                }
                if (updateProductCountry) {
                  //!UPDATE Product variant table starts here
                  let insertProductVariantOptionBulkQuery = `INSERT INTO productvariantoption (OptionID,ProductID, OptionName ) VALUES `;
                  for (let i = 0; i < Variations.length; i++) {
                    if (i == Variations.length - 1) {
                      insertProductVariantOptionBulkQuery += `(${OptionID[i]},${ProductID},'${Variations[i]}')`;
                    } else {
                      insertProductVariantOptionBulkQuery += `(${OptionID[i]},${ProductID},'${Variations[i]}'),`;
                    }
                  }
                  /*ON DUPLICATE KEY UPDATE
                     <column1> = VALUES(<column1>),
                     <column2> = VALUES(<column2>);*/
                  insertProductVariantOptionBulkQuery += ` ON DUPLICATE KEY UPDATE OptionID=VALUES(OptionID),OptionName=VALUES(OptionName)`;
                  let updateProductVariantOpion = await connection.query(
                    insertProductVariantOptionBulkQuery, {
                    transaction,
                  }
                  );

                  if (updateProductVariantOpion) {
                    if (transaction) await transaction.commit(); //!final commit
                    res.status(200).json({
                      status: true,
                      message: `Product Details Updated Successfully`,
                    });
                  } else {
                    if (transaction) await transaction.rollback();
                    res.status(200).json({
                      status: false,
                      message: `Error while updating Product Variant Option`,
                    });
                  }
                } else {
                  if (transaction) await transaction.rollback();
                  res.status(200).json({
                    status: false,
                    message: `Error while updating Product Country`,
                  });
                }
              } else {
                if (transaction) await transaction.rollback();
                res.status(200).json({
                  status: false,
                  message: `Error while updating Product City`,
                });
              }
            }
          } else {
            if (transaction) await transaction.rollback();
            res.status(200).json({
              status: false,
              message: `Error while updating Product basic details`,
            });
          }
        } else {
          let checkIFProductTitleAlreadyExists = await connection.query(
            `select * from product  where Title = '${Title}' AND VendorID='${VendorID}' `, {
            type: QueryTypes.SELECT,
            transaction,
          }
          );
          console.log(checkIFProductTitleAlreadyExists);
          if (
            checkIFProductTitleAlreadyExists &&
            checkIFProductTitleAlreadyExists.length > 0
          ) {
            //! Not changing product title as Current Vendor of this product already has same title for another product
            if (transaction) await transaction.rollback();
            res.status(200).json({
              status: false,
              Title: {},
              message: `Title already taken, please select another one`,
            });
          } else {
            console.log("2nd QUERY ");
            //! Update Product details only if Product titles is changed i.e different then old
            let updateProductQuery = await connection.query(
              `Update product SET  SubCategoryID="${SubCategoryID}",Title="${Title}",StoreName="${StoreName}",
                              Description="${Description}", SpecialInstruction="${SpecialInstruction}",ReturnPolicy="${ReturnPolicy}",
                              Currency="${Currency}",CostPrice="${CostPrice}", Price="${Price}" ,Quantity1="${Quantity1}",
                              PriceQuantity1="${PriceQuantity1}",Quantity2="${Quantity2}" ,PriceQuantity2="${PriceQuantity2}",
                              Quantity3="${Quantity3}", PriceQuantity3="${PriceQuantity3}",PromotionPrice="${PromotionPrice}",
                              PromotionRate="${PromotionRate}",  PromotionStartDate="${PromotionStartDate}",  PromotionEndDate="${PromotionEndDate}",
                              Weight="${Weight}",Height= "${Height}", Length="${Length}",  Width="${Width}",  AllowStorePickup="${AllowStorePickup}",
                              ShippingAvailable="${ShippingAvailable}",  ShippingGlobal="${ShippingGlobal}",  ShippingByAdmin="${ShippingByAdmin}",
                              ShippingByVendor="${ShippingByVendor}",  ShippingCostAdmin="${ShippingCostAdmin}", ShippingCostVendor="${ShippingCostVendor}",
                              TaxVATApply="${TaxVATApply}", LockEdit="${LockEdit}", Active="${Active}", LastUpdate="${LastUpdate}" , AdminNote="${AdminNote}",ProductCodStatus="${ProductCodStatus}",FreeProductReturn="${FreeProductReturn}"  WHERE ProductID="${ProductID}"`, {
              transaction,
            }
            );
            if (updateProductQuery) {
              if (checkIfSameStoreName && checkIfSameStoreName.length > 0) {
                //! updating product variant option
                let insertProductVariantOptionBulkQuery = `INSERT INTO productvariantoption (OptionID,ProductID, OptionName ) VALUES `;
                for (let i = 0; i < Variations.length; i++) {
                  if (i == Variations.length - 1) {
                    insertProductVariantOptionBulkQuery += `(${OptionID[i]},${ProductID},'${Variations[i]}')`;
                  } else {
                    insertProductVariantOptionBulkQuery += `(${OptionID[i]},${ProductID},'${Variations[i]}'),`;
                  }
                }
                /*ON DUPLICATE KEY UPDATE
                   <column1> = VALUES(<column1>),
                   <column2> = VALUES(<column2>);*/
                insertProductVariantOptionBulkQuery += ` ON DUPLICATE KEY UPDATE OptionID=VALUES(OptionID),OptionName=VALUES(OptionName)`;
                let updateProductVariantOpion = await connection.query(
                  insertProductVariantOptionBulkQuery, {
                  transaction,
                }
                );

                if (updateProductVariantOpion) {
                  if (transaction) await transaction.commit(); //!final commit
                  res.status(200).json({
                    status: true,
                    message: `Product Details Updated Successfully`,
                  });
                } else {
                  if (transaction) await transaction.rollback();
                  res.status(200).json({
                    status: false,
                    message: `Error while updating Product Variant Option`,
                  });
                }
              } else {
                //!updating product City
                getCityID = await connection.query(
                  `SELECT * FROM vendorstore WHERE VendorID="${VendorID}" AND StoreName="${StoreName}" `, {
                  type: QueryTypes.SELECT,
                  transaction,
                }
                );
                let getCurrentCityID = await connection.query(
                  `SELECT * FROM productcity WHERE  ProductID="${ProductID}" `, {
                  type: QueryTypes.SELECT,
                  transaction,
                }
                );
                let VendorOldCity = getCurrentCityID[0].CityID;
                let VendorProductCity = getCityID[0].CityID;
                let updateProductCityQuery = `UPDATE productcity SET CityID="${VendorProductCity}" WHERE ProductID="${ProductID}" AND CityID="${VendorOldCity}"  `;
                let updateProductCity = await connection.query(
                  updateProductCityQuery, {
                  transaction,
                }
                );
                if (updateProductCity) {
                  //!updating product country
                  const getCountryID = await connection.query(
                    `SELECT * FROM vendorstore WHERE VendorID="${VendorID}" AND StoreName="${StoreName}" `, {
                    type: QueryTypes.SELECT,
                    transaction,
                  }
                  );
                  let getCurrentCountryID = await connection.query(
                    `SELECT * FROM productcountry WHERE  ProductID="${ProductID}" `, {
                    type: QueryTypes.SELECT,
                    transaction,
                  }
                  );
                  let VendorOldCountry = getCurrentCountryID[0].CountryID;
                  let VendorProductCountry = getCountryID[0].CountryID;
                  let updateProductCountryQuery = `UPDATE productcountry SET CountryID="${VendorProductCountry}" WHERE ProductID="${ProductID}" AND CountryID="${VendorOldCountry}"  `;
                  let updateProductCountry = await connection.query(
                    updateProductCountryQuery, {
                    transaction,
                  }
                  );
                  let getVendorStoreID = await connection.query(
                    `SELECT * FROM vendorstore WHERE StoreName="${StoreName}" `, {
                    type: QueryTypes.SELECT,
                    transaction,
                  }
                  );
                  let VendorStoreID = getVendorStoreID[0].VendorStoreID;
                  let checkIFProductExistsINProductInventory =
                    await connection.query(
                      `SELECT * FROM productvariantcombination WHERE  ProductID="${ProductID}" `, {
                      type: QueryTypes.SELECT,
                      transaction,
                    }
                    );
                  console.log(checkIFProductExistsINProductInventory);
                  //! here we are updating vendorstore in Porduct variant combination and product inventory as it is changed in product city and product country
                  if (
                    checkIFProductExistsINProductInventory &&
                    checkIFProductExistsINProductInventory.length > 0
                  ) {
                    let updateProductVariantCombinationQuery = `UPDATE productvariantcombination SET VendorStoreID="${VendorStoreID}" WHERE  ProductID="${ProductID}" `;
                    let updateProductVariantCombination =
                      await connection.query(
                        updateProductVariantCombinationQuery, {
                        transaction,
                      }
                      );
                    for (
                      let i = 0; i < checkIFProductExistsINProductInventory.length; i++
                    ) {
                      if (
                        checkIFProductExistsINProductInventory[i]
                          .ProductVariantCombinationID ==
                        checkIFProductExistsINProductInventory[0]
                          .ProductVariantCombinationID
                      ) {
                        ProductVariantCombinationID += `(`;
                      }
                      if (
                        i <
                        checkIFProductExistsINProductInventory.length - 1
                      ) {
                        ProductVariantCombinationID += ` '${checkIFProductExistsINProductInventory[i].ProductVariantCombinationID}' ,`;
                      } else if (
                        i ==
                        checkIFProductExistsINProductInventory.length - 1
                      ) {
                        ProductVariantCombinationID += `'${checkIFProductExistsINProductInventory[i].ProductVariantCombinationID}')`;
                      }
                    }
                    let updateProductVariantInventoryQuery = `UPDATE productinventory SET VendorStoreID="${VendorStoreID}" WHERE  ProductVariantCombinationID IN ${ProductVariantCombinationID} `;
                    let updateProductVariantInventory = await connection.query(
                      updateProductVariantInventoryQuery, {
                      transaction,
                    }
                    );
                  }
                  if (updateProductCountry) {
                    //!updating product variant option
                    let insertProductVariantOptionBulkQuery = `INSERT INTO productvariantoption (OptionID,ProductID,OptionName ) VALUES `;
                    for (let i = 0; i < Variations.length; i++) {
                      if (i == Variations.length - 1) {
                        insertProductVariantOptionBulkQuery += `(${OptionID[i]},${ProductID},'${Variations[i]}')`;
                      } else {
                        insertProductVariantOptionBulkQuery += `(${OptionID[i]},${ProductID},'${Variations[i]}'),`;
                      }
                    }
                    /*ON DUPLICATE KEY UPDATE
                       <column1> = VALUES(<column1>),
                       <column2> = VALUES(<column2>);*/
                    insertProductVariantOptionBulkQuery += ` ON DUPLICATE KEY UPDATE OptionID=VALUES(OptionID),OptionName=VALUES(OptionName)`;
                    console.log("Query", insertProductVariantOptionBulkQuery);
                    let updateProductVariantOpion = await connection.query(
                      insertProductVariantOptionBulkQuery, {
                      transaction,
                    }
                    );
                    if (updateProductVariantOpion) {
                      if (transaction) await transaction.commit(); //!final commit
                      res.status(200).json({
                        status: true,
                        message: `Product Details Updated Successfully`,
                      });
                    } else {
                      if (transaction) await transaction.rollback();
                      res.status(200).json({
                        status: false,
                        message: `Error while updating Product Variant Option`,
                      });
                    }
                  } else {
                    if (transaction) await transaction.rollback();
                    res.status(200).json({
                      status: false,
                      message: `Error while updating Product Country`,
                    });
                  }
                } else {
                  if (transaction) await transaction.rollback();
                  res.status(200).json({
                    status: false,
                    message: `Error while updating Product City`,
                  });
                }
              }
            } else {
              if (transaction) await transaction.rollback();
              res.status(200).json({
                status: false,
                message: `Error while updating Product basic details`,
              });
            }
          }
        }
      } else if (checkIfSubCategoryExists && checkIfSubCategoryExists == "0") {
        if (transaction) await transaction.rollback();
        res.status(200).json({
          status: false,
          message: `SubCategory does not exist `,
          Product: [],
        });
      }
    } else {
      if (transaction) await transaction.rollback();
      res.status(200).json({
        status: false,
        message: `Product does not exist `,
        Product: [],
      });
    }
  } catch (err) {
    if (transaction) await transaction.rollback();
    console.log(err);
    res.status(200).json({
      status: false,
      Product: {},
      error: err.message,
    });
  }
};
exports.addNewProductVariantOption = async (req, res, next) => {
  try {
    let ProductID = req.params.id;
    const {
      Variations
    } = req.body;
    let insertProductVariantOptionBulkQuery = `insert into productvariantoption ( ProductID ,OptionName) values  `;
    for (let i = 0; i < Variations.length; i++) {
      if (i == Variations.length - 1) {
        insertProductVariantOptionBulkQuery += `('${ProductID}', '${Variations[i]}')`;
      } else {
        insertProductVariantOptionBulkQuery += `('${ProductID}', '${Variations[i]}'),`;
      }
    }
    let insertProductVariantOption = await connection.query(
      insertProductVariantOptionBulkQuery, {
      type: QueryTypes.INSERT,
    }
    );
    if (insertProductVariantOption) {
      res.status(200).json({
        status: true,
        message: "Product Variant Option added successfully",
      });
    } else {
      res.status(200).json({
        status: false,
        message: "Error while Product Variant Option",
      });
    }
  } catch (err) {
    next(err);
    res.status(200).json({
      status: false,
      Category: {},
      error: err.message,
    });
  }
};
let subCategoryIDCheck = async (SubCategoryID, transaction) => {
  try {
    let user = await connection.query(
      `select * from subcategory where SubCategoryID = '${SubCategoryID}'`, {
      type: QueryTypes.SELECT,
      transaction,
    }
    );
    if (user && user.length > 0) {
      return "1";
    } else {
      return "0";
    }
  } catch (err) {
    console.log(err.message);
    return null;
  }
};
exports.deleteProductVariantOptionById = async (req, res, next) => {
  try {
    const id = req.params.id;
    console.log(id);

    let checkProductVariantOption = await connection.query(
      `select * from productvariantoption where OptionID = "${id}" `, {
      type: QueryTypes.SELECT,
    }
    );
    if (checkProductVariantOption && checkProductVariantOption.length > 0) {
      let checkIfProductVariantIDExists =
        await productVariantOptionValueIDCheck(id);
      console.log(checkIfProductVariantIDExists);
      if (
        checkIfProductVariantIDExists &&
        checkIfProductVariantIDExists == "0"
      ) {
        let deleteProductVariant = await connection.query(
          `DELETE FROM productvariantoption WHERE OptionID="${id}" `, {
          type: QueryTypes.DELETE,
        }
        );
        res.status(200).json({
          status: true,
          message: `Product Variant deleted successfully`,
        });
      } else if (
        checkIfProductVariantIDExists &&
        checkIfProductVariantIDExists == "1"
      ) {
        console.log("*********");
        res.status(200).json({
          status: false,
          message: `This Product Variant has values it cannot be deleted`,
          ProductVariantOption: [],
        });
      }
    } else {
      console.log("*********");
      res.status(200).json({
        status: false,
        message: `Product Variant Option does not exist`,
        ProductVariantOption: [],
      });
    }
  } catch (err) {
    next(err);
    res.status(200).json({
      status: false,
      data: {},
      error: err.message,
    });
    console.log(err.message);
  }
};
let productVariantOptionValueIDCheck = async (OptionID) => {
  try {
    let checkOptionId = await connection.query(
      `select * from productvariantoptionvalue where OptionID = '${OptionID}'`, {
      type: QueryTypes.SELECT,
    }
    );
    if (checkOptionId && checkOptionId.length > 0) {
      return "1";
    } else {
      return "0";
    }
  } catch (err) {
    console.log(err.message);
    return null;
  }
};
/* exports.viewProductDetailsBySubCategory = async (req, res, next) => {
  try {
    let {
      limit,
      offset,
      sort,
    } = req.body;
    limit = parseInt(limit);
    offset = parseInt(offset);
    offset = limit * offset;
    let productsCount = await connection.query(`SELECT COUNT(ProductID) as total_records FROM product WHERE SubCategoryID='${req.params.id}'`, {
      type: QueryTypes.SELECT
    });
    if (productsCount && productsCount.length > 0) {
      let ProductDetailsQuery = `SELECT *,s.SubCategory,g.Small,G.Medium,g.Large
        FROM (((((subcategory s
        LEFT JOIN product p ON p.SubCategoryID=s.SubCategoryID)
        LEFT JOIN productvariantoption o ON o.ProductID IN (p.ProductID))
        LEFT JOIN productvariantoptionvalue v ON v.OptionID IN(o.OptionID))
        LEFT JOIN productimage i ON i.OptionValueID IN(v.OptionValueID))
        LEFT JOIN imagegallery g ON g.ImageGalleryID IN(i.ImageGalleryID))
        WHERE p.SubCategoryID='${req.params.id}' AND i.MainImage = 'Y'
        Order BY p.ProductID DESC
        limit ` +
        limit +
        " offset " +
        offset;
      let ProductDetails = await connection.query(ProductDetailsQuery, {
        type: QueryTypes.SELECT
      });

      if (ProductDetails && ProductDetails.length > 0) {
        res.status(200).json({
          status: true,
          total_records: productsCount[0].total_records,
          Product: ProductDetails,
          SubCategory: ProductDetails[0].SubCategory
        });
      } else {
        res.status(200).json({
          status: false,
          message: "NO Product found",
          total_records: productsCount[0].total_records,
          Product: [],
          SubCategory: []
        });
      }
    }
  } catch (err) {
    next(err);
    res.status(200).json({
      status: false,
      profile: {},
      error: err.message,
    });
    console.log(err.message);
  }
};
exports.viewProductDetailsByCategory = async (req, res, next) => {
  try {
    let {
      limit,
      offset,
      sort
    } = req.body;
    limit = parseInt(limit);
    offset = parseInt(offset);
    offset = limit * offset;
    let productsCount = await connection.query(`SELECT COUNT(ProductID) as total_records
     FROM ((product p
     LEFT JOIN subcategory s ON s.SubCategoryID = p.SubCategoryID)
     LEFT JOIN category c ON c.CategoryID = s.CategoryID)
     WHERE c.CategoryID='${req.params.id}'`, {
      type: QueryTypes.SELECT
    });
    if (productsCount && productsCount.length > 0) {
      let ProductDetailsQuery = `SELECT c.CategoryID,c.Category,s.SubCategory,p.*,g.Small,G.Medium,g.Large
        FROM ((((((product p
        LEFT JOIN subcategory s ON s.SubCategoryID = p.SubCategoryID)
        LEFT JOIN category c ON c.CategoryID = s.CategoryID)
        LEFT JOIN productvariantoption o ON o.ProductID IN (p.ProductID))
        LEFT JOIN productvariantoptionvalue v ON v.OptionID IN(o.OptionID))
        LEFT JOIN productimage i ON i.OptionValueID IN(v.OptionValueID))
        LEFT JOIN imagegallery g ON g.ImageGalleryID IN(i.ImageGalleryID))
        WHERE c.CategoryID='${req.params.id}' AND i.MainImage = 'Y' 
        ORDER BY p.ProductID DESC
       limit ` +
        limit +
        " offset " +
        offset;
      let ProductDetails = await connection.query(ProductDetailsQuery, {
        type: QueryTypes.SELECT
      });

      if (ProductDetails && ProductDetails.length > 0) {
        res.status(200).json({
          status: true,
          total_records: productsCount[0].total_records,
          Product: ProductDetails,
          Category: ProductDetails[0].Category

        });
      } else {
        res.status(200).json({
          status: false,
          message: "NO Product found",
          total_records: productsCount[0].total_records,
          Product: [],
          Category: []
        });
      }
    }
  } catch (err) {
    next(err);
    res.status(200).json({
      status: false,
      profile: {},
      error: err.message,
    });
    console.log(err.message);
  }
}; */
//! PRODUCT FORM 2 CRUD
exports.addProductDetailsForm2 = async (req, res, next) => {
  let transaction; //!transaction variable declare here
  try {
    const {
      StoreName,
      ProductID,
      OptionID,
      OptionValue,
      SKU,
      Price,
      AvailableInventory,
      Inventory,
      UnitPrice,
      TotalPrice,
      Status,
      optionValues,
      // isFirstVariant

    } = req.body;
    let setMainImage = 'Y';//first time we make it Y and it will be changed to N if at least one variant exists

    transaction = await connection.transaction(); //!transaction use here
    let addImages;
    let getVendorID;
    let getVendorStoreID;
    let VendorID;
    let insertProductVariantOptionValue;
    let OptionValueID;
    let VendorStoreID;
    let insertProductVariantCombination;

    let allOptoinValues = JSON.parse(optionValues)
    console.log("-------------------------------", allOptoinValues);

    const dataArray = [];
    for (let key in allOptoinValues) {
      if (!allOptoinValues[key].id) {
        let insertProductVariantOptionValueQuery = `insert into productvariantoptionvalue (OptionID,OptionValue ) values(?,?)`;
        insertProductVariantOptionValue = await connection.query(
          insertProductVariantOptionValueQuery, {
          replacements: [Number(key), allOptoinValues[key].text],
          type: QueryTypes.INSERT,
          transaction,
        }
        );

        const insertedOptionValueID = insertProductVariantOptionValue[0];
        console.log("Inserted OptionValueID:", insertedOptionValueID);
        allOptoinValues[key].id = insertedOptionValueID;
        dataArray.push({
          optionID: insertedOptionValueID,
          optionValue: allOptoinValues[key].text
        });
      }

      else {
        dataArray.push({
          optionID: Number(allOptoinValues[key].id),
          optionValue: allOptoinValues[key].text
        });
      }

    }
    console.log(dataArray, "--------------------------");

    const optionIDsArray = Object.values(allOptoinValues).map(item => parseInt(item.id)).sort((a, b) => a - b).join(',')


    insertProductVariantOptionValue = optionIDsArray.split(',').map(n => Number(n))
    console.log("=================>", insertProductVariantOptionValue, optionIDsArray);


    let checkOptionValuesQuery = `SELECT DISTINCT * FROM productvariantcombination WHERE OptionValueID = ?`;

    let result = await connection.query(checkOptionValuesQuery, {
      replacements: [optionIDsArray],
      type: QueryTypes.SELECT,
      transaction,
    });
    console.log("re ---------------", result);

    if (result && result.length > 0) {
      return res.status(409).json({
        status: false,
        message: "Value already exists with this name",
        data: result
      });
    }
    console.log(checkOptionValuesQuery, 'checkOptionValuesQuerycheckOptionValuesQuerycheckOptionValuesQuery');


    if (insertProductVariantOptionValue.length > 0) {


      let sortedOptionValueIds = insertProductVariantOptionValue.map(Number)
        .sort((a, b) => a - b).join(',')

      OptionValueID = sortedOptionValueIds

      console.log("sortedOptionValueIdssortedOptionValueIdssortedOptionValueIds", OptionValueID);

      let getVendorIDQuery = `SELECT * FROM product WHERE ProductID="${ProductID}" `;
      getVendorID = await connection.query(getVendorIDQuery, {
        type: QueryTypes.SELECT,
        transaction,
      });
      VendorID = getVendorID[0].VendorID;
      console.log("VendorID________" + VendorID);
      let Small, Medium, Large;

      console.log(req.files.Small[0].path);
      console.log(req.files.Medium[0].path);
      console.log(req.files.Medium[0].path);
      Small = req.files.Small[0].path;
      Medium = req.files.Medium[0].path;
      Large = req.files.Large[0].path;


      //!single
      let insertImagesQuery = `insert into imagegallery ( UserID , Small,Medium,Large) values (?,?,?,?)`;
      addImages = await connection.query(insertImagesQuery, {
        replacements: [VendorID, Small, Medium, Large],
        type: QueryTypes.INSERT,
        transaction,
      });

      if (addImages) {

        let checkIFFirstVariantQuery = `SELECT * FROM productimage WHERE ProductID="${ProductID}" `;
        let checkIFFirstVariant = await connection.query(checkIFFirstVariantQuery, {
          type: QueryTypes.SELECT,
          transaction,
        });

        if (checkIFFirstVariant && checkIFFirstVariant.length > 0) {
          console.log("inside isFirstVariat case --------------------------------")
          setMainImage = 'N'
        }

        console.log(insertProductVariantOptionValue, "insertProductVariantOptionValueinsertProductVariantOptionValue")

        let optionvalue_id = insertProductVariantOptionValue
        let optionValueIds = optionvalue_id.join(','); // Joins array elements into a string separated by commas

        console.log(optionvalue_id, "optionvalue_id-----------------------------------------------+=======")  //! all ids needed of table productvariantoptionvalue insertation
        let ImageGalleryID = addImages[0];
        let insertProductImagesQuery = 'INSERT INTO productimage (OptionValueID, ImageGalleryID, MainImage,optionValueIds,ProductID) VALUES(?,?,?,?,?)';

        let insertProductImage = await connection.query(
          insertProductImagesQuery, {
          replacements: [optionvalue_id[0], ImageGalleryID, setMainImage, optionValueIds, ProductID],
          type: QueryTypes.INSERT,
          transaction,
        }
        );


        console.log(insertProductImage, "insertProductImageinsertProductImage")


        // return
        if (insertProductImage && insertProductImage.length > 0) {
          let getVendorStoreIDQuery = `SELECT * FROM vendorstore WHERE VendorID="${VendorID}" AND StoreName="${StoreName}" `;
          getVendorStoreID = await connection.query(getVendorStoreIDQuery, {
            type: QueryTypes.SELECT,
            transaction,
          });
          VendorStoreID = getVendorStoreID[0].VendorStoreID;
          console.log("VendorStoreID______" + VendorStoreID);
          //!  //!Insert into Product Variant Combination table starts here
          let queryToBulkInsertProductVariantCombination = `insert into productvariantcombination ( ProductID ,VendorStoreID ,OptionValueID,SKU,Price,AvailableInventory) values(?,?,?,?,?,?) `;
          insertProductVariantCombination = await connection.query(
            queryToBulkInsertProductVariantCombination, {
            replacements: [
              ProductID,
              VendorStoreID,
              OptionValueID,
              SKU,
              Price,
              AvailableInventory,
            ],
            type: QueryTypes.INSERT,
            transaction,
          }
          );

          let ProductVariantCombinationID = insertProductVariantCombination[0];
          console.log("ProductVariantCombinationID____" + ProductVariantCombinationID);

          if (insertProductVariantCombination) {
            //!Insert into Product Inventory table starts here
            let insertProductInventoryQuery = `insert into productinventory ( VendorStoreID  ,ProductVariantCombinationID  ,Inventory,UnitPrice,TotalPrice,Status) values(?,?,?,?,?,?)`;
            let insertProductInventory = await connection.query(
              insertProductInventoryQuery, {
              replacements: [
                VendorStoreID,
                ProductVariantCombinationID,
                Inventory,
                UnitPrice,
                TotalPrice,
                Status,
              ],
              type: QueryTypes.INSERT,
              transaction,
            }
            );
            if (insertProductInventoryQuery) {
              if (transaction) await transaction.commit(); //!final commit
              res.status(200).json({
                status: true,
                message: " Product Variant Details Added Successfully",
              });
            } else {
              if (transaction) await transaction.rollback();
              res.status(200).json({
                status: false,
                message: "Error while adding Product Inventory",
              });
              //!Insert into  Product Inventory table ends here
            }
          } else {
            if (transaction) await transaction.rollback();
            res.status(200).json({
              status: false,
              message: "Error while adding Product Variant Combination",
            });
          } //!Insert into Product Variant Combination table ends here
        } else {
          if (transaction) await transaction.rollback();
          res.status(200).json({
            status: false,
            message: "Error while adding Product Images",
          });
        }
      } else {
        if (transaction) await transaction.rollback();
        res.status(200).json({
          status: false,
          message: "Error while adding into Image Gallery",
        });
      }

      //!Insert into Product Images table ends here
    } else {
      if (transaction) await transaction.rollback();
      res.status(200).json({
        status: false,
        message: "Error while Product Variant Option",
      });
    }


  } catch (err) {
    if (transaction) await transaction.rollback();
    // next(err);
    console.log(err, "============");
    res.status(200).json({
      status: false,
      Product: {},
      error: err.message,
    });
  }
};



exports.getProductVariantOptionDropDownByProductIDNew = async (req, res, next) => {
  try {
    const queryResult = await connection.query(
      `SELECT pvo.ProductID, pvo.OptionID, pvo.OptionName, pov.OptionValue, pov.OptionValueID 
       FROM productvariantoption pvo
       LEFT JOIN productvariantoptionvalue pov ON pvo.OptionID = pov.OptionID
       WHERE pvo.ProductID = ?`, {
      replacements: [req.params.id],
      type: QueryTypes.SELECT,
    }
    );


    // return res.send(queryResult)
    if (queryResult && queryResult.length > 0) {
      // Group by OptionID to format the response
      const groupedResult = {};
      queryResult.forEach(record => {
        if (!groupedResult[record.OptionID]) {
          groupedResult[record.OptionID] = {
            OptionID: record.OptionID,
            OptionName: record.OptionName,
            ProductID: record.ProductID,
            Values: []
          };
        }
        groupedResult[record.OptionID].Values.push({
          OptionValue: record.OptionValue,
          OptionValueID: record.OptionValueID
        });
      });

      res.status(200).json({
        status: true,
        ProductVariantOptions: Object.values(groupedResult),
      });
    } else {
      res.status(200).json({
        status: false,
        ProductVariantOptions: [],
      });
    }
  } catch (err) {
    next(err);
    res.status(200).json({
      status: false,
      error: err.message,
    });
  }
};



exports.getProductVariantOptionDropDownByProductID = async (req, res, next) => {
  try {
    let getProductVariantOptionName = await connection.query(
      `SELECT * 
       FROM productvariantoption WHERE ProductID="${req.params.id}"    `, {
      type: QueryTypes.SELECT,
    }
    );
    if (getProductVariantOptionName && getProductVariantOptionName.length > 0) {
      res.status(200).json({
        status: true,
        ProductVariantOptionName: getProductVariantOptionName,
      });
    } else {
      res.status(200).json({
        status: false,
        ProductVariantOptionName: [],
      });
    }
  } catch (err) {
    next(err);
    res.status(200).json({
      status: false,
      SubCategoryVariant: {},
      error: err.message,
    });
  }
};

exports.getProductVariantsDetailsByProductId = async (req, res, next) => {
  try {
    let viewProductVariantDetailsQuery = `SELECT o.OptionName AS VariantName, v.OptionValue AS VariantValue,g.Small,g.Medium,g.Large,c.SKU,c.Price,c.AvailableInventory,p.Inventory,p.UnitPrice,p.TotalPrice,p.Status,i.MainImage
    FROM ((((( productvariantoption o 
    INNER JOIN productvariantoptionvalue v  ON  v.OptionID IN (o.OptionID))  
    INNER JOIN productimage i  ON  i.OptionValueID IN (v.OptionValueID))
    INNER JOIN imagegallery g  ON  g.ImageGalleryID IN (i.ImageGalleryID))
    INNER JOIN  productvariantcombination c  ON  c.OptionValueID IN (v.OptionValueID))
    INNER JOIN  productinventory p  ON  p.ProductVariantCombinationID IN (c.ProductVariantCombinationID))
    WHERE  o.ProductID=${req.params.id} ORDER BY o.OptionName DESC`;

    let viewProductVariantDetails = await connection.query(
      viewProductVariantDetailsQuery, {
      type: QueryTypes.SELECT,
    }
    );
    if (viewProductVariantDetails && viewProductVariantDetails.length > 0) {
      res.status(200).json({
        status: true,
        ProductVariants: viewProductVariantDetails,
      });
    } else {
      res.status(200).json({
        status: false,
        message: "No Product Variants found",
        ProductVariants: [],
      });
    }
  } catch (err) {
    next(err);
    res.status(200).json({
      status: false,
      ProductVariants: {},
      error: err.message,
    });
  }
};
exports.getProductVariantsDetailsByOptionId = async (req, res, next) => {
  try {
    let viewProductVariantDetailsQuery = `SELECT o.OptionName AS VariantName, v.OptionValue AS VariantValue,v.OptionValueID,g.Small,g.Medium,g.Large,c.SKU,c.Price,c.AvailableInventory,p.Inventory,p.UnitPrice,p.TotalPrice,p.Status,i.MainImage
    FROM ((((( productvariantoption o 
    INNER JOIN productvariantoptionvalue v  ON  v.OptionID IN (o.OptionID))  
    INNER JOIN productimage i  ON  i.OptionValueID IN (v.OptionValueID))
    INNER JOIN imagegallery g  ON  g.ImageGalleryID IN (i.ImageGalleryID))
    INNER JOIN  productvariantcombination c  ON  c.OptionValueID IN (v.OptionValueID))
    INNER JOIN  productinventory p  ON  p.ProductVariantCombinationID IN (c.ProductVariantCombinationID))
    WHERE  o.OptionID=${req.params.id} 
    ORDER BY o.OptionName DESC`;

    let viewProductVariantDetails = await connection.query(
      viewProductVariantDetailsQuery, {
      type: QueryTypes.SELECT,
    }
    );
    if (viewProductVariantDetails && viewProductVariantDetails.length > 0) {
      res.status(200).json({
        status: true,
        ProductVariants: viewProductVariantDetails,
      });
    } else {
      res.status(200).json({
        status: false,
        message: "No Product Variants found",
        ProductVariants: [],
      });
    }
  } catch (err) {
    next(err);
    res.status(200).json({
      status: false,
      ProductVariants: {},
      error: err.message,
    });
  }
};
exports.updateProductDetailsForm2 = async (req, res, next) => {
  let transaction; //!transaction variable declare here
  try {
    const {
      OptionValue,
      SKU,
      Price,
      AvailableInventory,
      Inventory,
      UnitPrice,
      TotalPrice,
      Status,
      MainImage,
      variantionValues,
      ProductID,
      ProductImageID

    } = req.body;
    console.log(req.body, "req")
    console.log(JSON.parse(variantionValues))

    const allVariants = JSON.parse(variantionValues)
    let tmp;

    for (let variant of allVariants) {
      let { OptionValueID, VariantValue } = variant;
      console.log(OptionValueID, VariantValue, "----------------------")
      tmp = OptionValueID
      // return
      // Using parameterized query for safety against SQL injection
      let updateProductVariantOptionValueQuery = `UPDATE productvariantoptionvalue SET OptionValue=? WHERE OptionValueID=?`;

      let updateProductVariantOptionValue = await connection.query(
        updateProductVariantOptionValueQuery, {
        replacements: [VariantValue, OptionValueID],
        transaction,
        type: QueryTypes.UPDATE
      });
    }

    const allFiles = req.files

    const allImagesFiles = [];

    for (let i = 0; i < allFiles.length - 1; i += 3) {
      const group = allFiles.slice(i, i + 3);
      allImagesFiles.push(group);
    }
    const lastElement = allFiles[allFiles.length - 1];

    if (lastElement && lastElement.fieldname == 'video') {
      console.log("IMAGE FOUND")
    }
    // return
    transaction = await connection.transaction(); //!transaction use here
    let LastUpdate = new Date().toISOString().slice(0, 19).replace("T", " ");


    console.log("allImagesFiles", allImagesFiles);

    function determinePath(reqFiles, type) {
      if (reqFiles[type] && reqFiles[type].length > 0) {
        return reqFiles[type][0].path;
      }
      return null;
    }

    const insertedIds = [];

    const UserID = req.UserID

    console.log('uset===============', UserID)

    if (allImagesFiles.length > 0) {
      for (const group of allImagesFiles) {
        // Assuming each group is an array with [Large, Medium, Small] ordered objects
        const SmallPath = group[2].path;
        const MediumPath = group[1].path;
        const LargePath = group[0].path;

        // If these paths come from a request and there's a possibility they might not be present:
        Small = determinePath(req.files, 'Small') || SmallPath;
        Medium = determinePath(req.files, 'Medium') || MediumPath;
        Large = determinePath(req.files, 'Large') || LargePath;

        // Log the paths
        console.log(Small);
        console.log(Medium);
        console.log(Large);


        //!multiple
        let insertImageGalleryQuery = `INSERT INTO imagegallery (UserID, Small, Medium, Large) VALUES (?, ?, ?, ?)`;
        let result = await connection.query(
          insertImageGalleryQuery, {
          replacements: [UserID, Small, Medium, Large],
          transaction,
        });

        // Retrieve the inserted ID
        const insertedId = result[0];  // Adjust this line as per the structure of the result
        insertedIds.push(insertedId);
      }
    }

    if (insertedIds.length > 0) {


      let placeholders = [];
      let replacements = [];

      for (let i = 0; i < insertedIds.length; i++) {
        placeholders.push('(?, ?, ?, ?, ?)');
        replacements.push(insertedIds[i], tmp, req.params.id, 'N', ProductID);
      }
      //!2
      console.log("replacements", replacements);
      let insertProductImageBulkQuery = `INSERT INTO productimage (ImageGalleryID,OptionValueID, optionValueIds, MainImage, ProductID) VALUES ${placeholders.join(', ')}`;

      await connection.query(
        insertProductImageBulkQuery, {
        replacements: replacements,
        type: QueryTypes.INSERT,
        transaction,
      });
    }

    if (ProductImageID) {
      let setPreviousMainImageQuery = `UPDATE productimage SET MainImage="N"  WHERE ProductID=?`;
      let setPreviousMainImage = await connection.query(
        setPreviousMainImageQuery, {
        replacements: [ProductID],
        transaction,
      }
      )

      let updateMainImageQuery = `UPDATE productimage SET MainImage="Y"  WHERE ProductImageID=?`;
      let updateMainImage = await connection.query(
        updateMainImageQuery, {
        replacements: [ProductImageID],
        transaction,
      }
      )

    }


    let updateProductVariantCombinationQuery = `UPDATE productvariantcombination SET SKU=?, Price=?, AvailableInventory=?, LastUpdate=?`;
    let replacements = [SKU, Price, AvailableInventory, LastUpdate];


    if (lastElement && lastElement.fieldname === 'video') {
      console.log("VIDEO FOUND");

      // If there's a video file, extend the query to also update the video column
      updateProductVariantCombinationQuery += `, video=?`;
      replacements.push(lastElement.path); // Assuming path of the video is stored in 'path' property
    }
    updateProductVariantCombinationQuery += ` WHERE OptionValueID = ?`;
    replacements.push(req.params.id);

    // Now execute the query
    let updateProductVariantCombination = await connection.query(
      updateProductVariantCombinationQuery, {
      replacements: replacements,
      transaction,
    }
    );

    let getProductVariantCombinationID = await connection.query(
      `SELECT * FROM productvariantcombination WHERE OptionValueID="${req.params.id}" `, {
      type: QueryTypes.SELECT,
      transaction,
    }
    );
    let ProductVariantCombinationID =
      getProductVariantCombinationID[0].ProductVariantCombinationID;
    console.log("ProductVariantCombinationID", ProductVariantCombinationID)


    let updateProductInventoryQuery = `UPDATE productinventory SET Inventory=?,UnitPrice=?,TotalPrice=?,Status=? WHERE ProductVariantCombinationID  = "${ProductVariantCombinationID}"  `;
    updateProductInventoryQuery = await connection.query(
      updateProductInventoryQuery, {
      replacements: [Inventory, UnitPrice, TotalPrice, Status],

      transaction,
    }
    );

    if (updateProductInventoryQuery) {
      if (transaction) await transaction.commit(); //!final commit
      res.json({
        status: true,
        message: " Product Variant Details Updated Successfully",
      });
    }
    else {
      if (transaction) await transaction.rollback();
      res.json({
        status: false,
        message: "Error while updating Product Inventory",
      });
      //!Insert into  Product Inventory table ends here
    }

  } catch (err) {
    console.log(err);
    if (transaction) await transaction.rollback();
    next(err);
    res.status(200).json({
      status: false,
      Product: {},
      error: err.message,
    });
  }
};

//delete combination
//delete its variants
// exports.deleteProductVariantOptionValueById = async (req, res, next) => {
//   let transaction; //!transaction variable declare here
//   try {
//     const OptionValueID = req.params.id;
//     console.log(OptionValueID);
//     let ProductVariantCombinationID;
//     let ImageGalleryID;

//     transaction = await connection.transaction(); //!transaction use here
//     let checkProductVariantOptionValueExists = await connection.query(
//       `select * from productvariantoptionvalue where OptionValueID = "${OptionValueID}" `, {
//       type: QueryTypes.SELECT,
//     }
//     );
//     if (
//       checkProductVariantOptionValueExists &&
//       checkProductVariantOptionValueExists.length > 0
//     ) {
//       //!DELETE Product Inventory starts here
//       let getProductInventoryID = await connection.query(
//         `select * from productvariantcombination where OptionValueID = "${OptionValueID}" `, {
//         type: QueryTypes.SELECT,
//       }
//       );
//       ProductVariantCombinationID =
//         getProductInventoryID[0].ProductVariantCombinationID;
//       let deleteProductInventoryQuery = await connection.query(
//         `DELETE FROM productinventory WHERE ProductVariantCombinationID="${ProductVariantCombinationID}" `
//       );
//       if (deleteProductInventoryQuery) {
//         //!DELETE Product Varint Combination starts here
//         let deleteProductVariantCombination = await connection.query(
//           `DELETE from productvariantcombination where OptionValueID = "${OptionValueID}" `
//         );
//         if (deleteProductVariantCombination) {
//           //!DELETE Image Gallery starts here
//           let getImageGalleryID = await connection.query(
//             `select * from productimage where OptionValueID = "${OptionValueID}" `, {
//             type: QueryTypes.SELECT,
//           }
//           );
//           ImageGalleryID = getImageGalleryID[0].ImageGalleryID;
//           let deleteProductImage = await connection.query(
//             `DELETE from productimage where  OptionValueID= "${OptionValueID}" `
//           );
//           if (deleteProductImage) {
//             // fs.unlinkSync(`images/${ "./public/imageGallery"}/${req.params.id}.png`);
//             let deleteImageGallery = await connection.query(
//               `DELETE from imagegallery where ImageGalleryID = "${ImageGalleryID}" `
//             );
//             if (deleteImageGallery) {
//               let deleteProductVariantOptionValue = await connection.query(
//                 `DELETE FROM productvariantoptionvalue WHERE OptionValueID="${OptionValueID}" `
//               );
//               if (deleteProductVariantOptionValue) {
//                 if (transaction) await transaction.commit(); //!final commit
//                 res.status(200).json({
//                   status: true,
//                   message: "Product Variant Option Value deleted Successfully",
//                 });
//               } else {
//                 if (transaction) await transaction.rollback();
//                 res.status(200).json({
//                   status: false,
//                   message: "Error while deleting Product Variant Option Value",
//                   ProductVariantOptionValue: [],
//                 });
//               }
//             } else {
//               if (transaction) await transaction.rollback();
//               res.status(200).json({
//                 status: false,
//                 message: "Error while deleting Image Gallery",
//                 ProductVariantOptionValue: [],
//               });
//             }
//           } else {
//             if (transaction) await transaction.rollback();
//             res.status(200).json({
//               status: false,
//               message: "Error while deleting Product Images",
//               ProductVariantOptionValue: [],
//             });
//           }
//         } else {
//           if (transaction) await transaction.rollback();
//           res.status(200).json({
//             status: false,
//             message: "Error while deleting Product Variant Combination",
//             ProductVariantOptionValue: [],
//           });
//         }
//       } else {
//         if (transaction) await transaction.rollback();
//         res.status(200).json({
//           status: false,
//           message: "Error while deleting Product Inventory",
//           ProductVariantOptionValue: [],
//         });
//       }
//     } else {
//       if (transaction) await transaction.rollback();
//       res.status(200).json({
//         status: false,
//         message: `Product Variant Option Value does not exist`,
//         ProductVariantOptionValue: [],
//       });
//     }
//   } catch (err) {
//     if (transaction) await transaction.rollback();
//     next(err);
//     res.status(200).json({
//       status: false,
//       Product: {},
//       error: err.message,
//     });
//   }
// };
exports.deleteProductVariantOptionValueById = async (req, res, next) => {
  let transaction; //!transaction variable declare here
  try {
    const variant = req.body.variant

    console.log(variant, '---------------------------');
    // return


    return

    transaction = await connection.transaction(); //!transaction use here

    exports.deleteProductVariantOptionValueById = async (req, res, next) => {
      let transaction;

      try {
        const variants = req.body.variant;
        transaction = await connection.transaction();

        for (let variant of variants) {
          const OptionValueID = variant.OptionValueID;
          const combinationID = variant.ProductVariantCombinationID;

          let checkProductVariantOptionValueExists = await connection.query(
            `select * from productvariantoptionvalue where OptionValueID = "${OptionValueID}" `,
            { type: QueryTypes.SELECT }
          );

          if (checkProductVariantOptionValueExists.length > 0) {

            //!DELETE from productvariantoptionvalue using OptionValueID
            await connection.query(`DELETE FROM productvariantoptionvalue WHERE OptionValueID="${OptionValueID}"`);

            //!DELETE from productinventory using combinationID
            await connection.query(`DELETE FROM productinventory WHERE ProductVariantCombinationID="${combinationID}"`);


            //!DELETE from productvariantcombination using OptionValueID
            await connection.query(`DELETE from productvariantcombination where OptionValueID = "${OptionValueID}"`);

            //!DELETE from productvariantcombination using combinationID
            await connection.query(`DELETE from productvariantcombination where ProductVariantCombinationID = "${combinationID}"`);



            //!DELETE Image Gallery starts here
            let getImageGalleryID = await connection.query(`select * from productimage where OptionValueID = "${OptionValueID}"`, { type: QueryTypes.SELECT });
            let ImageGalleryID = getImageGalleryID[0].ImageGalleryID;

            //!DELETE from productimage using OptionValueID
            await connection.query(`DELETE from productimage where OptionValueID= "${OptionValueID}"`);

            //!DELETE from imagegallery using ImageGalleryID
            await connection.query(`DELETE from imagegallery where ImageGalleryID = "${ImageGalleryID}"`);


          } else {
            if (transaction) await transaction.rollback();
            return res.status(200).json({
              status: false,
              message: `Product Variant Option Value with OptionValueID ${OptionValueID} does not exist`,
              ProductVariantOptionValue: [],
            });
          }
        }

        if (transaction) await transaction.commit();
        res.status(200).json({
          status: true,
          message: "Product Variant Option Values deleted Successfully",
        });

      } catch (err) {
        if (transaction) await transaction.rollback();
        next(err);
        res.status(200).json({
          status: false,
          Product: {},
          error: err.message,
        });
      }
    };


    let checkProductVariantOptionValueExists = await connection.query(
      `select * from productvariantoptionvalue where OptionValueID = "${OptionValueID}" `, {
      type: QueryTypes.SELECT,
    }
    );
    if (
      checkProductVariantOptionValueExists &&
      checkProductVariantOptionValueExists.length > 0
    ) {
      //!DELETE Product Inventory starts here
      let getProductInventoryID = await connection.query(
        `select * from productvariantcombination where OptionValueID = "${OptionValueID}" `, {
        type: QueryTypes.SELECT,
      }
      );
      ProductVariantCombinationID =
        getProductInventoryID[0].ProductVariantCombinationID;
      let deleteProductInventoryQuery = await connection.query(
        `DELETE FROM productinventory WHERE ProductVariantCombinationID="${ProductVariantCombinationID}" `
      );
      if (deleteProductInventoryQuery) {
        //!DELETE Product Varint Combination starts here
        let deleteProductVariantCombination = await connection.query(
          `DELETE from productvariantcombination where OptionValueID = "${OptionValueID}" `
        );
        if (deleteProductVariantCombination) {
          //!DELETE Image Gallery starts here
          let getImageGalleryID = await connection.query(
            `select * from productimage where OptionValueID = "${OptionValueID}" `, {
            type: QueryTypes.SELECT,
          }
          );
          ImageGalleryID = getImageGalleryID[0].ImageGalleryID;
          let deleteProductImage = await connection.query(
            `DELETE from productimage where  OptionValueID= "${OptionValueID}" `
          );
          if (deleteProductImage) {
            // fs.unlinkSync(`images/${ "./public/imageGallery"}/${req.params.id}.png`);
            let deleteImageGallery = await connection.query(
              `DELETE from imagegallery where ImageGalleryID = "${ImageGalleryID}" `
            );
            if (deleteImageGallery) {
              let deleteProductVariantOptionValue = await connection.query(
                `DELETE FROM productvariantoptionvalue WHERE OptionValueID="${OptionValueID}" `
              );
              if (deleteProductVariantOptionValue) {
                if (transaction) await transaction.commit(); //!final commit
                res.status(200).json({
                  status: true,
                  message: "Product Variant Option Value deleted Successfully",
                });
              } else {
                if (transaction) await transaction.rollback();
                res.status(200).json({
                  status: false,
                  message: "Error while deleting Product Variant Option Value",
                  ProductVariantOptionValue: [],
                });
              }
            } else {
              if (transaction) await transaction.rollback();
              res.status(200).json({
                status: false,
                message: "Error while deleting Image Gallery",
                ProductVariantOptionValue: [],
              });
            }
          } else {
            if (transaction) await transaction.rollback();
            res.status(200).json({
              status: false,
              message: "Error while deleting Product Images",
              ProductVariantOptionValue: [],
            });
          }
        } else {
          if (transaction) await transaction.rollback();
          res.status(200).json({
            status: false,
            message: "Error while deleting Product Variant Combination",
            ProductVariantOptionValue: [],
          });
        }
      } else {
        if (transaction) await transaction.rollback();
        res.status(200).json({
          status: false,
          message: "Error while deleting Product Inventory",
          ProductVariantOptionValue: [],
        });
      }
    } else {
      if (transaction) await transaction.rollback();
      res.status(200).json({
        status: false,
        message: `Product Variant Option Value does not exist`,
        ProductVariantOptionValue: [],
      });
    }
  } catch (err) {
    if (transaction) await transaction.rollback();
    next(err);
    res.status(200).json({
      status: false,
      Product: {},
      error: err.message,
    });
  }
};
//! Product All Details Api
exports.getProductAllDetailsByProductId = async (req, res, next) => {
  try {
    // let Region = req.region || "US";

    // const currencyRate = req.currency_rate

    const Region = req.region;
    const getCurrencyRates = req.getCurrencyRates;
    let currencyRate;

    console.log("Region------->", Region)
    console.log("getCurrencyRates------->", getCurrencyRates)

    let currentUserID = req.params.UserID;

    let inWishList = false;
    if (
      currentUserID !== null ||
      currentUserID !== undefined ||
      currentUserID !== ""
    ) {
      let checkIfProductExists = await connection.query(
        `SELECT * FROM product WHERE ProductID="${req.params.id}"`, {
        type: QueryTypes.SELECT,
      }
      );
      if (checkIfProductExists && checkIfProductExists.length > 0) {
        let viewProductDetailQuery = `SELECT v.*, p.*, s.SubCategory, e.Category, e.ExpressDelivery, e.CategoryID, 
       t.City AS ProductCity, t.Native AS CityNative, y.country AS ProductCountry, 
       p.*, o.OptionName AS VariantName, o.OptionID, u.OptionValueID AS SingleOptionValueID, u.OptionValueID,
       u.OptionValue AS VariantValue, g.Small, g.Medium, g.Large, a.SKU, 
       a.Price AS VariantPrice, a.AvailableInventory, n.Inventory, n.UnitPrice, 
       n.TotalPrice, a.OptionValueID, n.Status, i.MainImage, a.ProductVariantCombinationID,a.video
FROM vendor v
LEFT JOIN product p ON p.VendorID = v.VendorID
LEFT JOIN subcategory s ON s.SubCategoryID = p.SubCategoryID
LEFT JOIN category e ON e.CategoryID = s.CategoryID
LEFT JOIN productcity c ON c.ProductID = p.ProductID
LEFT JOIN city t ON t.CityID = c.CityID
LEFT JOIN productcountry r ON r.ProductID = p.ProductID
LEFT JOIN country y ON y.CountryID = r.CountryID
LEFT JOIN productvariantoption o ON o.ProductID = p.ProductID
LEFT JOIN productvariantoptionvalue u ON u.OptionID = o.OptionID
LEFT JOIN productimage i ON i.OptionValueID = u.OptionValueID
LEFT JOIN imagegallery g ON g.ImageGalleryID = i.ImageGalleryID
LEFT JOIN productvariantcombination a ON a.ProductID = p.ProductID
LEFT JOIN productinventory n ON n.ProductVariantCombinationID = a.ProductVariantCombinationID
WHERE p.ProductID = ${req.params.id} AND FIND_IN_SET(u.OptionValueID, a.OptionValueID) > 0
ORDER BY p.ProductID DESC
`;

        let viewProductDetail = await connection.query(viewProductDetailQuery, {
          type: QueryTypes.SELECT,
        });

        const objects = viewProductDetail

        const transformObjectsToOutput = async (inputObjects) => {
          const groupedData = {};

          for (const obj of inputObjects) {
            const id = obj["ProductVariantCombinationID"];

            if (!groupedData[id]) {

              //!1
              const getImageQuery = `
                SELECT *
                FROM productimage
                JOIN imagegallery ON productimage.ImageGalleryID = imagegallery.ImageGalleryID
                WHERE optionValueIds = :optionValueId;
            `;

              const imageData = await connection.query(getImageQuery, {
                type: QueryTypes.SELECT,
                replacements: { optionValueId: obj["OptionValueID"] }
              });

              // Assuming you want to add the imageData to the groupedData object
              obj["imageData"] = imageData;

              // Create base data structure if not exists
              groupedData[id] = {
                "VariantName": obj["VariantName"],
                "OptionID": obj["OptionID"],
                "video": obj["video"],
                "OptionValueID": obj["OptionValueID"],
                "VariantValue": obj["VariantValue"],
                "Small": obj["Small"],
                "Medium": obj["Medium"],
                "Large": obj["Large"],
                "SKU": obj["SKU"],
                "AvailableInventory": obj["AvailableInventory"],
                "VariantPrice": obj["VariantPrice"],
                "Inventory": obj["Inventory"],
                "UnitPrice": obj["UnitPrice"],
                "TotalPrice": obj["TotalPrice"],
                "Status": obj["Status"],
                "MainImage": obj["MainImage"],
                "ProductVariantCombinationID": obj["ProductVariantCombinationID"],
                "Currency": obj["Currency"],
                "variantionValues": [],
                "Images": imageData
              };
            }

            // Check if the variantionValue with the same OptionValueID already exists
            const variantValueExists = groupedData[id].variantionValues.some(v => v.OptionValueID === obj["SingleOptionValueID"]);

            // If not, push the new variantionValue to the grouped object
            if (!variantValueExists) {

              groupedData[id].variantionValues.push({
                "VariantName": obj["VariantName"],
                "OptionID": obj["OptionID"],
                "VariantValue": obj["VariantValue"],
                "OptionValueID": obj["SingleOptionValueID"],
              });
            }
          };

          return groupedData;
        };


        // Test
        const output = await transformObjectsToOutput(objects);

        let variantResult = Object.values(output);

        // Function to rearrange the Images array
        // Find the index of the object with MainImage: "Y"
        const mainImageIndex = variantResult.findIndex(variant => {
          return variant.Images.some(image => image.MainImage === 'Y');
        });

        // If an object with MainImage: "Y" is found, move it to the first index
        if (mainImageIndex !== -1) {
          const mainImageVariant = variantResult.splice(mainImageIndex, 1)[0];
          variantResult.unshift(mainImageVariant);
        }

        // // Function to find images with MainImage: "Y"
        // async function findMainImages(variantDetails) {
        //   const mainImages = [];

        //   variantDetails.forEach(variant => {
        //     const images = variant.Images.filter(image => image.MainImage === "Y");
        //     mainImages.push(...images);
        //   });

        //   return mainImages;
        // }

        // // Finding images with MainImage: "Y"
        // const imagesWithMainY = await findMainImages(variantResult);

        async function extractOptionValues(variantDetailsArray) {
          const extractedValues = [];

          variantDetailsArray.forEach(variant => {
            const { OptionValueID, variantionValues } = variant;

            // Extract OptionValueID
            const optionValueIDs = OptionValueID.split(',').map(value => parseInt(value));

            // Extract values inside variantionValues
            const values = variantionValues.map(value => ({
              VariantName: value.VariantName,
              OptionValueID: value.OptionValueID,
              VariantValue: value.VariantValue,
            }));

            extractedValues.push({
              OptionValueID: optionValueIDs,
              values: values
            });
          });

          return extractedValues;
        }

        // Extracting OptionValueID and values inside variantionValues
        let result = await extractOptionValues(variantResult);

        /*---------------- main image part ------------------------

        async function extractOptionValues(variantDetailsArray) {
          const extractedValues = [];

          variantDetailsArray.forEach(variant => {
            const { OptionValueID, variantionValues, Images } = variant;

            // Extract OptionValueID
            const optionValueIDs = OptionValueID.split(',').map(value => parseInt(value));

            // Extract values inside variantionValues
            const values = variantionValues.map(value => ({
              VariantName: value.VariantName,
              OptionValueID: value.OptionValueID,
              VariantValue: value.VariantValue,
            }));

            // Extract Images with MainImage: "Y" and matching OptionValueID
            const mainImages = Images.filter(image => image.MainImage === "Y" && optionValueIDs.includes(image.OptionValueID));

            console.log("mainImages ------------->", mainImages)

            const Main_Image = mainImages.map(obj => obj.MainImage);

            extractedValues.push({
              OptionValueID: optionValueIDs,
              values: values,
              mainImages: Main_Image[0] // Adding mainImages as a property
            });
          });

          return extractedValues;
        }

        // Extracting OptionValueID, values inside variantionValues, and mainImages
        let result = await extractOptionValues(variantResult);

          main image ------ */

        // Mapping through the data and modifying the structure
        let modifiedData = result.map(item => {
          item.values.forEach(value => {
            value.OptionValueIDs = item.OptionValueID.join(',');
          });
          return item;
        });

        let extractedValues = result.map(item => item.values);

        /* ----------------------- main image part
        let extractedValues = result.map(item => {
          let values = item.values;
          if (item.mainImages) {
            values = values.map(value => {
              return {
                ...value,
                mainImages: item.mainImages
              };
            });
          }
          return values;
        });
        //  -------------- main image ------ */
        // Grouping by VariantName
        const groupedByVariantName = extractedValues.flat().reduce((acc, item) => {
          const { VariantName } = item;
          acc[VariantName] = acc[VariantName] || [];
          acc[VariantName].push(item);
          return acc;
        }, {});

        /* --------------------- main image part
        // Function to find OptionValueID from the first key with mainImages: 'Y'
        async function findOptionValueIDWithMainImage(data) {
          const keys = Object.keys(data);
          for (const key of keys) {
            const groupData = data[key];
            const objectWithMainImage = groupData.find(obj => obj.mainImages === 'Y');
            if (objectWithMainImage) {
              return objectWithMainImage.OptionValueID;
            }
          }
          return null; // If no object with mainImages: 'Y' is found in any key
        }

        // Retrieving OptionValueID from the first key with mainImages: 'Y'
        const optionValueID = await findOptionValueIDWithMainImage(groupedByVariantName);

        console.log("optionValueID---------->", optionValueID)


        // main image ------ */

        const values = variantResult.map((item) => item.variantionValues.map((item) => item));

        const options = values.reduce((acc, curr) => acc.concat(curr), []);

        // Group by 'VariantName' and filter duplicates by 'OptionValueID'
        let grouped = options.reduce((acc, curr) => {
          if (!acc[curr.VariantName]) {
            acc[curr.VariantName] = [];
          }

          if (!acc[curr.VariantName].some(item => item.OptionValueID === curr.OptionValueID)) {
            acc[curr.VariantName].push(curr);
          }

          return acc;
        }, {});



        // Adding isdisabled property with value false to each object
        Object.keys(grouped).forEach(key => {
          grouped[key] = grouped[key].map(obj => ({
            ...obj,
            isdisabled: false
          }));
        });

        // Get OptionValueID from the first array element of the first key
        const firstKey = Object.keys(grouped)[0]; // Get the first key in the object
        const firstOptionValueID = grouped[firstKey][0].OptionValueID;
        async function updateVariantOption(obj, optionValueId) {
          console.log("optionValueId________________________________", optionValueId);
          const keys = Object.keys(obj);
          let firstKey = true;
          for (const key of keys) {
            if (firstKey) {
              // Setting isdisabled to false for the first key
              obj[key].forEach(variant => {
                variant.isdisabled = false;
              });
              firstKey = false;
              continue; // Move to the next key
            }

            const variantsArray = obj[key];

            if (variantsArray) {
              variantsArray.forEach(variant => {
                const optionIds = variant.OptionValueIDs.split(',').map(id => parseInt(id));
                if (optionIds.includes(optionValueId)) {
                  variant.isdisabled = false;
                } else {
                  variant.isdisabled = true;
                }
              });
            }
          }

          return obj;
        }

        const updatedObject = await updateVariantOption(groupedByVariantName, firstOptionValueID);

        // this is working fine 
        const removeDuplicatesPreserveFalse = async (arr) => {
          const uniqueValues = new Map();

          arr.forEach((item) => {
            if (!uniqueValues.has(item.OptionValueID)) {
              uniqueValues.set(item.OptionValueID, item);
            } else if (item.isdisabled === false) {
              uniqueValues.set(item.OptionValueID, item);
            }
          });

          return Array.from(uniqueValues.values());
        };

        for (const key in updatedObject) {
          if (updatedObject.hasOwnProperty(key)) {
            updatedObject[key] = await removeDuplicatesPreserveFalse(updatedObject[key]);
          }
        }

        /* ------------------

        const removeDuplicatesPreserveFalse = async (arr) => {
          const uniqueValues = new Map();

          arr.forEach((item) => {
            if (!uniqueValues.has(item.OptionValueID)) {
              uniqueValues.set(item.OptionValueID, item);
            } else if (item.isdisabled === false && item.mainImages) {
              uniqueValues.set(item.OptionValueID, item);
            }
          });

          return Array.from(uniqueValues.values());
        };

        for (const key in updatedObject) {
          if (updatedObject.hasOwnProperty(key)) {
            updatedObject[key] = await removeDuplicatesPreserveFalse(updatedObject[key]);
          }
        }
        // ------------------ main image part -------- */
        let storeProductReviewCount = [];
        let storeIndiviudalRatingCount = [];
        let BuisnessDetail = {};
        let ProductDetail = {};
        let VariantValues = [];
        let tempVariantDetails = [];
        var Main_Image = "";
        let variantNames = [];
        let {
          ProductID,
          VendorID,
          SubCategoryID,
          SubCategory,
          ExpressDelivery,
          CategoryID,
          Category,
          Title,
          StoreName,
          Description,
          SpecialInstruction,
          ReturnPolicy,
          Currency,
          CostPrice,
          Price,
          Quantity1,
          PriceQuantity1,
          Quantity2,
          PriceQuantity2,
          Quantity3,
          PriceQuantity3,
          PromotionPrice,
          PromotionRate,
          PromotionStartDate,
          PromotionEndDate,
          Weight,
          Height,
          Length,
          Width,
          AllowStorePickup,
          ShippingAvailable,
          ShippingGlobal,
          ShippingByAdmin,
          ShippingByVendor,
          ShippingCostAdmin,
          ShippingCostVendor,
          ReviewedByAdmin,
          TaxVATApply,
          LockEdit,
          Active,
          LastUpdate,
          AdminNote,
          ProductCity,
          CityNative,
          ProductCountry,
        } = viewProductDetail[0];


        ProductDetail = {
          ProductID,
          VendorID,
          SubCategoryID,
          SubCategory,
          ExpressDelivery,
          CategoryID,
          Category,
          Title,
          StoreName,
          Description,
          SpecialInstruction,
          ReturnPolicy,
          Currency,
          CostPrice,
          Price,
          Quantity1,
          PriceQuantity1,
          Quantity2,
          PriceQuantity2,
          Quantity3,
          PriceQuantity3,
          PromotionPrice,
          PromotionRate,
          PromotionStartDate,
          PromotionEndDate,
          Weight,
          Height,
          Length,
          Width,
          AllowStorePickup,
          ShippingAvailable,
          ShippingGlobal,
          ShippingByAdmin,
          ShippingByVendor,
          ShippingCostAdmin,
          ShippingCostVendor,
          ReviewedByAdmin,
          TaxVATApply,
          LockEdit,
          Active,
          LastUpdate,
          AdminNote,
          ProductCity,
          CityNative,
          ProductCountry,
        };

        let {
          CompanyName,
          TaxID,
          TaxIDPic,
          GovernmentID,
          GovernmentIDPic,
          CompanyLogo,
          BannerImage,
          Address1,
          Address2,
          CityID,
          City,
          State,
          ZipCode,
          GoogleMapID,
          CountryID,
          PaymentAccount,
          PaymentRouting,
          BusinessEmail,
          BusinessPhone,
          EmailVerified,
          PhoneVerified,
          BusinessURL,
          PageURL,
          ReviewedBySuperAdmin,
          GatewayID,
          AllowDelivery,
          ProductApproval,
          CreatedDate,
          About,
          Policies,
        } = viewProductDetail[0];
        BuisnessDetail = {
          VendorID,
          CompanyName,
          TaxID,
          TaxIDPic,
          GovernmentID,
          GovernmentIDPic,
          CompanyLogo,
          BannerImage,
          Address1,
          Address2,
          CityID,
          City,
          State,
          ZipCode,
          GoogleMapID,
          CountryID,
          PaymentAccount,
          PaymentRouting,
          BusinessEmail,
          BusinessPhone,
          EmailVerified,
          PhoneVerified,
          BusinessURL,
          PageURL,
          ReviewedByAdmin,
          ReviewedBySuperAdmin,
          GatewayID,
          AllowDelivery,
          AllowStorePickup,
          ProductApproval,
          CreatedDate,
          LastUpdate,
          About,
          Policies,
          AdminNote,
        };

        const tmpObj = {};
        const tmpOptionValuesIds = [];

        for (let i = 0; i < viewProductDetail.length; i++) {
          let {
            VariantName,
            OptionID,
            OptionValueID,
            VariantValue,
            Small,
            Medium,
            Large,
            SKU,
            AvailableInventory,
            VariantPrice,
            Inventory,
            UnitPrice,
            TotalPrice,
            Status,
            MainImage,
            ProductVariantCombinationID,
            Currency,
            // optionValueIDs

          } = viewProductDetail[i];
          // if (viewProductDetail[i]?.optionValueIDs && !tmpObj[viewProductDetail[i]?.optionValueIDs]) {
          //   console.log("lenght============================================", viewProductDetail.length)

          //   tmpObj[viewProductDetail[i]?.optionValueIDs] = {
          //     VariantName,
          //     OptionID,
          //     OptionValueID,
          //     VariantValue,
          //     Small,
          //     Medium,
          //     Large,
          //     SKU,
          //     AvailableInventory,
          //     VariantPrice,
          //     Inventory,
          //     UnitPrice,
          //     TotalPrice,
          //     Status,
          //     MainImage,
          //     ProductVariantCombinationID,
          //     Currency,
          //     optionValueIDs
          //   }
          // }

        }

        //... (Your existing code above this)

        let t = []

        for (const key in tmpObj) {
          const ids = key.split(',').map(n => Number(n));
          t.push(ids)
        }
        const groupedMatchedObjects = {};

        for (let i = 0; i < viewProductDetail.length; i++) {
          const currentDetail = viewProductDetail[i];
          const {
            VariantName,
            OptionID,
            OptionValueID,
            VariantValue,
            Small,
            Medium,
            Large,
            SKU,
            AvailableInventory,
            VariantPrice,
            Inventory,
            UnitPrice,
            TotalPrice,
            Status,
            MainImage,
            ProductVariantCombinationID,
            Currency,
            // optionValueIDs
          } = currentDetail;

          const currentOptionValueID = currentDetail.OptionValueID;






          // for (let j = 0; j < t.length; j++) {



          //   const element = t[j];
          //   console.log("+++++++++++++++++++++++++000000+++++++>>>>>>>>>>>>", element);


          //   if (element.includes(currentOptionValueID)) {

          //     console.log("element.includes(currentOptionValueID))", element.includes(currentOptionValueID), element);
          //     const mergedObject = {
          //       ...tmpObj[element],
          //       VariantName,
          //       OptionID,
          //       OptionValueID,
          //       VariantValue,
          //       Small,
          //       Medium,
          //       Large,
          //       SKU,
          //       AvailableInventory,
          //       VariantPrice,
          //       Inventory,
          //       UnitPrice,
          //       TotalPrice,
          //       Status,
          //       MainImage,
          //       ProductVariantCombinationID,
          //       Currency,
          //       // optionValueIDs
          //     };

          //     if (!groupedMatchedObjects[element]) {
          //       groupedMatchedObjects[element] = [];
          //     }

          //     groupedMatchedObjects[element].push(mergedObject);
          //     break;

          //   }



          // }

          // for (const key in tmpObj) {
          //   const ids = key.split(',').map(n => Number(n));
          //   console.log("---------------------------------------------------------->", ids);
          //   if (ids.includes(currentOptionValueID)) {
          //     console.log("ids.includes(currentOptionValueID))", ids.includes(currentOptionValueID), ids);
          //     console.log();
          //     const mergedObject = {
          //       ...tmpObj[key],
          //       VariantName,
          //       OptionID,
          //       OptionValueID,
          //       VariantValue,
          //       Small,
          //       Medium,
          //       Large,
          //       SKU,
          //       AvailableInventory,
          //       VariantPrice,
          //       Inventory,
          //       UnitPrice,
          //       TotalPrice,
          //       Status,
          //       MainImage,
          //       ProductVariantCombinationID,
          //       Currency,
          //       optionValueIDs
          //     };

          //     if (!groupedMatchedObjects[key]) {
          //       groupedMatchedObjects[key] = [];
          //     }

          //     groupedMatchedObjects[key].push(mergedObject);
          //     break;
          //   }
          // }
        }

        for (let i = 0; i < viewProductDetail.length; i++) {
          if (!variantNames.includes(viewProductDetail[i].VariantName)) {
            variantNames.push(viewProductDetail[i].VariantName); //!combinationID
          }
        }

        for (let i = 0; i < variantNames.length; i++) {
          var obj = {
            Name: variantNames[i],
            Values: [],
          };
          let tempArray = [];
          for (let j = 0; j < viewProductDetail.length; j++) {
            let {
              VariantName,
              OptionID,
              OptionValueID,
              VariantValue,
              Small,
              Medium,
              Large,
              SKU,
              AvailableInventory,
              VariantPrice,
              Inventory,
              UnitPrice,
              TotalPrice,
              Status,
              MainImage,
              ProductVariantCombinationID,
              Currency,

            } = viewProductDetail[j];

            VariantValues[i] = {
              OptionID,
              OptionValueID,
              VariantValue,
              Small,
              Medium,
              Large,
              SKU,
              AvailableInventory,
              VariantPrice,
              Inventory,
              UnitPrice,
              TotalPrice,
              Status,
              MainImage,
              ProductVariantCombinationID,
              Currency,
            };
            if (VariantName === variantNames[i]) {
              tempArray.push(VariantValues[i]);
            }
            if (VariantValues[i].MainImage == "Y") {
              Main_Image = VariantValues[i].Large;
            }
          }
          obj.Values = tempArray;
          tempVariantDetails.push(obj);
          let variantsLength = tempVariantDetails[i].Values.length;
          let newVariantLength = variantResult.length

          let newArray;

          // this is the new change on variant result

          for (let j = 0; j < newVariantLength; j++) {

            console.log("variantResult[j].currency-----------------", variantResult[j].Currency)

            const fromCurrency = variantResult[j].Currency;
            console.log("fromCurrency", fromCurrency)
            const selectCurrency = getCurrencyRates.filter(item => item.FromCurrency === fromCurrency);
            currencyRate = selectCurrency.length ? selectCurrency[0].Rate : null;
            //   console.log("getCurrencyRates", getCurrencyRates)
            console.log("selectCurrency", selectCurrency)

            if (selectCurrency.length > 0) {
              console.log("currencyRate-------------------", currencyRate);
              newArray = getCurrencyRates.filter(item => item.FromCurrency === fromCurrency)
              console.log(newArray, "newArray")
              const convertedCurrency = newArray[0].ToCurrency;
              console.log(convertedCurrency, "at index", i)

              let Price = variantResult[j].VariantPrice;
              let TotalPrice = variantResult[j].TotalPrice;


              // changed total price.......................... 
              variantResult[j]["TotalPrice"] = parseFloat(
                currencyRate * TotalPrice
              ).toFixed(2);


              console.log("Price", Price)
              variantResult[j]["Currency"] = convertedCurrency;
              variantResult[j]["VariantPrice"] = parseFloat(
                currencyRate * Price
              ).toFixed(2);

            }

          }

          //           res.send(variantResult)
          //          // console.log("variantResult affter chaneg",variantResult)
          //           //// this is the new change on variant result

          // return
          // will use later after confirmation

          // for (let j = 0; j < variantsLength; j++) {

          //   const fromCurrency = tempVariantDetails[i].Values[j].Currency;
          //   console.log("fromCurrency", fromCurrency)
          //   const selectCurrency = getCurrencyRates.filter(item => item.FromCurrency === fromCurrency);
          //   currencyRate = selectCurrency.length ? selectCurrency[0].Rate : null;
          //   console.log("getCurrencyRates", getCurrencyRates)
          //   console.log("selectCurrency", selectCurrency)

          //   if (selectCurrency.length > 0) {
          //     console.log("currencyRate-------------------", currencyRate);
          //     newArray = getCurrencyRates.filter(item => item.FromCurrency === fromCurrency)
          //     console.log(newArray, "newArray")
          //     const convertedCurrency = newArray[0].ToCurrency;
          //     console.log(convertedCurrency, "at index", i)

          //     let Price = tempVariantDetails[i].Values[j].VariantPrice;

          //     console.log("Price", Price)
          //     tempVariantDetails[i].Values[j]["Currency"] = convertedCurrency;
          //     tempVariantDetails[i].Values[j]["VariantPrice"] = parseFloat(
          //       currencyRate * Price
          //     ).toFixed(2);

          //   }

          // }

        }
        // will use later end
        VendorID = viewProductDetail[0].VendorID;

        if (viewProductDetail && viewProductDetail.length > 0) {
          let getIndiviudalRatingCount = await connection.query(
            `SELECT  
        COUNT( CASE WHEN Rating = 1 THEN 1 END) as rating_1,
        COUNT( CASE WHEN Rating = 2 THEN 1 END) as rating_2,
        COUNT( CASE WHEN Rating = 3 THEN 1 END) as rating_3,
        COUNT( CASE WHEN Rating = 4 THEN 1 END) as rating_4,
        COUNT( CASE WHEN Rating = 5 THEN 1 END) as rating_5
        FROM productreviewrating 
         WHERE ProductID="${req.params.id}" 
     `, {
            type: QueryTypes.SELECT,
          }
          );
          if (getIndiviudalRatingCount && getIndiviudalRatingCount.length > 0) {
            storeIndiviudalRatingCount = getIndiviudalRatingCount[0];
          } else {
            storeIndiviudalRatingCount = [];
          }
          if (currentUserID != -1) {
            let getUserWishListStatus = await connection.query(
              `SELECT * FROM userwishlist 
         WHERE ProductID="${req.params.id}" AND UserID="${currentUserID}" 
     `, {
              type: QueryTypes.SELECT,
            }
            );
            if (getUserWishListStatus && getUserWishListStatus.length > 0) {
              inWishList = true;
            }
          }
          let getProductReviewRatingCount = await connection.query(
            `SELECT COUNT(Review) AS Total_Reviews,AVG(Rating) AS ProductAverageRating,SUM(Rating) AS TotalRating,
             (SELECT AVG(r.Rating) 
             FROM product  p
             INNER JOIN productreviewrating r ON r.ProductID IN (p.ProductID)
             WHERE p.VendorID="${VendorID}"
             GROUP BY p.VendorID) VendorRating ,
            (SELECT COUNT(r.Review) 
            FROM product  p
            INNER JOIN productreviewrating r ON r.ProductID IN (p.ProductID)
            WHERE p.VendorID="${VendorID}") TotalVendorReview 
            FROM productreviewrating 
            WHERE ProductID="${req.params.id}"  `, {
            type: QueryTypes.SELECT,
          }
          );
          if (
            getProductReviewRatingCount &&
            getProductReviewRatingCount.length > 0
          ) {
            storeProductReviewCount = getProductReviewRatingCount[0];
          } else {
            storeProductReviewCount = [];
          }
          let getProductReviewRating = await connection.query(
            `SELECT r.*,p.UserName,p.ProfilePic
               FROM productreviewrating r
               INNER JOIN profile p ON p.UserID=r.UserID
               WHERE r.ProductID="${req.params.id}"    `, {
            type: QueryTypes.SELECT,
          }
          );
          VendorRating = getProductReviewRatingCount[0].VendorRating;
          TotalVendorReview = getProductReviewRatingCount[0].TotalVendorReview;
          BuisnessDetail["VendorRating"] = VendorRating;
          BuisnessDetail["TotalVendorReview"] = TotalVendorReview;

          //!cuurency conversion

          // if (Region == "Bangladesh") {

          let productDetailArray;

          console.log("ProductDetail___________________", ProductDetail)
          const fromCurrency = ProductDetail.Currency;

          console.log("fromCurrency", fromCurrency)
          const selectCurrency = getCurrencyRates.filter(item => item.FromCurrency === fromCurrency);
          currencyRate = selectCurrency.length ? selectCurrency[0].Rate : null;

          console.log("getCurrencyRates", getCurrencyRates)


          if (selectCurrency.length > 0) {

            productDetailArray = getCurrencyRates.filter(item => item.FromCurrency === fromCurrency)

            const convertedCurrency = productDetailArray[0].ToCurrency;
            let Price = ProductDetail.Price;
            ProductDetail["Currency"] = convertedCurrency;
            ProductDetail["Price"] = parseFloat(
              currencyRate * Price
            ).toFixed(2);

          }
          let viewProductDetailArray;
          for (let i = 0; i < viewProductDetail.length; i++) {


            const fromCurrency = viewProductDetail[i].Currency;

            const selectCurrency = getCurrencyRates.filter(item => item.FromCurrency === fromCurrency);
            currencyRate = selectCurrency.length ? selectCurrency[0].Rate : null;
            if (selectCurrency.length > 0) {
              viewProductDetailArray = getCurrencyRates.filter(item => item.FromCurrency === fromCurrency)
              const convertedCurrency = viewProductDetailArray[0].ToCurrency;

              let Price = viewProductDetail[i].Price;

              viewProductDetail[i]["Currency"] = convertedCurrency;
              viewProductDetail[i]["Price"] = parseFloat(
                currencyRate * Price
              ).toFixed(2);

            }

          }

          if (getProductReviewRating && getProductReviewRating.length > 0) {

            res.status(200).json({
              status: true,
              BuisnessDetail,
              ProductDetail,
              MainImage: Main_Image,
              VariantDetails: variantResult,
              variantOptionValues: updatedObject,
              ProductAverageRatingAndReviews: storeProductReviewCount,
              ProductRatingCount: storeIndiviudalRatingCount,
              UsersProductReviewAndRating: getProductReviewRating,
              Product: viewProductDetail,
              inWishList,
            });
          } else {
            res.status(200).json({
              status: true,
              BuisnessDetail,
              ProductDetail,
              MainImage: Main_Image,
              VariantDetails: variantResult,
              variantOptionValues: updatedObject,
              ProductAverageRatingAndReviews: storeProductReviewCount,
              ProductRatingCount: storeIndiviudalRatingCount,
              UsersProductReviewAndRating: [],
              Product: viewProductDetail,
              inWishList,
            });
          }
        }
      } else {
        res.status(200).json({
          status: false,
          message: "No Product Found",
        });
      }
    } else {
      res.status(200).json({
        status: false,
        message: "User ID cannot be null",
      });
    }
  } catch (err) {
    // next(err);
    console.log("ERRORORO", err)
    res.status(200).json({
      status: false,
      error: err.message,
    });
    console.log(err.message);
  }
};
//// new api start
exports.getProductAllVariantDetailsByProductId = async (req, res, next) => {
  try {

    let { optionValueIDone, optionValueIDtwo } = req.body

    if (
      optionValueIDone !== null ||
      optionValueIDone !== undefined ||
      optionValueIDtwo !== null ||
      optionValueIDtwo !== undefined
    ) {
      let checkIfProductExists = await connection.query(
        `SELECT * FROM product WHERE ProductID="${req.params.id}"`, {
        type: QueryTypes.SELECT,
      }
      );

      if (checkIfProductExists && checkIfProductExists.length > 0) {
        let viewProductDetailQuery = `SELECT v.*, p.*,
       p.*, o.OptionName AS VariantName, o.OptionID, u.OptionValueID AS SingleOptionValueID, u.OptionValueID,
       u.OptionValue AS VariantValue, g.Small, g.Medium, g.Large, a.SKU, 
       a.Price AS VariantPrice, a.AvailableInventory, n.Inventory, n.UnitPrice, 
       n.TotalPrice, a.OptionValueID, n.Status, i.MainImage, a.ProductVariantCombinationID,a.video
FROM vendor v
LEFT JOIN product p ON p.VendorID = v.VendorID
LEFT JOIN productvariantoption o ON o.ProductID = p.ProductID
LEFT JOIN productvariantoptionvalue u ON u.OptionID = o.OptionID
LEFT JOIN productimage i ON i.OptionValueID = u.OptionValueID
LEFT JOIN imagegallery g ON g.ImageGalleryID = i.ImageGalleryID
LEFT JOIN productvariantcombination a ON a.ProductID = p.ProductID
LEFT JOIN productinventory n ON n.ProductVariantCombinationID = a.ProductVariantCombinationID
WHERE p.ProductID = ${req.params.id} AND FIND_IN_SET(u.OptionValueID, a.OptionValueID) > 0
ORDER BY p.ProductID DESC
`;

        let viewProductDetail = await connection.query(viewProductDetailQuery, {
          type: QueryTypes.SELECT,
        });

        const objects = viewProductDetail

        const transformObjectsToOutput = async (inputObjects) => {
          const groupedData = {};

          for (const obj of inputObjects) {
            const id = obj["ProductVariantCombinationID"];

            if (!groupedData[id]) {

              //!1
              const getImageQuery = `
                SELECT *
                FROM productimage
                JOIN imagegallery ON productimage.ImageGalleryID = imagegallery.ImageGalleryID
                WHERE optionValueIds = :optionValueId;
            `;
              console.log(obj["OptionValueID"], "chcecking-------------------------------------------------------------------")
              const imageData = await connection.query(getImageQuery, {
                type: QueryTypes.SELECT,
                replacements: { optionValueId: obj["OptionValueID"] }
              });

              // Assuming you want to add the imageData to the groupedData object
              obj["imageData"] = imageData;

              // console.log("imageDataimageDataimageData", imageData)
              // Create base data structure if not exists
              groupedData[id] = {
                "VariantName": obj["VariantName"],
                "OptionID": obj["OptionID"],
                "video": obj["video"],
                "OptionValueID": obj["OptionValueID"],
                "VariantValue": obj["VariantValue"],
                "Small": obj["Small"],
                "Medium": obj["Medium"],
                "Large": obj["Large"],
                "SKU": obj["SKU"],
                "AvailableInventory": obj["AvailableInventory"],
                "VariantPrice": obj["VariantPrice"],
                "Inventory": obj["Inventory"],
                "UnitPrice": obj["UnitPrice"],
                "TotalPrice": obj["TotalPrice"],
                "Status": obj["Status"],
                "MainImage": obj["MainImage"],
                "ProductVariantCombinationID": obj["ProductVariantCombinationID"],
                "Currency": obj["Currency"],
                "variantionValues": [],
                "Images": imageData
              };
            }

            // Check if the variantionValue with the same OptionValueID already exists
            const variantValueExists = groupedData[id].variantionValues.some(v => v.OptionValueID === obj["SingleOptionValueID"]);

            // If not, push the new variantionValue to the grouped object
            if (!variantValueExists) {

              groupedData[id].variantionValues.push({
                "VariantName": obj["VariantName"],
                "OptionID": obj["OptionID"],
                "VariantValue": obj["VariantValue"],
                "OptionValueID": obj["SingleOptionValueID"],
              });
            }
          };

          return groupedData;
        };

        // Test
        const output = await transformObjectsToOutput(objects);

        const variantResult = Object.values(output);

        async function extractOptionValues(variantDetailsArray) {
          const extractedValues = [];

          variantDetailsArray.forEach(variant => {
            const { OptionValueID, variantionValues } = variant;

            // Extract OptionValueID
            const optionValueIDs = OptionValueID.split(',').map(value => parseInt(value));

            // Extract values inside variantionValues
            const values = variantionValues.map(value => ({
              VariantName: value.VariantName,
              OptionValueID: value.OptionValueID,
              VariantValue: value.VariantValue
            }));

            extractedValues.push({
              OptionValueID: optionValueIDs,
              values: values
            });
          });

          return extractedValues;
        }

        // Extracting OptionValueID and values inside variantionValues
        let result = await extractOptionValues(variantResult);

        // Mapping through the data and modifying the structure
        let modifiedData = result.map(item => {
          item.values.forEach(value => {
            value.OptionValueIDs = item.OptionValueID.join(',');
          });
          return item;
        });

        let extractedValues = result.map(item => item.values);

        // Grouping by VariantName
        const groupedByVariantName = extractedValues.flat().reduce((acc, item) => {
          const { VariantName } = item;
          acc[VariantName] = acc[VariantName] || [];
          acc[VariantName].push(item);
          return acc;
        }, {});

        const groupedByVariantNameLength = Object.keys(groupedByVariantName).length

        console.log("groupedByVariantNameLength", groupedByVariantNameLength)
        console.log("groupedByVariantName", groupedByVariantName)


        let updatedObject;

        if (groupedByVariantNameLength < 2) {
          console.log("inside ...............")
          async function updateVariantOption(obj) {
            const keys = Object.keys(obj);
            for (const key of keys) {
              if (Object.prototype.hasOwnProperty.call(obj, key)) {
                obj[key].forEach(variant => {
                  variant.isdisabled = false;
                });
              }
            }
            return obj;
          }

          updatedObject = await updateVariantOption(groupedByVariantName);
        } else {
          console.log("inside 2")
          async function updateVariantOption(obj, optionValueIdOne, optionValueIdTwo) {
            const keys = Object.keys(obj);

            // Skip the first key
            const keysToProcess = keys.slice(1);

            for (const key of keysToProcess) {
              if (Object.prototype.hasOwnProperty.call(obj, key)) {
                obj[key].forEach(variant => {
                  const optionIds = variant.OptionValueIDs.split(',').map(id => parseInt(id));
                  const includesOne = optionIds.includes(optionValueIdOne);
                  const includesTwo = optionIds.includes(optionValueIdTwo);

                  if (includesOne && includesTwo) {
                    variant.isdisabled = false;
                  } else if (includesOne) {
                    variant.isdisabled = false;
                  } else {
                    variant.isdisabled = true;
                  }
                });
              }
            }
            return obj;
          }

          updatedObject = await updateVariantOption(groupedByVariantName, optionValueIDone, optionValueIDtwo);
        }

        const values = variantResult.map((item) => item.variantionValues.map((item) => item));

        const options = values.reduce((acc, curr) => acc.concat(curr), []);

        const removeDuplicatesPreserveFalse = async (arr) => {
          const uniqueValues = new Map();

          arr.forEach((item) => {
            if (!uniqueValues.has(item.OptionValueID)) {
              uniqueValues.set(item.OptionValueID, item);
            } else if (item.isdisabled === false) {
              uniqueValues.set(item.OptionValueID, item);
            }
          });

          return Array.from(uniqueValues.values());
        };

        for (const key in updatedObject) {
          if (updatedObject.hasOwnProperty(key)) {
            updatedObject[key] = await removeDuplicatesPreserveFalse(updatedObject[key]);
          }
        }

        if (viewProductDetail && viewProductDetail.length > 0) {

          if (variantResult && variantResult.length > 0) {
            res.status(200).json({
              status: true,
              variantOptionValues: updatedObject,
            });
          } else {
            res.status(200).json({
              status: true,
              variantOptionValues: updatedObject,
            });
          }
        }
      } else {
        res.status(200).json({
          status: false,
          message: "No Product Found",
        });
      }
    } else {
      res.status(200).json({
        status: false,
        message: "OptionValueID cannot be null",
      });
    }
  } catch (err) {
    // next(err);
    console.log("error----->", err)
    res.status(200).json({
      status: false,
      error: err.message,
    });
    console.log(err.message);
  }
};


// new api end


//! SUBCATEGORY Variants APi
exports.getSubCategoryVariantsById = async (req, res, next) => {
  try {
    let getSubCategoryVariantID = await connection.query(
      `SELECT *  FROM subcategoryvariant WHERE SubCategoryID="${req.params.id}"    `, {
      type: QueryTypes.SELECT,
    }
    );
    if (getSubCategoryVariantID && getSubCategoryVariantID.length) {
      let SubCategoryVariantID = [];
      console.log(getSubCategoryVariantID);
      for (let i = 0; i < getSubCategoryVariantID.length; i++) {
        if (
          getSubCategoryVariantID[i].SubCategoryVariantID ==
          getSubCategoryVariantID[0].SubCategoryVariantID
        ) {
          SubCategoryVariantID += `(`;
        }
        if (i < getSubCategoryVariantID.length - 1) {
          SubCategoryVariantID += ` '${getSubCategoryVariantID[i].SubCategoryVariantID}' ,`;
        } else if (i == getSubCategoryVariantID.length - 1) {
          SubCategoryVariantID += `'${getSubCategoryVariantID[i].SubCategoryVariantID}')`;
        }
      }

      let viewSubCategoryVariantQuery = `SELECT  s.Variant,GROUP_CONCAT( v.VariantValue) AS VariantValue
                FROM ( subcategoryvariantvalue v
                INNER JOIN subcategoryvariant s  ON  s.SubCategoryVariantID IN (v.SubCategoryVariantID))
                WHERE  v.SubCategoryVariantID IN ${SubCategoryVariantID} 
                GROUP BY v.SubCategoryVariantID`;
      let viewSubCategoryVariant = await connection.query(
        viewSubCategoryVariantQuery, {
        type: QueryTypes.SELECT,
      }
      );
      if (viewSubCategoryVariant && viewSubCategoryVariant.length > 0) {
        res.status(200).json({
          status: true,
          SubCategoryVariant: viewSubCategoryVariant,
        });
      } else {
        res.status(200).json({
          status: false,
          message: "No SubCategory Variant found",
          SubCategoryVariant: [],
        });
      }
    } else {
      res.status(200).json({
        status: false,
        message: "SubCategoryID does not exist",
        SubCategoryVariant: [],
      });
    }
  } catch (err) {
    console.log(err)
    res.status(200).json({
      status: false,
      SubCategoryVariant: {},
      error: err.message,
    });
  }
};
//! Product Clicks CRUD
exports.addProductClicks = async (req, res, next) => {
  try {
    const {
      ProductID,
      UserID,
      SessionID,
      Country,
      IPAddress
    } = req.body;
    console.log(req.body);
    let LastUpdate = new Date().toISOString().slice(0, 19).replace("T", " ");
    let insertProductClicksQuery = `insert into productclicks ( ProductID ,UserID,SessionID,Country,Clicks,IPAddress,LastUpdate) values  `;
    for (let i = 0; i < ProductID.length; i++) {
      if (i == ProductID.length - 1) {
        insertProductClicksQuery += `('${ProductID[i]}', '${UserID}','${SessionID[i]}', '${Country[i]}','1','${IPAddress[i]}','${LastUpdate}')`;
      } else {
        insertProductClicksQuery += `('${ProductID[i]}', '${UserID}','${SessionID[i]}', '${Country[i]}','1','${IPAddress[i]}','${LastUpdate}'),`;
      }
    }
    insertProductClicksQuery += ` ON DUPLICATE Key UPDATE Clicks=Clicks+1 ,RemoveStatus="N",LastUpdate=VALUES(LastUpdate)`;
    ProductClicks = await connection.query(insertProductClicksQuery, {
      type: QueryTypes.INSERT,
    });
    if (ProductClicks) {
      res.status(200).json({
        status: true,
        message: "Product Clicks added Successfully",
      });
    } else {
      res.status(200).json({
        status: false,
        message: "Error while adding Product Clicks",
      });
    }
  } catch (err) {
    next(err);
    res.status(200).json({
      status: false,
      Product: {},
      error: err.message,
    });
  }
};
//!Product Search Filter Api's
exports.viewProductDetailsByNameFilter = async (req, res, next) => {
  try {
    let Region = req.region;
    const currencyRate = req.currency_rate;

    let {
      limit,
      offset,
      search,
      sort
    } = req.body;
    limit = parseInt(limit);
    offset = parseInt(offset);
    offset = limit * offset;
    console.log(req.body);
    search = search.trim();

    // let CountryID;
    // if (Region == "Bangladesh") {
    //   CountryID = "16";
    // } else {
    //   CountryID = "226";
    // }
    let producstCount = await connection.query(
      `SELECT COUNT(p.ProductID ) as total_records 
      FROM product p
      LEFT JOIN vendor n on n.VendorID = p.VendorID 
      WHERE  p.Title  LIKE "%${search}%" `, {
      type: QueryTypes.SELECT,
    }
    );
    if (producstCount[0].total_records && producstCount[0].total_records > 0) {
      let viewProductDetailByNameQuery =
        `SELECT *  FROM product p
        LEFT JOIN vendor n on n.VendorID = p.VendorID 
        WHERE  p.Title  LIKE "%${search}%" 
         order by ProductID ${sort} limit ` +
        limit +
        " offset " +
        offset;
      let viewProductDetailByName = await connection.query(
        viewProductDetailByNameQuery, {
        type: QueryTypes.SELECT,
      }
      );
      if (viewProductDetailByName && viewProductDetailByName.length > 0) {
        if (Region == "Bangladesh") {
          for (let i = 0; i < viewProductDetailByName.length; i++) {
            let Price = viewProductDetailByName[i].Price;
            if (viewProductDetailByName[i].Currency == "USD") {
              viewProductDetailByName[i]["Currency"] = "BDT";
              viewProductDetailByName[i]["Price"] = parseFloat(
                currencyRate * Price
              ).toFixed(2);
            }
          }
        }
        if (Region == "USA") {
          for (let i = 0; i < viewProductDetailByName.length; i++) {
            let Price = viewProductDetailByName[i].Price;
            if (viewProductDetailByName[i].Currency == "BDT") {
              viewProductDetailByName[i]["Currency"] = "USD";
              viewProductDetailByName[i]["Price"] = parseFloat(
                currencyRate * Price
              ).toFixed(2);
            }
          }
        }

        res.status(200).json({
          status: true,
          total_records: producstCount[0].total_records,
          Products: viewProductDetailByName,
        });
      } else {
        res.status(200).json({
          status: false,
          total_records: producstCount[0].total_records,
          Products: [],
        });
      }
    } else {
      res.status(200).json({
        status: true,
        total_records: producstCount[0].total_records,
        Products: [],
      });
    }
  } catch (err) {
    next(err);
    res.status(200).json({
      status: false,
      error: err.message,
    });
    console.log(err.message);
  }
};
exports.viewProductDetailsByCityFilter = async (req, res, next) => {
  try {
    let Region = req.region;
    const currencyRate = req.currency_rate;
    let {
      limit,
      offset,
      search,
      sort
    } = req.body;
    limit = parseInt(limit);
    offset = parseInt(offset);
    offset = limit * offset;
    console.log(req.body);
    search = search.trim();

    // let CountryID;
    // if (Region == "Bangladesh") {
    //   CountryID = "16";
    // } else {
    //   CountryID = "226";
    // }
    let producstCount = await connection.query(
      `SELECT COUNT(p.ProductID) as total_records
      FROM product p
      LEFT JOIN vendor n on n.VendorID = p.VendorID
       LEFT JOIN productcity c ON c.ProductID = p.ProductID
       LEFT JOIN city t ON t.CityID = c.CityID
      WHERE  t.City  LIKE "%${search}%"
         `, {
      type: QueryTypes.SELECT,
    }
    );
    if (producstCount[0].total_records && producstCount[0].total_records > 0) {
      let viewProductDetailByNameQuery =
        `  SELECT t.City AS ProductCity,t.Native AS CityNative,y.country AS ProductCountry,p.*
        FROM  (((((product  p
       LEFT JOIN productcity c ON c.ProductID = p.ProductID)
       LEFT JOIN city t ON t.CityID = c.CityID)
       LEFT  JOIN productcountry r ON r.ProductID = p.ProductID)
       LEFT JOIN vendor n on(n.VendorID = p.VendorID))
       LEFT JOIN country y ON y.CountryID = r.CountryID)
        WHERE  t.City  LIKE "%${search}%"  order by ProductID ${sort} limit ` +
        limit +
        " offset " +
        offset;
      let viewProductDetailByName = await connection.query(
        viewProductDetailByNameQuery, {
        type: QueryTypes.SELECT,
      }
      );
      if (viewProductDetailByName && viewProductDetailByName.length > 0) {
        //!cuurency conversion
        if (Region == "Bangladesh") {
          for (let i = 0; i < viewProductDetailByName.length; i++) {
            let Price = viewProductDetailByName[i].Price;
            if (viewProductDetailByName[i].Currency == "USD") {
              viewProductDetailByName[i]["Currency"] = "BDT";
              viewProductDetailByName[i]["Price"] = parseFloat(
                currencyRate * Price
              ).toFixed(2);
            }
          }
        } else if (Region == "USA") {
          for (let i = 0; i < viewProductDetailByName.length; i++) {
            let Price = viewProductDetailByName[i].Price;
            if (viewProductDetailByName[i].Currency == "BDT") {
              viewProductDetailByName[i]["Currency"] = "USD";
              viewProductDetailByName[i]["Price"] = parseFloat(
                currencyRate * Price
              ).toFixed(2);
            }
          }
        } else {
          for (let i = 0; i < viewProductDetailByName.length; i++) {
            let Price = viewProductDetailByName[i].Price;
            viewProductDetailByName[i]["Currency"] = "USD";
            viewProductDetailByName[i]["Price"] = parseFloat(
              currencyRate * Price
            ).toFixed(2);
          }
        }

        res.status(200).json({
          status: true,
          total_records: producstCount[0].total_records,
          Products: viewProductDetailByName,
        });
      } else {
        res.status(200).json({
          status: false,
          total_records: producstCount[0].total_records,
          Products: [],
        });
      }
    } else {
      res.status(200).json({
        status: true,
        total_records: producstCount[0].total_records,
        Products: [],
      });
    }
  } catch (err) {
    next(err);
    res.status(200).json({
      status: false,
      users: {},
      error: err.message,
    });
    console.log(err.message);
  }
};
exports.viewProductDetailsByCountryFilter = async (req, res, next) => {
  try {
    let Region = req.region;
    const currencyRate = req.currency_rate;
    let {
      limit,
      offset,
      search,
      sort
    } = req.body;
    // let CountryID;
    // if (Region == "Bangladesh") {
    //   CountryID = "16";
    // } else {
    //   CountryID = "226";
    // }
    limit = parseInt(limit);
    offset = parseInt(offset);
    offset = limit * offset;
    console.log(req.body);
    search = search.trim();

    let producstCount = await connection.query(
      `SELECT COUNT(p.ProductID ) as total_records 
      FROM product p
      LEFT JOIN vendor n on n.VendorID = p.VendorID
      LEFT  JOIN productcountry r ON r.ProductID = p.ProductID
       LEFT JOIN country y ON y.CountryID = r.CountryID
       WHERE  y.Country LIKE "%${search}%"`, {
      type: QueryTypes.SELECT,
    }
    );
    console.log(producstCount, "producstCount");
    if (producstCount[0].total_records && producstCount[0].total_records > 0) {
      let viewProductDetailByNameQuery =
        ` SELECT t.City AS ProductCity,t.Native AS CityNative,y.country AS ProductCountry,p.*
        FROM  (((((product  p
       LEFT JOIN productcity c ON c.ProductID = p.ProductID)
       LEFT JOIN city t ON t.CityID = c.CityID)
       LEFT  JOIN productcountry r ON r.ProductID = p.ProductID)
       LEFT JOIN vendor n on n.VendorID = p.VendorID)
       LEFT JOIN country y ON y.CountryID = r.CountryID) 
       WHERE  y.Country LIKE "%${search}%"  order by ProductID ${sort} limit ` +
        limit +
        " offset " +
        offset;
      let viewProductDetailByName = await connection.query(
        viewProductDetailByNameQuery, {
        type: QueryTypes.SELECT,
      }
      );
      if (viewProductDetailByName && viewProductDetailByName.length > 0) {
        //!cuurency conversion
        if (Region == "Bangladesh") {
          for (let i = 0; i < viewProductDetailByName.length; i++) {
            let Price = viewProductDetailByName[i].Price;
            if (viewProductDetailByName[i].Currency == "USD") {
              viewProductDetailByName[i]["Currency"] = "BDT";
              viewProductDetailByName[i]["Price"] = parseFloat(
                currencyRate * Price
              ).toFixed(2);
            }
          }
        } else if (Region == "USA") {
          for (let i = 0; i < viewProductDetailByName.length; i++) {
            let Price = viewProductDetailByName[i].Price;
            if (viewProductDetailByName[i].Currency == "BDT") {
              viewProductDetailByName[i]["Currency"] = "USD";
              viewProductDetailByName[i]["Price"] = parseFloat(
                currencyRate * Price
              ).toFixed(2);
            }
          }
        } else {
          for (let i = 0; i < viewProductDetailByName.length; i++) {
            let Price = viewProductDetailByName[i].Price;
            viewProductDetailByName[i]["Currency"] = "USD";
            viewProductDetailByName[i]["Price"] = parseFloat(
              currencyRate * Price
            ).toFixed(2);
          }
        }
        res.status(200).json({
          status: true,
          total_records: producstCount[0].total_records,
          Products: viewProductDetailByName,
        });
      } else {
        res.status(200).json({
          status: false,
          total_records: producstCount[0].total_records,
          Products: [],
        });
      }
    } else {
      res.status(200).json({
        status: true,
        total_records: producstCount[0].total_records,
        Products: [],
      });
    }
  } catch (err) {
    console.log(err.message);
    res.status(200).json({
      status: false,
      users: {},
      error: err.message,
    });
    console.log(err.message);
  }
};
//!Product Review Rating CRUD
exports.addProductRating = async (req, res, next) => {
  try {
    const {
      UserID,
      ProductID,
      Review,
      Rating,
      PurchaseVerified
    } = req.body;
    let LastUpdate = new Date().toISOString().slice(0, 19).replace("T", " ");
    let CheckIFUserAlreadyReviewedThisProduct =
      await checkIFalreadyReviewedProduct(UserID, ProductID);
    if (
      CheckIFUserAlreadyReviewedThisProduct &&
      CheckIFUserAlreadyReviewedThisProduct == "0"
    ) {
      let insertProductReviewRatingQuery = `insert into productreviewrating ( UserID,
          ProductID,
          Review,
          Rating,
          PurchaseVerified,
          LastUpdate) values (?,?,?,?,?,?)`;
      let insertProductReviewRating = await connection.query(
        insertProductReviewRatingQuery, {
        replacements: [
          UserID,
          ProductID,
          Review,
          Rating,
          PurchaseVerified,
          LastUpdate,
        ],
      }
      );
      if (insertProductReviewRating) {
        res.status(200).json({
          status: true,
          message: "Product Review Rating added successfully",
        });
      } else {
        res.status(200).json({
          status: false,
          message: "Error while adding Product Review Rating",
        });
      }
    } else if (
      CheckIFUserAlreadyReviewedThisProduct &&
      CheckIFUserAlreadyReviewedThisProduct == "1"
    ) {
      res.status(200).json({
        status: false,
        message: "User Already Reviewed This Product ",
      });
    }
  } catch (err) {
    next(err);
    res.status(200).json({
      status: false,
      error: err.message,
    });
  }
};
let checkIFalreadyReviewedProduct = async (UserID, ProductID) => {
  try {
    let checkIFAlreadyReviewdThisProduct = await connection.query(
      `select * from productreviewrating where UserID = '${UserID}' AND ProductID= '${ProductID}'`, {
      type: QueryTypes.SELECT,
    }
    );
    if (
      checkIFAlreadyReviewdThisProduct &&
      checkIFAlreadyReviewdThisProduct.length > 0
    ) {
      return "1";
    } else {
      return "0";
    }
  } catch (err) {
    console.log(err.message);
    return null;
  }
};
//! Most Popular And Top-Rated Products BY Category And SubCategory Api's
exports.MostPouplarProductsByCategoryAndSubCategoryId = async (
  req,
  res,
  next
) => {

  console.log("inside mostpopular")
  try {
    const Region = req.region;
    const getCurrencyRates = req.getCurrencyRates;
    console.log("getCurrencyRates", getCurrencyRates)
    let currencyRate;
    let {
      limit,
      offset,
      sort,
      status,
      searchType,
      search
    } = req.body;
    limit = parseInt(limit);
    offset = parseInt(offset);
    offset = limit * offset;
    let CountryID;
    if (Region == "Bangladesh") {
      CountryID = "16";
    } else {
      CountryID = "226";
    }
    if (searchType == "0") {
      console.log("inside first condition")
      if (status == "1") {
        let productsCount = await connection.query(
          `SELECT COUNT(p.ProductID) as total_records
         FROM product p
         LEFT JOIN vendor n on n.VendorID = p.VendorID
         WHERE SubCategoryID='${req.params.id}'  AND n.CountryID="${CountryID}" `, {
          type: QueryTypes.SELECT,
        }
        );
        if (
          productsCount[0].total_records &&
          productsCount[0].total_records > 0
        ) {
          let ProductDetailsQuery =
            `SELECT *,s.SubCategory,g.Small,g.Medium,g.Large
            FROM ((((((subcategory s
            LEFT JOIN product p ON p.SubCategoryID=s.SubCategoryID)
            LEFT JOIN productvariantoption o ON o.ProductID IN (p.ProductID))
            LEFT JOIN productvariantoptionvalue v ON v.OptionID IN(o.OptionID))
            LEFT JOIN productimage i ON i.OptionValueID IN(v.OptionValueID))
            LEFT JOIN imagegallery g ON g.ImageGalleryID IN(i.ImageGalleryID))
            LEFT JOIN vendor n on(n.VendorID = p.VendorID))
            WHERE p.SubCategoryID='${req.params.id}'AND  p.Title LIKE "%${search}%" AND p.Active="Y" AND i.MainImage = 'Y' AND n.CountryID="${CountryID}"
            Order BY p.ProductID DESC
            limit ` +
            limit +
            " offset " +
            offset;
          let ProductDetails = await connection.query(ProductDetailsQuery, {
            type: QueryTypes.SELECT,
          });

          if (ProductDetails && ProductDetails.length > 0) {
            //!cuurency conversion
            let newArray;
            for (let i = 0; i < ProductDetails.length; i++) {
              const fromCurrency = ProductDetails[i].Currency;
              const selectCurrency = getCurrencyRates.filter(item => item.FromCurrency === fromCurrency);
              currencyRate = selectCurrency.length ? selectCurrency[0].Rate : null;
              if (selectCurrency.length > 0) {
                newArray = getCurrencyRates.filter(item => item.FromCurrency === fromCurrency)
                const convertedCurrency = newArray[0].ToCurrency;
                let Price = ProductDetails[i].Price;
                ProductDetails[i]["Currency"] = convertedCurrency;
                ProductDetails[i]["Price"] = parseFloat(
                  currencyRate * Price
                ).toFixed(2);
              }
            }
            res.status(200).json({
              status: true,
              total_records: productsCount[0].total_records,
              Product: ProductDetails,
              SubCategory: ProductDetails[0].SubCategory,
            });
          } else {
            res.status(200).json({
              status: false,
              message: "NO Product found",
              total_records: productsCount[0].total_records,
              Product: [],
              SubCategory: [],
            });
          }
        } else {
          res.status(200).json({
            status: true,
            total_records: productsCount[0].total_records,
            Product: [],
            SubCategory: [],
          });
        }
      } else if (status == "0") {
        let productsCount = await connection.query(
          `SELECT COUNT(ProductID) as total_records
        FROM (((product p
        LEFT JOIN subcategory s ON s.SubCategoryID = p.SubCategoryID)
        LEFT JOIN category c ON c.CategoryID = s.CategoryID)
        LEFT JOIN vendor n on(n.VendorID = p.VendorID))
        WHERE c.CategoryID='${req.params.id}' AND n.CountryID="${CountryID}"`, {
          type: QueryTypes.SELECT,
        }
        );
        if (
          productsCount[0].total_records &&
          productsCount[0].total_records > 0
        ) {
          let ProductDetailsQuery =
            `SELECT c.CategoryID,c.Category,s.SubCategory,p.*,g.Small,g.Medium,g.Large
           FROM (((((((product p
           LEFT JOIN subcategory s ON s.SubCategoryID = p.SubCategoryID)
           LEFT JOIN category c ON c.CategoryID = s.CategoryID)
           LEFT JOIN productvariantoption o ON o.ProductID IN (p.ProductID))
           LEFT JOIN productvariantoptionvalue v ON v.OptionID IN(o.OptionID))
           LEFT JOIN productimage i ON i.OptionValueID IN(v.OptionValueID))
           LEFT JOIN imagegallery g ON g.ImageGalleryID IN(i.ImageGalleryID))
           LEFT JOIN vendor n on(n.VendorID = p.VendorID))
           WHERE c.CategoryID='${req.params.id}' AND p.Title  LIKE "%${search}%"  AND i.MainImage = 'Y' AND p.Active="Y" AND n.CountryID="${CountryID}"
           ORDER BY p.ProductID DESC
          limit ` +
            limit +
            " offset " +
            offset;
          let ProductDetails = await connection.query(ProductDetailsQuery, {
            type: QueryTypes.SELECT,
          });

          if (ProductDetails && ProductDetails.length > 0) {
            //!cuurency conversion
            let newArray;
            for (let i = 0; i < ProductDetails.length; i++) {
              const fromCurrency = ProductDetails[i].Currency;
              const selectCurrency = getCurrencyRates.filter(item => item.FromCurrency === fromCurrency);
              currencyRate = selectCurrency.length ? selectCurrency[0].Rate : null;
              if (selectCurrency.length > 0) {
                newArray = getCurrencyRates.filter(item => item.FromCurrency === fromCurrency)
                const convertedCurrency = newArray[0].ToCurrency;
                let Price = ProductDetails[i].Price;
                ProductDetails[i]["Currency"] = convertedCurrency;
                ProductDetails[i]["Price"] = parseFloat(
                  currencyRate * Price
                ).toFixed(2);
              }
            }
            res.status(200).json({
              status: true,
              total_records: productsCount[0].total_records,
              Product: ProductDetails,
              Category: ProductDetails[0].Category,
            });
          } else {
            res.status(200).json({
              status: false,
              message: "NO Product found",
              total_records: productsCount[0].total_records,
              Product: [],
            });
          }
        } else {
          res.status(200).json({
            status: true,
            total_records: productsCount[0].total_records,
            Product: [],
          });
        }
      }
    }
    if (searchType == "1") {
      console.log("inside second condition")
      if (status == "1") {
        //! Status 1 is for SubCategory
        let productsCount = await connection.query(
          `SELECT COUNT(p.ProductID) as total_records
         FROM product p
         LEFT JOIN vendor n on n.VendorID = p.VendorID
         WHERE p.SubCategoryID='${req.params.id}' AND n.CountryID="${CountryID}"`, {
          type: QueryTypes.SELECT,
        }
        );
        if (
          productsCount[0].total_records &&
          productsCount[0].total_records > 0
        ) {
          let ProductDetailsQuery =
            `SELECT p.*,s.SubCategory,SUM(c.Clicks) AS Total_Clicks,g.Small,g.Medium,g.large
      FROM (((((((subcategory s
      LEFT JOIN product p ON p.SubCategoryID=s.SubCategoryID)
      LEFT JOIN productclicks c ON c.ProductID IN (p.ProductID))
      LEFT JOIN productvariantoption o ON o.ProductID IN (p.ProductID))
      LEFT JOIN productvariantoptionvalue v ON v.OptionID IN(o.OptionID))
      LEFT JOIN productimage i ON i.OptionValueID IN(v.OptionValueID))
      LEFT JOIN imagegallery g ON g.ImageGalleryID IN(i.ImageGalleryID))
      LEFT JOIN vendor n on(n.VendorID = p.VendorID))
      WHERE p.SubCategoryID='${req.params.id}' AND p.Title  LIKE "%${search}%"  AND i.MainImage = 'Y' AND p.Active="Y" AND n.CountryID="${CountryID}"
      GROUP BY p.ProductID
      Order BY Total_Clicks ${sort}
       limit ` +
            limit +
            " offset " +
            offset;
          let ProductDetails = await connection.query(ProductDetailsQuery, {
            type: QueryTypes.SELECT,
          });

          if (ProductDetails && ProductDetails.length > 0) {
            //!cuurency conversion
            let newArray;
            for (let i = 0; i < ProductDetails.length; i++) {
              const fromCurrency = ProductDetails[i].Currency;
              const selectCurrency = getCurrencyRates.filter(item => item.FromCurrency === fromCurrency);
              currencyRate = selectCurrency.length ? selectCurrency[0].Rate : null;
              if (selectCurrency.length > 0) {
                newArray = getCurrencyRates.filter(item => item.FromCurrency === fromCurrency)
                const convertedCurrency = newArray[0].ToCurrency;
                let Price = ProductDetails[i].Price;
                ProductDetails[i]["Currency"] = convertedCurrency;
                ProductDetails[i]["Price"] = parseFloat(
                  currencyRate * Price
                ).toFixed(2);
              }
            }
            res.status(200).json({
              status: true,
              total_records: productsCount[0].total_records,
              Product: ProductDetails,
              SubCategory: ProductDetails[0].SubCategory,
            });
          } else {
            res.status(200).json({
              status: false,
              message: "NO Product found",
              total_records: productsCount[0].total_records,
              Product: [],
            });
          }
        } else {
          res.status(200).json({
            status: true,
            total_records: productsCount[0].total_records,
            Product: [],
          });
        }
      } else if (status == "0") {
        //! Status 0 is for Category
        let productsCount = await connection.query(
          `SELECT COUNT(p.ProductID) as total_records
    FROM (((product p
    LEFT JOIN subcategory s ON s.SubCategoryID = p.SubCategoryID)
    LEFT JOIN category c ON c.CategoryID = s.CategoryID)
    LEFT JOIN vendor n on n.VendorID = p.VendorID)
    WHERE c.CategoryID='${req.params.id}' AND n.CountryID="${CountryID}"`, {
          type: QueryTypes.SELECT,
        }
        );
        if (
          productsCount[0].total_records &&
          productsCount[0].total_records > 0
        ) {
          let ProductDetailsQuery =
            `SELECT c.CategoryID,c.Category,s.SubCategory,p.* ,SUM(k.clicks) AS Total_Clicks,g.Small,g.Medium,g.large
        FROM ((((((((product p
        LEFT JOIN subcategory s ON s.SubCategoryID = p.SubCategoryID)
        LEFT JOIN category c ON c.CategoryID = s.CategoryID)
        LEFT JOIN productvariantoption o ON o.ProductID IN (p.ProductID))
        LEFT JOIN productvariantoptionvalue v ON v.OptionID IN(o.OptionID))
        LEFT JOIN productimage i ON i.OptionValueID IN(v.OptionValueID))
        LEFT JOIN imagegallery g ON g.ImageGalleryID IN(i.ImageGalleryID))
        LEFT JOIN productclicks k ON k.ProductID IN (p.ProductID))
        LEFT JOIN vendor n on n.VendorID = p.VendorID)
        WHERE c.CategoryID='${req.params.id}' AND p.Title  LIKE "%${search}%"  AND i.MainImage = 'Y' AND p.Active="Y" AND n.CountryID="${CountryID}"
        GROUP BY p.ProductID
        Order BY Total_Clicks ${sort}
        limit ` +
            limit +
            " offset " +
            offset;
          let ProductDetails = await connection.query(ProductDetailsQuery, {
            type: QueryTypes.SELECT,
          });
          if (ProductDetails && ProductDetails.length > 0) {
            //!cuurency conversion
            let newArray;
            for (let i = 0; i < ProductDetails.length; i++) {
              const fromCurrency = ProductDetails[i].Currency;
              const selectCurrency = getCurrencyRates.filter(item => item.FromCurrency === fromCurrency);
              currencyRate = selectCurrency.length ? selectCurrency[0].Rate : null;
              if (selectCurrency.length > 0) {
                newArray = getCurrencyRates.filter(item => item.FromCurrency === fromCurrency)
                const convertedCurrency = newArray[0].ToCurrency;
                let Price = ProductDetails[i].Price;
                ProductDetails[i]["Currency"] = convertedCurrency;
                ProductDetails[i]["Price"] = parseFloat(
                  currencyRate * Price
                ).toFixed(2);
              }
            }
            res.status(200).json({
              status: true,
              total_records: productsCount[0].total_records,
              Product: ProductDetails,
              Category: ProductDetails[0].Category,
            });
          } else {
            res.status(200).json({
              status: false,
              message: "NO Product found",
              total_records: productsCount[0].total_records,
              Product: [],
            });
          }
        } else {
          res.status(200).json({
            status: true,
            total_records: productsCount[0].total_records,
            Product: [],
          });
        }
      }
    } else if (searchType == "2") {
      if (status == "1") {
        //! Status 1 is for SubCategory
        let productsCount = await connection.query(
          `SELECT COUNT(ProductID) as total_records 
        FROM product p 
        LEFT JOIN vendor n on n.VendorID = p.VendorID
        WHERE SubCategoryID='${req.params.id}' AND n.CountryID="${CountryID}" `, {
          type: QueryTypes.SELECT,
        }
        );
        if (
          productsCount[0].total_records &&
          productsCount[0].total_records > 0
        ) {
          let ProductDetailsQuery =
            `SELECT p.*,s.SubCategory,SUM(r.Rating) AS Total_Rating,g.Small,g.Medium,g.large
      FROM (((((((subcategory s
      LEFT JOIN product p ON p.SubCategoryID=s.SubCategoryID)
      LEFT JOIN productreviewrating r ON r.ProductID IN (p.ProductID))
      LEFT JOIN productvariantoption o ON o.ProductID IN (p.ProductID))
      LEFT JOIN productvariantoptionvalue v ON v.OptionID IN(o.OptionID))
      LEFT JOIN productimage i ON i.OptionValueID IN(v.OptionValueID))
      LEFT JOIN imagegallery g ON g.ImageGalleryID IN(i.ImageGalleryID))
      LEFT JOIN vendor n on(n.VendorID = p.VendorID))
      WHERE p.SubCategoryID='${req.params.id}' AND p.Title  LIKE "%${search}%"  AND i.MainImage = 'Y' AND p.Active="Y" AND n.CountryID="${CountryID}"
      GROUP BY p.ProductID
      Order BY Total_Rating ${sort}
       limit ` +
            limit +
            " offset " +
            offset;
          let ProductDetails = await connection.query(ProductDetailsQuery, {
            type: QueryTypes.SELECT,
          });

          if (ProductDetails && ProductDetails.length > 0) {
            //!cuurency conversion
            let newArray;
            for (let i = 0; i < ProductDetails.length; i++) {
              const fromCurrency = ProductDetails[i].Currency;
              const selectCurrency = getCurrencyRates.filter(item => item.FromCurrency === fromCurrency);
              currencyRate = selectCurrency.length ? selectCurrency[0].Rate : null;
              if (selectCurrency.length > 0) {
                newArray = getCurrencyRates.filter(item => item.FromCurrency === fromCurrency)
                const convertedCurrency = newArray[0].ToCurrency;
                let Price = ProductDetails[i].Price;
                ProductDetails[i]["Currency"] = convertedCurrency;
                ProductDetails[i]["Price"] = parseFloat(
                  currencyRate * Price
                ).toFixed(2);
              }
            }

            res.status(200).json({
              status: true,
              total_records: productsCount[0].total_records,
              Product: ProductDetails,
              SubCategory: ProductDetails[0].SubCategory,
            });
          } else {
            res.status(200).json({
              status: false,
              message: "NO Product found",
              total_records: productsCount[0].total_records,
              Product: [],
            });
          }
        } else {
          res.status(200).json({
            status: true,
            total_records: productsCount[0].total_records,
            Product: [],
          });
        }
      } else if (status == "0") {
        //! Status 0 is for Category
        let productsCount = await connection.query(
          `SELECT COUNT(p.ProductID) as total_records
    FROM (((product p
    LEFT JOIN subcategory s ON s.SubCategoryID = p.SubCategoryID)
    LEFT JOIN category c ON c.CategoryID = s.CategoryID)
    LEFT JOIN vendor n on(n.VendorID = p.VendorID))
    WHERE c.CategoryID='${req.params.id}' AND n.CountryID="${CountryID}"`, {
          type: QueryTypes.SELECT,
        }
        );
        if (
          productsCount[0].total_records &&
          productsCount[0].total_records > 0
        ) {
          let ProductDetailsQuery =
            `SELECT c.CategoryID,c.Category,s.SubCategory,p.* ,SUM(r.Rating) AS Total_Rating,g.Small,g.Medium,g.large
        FROM ((((((((product p
        LEFT JOIN subcategory s ON s.SubCategoryID = p.SubCategoryID)
        LEFT JOIN category c ON c.CategoryID = s.CategoryID)
        LEFT JOIN productvariantoption o ON o.ProductID IN (p.ProductID))
        LEFT JOIN productvariantoptionvalue v ON v.OptionID IN(o.OptionID))
        LEFT JOIN productimage i ON i.OptionValueID IN(v.OptionValueID))
        LEFT JOIN imagegallery g ON g.ImageGalleryID IN(i.ImageGalleryID))
        LEFT JOIN productreviewrating r ON r.ProductID IN (p.ProductID))
        LEFT JOIN vendor n on (n.VendorID = p.VendorID))
        WHERE c.CategoryID='${req.params.id}' AND p.Title  LIKE "%${search}%"  AND i.MainImage = 'Y' AND p.Active="Y" AND n.CountryID="${CountryID}"
        GROUP BY p.ProductID
        Order BY Total_Rating ${sort}
        limit ` +
            limit +
            " offset " +
            offset;
          let ProductDetails = await connection.query(ProductDetailsQuery, {
            type: QueryTypes.SELECT,
          });
          if (ProductDetails && ProductDetails.length > 0) {
            //!cuurency conversion
            let newArray;
            for (let i = 0; i < ProductDetails.length; i++) {
              const fromCurrency = ProductDetails[i].Currency;
              const selectCurrency = getCurrencyRates.filter(item => item.FromCurrency === fromCurrency);
              currencyRate = selectCurrency.length ? selectCurrency[0].Rate : null;
              if (selectCurrency.length > 0) {
                newArray = getCurrencyRates.filter(item => item.FromCurrency === fromCurrency)
                const convertedCurrency = newArray[0].ToCurrency;
                let Price = ProductDetails[i].Price;
                ProductDetails[i]["Currency"] = convertedCurrency;
                ProductDetails[i]["Price"] = parseFloat(
                  currencyRate * Price
                ).toFixed(2);
              }
            }
            res.status(200).json({
              status: true,
              total_records: productsCount[0].total_records,
              Product: ProductDetails,
              Category: ProductDetails[0].Category,
            });
          } else {
            res.status(200).json({
              status: false,
              message: "NO Product found",
              total_records: productsCount[0].total_records,
              Product: [],
            });
          }
        } else {
          res.status(200).json({
            status: true,
            total_records: productsCount[0].total_records,
            Product: [],
          });
        }
      }
    }
  } catch (err) {
    next(err);
    res.status(200).json({
      status: false,
      Product: {},
      error: err.message,
    });
    console.log(err.message);
  }
};
//! Global Search Most Popular And Top-Rated Products Api's
exports.GlobalSearchProductDetailsByCategory = async (req, res, next) => {
  try {

    const Region = req.region;
    const getCurrencyRates = req.getCurrencyRates;
    console.log("getCurrencyRates", getCurrencyRates)
    let currencyRate;

    let {
      CategoryID,
      search,
      limit,
      offset,
      searchType
    } = req.body;
    let CountryID;
    if (Region == "Bangladesh") {
      CountryID = "16";
    } else {
      CountryID = "226";
    }
    limit = parseInt(limit);
    offset = parseInt(offset);
    offset = limit * offset;
    if (searchType == "0") {
      console.log("inside first")
      if (CategoryID) {
        let productsCount = await connection.query(
          `SELECT COUNT(ProductID) as total_records
      FROM (((product p
      LEFT JOIN subcategory s ON s.SubCategoryID = p.SubCategoryID)
      LEFT JOIN category c ON c.CategoryID = s.CategoryID)
      LEFT JOIN vendor n on (n.VendorID = p.VendorID))
      WHERE c.CategoryID='${CategoryID}' AND n.CountryID="${CountryID}" `, {
          type: QueryTypes.SELECT,
        }
        );
        if (
          productsCount[0].total_records &&
          productsCount[0].total_records > 0
        ) {
          let ProductDetailsQuery =
            `SELECT r.CompanyName,c.CategoryID,c.Category,s.SubCategory,p.*,g.Small,g.Medium,g.Large
         FROM (((((((product p
         LEFT JOIN vendor r ON r.VendorID = p.VendorID)
         LEFT JOIN subcategory s ON s.SubCategoryID = p.SubCategoryID)
         LEFT JOIN category c ON c.CategoryID = s.CategoryID)
         LEFT JOIN productvariantoption o ON o.ProductID IN (p.ProductID))
         LEFT JOIN productvariantoptionvalue v ON v.OptionID IN(o.OptionID))
         LEFT JOIN productimage i ON i.OptionValueID IN(v.OptionValueID))
         LEFT JOIN imagegallery g ON g.ImageGalleryID IN(i.ImageGalleryID))
         WHERE c.CategoryID='${CategoryID}' AND (p.Title LIKE "%${search}%"||p.Description LIKE "%${search}%"||p.StoreName LIKE "%${search}%"||r.CompanyName  LIKE "%${search}%") AND i.MainImage = 'Y' AND p.Active = 'Y' AND r.CountryID="${CountryID}"
         ORDER BY p.ProductID DESC
         limit ` +
            limit +
            " offset " +
            offset;
          let ProductDetails = await connection.query(ProductDetailsQuery, {
            type: QueryTypes.SELECT,
          });
          if (ProductDetails && ProductDetails.length > 0) {
            let newArray;
            //!cuurency conversion
            // if (Region == "Bangladesh") {
            for (let i = 0; i < ProductDetails.length; i++) {

              const fromCurrency = ProductDetails[i].Currency;
              const selectCurrency = getCurrencyRates.filter(item => item.FromCurrency === fromCurrency);
              currencyRate = selectCurrency.length ? selectCurrency[0].Rate : null;

              if (selectCurrency.length > 0) {
                console.log("currencyRate-------------------", currencyRate);
                newArray = getCurrencyRates.filter(item => item.FromCurrency === fromCurrency)
                console.log(newArray, "newArray")
                const convertedCurrency = newArray[0].ToCurrency;
                console.log(convertedCurrency, "at index", i)

                let Price = ProductDetails[i].Price;

                console.log("Price", Price)
                ProductDetails[i]["Currency"] = convertedCurrency;
                ProductDetails[i]["Price"] = parseFloat(
                  currencyRate * Price
                ).toFixed(2);

              }
              console.log("ProductDetails", ProductDetails)
              // if (ProductDetails[i].Currency == "USD") {
              //   ProductDetails[i]["Currency"] = "BDT";
              //   ProductDetails[i]["Price"] = parseFloat(
              //     currencyRate * Price
              //   ).toFixed(2);
              // }
            }
            // } else if (Region == "USA") {
            //   for (let i = 0; i < ProductDetails.length; i++) {
            //     let Price = ProductDetails[i].Price;
            //     if (ProductDetails[i].Currency == "BDT") {
            //       ProductDetails[i]["Currency"] = "USD";
            //       ProductDetails[i]["Price"] = parseFloat(
            //         currencyRate * Price
            //       ).toFixed(2);
            //     }
            //   }
            // } else {
            //   for (let i = 0; i < ProductDetails.length; i++) {
            //     let Price = ProductDetails[i].Price;
            //     ProductDetails[i]["Currency"] = "USD";
            //     ProductDetails[i]["Price"] = parseFloat(
            //       currencyRate * Price
            //     ).toFixed(2);
            //   }
            // }
            res.status(200).json({
              status: true,
              total_records: productsCount[0].total_records,
              Product: ProductDetails,
              Category: ProductDetails[0].Category,
            });
          } else {
            res.status(200).json({
              status: false,
              message: "NO Product found",
              total_records: productsCount[0].total_records,
              Product: [],
              Category: [],
            });
          }
        } else {
          res.status(200).json({
            status: true,
            total_records: productsCount[0].total_records,
            Product: [],
            Category: [],
          });
        }
      } else if (CategoryID == null || CategoryID == "") {
        let productsCount = await connection.query(
          `SELECT COUNT(p.ProductID) as total_records
          FROM product p
          LEFT JOIN vendor r ON r.VendorID = p.VendorID 
          WHERE r.CountryID="${CountryID}" `, {
          type: QueryTypes.SELECT,
        }
        );
        if (
          productsCount[0].total_records &&
          productsCount[0].total_records > 0
        ) {
          let ProductDetailsQuery =
            `SELECT r.CompanyName,c.CategoryID,c.Category,s.SubCategory,p.*,g.Small,g.Medium,g.Large
     FROM (((((((product p
     LEFT JOIN vendor r ON r.VendorID = p.VendorID)
     LEFT JOIN subcategory s ON s.SubCategoryID = p.SubCategoryID)
     LEFT JOIN category c ON c.CategoryID = s.CategoryID)
     LEFT JOIN productvariantoption o ON o.ProductID IN (p.ProductID))
     LEFT JOIN productvariantoptionvalue v ON v.OptionID IN(o.OptionID))
     LEFT JOIN productimage i ON i.OptionValueID IN(v.OptionValueID))
     LEFT JOIN imagegallery g ON g.ImageGalleryID IN(i.ImageGalleryID))
     WHERE (p.Title LIKE "%${search}%"||p.Description LIKE "%${search}%"||p.StoreName LIKE "%${search}%"||r.CompanyName  LIKE "%${search}%")  AND i.MainImage = 'Y' AND p.Active = 'Y' AND r.CountryID="${CountryID}"
     ORDER BY p.ProductID DESC
     limit ` +
            limit +
            " offset " +
            offset;
          let ProductDetails = await connection.query(ProductDetailsQuery, {
            type: QueryTypes.SELECT,
          });
          if (ProductDetails && ProductDetails.length > 0) {
            let newArray;
            //!currency conversion
            for (let i = 0; i < ProductDetails.length; i++) {
              const fromCurrency = ProductDetails[i].Currency;
              const selectCurrency = getCurrencyRates.filter(item => item.FromCurrency === fromCurrency);
              currencyRate = selectCurrency.length ? selectCurrency[0].Rate : null;
              if (selectCurrency.length > 0) {
                newArray = getCurrencyRates.filter(item => item.FromCurrency === fromCurrency)
                const convertedCurrency = newArray[0].ToCurrency;
                console.log(convertedCurrency, "at index", i)
                let Price = ProductDetails[i].Price;
                console.log("Price", Price)
                ProductDetails[i]["Currency"] = convertedCurrency;
                ProductDetails[i]["Price"] = parseFloat(
                  currencyRate * Price
                ).toFixed(2);
              }
            }
            res.status(200).json({
              status: true,
              total_records: productsCount[0].total_records,
              Product: ProductDetails,
            });
          } else {
            res.status(200).json({
              status: false,
              message: "NO Product found",
              total_records: productsCount[0].total_records,
              Product: [],
              Category: [],
            });
          }
        } else {
          res.status(200).json({
            status: true,
            total_records: productsCount[0].total_records,
            Product: [],
            Category: [],
          });
        }
      }
    } else if (searchType == "1") {
      console.log("inside second")
      if (CategoryID) {
        let productsCount = await connection.query(
          `SELECT COUNT(p.ProductID) as total_records
        FROM (((product p
        LEFT JOIN subcategory s ON s.SubCategoryID = p.SubCategoryID)
        LEFT JOIN category c ON c.CategoryID = s.CategoryID)
        LEFT JOIN vendor r ON r.VendorID = p.VendorID)
        WHERE c.CategoryID='${CategoryID}' AND r.CountryID="${CountryID}"`, {
          type: QueryTypes.SELECT,
        }
        );
        if (
          productsCount[0].total_records &&
          productsCount[0].total_records > 0
        ) {
          let ProductDetailsQuery =
            `SELECT r.CompanyName,c.CategoryID,c.Category,s.SubCategory,p.* ,SUM(k.clicks) AS Total_Clicks,g.Small,g.Medium,g.large
        FROM ((((((((product p
        LEFT JOIN vendor r ON r.VendorID = p.VendorID)
        LEFT JOIN subcategory s ON s.SubCategoryID = p.SubCategoryID)
        LEFT JOIN category c ON c.CategoryID = s.CategoryID)
        LEFT JOIN productvariantoption o ON o.ProductID IN (p.ProductID))
        LEFT JOIN productvariantoptionvalue v ON v.OptionID IN(o.OptionID))
        LEFT JOIN productimage i ON i.OptionValueID IN(v.OptionValueID))
        LEFT JOIN imagegallery g ON g.ImageGalleryID IN(i.ImageGalleryID))
        LEFT JOIN productclicks k ON k.ProductID IN (p.ProductID))
        WHERE c.CategoryID='${CategoryID}' AND (p.Title LIKE "%${search}%"||p.Description LIKE "%${search}%"||p.StoreName LIKE "%${search}%"||r.CompanyName  LIKE "%${search}%") AND i.MainImage = 'Y' AND p.Active = 'Y' AND r.CountryID="${CountryID}"
        GROUP BY p.ProductID
        Order BY Total_Clicks DESC
        limit ` +
            limit +
            " offset " +
            offset;
          let ProductDetails = await connection.query(ProductDetailsQuery, {
            type: QueryTypes.SELECT,
          });
          if (ProductDetails && ProductDetails.length > 0) {
            //!cuurency conversion
            let newArray;
            for (let i = 0; i < ProductDetails.length; i++) {
              const fromCurrency = ProductDetails[i].Currency;
              const selectCurrency = getCurrencyRates.filter(item => item.FromCurrency === fromCurrency);
              currencyRate = selectCurrency.length ? selectCurrency[0].Rate : null;

              if (selectCurrency.length > 0) {
                newArray = getCurrencyRates.filter(item => item.FromCurrency === fromCurrency)
                const convertedCurrency = newArray[0].ToCurrency;
                let Price = ProductDetails[i].Price;
                ProductDetails[i]["Currency"] = convertedCurrency;
                ProductDetails[i]["Price"] = parseFloat(
                  currencyRate * Price
                ).toFixed(2);
              }
            }
            res.status(200).json({
              status: true,
              total_records: productsCount[0].total_records,
              Product: ProductDetails,
              Category: ProductDetails[0].Category,
            });
          } else {
            res.status(200).json({
              status: false,
              message: "NO Product found",
              total_records: productsCount[0].total_records,
              Product: [],
            });
          }
        } else {
          res.status(200).json({
            status: true,
            total_records: productsCount[0].total_records,
            Product: [],
          });
        }
      } else if (CategoryID == null || CategoryID == "") {
        let productsCount = await connection.query(
          `SELECT COUNT(p.ProductID) as total_records
          FROM product p
          LEFT JOIN vendor r ON r.VendorID = p.VendorID 
          WHERE  r.CountryID="${CountryID}"
          `, {
          type: QueryTypes.SELECT,
        }
        );
        if (
          productsCount[0].total_records &&
          productsCount[0].total_records > 0
        ) {
          let ProductDetailsQuery =
            `SELECT r.CompanyName,c.CategoryID,c.Category,s.SubCategory,p.* ,SUM(k.clicks) AS Total_Clicks,g.Small,g.Medium,g.large
    FROM ((((((((product p
    LEFT JOIN vendor r ON r.VendorID = p.VendorID)
    LEFT JOIN subcategory s ON s.SubCategoryID = p.SubCategoryID)
    LEFT JOIN category c ON c.CategoryID = s.CategoryID)
    LEFT JOIN productvariantoption o ON o.ProductID IN (p.ProductID))
    LEFT JOIN productvariantoptionvalue v ON v.OptionID IN(o.OptionID))
    LEFT JOIN productimage i ON i.OptionValueID IN(v.OptionValueID))
    LEFT JOIN imagegallery g ON g.ImageGalleryID IN(i.ImageGalleryID))
    LEFT JOIN productclicks k ON k.ProductID IN (p.ProductID))
    WHERE  i.MainImage = 'Y' AND (p.Title LIKE "%${search}%"||p.Description LIKE "%${search}%"||p.StoreName LIKE "%${search}%"||r.CompanyName  LIKE "%${search}%") AND p.Active = 'Y' AND  r.CountryID="${CountryID}"
    GROUP BY p.ProductID
    Order BY Total_Clicks DESC
    limit ` +
            limit +
            " offset " +
            offset;
          let ProductDetails = await connection.query(ProductDetailsQuery, {
            type: QueryTypes.SELECT,
          });
          if (ProductDetails && ProductDetails.length > 0) {
            //!cuurency conversion
            let newArray;
            for (let i = 0; i < ProductDetails.length; i++) {
              const fromCurrency = ProductDetails[i].Currency;
              const selectCurrency = getCurrencyRates.filter(item => item.FromCurrency === fromCurrency);
              currencyRate = selectCurrency.length ? selectCurrency[0].Rate : null;
              if (selectCurrency.length > 0) {
                newArray = getCurrencyRates.filter(item => item.FromCurrency === fromCurrency)
                const convertedCurrency = newArray[0].ToCurrency;
                let Price = ProductDetails[i].Price;
                ProductDetails[i]["Currency"] = convertedCurrency;
                ProductDetails[i]["Price"] = parseFloat(
                  currencyRate * Price
                ).toFixed(2);
              }
            }

            res.status(200).json({
              status: true,
              total_records: productsCount[0].total_records,
              Product: ProductDetails,
              Category: ProductDetails[0].Category,
            });
          } else {
            res.status(200).json({
              status: false,
              message: "NO Product found",
              total_records: productsCount[0].total_records,
              Product: [],
            });
          }
        } else {
          res.status(200).json({
            status: true,
            total_records: productsCount[0].total_records,
            Product: [],
          });
        }
      }
    } else if (searchType == "2") {
      console.log("inside third")
      if (CategoryID) {
        let productsCount = await connection.query(
          `SELECT COUNT(p.ProductID) as total_records
        FROM (((product p
        LEFT JOIN subcategory s ON s.SubCategoryID = p.SubCategoryID)
        LEFT JOIN category c ON c.CategoryID = s.CategoryID)
        LEFT JOIN vendor e ON e.VendorID = p.VendorID)
        WHERE c.CategoryID='${CategoryID}' AND e.CountryID="${CountryID}"`, {
          type: QueryTypes.SELECT,
        }
        );
        if (
          productsCount[0].total_records &&
          productsCount[0].total_records > 0
        ) {
          let ProductDetailsQuery =
            `SELECT e.CompanyName,c.CategoryID,c.Category,s.SubCategory,p.* ,SUM(r.Rating) AS Total_Rating,g.Small,g.Medium,g.large
        FROM ((((((((product p
        LEFT JOIN vendor e ON e.VendorID = p.VendorID)
        LEFT JOIN subcategory s ON s.SubCategoryID = p.SubCategoryID)
        LEFT JOIN category c ON c.CategoryID = s.CategoryID)
        LEFT JOIN productvariantoption o ON o.ProductID IN (p.ProductID))
        LEFT JOIN productvariantoptionvalue v ON v.OptionID IN(o.OptionID))
        LEFT JOIN productimage i ON i.OptionValueID IN(v.OptionValueID))
        LEFT JOIN imagegallery g ON g.ImageGalleryID IN(i.ImageGalleryID))
        LEFT JOIN productreviewrating r ON r.ProductID IN (p.ProductID))
        WHERE c.CategoryID='${CategoryID}' AND (p.Title LIKE "%${search}%"||p.Description LIKE "%${search}%"||p.StoreName LIKE "%${search}%"||e.CompanyName  LIKE "%${search}%") AND p.Active = 'Y' AND i.MainImage = 'Y' AND e.CountryID="${CountryID}"
        GROUP BY p.ProductID
        Order BY Total_Rating DESC
        limit ` +
            limit +
            " offset " +
            offset;
          let ProductDetails = await connection.query(ProductDetailsQuery, {
            type: QueryTypes.SELECT,
          });
          if (ProductDetails && ProductDetails.length > 0) {
            //!cuurency conversion
            let newArray;
            // if (Region == "Bangladesh") {
            for (let i = 0; i < ProductDetails.length; i++) {
              const fromCurrency = ProductDetails[i].Currency;
              const selectCurrency = getCurrencyRates.filter(item => item.FromCurrency === fromCurrency);
              currencyRate = selectCurrency.length ? selectCurrency[0].Rate : null;
              if (selectCurrency.length > 0) {
                newArray = getCurrencyRates.filter(item => item.FromCurrency === fromCurrency)
                const convertedCurrency = newArray[0].ToCurrency;
                let Price = ProductDetails[i].Price;
                ProductDetails[i]["Currency"] = convertedCurrency;
                ProductDetails[i]["Price"] = parseFloat(
                  currencyRate * Price
                ).toFixed(2);

              }
            }
            res.status(200).json({
              status: true,
              total_records: productsCount[0].total_records,
              Product: ProductDetails,
              Category: ProductDetails[0].Category,
            });
          } else {
            res.status(200).json({
              status: false,
              message: "NO Product found",
              total_records: productsCount[0].total_records,
              Product: [],
            });
          }
        } else {
          res.status(200).json({
            status: true,
            total_records: productsCount[0].total_records,
            Product: [],
          });
        }
      } else if (CategoryID == null || CategoryID == "") {
        let productsCount = await connection.query(
          `SELECT COUNT(p.ProductID) as total_records
          FROM product p
          LEFT JOIN vendor e ON e.VendorID = p.VendorID
          WHERE e.CountryID="${CountryID}" `, {
          type: QueryTypes.SELECT,
        }
        );
        if (
          productsCount[0].total_records &&
          productsCount[0].total_records > 0
        ) {
          let ProductDetailsQuery =
            `SELECT e.CompanyName,c.CategoryID,c.Category,s.SubCategory,p.* ,SUM(r.Rating) AS Total_Rating,g.Small,g.Medium,g.large
        FROM ((((((((product p
          LEFT JOIN vendor e ON e.VendorID = p.VendorID)
        LEFT JOIN subcategory s ON s.SubCategoryID = p.SubCategoryID)
        LEFT JOIN category c ON c.CategoryID = s.CategoryID)
        LEFT JOIN productvariantoption o ON o.ProductID IN (p.ProductID))
        LEFT JOIN productvariantoptionvalue v ON v.OptionID IN(o.OptionID))
        LEFT JOIN productimage i ON i.OptionValueID IN(v.OptionValueID))
        LEFT JOIN imagegallery g ON g.ImageGalleryID IN(i.ImageGalleryID))
        LEFT JOIN productreviewrating r ON r.ProductID IN (p.ProductID))
        WHERE  (p.Title LIKE "%${search}%"||p.Description LIKE "%${search}%"||p.StoreName LIKE "%${search}%"||e.CompanyName  LIKE "%${search}%") AND i.MainImage = 'Y' AND p.Active = 'Y' AND e.CountryID="${CountryID}" 
        GROUP BY p.ProductID
        Order BY Total_Rating DESC
        limit ` +
            limit +
            " offset " +
            offset;
          let ProductDetails = await connection.query(ProductDetailsQuery, {
            type: QueryTypes.SELECT,
          });
          if (ProductDetails && ProductDetails.length > 0) {
            let newArray;
            //!cuurency conversion
            for (let i = 0; i < ProductDetails.length; i++) {
              const fromCurrency = ProductDetails[i].Currency;
              const selectCurrency = getCurrencyRates.filter(item => item.FromCurrency === fromCurrency);
              currencyRate = selectCurrency.length ? selectCurrency[0].Rate : null;
              if (selectCurrency.length > 0) {
                newArray = getCurrencyRates.filter(item => item.FromCurrency === fromCurrency)
                const convertedCurrency = newArray[0].ToCurrency;
                let Price = ProductDetails[i].Price;
                ProductDetails[i]["Currency"] = convertedCurrency;
                ProductDetails[i]["Price"] = parseFloat(
                  currencyRate * Price
                ).toFixed(2);
              }
            }
            res.status(200).json({
              status: true,
              total_records: productsCount[0].total_records,
              Product: ProductDetails,
              Category: ProductDetails[0].Category,
            });
          } else {
            res.status(200).json({
              status: false,
              message: "NO Product found",
              total_records: productsCount[0].total_records,
              Product: [],
            });
          }
        } else {
          res.status(200).json({
            status: true,
            total_records: productsCount[0].total_records,
            Product: [],
          });
        }
      }
    }
  } catch (err) {
    next(err);
    res.status(200).json({
      status: false,
      Product: [],
      error: err.message,
    });
    console.log(err.message);
  }
};
exports.viewProductDetailsBySubCategory = async (req, res, next) => {
  try {
    let Region = req.region;
    const currencyRate = req.currency_rate;
    let {
      limit,
      offset,
      sort
    } = req.body;
    let CountryID;
    limit = parseInt(limit);
    offset = parseInt(offset);
    offset = limit * offset;
    if (Region == "Bangladesh") {
      CountryID = "16";
    } else {
      CountryID = "226";
    }
    let productsCount = await connection.query(
      `SELECT COUNT(p.ProductID) as total_records 
    FROM product p
    left join vendor n on n.VendorID = p.VendorID
    WHERE p.SubCategoryID="${req.params.id}" AND n.CountryID="${CountryID}"`, {
      type: QueryTypes.SELECT,
    }
    );
    console.log(productsCount[0].total_records);
    if (productsCount[0].total_records && productsCount[0].total_records > 0) {
      let ProductDetailsQuery =
        `SELECT p.*,SUM(c.Clicks) AS Total_Clicks,g.Small,g.Medium,g.Large,AVG(r.Rating) AS AVG_RATING
            FROM (((((((product p
            LEFT JOIN productvariantoption o ON o.ProductID IN (p.ProductID))
            LEFT JOIN productvariantoptionvalue v ON v.OptionID IN(o.OptionID))
            LEFT JOIN productimage i ON i.OptionValueID IN(v.OptionValueID))
            LEFT JOIN imagegallery g ON g.ImageGalleryID IN(i.ImageGalleryID))
            LEFT JOIN productclicks c ON c.ProductID IN (p.ProductID))
            LEFT JOIN productreviewrating r ON r.ProductID IN (p.ProductID))
            left join vendor n on(n.VendorID = p.VendorID))
            WHERE p.SubCategoryID='${req.params.id}' AND n.CountryID="${CountryID}"
            GROUP BY p.ProductID
            Order BY Total_Clicks ${sort}
            limit ` +
        limit +
        " offset " +
        offset;
      let ProductDetails = await connection.query(ProductDetailsQuery, {
        type: QueryTypes.SELECT,
      });

      if (ProductDetails && ProductDetails.length > 0) {
        //!cuurency conversion
        if (Region == "Bangladesh") {
          for (let i = 0; i < ProductDetails.length; i++) {
            let Price = ProductDetails[i].Price;
            if (ProductDetails[i].Currency == "USD") {
              ProductDetails[i]["Currency"] = "BDT";
              ProductDetails[i]["Price"] = parseFloat(
                currencyRate * Price
              ).toFixed(2);
            }
          }
        } else if (Region == "USA") {
          for (let i = 0; i < ProductDetails.length; i++) {
            let Price = ProductDetails[i].Price;
            if (ProductDetails[i].Currency == "BDT") {
              ProductDetails[i]["Currency"] = "USD";
              ProductDetails[i]["Price"] = parseFloat(
                currencyRate * Price
              ).toFixed(2);
            }
          }
        } else {
          for (let i = 0; i < ProductDetails.length; i++) {
            let Price = ProductDetails[i].Price;
            ProductDetails[i]["Currency"] = "USD";
            ProductDetails[i]["Price"] = parseFloat(
              currencyRate * Price
            ).toFixed(2);
          }
        }
        res.status(200).json({
          status: true,
          total_records: productsCount[0].total_records,
          Product: ProductDetails,
        });
      } else {
        res.status(200).json({
          status: false,
          message: "NO Product found",
          total_records: productsCount[0].total_records,
          Product: [],
        });
      }
    } else {
      res.status(200).json({
        status: true,
        total_records: productsCount[0].total_records,
        Product: [],
      });
    }
  } catch (err) {
    next(err);
    res.status(200).json({
      status: false,
      profile: {},
      error: err.message,
    });
    console.log(err.message);
  }
};
exports.viewProductDetailsByCategory = async (req, res, next) => {
  try {
    let Region = req.region;
    const currencyRate = req.currency_rate;
    let {
      limit,
      offset,
      sort
    } = req.body;
    limit = parseInt(limit);
    offset = parseInt(offset);
    offset = limit * offset;
    let CountryID;
    if (Region == "Bangladesh") {
      CountryID = "16";
    } else {
      CountryID = "226";
    }
    let productsCount = await connection.query(
      `SELECT COUNT(p.ProductID) as total_records
     FROM (((product p
     LEFT JOIN subcategory s ON s.SubCategoryID = p.SubCategoryID)
     LEFT JOIN category c ON c.CategoryID = s.CategoryID)
     left JOIN vendor n on (n.VendorID = p.VendorID))
     WHERE c.CategoryID='${req.params.id}' AND n.CountryID="${CountryID}"`, {
      type: QueryTypes.SELECT,
    }
    );
    console.log(productsCount[0].total_records);

    if (productsCount[0].total_records && productsCount[0].total_records > 0) {
      let ProductDetailsQuery =
        `SELECT c.CategoryID,c.Category,s.SubCategory,p.* ,SUM(k.clicks) AS Total_Clicks
        FROM ((((product p
        LEFT JOIN subcategory s ON s.SubCategoryID = p.SubCategoryID)
        LEFT JOIN category c ON c.CategoryID = s.CategoryID)
        LEFT JOIN productclicks k ON k.ProductID IN (p.ProductID))
        left join vendor n on(n.VendorID = p.VendorID))
        WHERE c.CategoryID='${req.params.id}' AND n.CountryID="${CountryID}"
        GROUP BY p.ProductID
        Order BY Total_Clicks ${sort}
       limit ` +
        limit +
        " offset " +
        offset;
      let ProductDetails = await connection.query(ProductDetailsQuery, {
        type: QueryTypes.SELECT,
      });

      if (ProductDetails && ProductDetails.length > 0) {
        //!cuurency conversion
        if (Region == "Bangladesh") {
          for (let i = 0; i < ProductDetails.length; i++) {
            let Price = ProductDetails[i].Price;
            if (ProductDetails[i].Currency == "USD") {
              ProductDetails[i]["Currency"] = "BDT";
              ProductDetails[i]["Price"] = parseFloat(
                currencyRate * Price
              ).toFixed(2);
            }
          }
        } else if (Region == "USA") {
          for (let i = 0; i < ProductDetails.length; i++) {
            let Price = ProductDetails[i].Price;
            if (ProductDetails[i].Currency == "BDT") {
              ProductDetails[i]["Currency"] = "USD";
              ProductDetails[i]["Price"] = parseFloat(
                currencyRate * Price
              ).toFixed(2);
            }
          }
        } else {
          for (let i = 0; i < ProductDetails.length; i++) {
            let Price = ProductDetails[i].Price;
            ProductDetails[i]["Currency"] = "USD";
            ProductDetails[i]["Price"] = parseFloat(
              currencyRate * Price
            ).toFixed(2);
          }
        }

        res.status(200).json({
          status: true,
          total_records: productsCount[0].total_records,
          Product: ProductDetails,
        });
      } else {
        res.status(200).json({
          status: false,
          message: "NO Product found",
          total_records: productsCount[0].total_records,
          Product: [],
        });
      }
    } else {
      res.status(200).json({
        status: true,
        total_records: productsCount[0].total_records,
        Product: [],
      });
    }
  } catch (err) {
    next(err);
    res.status(200).json({
      status: false,
      profile: {},
      error: err.message,
    });
    console.log(err.message);
  }
};

// exports.addProductDetailsForm1 = async (req, res, next) => {
//   let transaction; //!transaction variable declare here
//   try {
//     let {
//       VendorID,
//       SubCategoryID,
//       Title,
//       Description,
//       SpecialInstruction,
//       ReturnPolicy,
//       Currency,
//       CostPrice,
//       Price,
//       Quantity1,
//       PriceQuantity1,
//       Quantity2,
//       PriceQuantity2,
//       Quantity3,
//       PriceQuantity3,
//       PromotionPrice,
//       PromotionRate,
//       PromotionStartDate,
//       PromotionEndDate,
//       Weight,
//       Height,
//       Length,
//       Width,
//       AllowStorePickup,
//       ShippingAvailable,
//       ShippingGlobal,
//       ShippingByAdmin,
//       ShippingByVendor,
//       ShippingCostAdmin,
//       ShippingCostVendor,
//       ReviewedByAdmin,
//       TaxVATApply,
//       LockEdit,
//       Active,
//       StoreName,
//       Variations,
//       ShippingCostVendorCountry,
//       ShippingCostKiloVendorCountry,
//       CityShippingCost,
//       FreeProductReturn,
//       ShippingCostVendorInternational,
//       ShippingCostKiloVendorInternational,
//       ProductCodStatus
//     } = req.body;
//     console.log("==========================================>", Active);
//     transaction = await connection.transaction(); //!transaction use here
//     let addProduct;
//     let getCityID;
//     let ProductID;
//     let StoreOptionName = [];
//     let CityShipping = "Y";
//     let checkIfVendorExists = await vendorIDCheck(VendorID, transaction);
//     console.log(checkIfVendorExists);
//     if (checkIfVendorExists && checkIfVendorExists == "1") {
//       let checkIfSubCategoryExists = await subcategoryIDCheck(
//         SubCategoryID,
//         transaction
//       );
//       if (checkIfSubCategoryExists && checkIfSubCategoryExists == "1") {
//         StoreName = StoreName.trim(); // new changess
//         let checkProductTitleExists = await productTitleCheck(
//           Title,
//           VendorID,
//           transaction
//         );
//         if (checkProductTitleExists && checkProductTitleExists == "0") {
//           let costPrice = parseFloat(CostPrice).toFixed(2);
//           let price = parseFloat(Price).toFixed(2);
//           let priceQuantity1 = parseFloat(PriceQuantity1).toFixed(2);
//           let priceQuantity2 = parseFloat(PriceQuantity2).toFixed(2);
//           let priceQuantity3 = parseFloat(PriceQuantity3).toFixed(2);
//           let promotionPrice = parseFloat(PromotionPrice).toFixed(2);
//           let promotionRate = parseFloat(PromotionRate).toFixed(2);
//           let weight = parseFloat(Weight).toFixed(2);
//           let length = parseFloat(Length).toFixed(2);
//           let width = parseFloat(Width).toFixed(2);
//           let height = parseFloat(Height).toFixed(2);
//           let quantity1 = Math.trunc(Quantity1);
//           let quantity2 = Math.trunc(Quantity2);
//           let quantity3 = Math.trunc(Quantity3);

//           //!Insert into Product table starts here
//           try {
//             let insertProductQuery = `insert into product ( VendorID, SubCategoryID,Title,StoreName, Description, SpecialInstruction,ReturnPolicy, Currency,CostPrice, Price ,Quantity1,PriceQuantity1,Quantity2 ,PriceQuantity2, Quantity3,  PriceQuantity3,PromotionPrice,  PromotionRate,  PromotionStartDate,  PromotionEndDate, Weight,Height, Length,  Width,  AllowStorePickup,   ShippingAvailable,  ShippingGlobal,  ShippingByAdmin,  ShippingByVendor,  ShippingCostAdmin, ShippingCostVendor, ReviewedByAdmin,TaxVATApply, LockEdit, Active,ProductCodStatus)`;
//             insertProductQuery += ` values ("${VendorID}","${SubCategoryID}","${Title}","${StoreName}", "${Description}","${SpecialInstruction}","${ReturnPolicy}","${Currency}","${costPrice}","${price}","${quantity1}", "${priceQuantity1}","${quantity2}","${priceQuantity2}","${quantity3}","${priceQuantity3}","${promotionPrice}","${promotionRate}", "${PromotionStartDate}","${PromotionEndDate}","${weight}", "${height}","${length}","${width}","${AllowStorePickup}","${ShippingAvailable}","${ShippingGlobal}","${ShippingByAdmin}", "${ShippingByVendor}","${ShippingCostAdmin}","${ShippingCostVendor}","${ReviewedByAdmin}","${TaxVATApply}","${LockEdit}","${Active}","${ProductCodStatus}") `;

//             addProduct = await connection.query(insertProductQuery, {
//               transaction,
//             });
//           } catch (err) {
//             console.log(
//               err.message,
//               "error here------------------------------------------------------------------------------"
//             );
//             if (transaction) await transaction.rollback();
//             res.status(200).json({
//               status: false,
//               Product: [],
//               error: err.message,
//             });
//           }
//           if (addProduct) {
//             //!Insert into Product City table starts here
//             getCityID = await connection.query(
//               `SELECT * FROM vendorstore WHERE VendorID="${VendorID}" AND StoreName="${StoreName}" `, {
//               type: QueryTypes.SELECT,
//               transaction,
//             }
//             );
//             let VendorProductCity = getCityID[0].CityID;
//             ProductID = addProduct[0];

//             let insertProductCityQuery = `insert into productcity ( ProductID,CityID) values(?,?)`;
//             let insertProductCity = await connection.query(
//               insertProductCityQuery, {
//               replacements: [ProductID, VendorProductCity],
//               type: QueryTypes.INSERT,
//               transaction,
//             }
//             );
//             if (insertProductCity) {
//               //!Insert into Product Country table starts here
//               const getCountryID = await connection.query(
//                 `SELECT * FROM vendorstore WHERE VendorID="${VendorID}" AND StoreName="${StoreName}" `, {
//                 type: QueryTypes.SELECT,
//                 transaction,
//               }
//               );
//               console.log(getCountryID[0].CountryID);
//               const VendorProductCountry = getCountryID[0].CountryID;
//               let ProductID = addProduct[0];
//               let insertProductCountryQuery = `insert into productcountry ( ProductID, CountryID) values(?,?)`;
//               let insertProductCountry = await connection.query(
//                 insertProductCountryQuery, {
//                 replacements: [ProductID, VendorProductCountry],
//                 type: QueryTypes.INSERT,
//                 transaction,
//               }
//               );

//               if (insertProductCountry) {
//                 console.log(Variations.length);
//                 //!Insert into Product Variant Option table starts here
//                 for (let i = 0; i < Variations.length; i++) {
//                   StoreOptionName.push(Variations[i]);
//                 }

//                 let insertProductVariantOptionBulkQuery = `insert into productvariantoption ( ProductID ,OptionName) values  `;
//                 for (let i = 0; i < StoreOptionName.length; i++) {
//                   if (i == StoreOptionName.length - 1) {
//                     insertProductVariantOptionBulkQuery += `('${ProductID}', '${StoreOptionName[i]}')`;
//                   } else {
//                     insertProductVariantOptionBulkQuery += `('${ProductID}', '${StoreOptionName[i]}'),`;
//                   }
//                 }
//                 insertProductVariantOption = await connection.query(
//                   insertProductVariantOptionBulkQuery, {
//                   type: QueryTypes.INSERT,
//                   transaction,
//                 }
//                 );

//                 if (insertProductVariantOption) {
//                   //!below this cod status
//                   let updateVendorAndProductsCodStatus =
//                     await connection.query(
//                       `UPDATE product SET ProductCodStatus ="${ProductCodStatus}",FreeProductReturn="${FreeProductReturn}" WHERE ProductID = "${ProductID}"
//                        `, {
//                       transaction,
//                     }
//                     );
//                   if (updateVendorAndProductsCodStatus) {
//                     //!below this shipping----------------------------------------------------
//                     if (ShippingByVendor == "N") {
//                       CityShipping = "N";
//                     }
//                     if (CityShippingCost.length == 0) {
//                       CityShipping = "N";
//                     }
//                     let insertCountryShipping = false;

//                     if (ShippingByVendor == "Y") {
//                       let insertCountryShippingCostQuery = `INSERT INTO shippingcostvendorcountry( ProductID, CountryID, ShippingCostVendorCountry,ShippingCostKiloVendorCountry,ShippingCostVendorInternational,ShippingCostKiloVendorInternational) values(?,?,?,?,?,?)`;
//                       let insertCountryShippingCost = await connection.query(
//                         insertCountryShippingCostQuery, {
//                         replacements: [
//                           ProductID,
//                           VendorProductCountry,
//                           ShippingCostVendorCountry,
//                           ShippingCostKiloVendorCountry,
//                           ShippingCostVendorInternational,
//                           ShippingCostKiloVendorInternational,
//                         ],
//                         transaction,
//                       }
//                       );
//                       if (insertCountryShippingCost) {
//                         insertCountryShipping = true;
//                       }
//                     }
//                     if (ShippingByVendor == "N") {
//                       insertCountryShipping = true;
//                     }

//                     if (insertCountryShipping) {
//                       //inside
//                       let insertCityShipping = false;
//                       console.log(CityShipping, "CityShipping");
//                       if (CityShipping == "Y") {
//                         let insertCityShippingCostQuery = `INSERT INTO shippingcostvendorcity( ProductID, CityID, ShippingCostVendorCity,ShippingCostKiloVendorCity) values  `;
//                         for (let i = 0; i < CityShippingCost.length; i++) {
//                           if (i == CityShippingCost.length - 1) {
//                             insertCityShippingCostQuery += `('${ProductID}', '${CityShippingCost[i].CityID}','${CityShippingCost[i].ShippingCostVendorCity}','${CityShippingCost[i].ShippingCostKiloVendorCity}')`;
//                           } else {
//                             insertCityShippingCostQuery += `('${ProductID}', '${CityShippingCost[i].CityID}','${CityShippingCost[i].ShippingCostVendorCity}','${CityShippingCost[i].ShippingCostKiloVendorCity}'),`;
//                           }
//                         }
//                         let insertCityShippingCost = await connection.query(
//                           insertCityShippingCostQuery, {
//                           type: QueryTypes.INSERT,
//                           transaction,
//                         }
//                         );
//                         if (insertCityShippingCost) {
//                           insertCityShipping = true;
//                         }
//                       }
//                       if (CityShipping == "N") {
//                         insertCityShipping = true;
//                       }
//                       if (insertCityShipping) {
//                         const getProductApprovalStatus =
//                           await connection.query(
//                             `SELECT * FROM vendor WHERE VendorID="${VendorID}"  `, {
//                             type: QueryTypes.SELECT,
//                             transaction,
//                           }
//                           );
//                         let updateProductActiveStatus;
//                         if (
//                           getProductApprovalStatus[0].ProductApproval == "Y"
//                         ) {
//                           // const updateProductApprovalStatusInVendorTable =
//                           //   await connection.query(
//                           //     `UPDATE vendor SET ProductApproval="N" WHERE VendorID="${VendorID}"  `, {
//                           //       transaction,
//                           //     }
//                           //   );
//                           updateProductActiveStatus =
//                             await connection.query(
//                               `UPDATE product SET Active="N" WHERE ProductID="${ProductID}"  `, {
//                               transaction,
//                             }
//                             );
//                         } else if (
//                           getProductApprovalStatus[0].ProductApproval == "N"
//                         ) {
//                           updateProductActiveStatus =
//                             await connection.query(
//                               `UPDATE product SET Active="Y" WHERE ProductID="${ProductID}"  `, {
//                               transaction,
//                             }
//                             );

//                           // const updateProductApprovalStatusInVendorTable =
//                           //   await connection.query(
//                           //     `UPDATE vendor SET ProductApproval="Y" WHERE VendorID="${VendorID}"  `, {
//                           //       transaction,
//                           //     }
//                           //   );
//                         }
//                         if (transaction) await transaction.commit(); //!final commit
//                         res.status(200).json({
//                           status: true,
//                           message: "Product Form 1 Details Added Successfully",
//                           ProductID: ProductID,
//                         });
//                       } else {
//                         if (transaction) await transaction.rollback();
//                         res.status(200).json({
//                           status: false,
//                           message: "Error while adding city shipping cost details",
//                         });
//                       }
//                     } else {
//                       if (transaction) await transaction.rollback();
//                       res.status(200).json({
//                         status: false,
//                         message: "Error while adding country shipping cost details",
//                       });
//                     }
//                   } else {
//                     if (transaction) await transaction.rollback();
//                     res.status(200).json({
//                       status: false,
//                       message: "Unable to update Product COD status",
//                     });
//                   }
//                 } else {
//                   if (transaction) await transaction.rollback();
//                   res.status(200).json({
//                     status: false,
//                     message: "Error while adding Product Variant Option",
//                   });
//                 }

//                 //!Insert into Product Variant table ends here
//               } else {
//                 if (transaction) await transaction.rollback();
//                 res.status(200).json({
//                   status: false,
//                   message: "Error while adding Product country",
//                 });
//               }
//               //!Insert into Product Country table ends here
//             } else {
//               if (transaction) await transaction.rollback();
//               res.status(200).json({
//                 status: false,
//                 message: "Error while adding Product City",
//               });
//             }
//             //!Insert into Product City table ends here
//           } else {
//             if (transaction) await transaction.rollback();
//             res.status(200).json({
//               status: false,
//               message: "Error while adding Product Details",
//             });
//           }
//         } else if (
//           checkProductTitleExists &&
//           checkProductTitleExists == "1"
//         ) {
//           if (transaction) await transaction.rollback();
//           res.status(200).json({
//             status: false,
//             message: "Product already registered with this Title",
//             Product: [],
//           });
//         }
//       } else if (checkIfSubCategoryExists && checkIfSubCategoryExists == "0") {
//         if (transaction) await transaction.rollback();
//         res.status(200).json({
//           status: false,
//           message: "SubCategory does not exist",
//           SubCategory: [],
//         });
//       }
//     } else if (checkIfVendorExists && checkIfVendorExists == "0") {
//       if (transaction) await transaction.rollback();
//       res.status(200).json({
//         status: false,
//         message: "Vendor does not have Store",
//         Vendor: [],
//       });
//     }
//   } catch (err) {
//     if (transaction) await transaction.rollback();
//     next(err);
//     res.status(200).json({
//       status: false,
//       Product: {},
//       error: err.message,
//     });
//   }
// };





//below this
/*
exports.viewProductDetailsBySubCategory = async (req, res, next) => {
  try {
    let {
      limit,
      offset,
      sort,
    } = req.body;
    limit = parseInt(limit);
    offset = parseInt(offset);
    offset = limit * offset;
    let productsCount = await connection.query(`SELECT COUNT(ProductID) as total_records FROM product WHERE SubCategoryID='${req.params.id}'`, {
      type: QueryTypes.SELECT
    });
    if (productsCount && productsCount.length > 0) {
      let ProductDetailsQuery = `SELECT p.*,SUM(c.Clicks) AS Total_Clicks
      FROM (product p
      INNER JOIN productclicks c ON c.ProductID IN (p.ProductID))
      WHERE p.SubCategoryID='${req.params.id}'
      GROUP BY p.ProductID
      Order BY Total_Clicks ${sort}
       limit ` +
        limit +
        " offset " +
        offset;
      let ProductDetails = await connection.query(ProductDetailsQuery, {
        type: QueryTypes.SELECT
      });

      if (ProductDetails && ProductDetails.length > 0) {
        res.status(200).json({
          status: true,
          total_records: productsCount[0].total_records,
          Product: ProductDetails
        });
      } else {
        res.status(200).json({
          status: false,
          message: "NO Product found",
          total_records: productsCount[0].total_records,
          Product: [],
        });
      }
    }
  } catch (err) {
    next(err);
    res.status(200).json({
      status: false,
      profile: {},
      error: err.message,
    });
    console.log(err.message);
  }
};
exports.viewProductDetailsByCategory = async (req, res, next) => {
  try {
    let {
      limit,
      offset,
      sort
    } = req.body;
    limit = parseInt(limit);
    offset = parseInt(offset);
    offset = limit * offset;
    let productsCount = await connection.query(`SELECT COUNT(ProductID) as total_records
     FROM ((product p
     LEFT JOIN subcategory s ON s.SubCategoryID = p.SubCategoryID)
     LEFT JOIN category c ON c.CategoryID = s.CategoryID)
     WHERE c.CategoryID='${req.params.id}'`, {
      type: QueryTypes.SELECT
    });
    if (productsCount && productsCount.length > 0) {
      let ProductDetailsQuery = `SELECT c.CategoryID,c.Category,s.SubCategory,p.* ,SUM(k.clicks) AS Total_Clicks
        FROM (((product p
        LEFT JOIN subcategory s ON s.SubCategoryID = p.SubCategoryID)
        LEFT JOIN category c ON c.CategoryID = s.CategoryID)
        LEFT JOIN productclicks k ON k.ProductID IN (p.ProductID))
        WHERE c.CategoryID='${req.params.id}'
        GROUP BY p.ProductID
        Order BY Total_Clicks ${sort}
       limit ` +
        limit +
        " offset " +
        offset;
      let ProductDetails = await connection.query(ProductDetailsQuery, {
        type: QueryTypes.SELECT
      });

      if (ProductDetails && ProductDetails.length > 0) {
        res.status(200).json({
          status: true,
          total_records: productsCount[0].total_records,
          Product: ProductDetails
        });
      } else {
        res.status(200).json({
          status: false,
          message: "NO Product found",
          total_records: productsCount[0].total_records,
          Product: [],
        });
      }
    }
  } catch (err) {
    next(err);
    res.status(200).json({
      status: false,
      profile: {},
      error: err.message,
    });
    console.log(err.message);
  }
};/*
/*
exports.viewProductById = async (req, res, next) => {
  try {
    let ProductDetails = await connection.query(
      `SELECT *  FROM product WHERE ProductID='${req.params.id}' `,
      {
        type: QueryTypes.SELECT,
      }
    );

    if (ProductDetails && ProductDetails.length > 0) {
      res.status(200).json({
        status: true,
        Product: ProductDetails,
      });
    } else {
      res.status(200).json({
        status: false,
        message: "Product does not exist",
        Product: [],
      });
    }
  } catch (err) {
    next(err);
    res.status(200).json({
      status: false,
      profile: {},
      error: err.message,
    });
    console.log(err.message);
  }
};
exports.deleteProductById = async (req, res, next) => {
  try {
    const id = req.params.id;
    console.log(id);

    let checkCategory = await connection.query(
      `select * from product where ProductID = "${id}" `,
      {
        type: QueryTypes.SELECT,
      }
    );
    if (checkCategory && checkCategory.length > 0) {
      console.log("--------------");
      let deleteProduct = await connection.query(
        `DELETE FROM product WHERE ProductID="${id}" `,
        {
          type: QueryTypes.DELETE,
        }
      );
      res.status(200).json({
        status: true,
        message: `Product deleted successfully`,
      });
    } else {
      console.log("*********");
      res.status(200).json({
        status: false,
        message: `Product does not exist`,
      });
    }
  } catch (err) {
    next(err);
    res.status(200).json({
      status: false,
      data: {},
      error: err.message,
    });
    console.log(err.message);
  }
};
exports.addProductCountry = async (req, res, next) => {
  try {
    const { ProductID } = req.body;

    let checkIfProductExists = await productIDIDCheck(ProductID);
    console.log(checkIfProductExists);
    if (checkIfProductExists && checkIfProductExists == "1") {
      let checkProductCountryExist = await checkProductCountryExists(ProductID);
      console.log(checkProductCountryExist);
      if (checkProductCountryExist && checkProductCountryExist == "0") {
        const getVendorID = await connection.query(
          `SELECT * FROM product WHERE ProductID='${ProductID}' `,
          {
            type: QueryTypes.SELECT,
          }
        );
        console.log(getVendorID[0].VendorID);
        if (getVendorID && getVendorID.length > 0) {
          const getCountryID = await connection.query(
            `SELECT * FROM vendorstore WHERE VendorID='${getVendorID[0].VendorID}' `,
            {
              type: QueryTypes.SELECT,
            }
          );
          console.log(getCountryID[0].CountryID);
          let insertProductCountryQuery = `insert into productcountry ( ProductID, CountryID) values(?,?)`;
          let insertProductCountry = await connection.query(
            insertProductCountryQuery,
            {
              replacements: [ProductID, getCountryID[0].CountryID],
            }
          );
          if (insertProductCountry) {
            res.status(200).json({
              status: true,
              message: "Product Country added successfully",
            });
          } else {
            res.status(200).json({
              status: false,
              message: "Error while adding Product country",
            });
          }
        } else {
          res.status(200).json({
            status: false,
            message: "Vendor ID does not found",
            Vendor: [],
          });
        }
      } else if (checkProductCountryExist && checkProductCountryExist == "1") {
        res.status(200).json({
          status: false,
          message: "Product Country already registered",
          ProductCountry: [],
        });
      }
    } else if (checkIfProductExists && checkIfProductExists == "0") {
      res.status(200).json({
        status: false,
        message: "Product does not exist",
        Product: [],
      });
    }
  } catch (err) {
    next(err);
    res.status(200).json({
      status: false,
      profile: {},
      error: err.message,
    });
  }
};
let productIDIDCheck = async (ProductID) => {
  try {
    let user = await connection.query(
      `select * from product where ProductID = '${ProductID}'`,
      {
        type: QueryTypes.SELECT,
      }
    );
    if (user && user.length > 0) {
      return "1";
    } else {
      return "0";
    }
  } catch (err) {
    console.log(err.message);
    return null;
  }
};
let checkProductCountryExists = async (ProductID) => {
  try {
    let user = await connection.query(
      `select * from productcountry where ProductID = '${ProductID}'`,
      {
        type: QueryTypes.SELECT,
      }
    );
    if (user && user.length > 0) {
      return "1";
    } else {
      return "0";
    }
  } catch (err) {
    console.log(err.message);
    return null;
  }
};
exports.showProductCountryById = async (req, res, next) => {
  try {
    const id = req.params.id;
    console.log("---------------", id);
    let viewProductCountryQuery = `SELECT  p.ProductID,d.Title,c.CountryID,c.Country
                FROM (( productcountry p
                INNER JOIN product d ON p.ProductID = d.ProductID)
                INNER JOIN country c  ON p.CountryID = c.CountryID)
                WHERE p.ID=${id}`;
    console.log(viewProductCountryQuery);
    let viewProductCountry = await connection.query(viewProductCountryQuery, {
      type: QueryTypes.SELECT,
    });
    if (viewProductCountry && viewProductCountry.length > 0) {
      res.status(200).json({
        status: true,
        ProductCountry: viewProductCountry,
      });
    } else {
      res.status(200).json({
        status: false,
        message: "No Product Country found",
        ProductCountry: [],
      });
    }
  } catch (err) {
    next(err);
    res.status(200).json({
      status: false,
      profile: {},
      error: err.message,
    });
  }
};
exports.addProductCity = async (req, res, next) => {
  try {
    const { ProductID } = req.body;

    let checkIfProductExists = await productIDIDCheck(ProductID);
    console.log(checkIfProductExists);
    if (checkIfProductExists && checkIfProductExists == "1") {
      let checkIfProductCityExist = await checkProductCityExists(ProductID);
      console.log(checkIfProductCityExist);
      if (checkIfProductCityExist && checkIfProductCityExist == "0") {
        const getVendorID = await connection.query(
          `SELECT * FROM product WHERE ProductID='${ProductID}' `,
          {
            type: QueryTypes.SELECT,
          }
        );
        console.log(getVendorID[0].VendorID);
        if (getVendorID && getVendorID.length > 0) {
          const getCityID = await connection.query(
            `SELECT * FROM vendorstore WHERE VendorID='${getVendorID[0].VendorID}' `,
            {
              type: QueryTypes.SELECT,
            }
          );
          console.log(getCityID[0].CityID);
          if (getCityID && getCityID.length > 0) {
            let insertProductCityQuery = `insert into productcity ( ProductID, CityID) values(?,?)`;
            let insertProductCity = await connection.query(
              insertProductCityQuery,
              {
                replacements: [ProductID, getCityID[0].CityID],
              }
            );
            if (insertProductCity) {
              res.status(200).json({
                status: true,
                message: "Product City added successfully",
              });
            } else {
              res.status(200).json({
                status: false,
                message: "Error while adding Product City",
              });
            }
          }
        }
      } else if (checkIfProductExists && checkIfProductExists == "1") {
        res.status(200).json({
          status: false,
          message: "Product City already Registered",
          ProductCity: [],
        });
      }
    } else if (checkIfProductExists && checkIfProductExists == "0") {
      res.status(200).json({
        status: false,
        message: "Product does not exist",
        Product: [],
      });
    }
  } catch (err) {
    next(err);
    res.status(200).json({
      status: false,
      profile: {},
      error: err.message,
    });
  }
};
exports.showProductCityById = async (req, res, next) => {
  try {
    const id = req.params.id;
    console.log("---------------", id);
    let viewProductCityQuery = `SELECT  p.ProductID,d.Title,c.CityID,c.City
                FROM (( productcity p
                INNER JOIN product d ON p.ProductID = d.ProductID)
                INNER JOIN city c  ON p.CityID = c.CityID)
                WHERE p.ID=${id}`;

    let viewProductCity = await connection.query(viewProductCityQuery, {
      type: QueryTypes.SELECT,
    });
    console.log(viewProductCity);
    if (viewProductCity && viewProductCity.length > 0) {
      res.status(200).json({
        status: true,
        ProductCity: viewProductCity,
      });
    } else {
      res.status(200).json({
        status: false,
        message: "No Product City found",
        ProductCity: [],
      });
    }
  } catch (err) {
    next(err);
    res.status(200).json({
      status: false,
      profile: {},
      error: err.message,
    });
  }
};
exports.insertImageGallery = async (req, res, next) => {
  try {
    const { UserID } = req.body;
    let Small, Medium, Large;

    console.log(req.files.Small[0].path);
    console.log(req.files.Medium[0].path);
    console.log(req.files.Medium[0].path);
    Small = req.files.Small[0].path;
    Medium = req.files.Medium[0].path;
    Large = req.files.Large[0].path;
    let checkIfUserExists = await userIDCheck(UserID);
    console.log(checkIfUserExists);
    if (checkIfUserExists && checkIfUserExists == "1") {
      let insertimagesQuery = `insert into imagegallery ( UserID , Small,Medium,Large) values (?,?,?,?)`;
      let addImages = await connection.query(insertimagesQuery, {
        replacements: [UserID, Small, Medium, Large],
      });
      if (addImages) {
        res.status(200).json({
          status: true,
          message: "Images added successfully",
        });
      } else {
        res.status(200).json({
          status: false,
          message: "Error while adding Images",
        });
      }
    } else if (checkIfUserExists && checkIfUserExists == "0") {
      res.status(200).json({
        status: false,
        message: "User not found",
        User: [],
      });
    }
  } catch (err) {
    next(err);
    res.status(200).json({
      status: false,
      Category: {},
      error: err.message,
    });
  }
};
let userIDCheck = async (UserID) => {
  try {
    let user = await connection.query(
      `select * from profile where UserID = '${UserID}'`,
      {
        type: QueryTypes.SELECT,
      }
    );
    console.log(user);
    if (user && user.length > 0) {
      return "1";
    } else {
      return "0";
    }
  } catch (error) {
    return null;
  }
};
exports.viewImageGalleryById = async (req, res, next) => {
  try {
    let ImageGalleryDetails = await connection.query(
      `SELECT *  FROM imagegallery WHERE ImageGalleryID='${req.params.id}' `,
      {
        type: QueryTypes.SELECT,
      }
    );

    if (ImageGalleryDetails && ImageGalleryDetails.length > 0) {
      res.status(200).json({
        status: true,
        ImageGallery: ImageGalleryDetails,
      });
    } else {
      res.status(200).json({
        status: false,
        message: "User Images does not exist",
        ImageGallery: [],
      });
    }
  } catch (err) {
    next(err);
    res.status(200).json({
      status: false,
      profile: {},
      error: err.message,
    });
    console.log(err.message);
  }
};
exports.updateImageGalleryById = async (req, res, next) => {
  try {
    const id = req.params.id;
    console.log(id);
    var checkImageGalleryID = await connection.query(
      `select * from imagegallery where ImageGalleryID = '${id}' `,
      {
        type: QueryTypes.SELECT,
      }
    );
    if (checkImageGalleryID && checkImageGalleryID.length > 0) {
      let Small;
      let Medium;
      let Large;

      console.log("-----------------------------");
      console.log(req.files);

      if (Object.keys(req.files).length > 0) {
        if (req.files.Small && req.files.Small.length > 0) {
          Small = req.files.Small[0].path;
        } else {
          Small = checkImageGalleryID[0].Small;
        }
        if (req.files.Medium && req.files.Medium.length > 0) {
          Medium = req.files.Medium[0].path;
        } else {
          Medium = checkImageGalleryID[0].Medium;
        }
        if (req.files.Large && req.files.Large.length > 0) {
          Large = req.files.Large[0].path;
        } else {
          Large = checkImageGalleryID[0].Large;
        }
      } else {
        Small = checkImageGalleryID[0].Small;
        Medium = checkImageGalleryID[0].Medium;
        Large = checkImageGalleryID[0].Large;
      }

      console.log(Small);
      console.log(Medium);
      console.log(Large);
      let LastUpdate = new Date().toISOString().slice(0, 19).replace("T", " ");

      let updateImageGalleryQuery = `UPDATE  imagegallery SET Small=?,Medium=?,Large=?,LastUpdate=? WHERE ImageGalleryID  = "${id}"   `;
      let updateImageGallery = await connection.query(updateImageGalleryQuery, {
        replacements: [Small, Medium, Large, LastUpdate],
      });
      if (updateImageGallery) {
        res.status(200).json({
          status: true,
          message: `ImageGallery updated Successfully`,
        });
      }
    } else {
      res.status(200).json({
        status: false,
        message: `ImageGallery does not found`,
      });
    }
  } catch (err) {
    next(err);
    console.log(err.message);
    res.status(200).json({
      status: false,
      profile: {},
      error: err.message,
    });
    console.log(err);
  }
};
exports.deleteImageGalleryById = async (req, res, next) => {
  try {
    const id = req.params.id;
    console.log(id);

    let checkImagegallery = await connection.query(
      `select * from imagegallery where ImageGalleryID = "${id}" `,
      {
        type: QueryTypes.SELECT,
      }
    );
    if (checkImagegallery && checkImagegallery.length > 0) {
      console.log("--------------");
      let deleteImageGallery = await connection.query(
        `DELETE FROM imagegallery WHERE ImageGalleryID="${id}" `,
        {
          type: QueryTypes.DELETE,
        }
      );
      res.status(200).json({
        status: true,
        message: `Image Gallery deleted successfully`,
      });
    } else {
      console.log("*********");
      res.status(200).json({
        status: false,
        message: `Image Gallery does not exist`,
      });
    }
  } catch (err) {
    next(err);
    res.status(200).json({
      status: false,
      data: {},
      error: err.message,
    });
    console.log(err.message);
  }
};
exports.insertProductVariantOption = async (req, res, next) => {
  try {
    const { ProductID, OptionName } = req.body;
    let checkIfProductExists = await productIDIDCheck(ProductID);
    console.log(checkIfProductExists);
    if (checkIfProductExists && checkIfProductExists == "1") {
      let insertProductVariantOptionQuery = `insert into productvariantoption ( ProductID ,OptionName) values (?,?)`;
      let insertProductVariantOption = await connection.query(
        insertProductVariantOptionQuery,
        {
          replacements: [ProductID, OptionName],
        }
      );
      if (insertProductVariantOption) {
        res.status(200).json({
          status: true,
          message: "Product Variant Option added successfully",
        });
      } else {
        res.status(200).json({
          status: false,
          message: "Error while Product Variant Option",
        });
      }
    } else if (checkIfProductExists && checkIfProductExists == "0") {
      res.status(200).json({
        status: false,
        message: "Prodcut does not exist",
        Product: [],
      });
    }
  } catch (err) {
    next(err);
    res.status(200).json({
      status: false,
      Category: {},
      error: err.message,
    });
  }
};
exports.viewProductVariantOptionById = async (req, res, next) => {
  try {
    const id = req.params.id;
    console.log("---------------", id);
    let viewProductVariantOptionQuery = `SELECT  p.*,d.Title AS ProductName
                FROM ( productvariantoption p
                INNER JOIN product d ON p.ProductID = d.ProductID)
                WHERE p.OptionID=${id}`;
    let viewProductVariantOption = await connection.query(
      viewProductVariantOptionQuery,
      {
        type: QueryTypes.SELECT,
      }
    );
    if (viewProductVariantOption && viewProductVariantOption.length > 0) {
      res.status(200).json({
        status: true,
        ProductVariantOption: viewProductVariantOption,
      });
    } else {
      res.status(200).json({
        status: false,
        message: "No Product Variant Option found",
        ProductVariantOption: [],
      });
    }
  } catch (err) {
    next(err);
    res.status(200).json({
      status: false,
      profile: {},
      error: err.message,
    });
  }
};
exports.insertProductVariantOptionValue = async (req, res, next) => {
  try {
    const { OptionID, OptionValue } = req.body;

    let checkOptionIdExists = await checkOptionID(OptionID);
    console.log(checkOptionIdExists);
    if (checkOptionIdExists && checkOptionIdExists == "1") {
      let insertProductVariantOptionQuery = `insert into productvariantoptionvalue ( OptionID  ,OptionValue ) values (?,?)`;
      let insertProductVariantOption = await connection.query(
        insertProductVariantOptionQuery,
        {
          replacements: [OptionID, OptionValue],
        }
      );
      if (insertProductVariantOption) {
        res.status(200).json({
          status: true,
          message: "Product Variant Option added successfully",
        });
      } else {
        res.status(200).json({
          status: false,
          message: "Error while Product Variant Option",
        });
      }
    } else if (checkOptionIdExists && checkOptionIdExists == "0") {
      res.status(200).json({
        status: false,
        message: "Product Variant Option does not exist",
        ProductOption: [],
      });
    }
  } catch (err) {
    next(err);
    res.status(200).json({
      status: false,
      Category: {},
      error: err.message,
    });
  }
};
let checkOptionID = async (OptionID) => {
  try {
    let user = await connection.query(
      `select * from productvariantoption where OptionID = '${OptionID}'`,
      {
        type: QueryTypes.SELECT,
      }
    );
    console.log(user);
    if (user && user.length > 0) {
      return "1";
    } else {
      return "0";
    }
  } catch (error) {
    return null;
  }
};
exports.viewProductVariantOptionValueById = async (req, res, next) => {
  try {
    const id = req.params.id;
    console.log("---------------", id);
    let viewProductVarientOptionValueQuery = `SELECT  p.*,d.OptionName
                FROM ( productvariantoptionvalue p
                INNER JOIN productvariantoption d ON p.OptionID = d.OptionID)
                WHERE p.OptionValueID=${id}`;

    let viewProductVarientOptionValue = await connection.query(
      viewProductVarientOptionValueQuery,
      {
        type: QueryTypes.SELECT,
      }
    );
    console.log(viewProductVarientOptionValue);
    if (
      viewProductVarientOptionValue &&
      viewProductVarientOptionValue.length > 0
    ) {
      res.status(200).json({
        status: true,
        ProductVariantOptionValue: viewProductVarientOptionValue,
      });
    } else {
      res.status(200).json({
        status: false,
        message: "Product Varint Option Value does not found",
        ProductVariantOptionValue: [],
      });
    }
  } catch (err) {
    next(err);
    res.status(200).json({
      status: false,
      profile: {},
      error: err.message,
    });
  }
};
exports.addProductImage = async (req, res, next) => {
  try {
    const { OptionValueID, ImageGalleryID, MainImage } = req.body;
    let checkIfProducOptionValueExists = await checkOptionValueID(
      OptionValueID
    );
    console.log(checkIfProducOptionValueExists);
    if (
      checkIfProducOptionValueExists &&
      checkIfProducOptionValueExists == "1"
    ) {
      let checkIfImageGalleryExists = await checkImageGalleryID(ImageGalleryID);
      console.log(checkIfImageGalleryExists);
      if (checkIfImageGalleryExists && checkIfImageGalleryExists == "1") {
        let insertProductImageQuery = `insert into productimage ( OptionValueID ,ImageGalleryID,MainImage) values (?,?,?)`;
        let insertProductImage = await connection.query(
          insertProductImageQuery,
          {
            replacements: [OptionValueID, ImageGalleryID, MainImage],
          }
        );
        if (insertProductImage) {
          res.status(200).json({
            status: true,
            message: "Product Images added successfully",
          });
        } else {
          res.status(200).json({
            status: false,
            message: "Error while adding Product Images",
          });
        }
      } else if (
        checkIfImageGalleryExists &&
        checkIfImageGalleryExists == "0"
      ) {
        res.status(200).json({
          status: false,
          message: "Image Gallery does not exist",
          ImageGallery: [],
        });
      }
    } else if (
      checkIfProducOptionValueExists &&
      checkIfProducOptionValueExists == "0"
    ) {
      res.status(200).json({
        status: false,
        message: "Product Option Value does not exist",
        ProducOptionValue: [],
      });
    }
  } catch (err) {
    next(err);
    res.status(200).json({
      status: false,
      Category: {},
      error: err.message,
    });
  }
};
let checkOptionValueID = async (OptionValueID) => {
  try {
    let user = await connection.query(
      `select * from productvariantoptionvalue where OptionValueID = '${OptionValueID}'`,
      {
        type: QueryTypes.SELECT,
      }
    );
    console.log(user);
    if (user && user.length > 0) {
      return "1";
    } else {
      return "0";
    }
  } catch (error) {
    return null;
  }
};
let checkImageGalleryID = async (ImageGalleryID) => {
  try {
    let user = await connection.query(
      `select * from imagegallery where ImageGalleryID = '${ImageGalleryID}'`,
      {
        type: QueryTypes.SELECT,
      }
    );
    console.log(user);
    if (user && user.length > 0) {
      return "1";
    } else {
      return "0";
    }
  } catch (error) {
    return null;
  }
};
exports.viewProductImage = async (req, res, next) => {
  try {
    const id = req.params.id;
    console.log("---------------", id);
    let viewProductImageQuery = `SELECT  p.*,d.OptionValue,i.Small,i.Medium,i.Large
                FROM (( productimage p
                INNER JOIN productvariantoptionvalue d ON p.OptionValueID = d.OptionValueID)
                INNER JOIN imagegallery i  ON p.ImageGalleryID = i.ImageGalleryID)
                WHERE p.ProductImageID=${id}`;
    let viewProductImage = await connection.query(viewProductImageQuery, {
      type: QueryTypes.SELECT,
    });
    if (viewProductImage && viewProductImage.length > 0) {
      res.status(200).json({
        status: true,
        ProductImage: viewProductImage,
      });
    } else {
      res.status(200).json({
        status: false,
        message: "No Product Image found",
        ProductVariantOption: [],
      });
    }
  } catch (err) {
    next(err);
    res.status(200).json({
      status: false,
      profile: {},
      error: err.message,
    });
  }
};
 */
exports.addProductDetailsForm1 = async (req, res, next) => {
  let transaction; //!transaction variable declare here
  try {
    let {
      VendorID,
      SubCategoryID,
      Title,
      Description,
      SpecialInstruction,
      ReturnPolicy,
      Currency,
      CostPrice,
      Price,
      Quantity1,
      PriceQuantity1,
      Quantity2,
      PriceQuantity2,
      Quantity3,
      PriceQuantity3,
      PromotionPrice,
      PromotionRate,
      PromotionStartDate,
      PromotionEndDate,
      Weight,
      Height,
      Length,
      Width,
      AllowStorePickup,
      ShippingAvailable,
      ShippingGlobal,
      ShippingByAdmin,
      ShippingByVendor,
      ShippingCostAdmin,
      ShippingCostVendor,
      ReviewedByAdmin,
      TaxVATApply,
      LockEdit,
      Active,
      StoreName,
      Variations,
      ShippingCostVendorCountry,
      ShippingCostKiloVendorCountry,
      CityShippingCost,
      FreeProductReturn,
      ShippingCostVendorInternational,
      ShippingCostKiloVendorInternational,
      ProductCodStatus
    } = req.body;
    console.log("req.body-------------------",req.body)
    console.log("==========================================>", Active);
    transaction = await connection.transaction(); //!transaction use here
    let addProduct;
    let getCityID;
    let ProductID;
    let StoreOptionName = [];
    let CityShipping = "Y";
    let checkIfVendorExists = await vendorIDCheck(VendorID, transaction);
    console.log(checkIfVendorExists);
    if (checkIfVendorExists && checkIfVendorExists == "1") {
      let checkIfSubCategoryExists = await subcategoryIDCheck(
        SubCategoryID,
        transaction
      );
      if (checkIfSubCategoryExists && checkIfSubCategoryExists == "1") {
        StoreName = StoreName.trim(); // new changess
        let checkProductTitleExists = await productTitleCheck(
          Title,
          VendorID,
          transaction
        );
        if (checkProductTitleExists && checkProductTitleExists == "0") {
          let costPrice = parseFloat(CostPrice).toFixed(2);
          let price = parseFloat(Price).toFixed(2);
          let priceQuantity1 = parseFloat(PriceQuantity1).toFixed(2);
          let priceQuantity2 = parseFloat(PriceQuantity2).toFixed(2);
          let priceQuantity3 = parseFloat(PriceQuantity3).toFixed(2);
          let promotionPrice = parseFloat(PromotionPrice).toFixed(2);
          let promotionRate = parseFloat(PromotionRate).toFixed(2);
          let weight = parseFloat(Weight).toFixed(2);
          let length = parseFloat(Length).toFixed(2);
          let width = parseFloat(Width).toFixed(2);
          let height = parseFloat(Height).toFixed(2);
          let quantity1 = Math.trunc(Quantity1);
          let quantity2 = Math.trunc(Quantity2);
          let quantity3 = Math.trunc(Quantity3);

          //!Insert into Product table starts here
          try {
            let insertProductQuery = `insert into product ( VendorID, SubCategoryID,Title,StoreName, Description, SpecialInstruction,ReturnPolicy, Currency,CostPrice, Price ,Quantity1,PriceQuantity1,Quantity2 ,PriceQuantity2, Quantity3,  PriceQuantity3,PromotionPrice,  PromotionRate,  PromotionStartDate,  PromotionEndDate, Weight,Height, Length,  Width,  AllowStorePickup,   ShippingAvailable,  ShippingGlobal,  ShippingByAdmin,  ShippingByVendor,  ShippingCostAdmin, ShippingCostVendor, ReviewedByAdmin,TaxVATApply, LockEdit, Active,ProductCodStatus)`;
            insertProductQuery += ` values ("${VendorID}","${SubCategoryID}","${Title}","${StoreName}", "${Description}","${SpecialInstruction}","${ReturnPolicy}","${Currency}","${costPrice}","${price}","${quantity1}", "${priceQuantity1}","${quantity2}","${priceQuantity2}","${quantity3}","${priceQuantity3}","${promotionPrice}","${promotionRate}", "${PromotionStartDate}","${PromotionEndDate}","${weight}", "${height}","${length}","${width}","${AllowStorePickup}","${ShippingAvailable}","${ShippingGlobal}","${ShippingByAdmin}", "${ShippingByVendor}","${ShippingCostAdmin}","${ShippingCostVendor}","${ReviewedByAdmin}","${TaxVATApply}","${LockEdit}","${Active}","${ProductCodStatus}") `;

            addProduct = await connection.query(insertProductQuery, {
              transaction,
            });
          } catch (err) {
            console.log(
              err.message,
              "error here------------------------------------------------------------------------------"
            );
            if (transaction) await transaction.rollback();
            res.status(200).json({
              status: false,
              Product: [],
              error: err.message,
            });
          }
          if (addProduct) {
            //!Insert into Product City table starts here
            getCityID = await connection.query(
              `SELECT * FROM vendorstore WHERE VendorID="${VendorID}" AND StoreName="${StoreName}" `, {
              type: QueryTypes.SELECT,
              transaction,
            }
            );
            let VendorProductCity = getCityID[0].CityID;
            ProductID = addProduct[0];

            let insertProductCityQuery = `insert into productcity ( ProductID,CityID) values(?,?)`;
            let insertProductCity = await connection.query(
              insertProductCityQuery, {
              replacements: [ProductID, VendorProductCity],
              type: QueryTypes.INSERT,
              transaction,
            }
            );
            if (insertProductCity) {
              //!Insert into Product Country table starts here
              const getCountryID = await connection.query(
                `SELECT * FROM vendorstore WHERE VendorID="${VendorID}" AND StoreName="${StoreName}" `, {
                type: QueryTypes.SELECT,
                transaction,
              }
              );
              console.log("countryID--------------------",getCountryID[0].CountryID);
              const VendorProductCountry = getCountryID[0].CountryID;
              console.log("VendorProductCountry--------",VendorProductCountry)
              let ProductID = addProduct[0];
              let insertProductCountryQuery = `insert into productcountry ( ProductID, CountryID) values(?,?)`;
              let insertProductCountry = await connection.query(
                insertProductCountryQuery, {
                replacements: [ProductID, VendorProductCountry],
                type: QueryTypes.INSERT,
                transaction,
              }
              );

              if (insertProductCountry) {
                console.log(Variations.length);
                //!Insert into Product Variant Option table starts here
                for (let i = 0; i < Variations.length; i++) {
                  StoreOptionName.push(Variations[i]);
                }

                let insertProductVariantOptionBulkQuery = `insert into productvariantoption ( ProductID ,OptionName) values  `;
                for (let i = 0; i < StoreOptionName.length; i++) {
                  if (i == StoreOptionName.length - 1) {
                    insertProductVariantOptionBulkQuery += `('${ProductID}', '${StoreOptionName[i]}')`;
                  } else {
                    insertProductVariantOptionBulkQuery += `('${ProductID}', '${StoreOptionName[i]}'),`;
                  }
                }
                insertProductVariantOption = await connection.query(
                  insertProductVariantOptionBulkQuery, {
                  type: QueryTypes.INSERT,
                  transaction,
                }
                );

                if (insertProductVariantOption) {
                  //!below this cod status
                  let updateVendorAndProductsCodStatus =
                    await connection.query(
                      `UPDATE product SET ProductCodStatus ="${ProductCodStatus}",FreeProductReturn="${FreeProductReturn}" WHERE ProductID = "${ProductID}"
                       `, {
                      transaction,
                    }
                    );
                  if (updateVendorAndProductsCodStatus) {
                    //!below this shipping----------------------------------------------------
                    if (ShippingByVendor == "N") {
                      CityShipping = "N";
                    }
                    if (CityShippingCost.length == 0) {
                      CityShipping = "N";
                    }
                    let insertCountryShipping = false;

                    if (ShippingByVendor == "Y") {
                      let insertCountryShippingCostQuery = `INSERT INTO shippingcostvendorcountry( ProductID, CountryID, ShippingCostVendorCountry,ShippingCostKiloVendorCountry,ShippingCostVendorInternational,ShippingCostKiloVendorInternational) values(?,?,?,?,?,?)`;
                      let insertCountryShippingCost = await connection.query(
                        insertCountryShippingCostQuery, {
                        replacements: [
                          ProductID,
                          VendorProductCountry,
                          ShippingCostVendorCountry,
                          ShippingCostKiloVendorCountry,
                          ShippingCostVendorInternational,
                          ShippingCostKiloVendorInternational,
                        ],
                        transaction,
                      }
                      );
                      if (insertCountryShippingCost) {
                        insertCountryShipping = true;
                      }
                    }
                    if (ShippingByVendor == "N") {
                      insertCountryShipping = true;
                    }

                    if (insertCountryShipping) {
                      //inside
                      let insertCityShipping = false;
                      console.log(CityShipping, "CityShipping");
                      if (CityShipping == "Y") {
                        let insertCityShippingCostQuery = `INSERT INTO shippingcostvendorcity( ProductID, CityID, ShippingCostVendorCity,ShippingCostKiloVendorCity) values  `;
                        for (let i = 0; i < CityShippingCost.length; i++) {
                          if (i == CityShippingCost.length - 1) {
                            insertCityShippingCostQuery += `('${ProductID}', '${CityShippingCost[i].CityID}','${CityShippingCost[i].ShippingCostVendorCity}','${CityShippingCost[i].ShippingCostKiloVendorCity}')`;
                          } else {
                            insertCityShippingCostQuery += `('${ProductID}', '${CityShippingCost[i].CityID}','${CityShippingCost[i].ShippingCostVendorCity}','${CityShippingCost[i].ShippingCostKiloVendorCity}'),`;
                          }
                        }
                        let insertCityShippingCost = await connection.query(
                          insertCityShippingCostQuery, {
                          type: QueryTypes.INSERT,
                          transaction,
                        }
                        );
                        if (insertCityShippingCost) {
                          insertCityShipping = true;
                        }
                      }
                      if (CityShipping == "N") {
                        insertCityShipping = true;
                      }
                      if (insertCityShipping) {
                        const getProductApprovalStatus =
                          await connection.query(
                            `SELECT * FROM vendor WHERE VendorID="${VendorID}"  `, {
                            type: QueryTypes.SELECT,
                            transaction,
                          }
                          );
                        let updateProductActiveStatus;
                        if (
                          getProductApprovalStatus[0].ProductApproval == "Y"
                        ) {
                          // const updateProductApprovalStatusInVendorTable =
                          //   await connection.query(
                          //     `UPDATE vendor SET ProductApproval="N" WHERE VendorID="${VendorID}"  `, {
                          //       transaction,
                          //     }
                          //   );
                          updateProductActiveStatus =
                            await connection.query(
                              `UPDATE product SET Active="N" WHERE ProductID="${ProductID}"  `, {
                              transaction,
                            }
                            );
                        } else if (
                          getProductApprovalStatus[0].ProductApproval == "N"
                        ) {
                          updateProductActiveStatus =
                            await connection.query(
                              `UPDATE product SET Active="Y" WHERE ProductID="${ProductID}"  `, {
                              transaction,
                            }
                            );

                          // const updateProductApprovalStatusInVendorTable =
                          //   await connection.query(
                          //     `UPDATE vendor SET ProductApproval="Y" WHERE VendorID="${VendorID}"  `, {
                          //       transaction,
                          //     }
                          //   );
                        }
                        if (transaction) await transaction.commit(); //!final commit
                        res.status(200).json({
                          status: true,
                          message: "Product Form 1 Details Added Successfully",
                          ProductID: ProductID,
                        });
                      } else {
                        if (transaction) await transaction.rollback();
                        res.status(200).json({
                          status: false,
                          message: "Error while adding city shipping cost details",
                        });
                      }
                    } else {
                      if (transaction) await transaction.rollback();
                      res.status(200).json({
                        status: false,
                        message: "Error while adding country shipping cost details",
                      });
                    }
                  } else {
                    if (transaction) await transaction.rollback();
                    res.status(200).json({
                      status: false,
                      message: "Unable to update Product COD status",
                    });
                  }
                } else {
                  if (transaction) await transaction.rollback();
                  res.status(200).json({
                    status: false,
                    message: "Error while adding Product Variant Option",
                  });
                }

                //!Insert into Product Variant table ends here
              } else {
                if (transaction) await transaction.rollback();
                res.status(200).json({
                  status: false,
                  message: "Error while adding Product country",
                });
              }
              //!Insert into Product Country table ends here
            } else {
              if (transaction) await transaction.rollback();
              res.status(200).json({
                status: false,
                message: "Error while adding Product City",
              });
            }
            //!Insert into Product City table ends here
          } else {
            if (transaction) await transaction.rollback();
            res.status(200).json({
              status: false,
              message: "Error while adding Product Details",
            });
          }
        } else if (
          checkProductTitleExists &&
          checkProductTitleExists == "1"
        ) {
          if (transaction) await transaction.rollback();
          res.status(200).json({
            status: false,
            message: "Product already registered with this Title",
            Product: [],
          });
        }
      } else if (checkIfSubCategoryExists && checkIfSubCategoryExists == "0") {
        if (transaction) await transaction.rollback();
        res.status(200).json({
          status: false,
          message: "SubCategory does not exist",
          SubCategory: [],
        });
      }
    } else if (checkIfVendorExists && checkIfVendorExists == "0") {
      if (transaction) await transaction.rollback();
      res.status(200).json({
        status: false,
        message: "Vendor does not have Store",
        Vendor: [],
      });
    }
  } catch (err) {
    if (transaction) await transaction.rollback();
    next(err);
    res.status(200).json({
      status: false,
      Product: {},
      error: err.message,
    });
  }
};

exports.deletedImage = async (req, res) => {
  try {
    const { ImageGalleryID } = req.params;
    const deleteproductimage = await connection.query(
      `DELETE FROM productimage WHERE ImageGalleryID="${ImageGalleryID}" `, {
      type: QueryTypes.DELETE,
    }
    )
    const deleteImageGalleryTable = await connection.query(
      `DELETE FROM imagegallery WHERE ImageGalleryID="${ImageGalleryID}" `, {
      type: QueryTypes.DELETE,
    }
    )



    res.send("deleted")


  } catch (err) {
    console.log(err)
    res.status(500).json({
      status: false,
      error: err.message,
    });
  }
}

exports.deletedVideo = async (req, res) => {
  try {
    const { ProductVariantCombinationID } = req.params;
    console.log("ProductVariantCombinationID", ProductVariantCombinationID)

    const fetchVariant = await connection.query(
      `SELECT * FROM productvariantcombination WHERE ProductVariantCombinationID="${ProductVariantCombinationID}" `, {
      type: QueryTypes.SELECT,
    }
    )

    if (fetchVariant.length > 0 && fetchVariant[0].video !== null) {

      const deleteproductVideo = await connection.query(
        `UPDATE productvariantcombination
      SET video = NULL WHERE ProductVariantCombinationID="${ProductVariantCombinationID}" `, {
        type: QueryTypes.DELETE,
      }
      )

      const video = fetchVariant[0].video
      const fileName = video.replace("public\\imageGallery\\", "")
      const imagePath = path.join('public', 'imageGallery', `${fileName}`);

      // Unlink (delete) the file
      fs.unlink(imagePath, (err) => {
        if (err) {
          console.error(err);
          return;
        }
        console.log('File deleted successfully');
      });

      res.status(200).json({
        status: true,
        message: "video removed successfully",
        fetchVariant: fetchVariant
      })
    } else {
      res.status(400).json({
        status: false,
        message: "No variant found ! "
      })
    }

  } catch (err) {
    console.log(err)
    res.status(500).json({
      status: false,
      error: err.message,
    });
  }
}
