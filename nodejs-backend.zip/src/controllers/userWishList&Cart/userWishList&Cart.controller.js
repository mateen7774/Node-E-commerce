const connection = require("../../db/db.connection");
const { QueryTypes } = require("sequelize");
//!User Wish List Api's
exports.addUserWishList = async (req, res, next) => {
  try {
    UserID = req.UserID;
    var { ProductID, ProductVariantCombinationID } = req.body;
    let checkIfProductVariantAlreadyAdded = await connection.query(
      `
            select * from userwishlist where ProductID = "${ProductID}" AND UserID = "${UserID}" 
            `,
      {
        type: QueryTypes.SELECT,
      }
    );
    if (
      checkIfProductVariantAlreadyAdded &&
      checkIfProductVariantAlreadyAdded.length > 0
    ) {
      res.status(200).json({
        status: false,
        message: "Product Variant Already Exists in WishList ",
      });
    } else {
      let LastUpdate = new Date().toISOString().slice(0, 19).replace("T", " ");
      let addUserWishListQuery = `INSERT INTO userwishlist (UserID,ProductID,ProductVariantCombinationID,LastUpdate) values (?,?,?,?) `;
      let addUserWishList = await connection.query(addUserWishListQuery, {
        replacements: [
          UserID,
          ProductID,
          ProductVariantCombinationID,
          LastUpdate,
        ],
        type: QueryTypes.INSERT,
      });
      if (addUserWishList && addUserWishList.length > 0) {
        res.status(200).json({
          status: true,
          message: "Product added into WishList ",
        });
      } else {
        res.status(200).json({
          status: false,
          message: "Error while adding User WishList",
        });
      }
    }
  } catch (err) {
    next(err);
    res.status(200).json({
      status: false,
      message: err.message,
    });
  }
};
exports.viewUserWishList = async (req, res, next) => {
  try {
    UserID = req.UserID;

    let viewUserWishListQuery = `SELECT p.ProductID,p.Title,p.Price,p.Currency,u.UserID,g.Small,g.Medium,g.Large,COUNT(r.Review) AS REVIEW_COUNT,AVG(r.Rating) AS AVG_RATING
        FROM ((((((product p
        LEFT JOIN productvariantoption o ON o.ProductID IN (p.ProductID))
        LEFT JOIN productvariantoptionvalue v ON v.OptionID IN(o.OptionID))
        LEFT JOIN productimage i ON i.OptionValueID IN(v.OptionValueID))
        LEFT JOIN imagegallery g ON g.ImageGalleryID IN(i.ImageGalleryID))
        LEFT JOIN productreviewrating r ON r.ProductID IN (p.ProductID))
        LEFT JOIN userwishlist u ON u.ProductID IN(p.ProductID))
        WHERE i.MainImage = 'Y' AND u.UserID="${UserID}"
        GROUP BY p.ProductID `;
    let viewUserWishList = await connection.query(viewUserWishListQuery, {
      type: QueryTypes.SELECT,
    });
    if (viewUserWishList && viewUserWishList.length > 0) {
      res.status(200).json({
        status: true,
        userWishList: viewUserWishList,
      });
    } else {
      res.status(200).json({
        status: true,
        userWishList: [],
      });
    }
  } catch (err) {
    next(err);
    res.status(200).json({
      status: false,
      userWishList: [],
      message: err.message,
    });
  }
};
exports.deleteUserWishList = async (req, res, next) => {
  try {
    let ProductID = req.params.id;
    let UserID = req.UserID;
    let checkIfUserWishListExists = await connection.query(
      `
            select * from userwishlist where ProductID = "${ProductID}" AND UserID = "${UserID}" 
            `,
      {
        type: QueryTypes.SELECT,
      }
    );
    if (checkIfUserWishListExists && checkIfUserWishListExists.length > 0) {
      let deleteUserWishList = await connection.query(
        ` DELETE FROM userwishlist WHERE ProductID = "${ProductID}" AND UserID = "${UserID}"  `
      );
      res.status(200).json({
        status: true,
        message: `User Wish List removed successfully `,
      });
    }
  } catch (err) {
    next(err);
    res.status(200).json({
      status: false,
      message: err.message,
    });
    console.log(err.message);
  }
};
exports.addToCart = async (req, res, next) => {
  try {
    let UserID = req.UserID;
    let saveProductID = [];
    let Quantity = [];
    var { SessionID, ProductDetail } = req.body;

    // console.log("req.body----------------------------", req.body)
    // return
    /*  for (let i = 0; i < ProductDetail.length; i++) {
             saveProductID.push(ProductDetail[i].ProductID)
         }
         ProductID = `(${ saveProductID.join(",")})`; */
    /* let getProductCountryAndCity =
            await connection.query(
                `SELECT p.ProductID,p.AllowStorePickup,t.CountryID,c.CityID
                FROM ((product p
                LEFT JOIN productcity c ON c.ProductID IN (p.ProductID))
                LEFT JOIN productcountry t ON t.ProductID IN (p.ProductID))
                WHERE p.ProductID IN ${ProductID}
              `, {
                    type: QueryTypes.SELECT,
                }
            ); */
    let getProductCountryAndCity;
    let LastUpdate = new Date().toISOString().slice(0, 19).replace("T", " ");
    let addToCartQuery = `INSERT INTO shoppingcart (SessionID,ProductID,Quantity,UserID,CountryID,CityID,ProductVariantCombinationDetail,AllowStorePickup,LastUpdate) values  `;
    let ProductVariantCombinationIDs = [];
    for (let i = 0; i < ProductDetail.length; i++) {
      let ProductID = ProductDetail[i].ProductID;
      getProductCountryAndCity = await connection.query(
        `SELECT p.ProductID,p.AllowStorePickup,t.CountryID,c.CityID
                FROM ((product p
                LEFT JOIN productcity c ON c.ProductID IN (p.ProductID))
                LEFT JOIN productcountry t ON t.ProductID IN (p.ProductID))
                WHERE p.ProductID="${ProductID}" `,
        {
          type: QueryTypes.SELECT,
        }
      );
      Quantity = ProductDetail[i].Quantity;
      let variantsLength =
        ProductDetail[i].ProductVariantCombinationDetail.length;
      let variants = ProductDetail[i].ProductVariantCombinationDetail;
      let array = [];
      for (j = 0; j < variantsLength; j++) {
        array.push(variants[j].ProductVariantCombinationID);
      }
      array.sort(); // sort the array in ascending order   //! chnages made here
      let ProductVariantCombinationID = `${array.join(",")}`;
      if (i == ProductDetail.length - 1) {
        addToCartQuery += `('${SessionID}', '${ProductID}','${Quantity}',
             '${UserID}','${getProductCountryAndCity[0].CountryID}','${getProductCountryAndCity[0].CityID}',
             '${ProductVariantCombinationID}',
             '${getProductCountryAndCity[0].AllowStorePickup}','${LastUpdate}')`;
      } else {
        addToCartQuery += `('${SessionID}', '${ProductID}','${Quantity}',
                     '${UserID}','${getProductCountryAndCity[0].CountryID}','${getProductCountryAndCity[0].CityID}',
                     '${ProductVariantCombinationID}',
                     '${getProductCountryAndCity[0].AllowStorePickup}','${LastUpdate}'),`;
      }
    }
    addToCartQuery += ` ON DUPLICATE KEY UPDATE Quantity=Quantity+${Quantity},LastUpdate=VALUES(LastUpdate)`;
    let addToCart = await connection.query(addToCartQuery, {
      type: QueryTypes.INSERT,
    });
    if (addToCart && addToCart.length > 0) {
      res.status(200).json({
        status: true,
        message: "Product added into Shopping Cart successfully",
      });
    } else {
      res.status(200).json({
        status: false,
        message: "Error while adding Product into Shopping Cart",
      });
    }
  } catch (err) {
    next(err);
    res.status(200).json({
      status: false,
      message: err.message,
    });
  }
};
exports.viewCartList = async (req, res, next) => {
  try {
    //view cart
    // let Region = req.region;
    // const currencyRate = req.currency_rate;
    const Region = req.region;
    const getCurrencyRates = req.getCurrencyRates;
    let currencyRate;


    let productCombinationPriceDetail = [];
    let UserID = req.UserID;

    let viewCartListQuery = `SELECT p.*,k.City,k.Native,y.CityID AS ProductCityID,u.CountryID AS ProductCountry,r.CompanyName,r.VendorID,s.UserID,s.AllowStorePickup,s.Quantity AS Total_Quantity,e.ZipCode AS VendorStoreZip,e.City AS StoreCity,e.CountryID AS StoreCountry,e.State AS StoreState,e.Active AS StoreActiveStatus,s.ProductVariantCombinationDetail,IF(k.VATTaxRate="0.00" OR k.VATTaxRate IS NULL, cy.VATTaxRate, k.VATTaxRate) AS VATTaxRate,
        (SELECT COUNT(t.ProductID)
        from productreviewrating t WHERE t.ProductID = p.ProductID) AS REVIEW_COUNT,
        (SELECT AVG(t.Rating) from productreviewrating t WHERE t.ProductID = p.ProductID) AS  AVG_Rating
            FROM (((((((((( product p
            LEFT JOIN productcity y ON y.ProductID IN( p.ProductID))
            LEFT JOIN city k ON k.CityID IN( y.CityID))
            LEFT JOIN productcountry u ON u.ProductID IN( p.ProductID))  
            LEFT JOIN vendor r ON r.VendorID IN( p.VendorID))      
            LEFT JOIN productvariantoption o ON o.ProductID IN( p.ProductID))
            LEFT JOIN productvariantoptionvalue v  ON  v.OptionID IN (o.OptionID))  
            LEFT JOIN productvariantcombination c  ON  c.OptionValueID IN (v.OptionValueID))
            LEFT JOIN vendorstore e ON e.VendorStoreID IN( c.VendorStoreID))
            LEFT JOIN shoppingcart s ON s.ProductID IN(c.ProductID))
            LEFT JOIN country cy ON cy.CountryID IN(u.CountryID))
            WHERE s.UserID='${UserID}' 
            GROUP BY s.ID
            ORDER BY s.ID DESC
         `;
    let productCartList = await connection.query(viewCartListQuery, {
      type: QueryTypes.SELECT,
    });
    //console.log(productCartList, "productCartList")
    let productCombinationPrice;

    if (productCartList && productCartList.length > 0) {
      for (let i = 0; i < productCartList.length; i++) {
        let ProductVariantCombinationDetail = [];
        ProductVariantCombinationDetail.push(
          productCartList[i].ProductVariantCombinationDetail
        );
        ProductVariantCombinationDetail = `(${ProductVariantCombinationDetail.join(
          ","
        )})`;
        console.log("ProductVariantCombinationDetailProductVariantCombinationDetailProductVariantCombinationDetail", ProductVariantCombinationDetail)
        productCombinationPrice = await connection.query(
          `SELECT p.ProductID,p.Currency,c.ProductVariantCombinationID,c.VendorStoreID,c.Price AS ProductCombinationPrice,c.AvailableInventory,o.OptionID,o.OptionName,v.OptionValue,v.OptionValueID,
                            g.Small,g.Medium,g.Large
                FROM ((((((product p
                LEFT JOIN productvariantoption o ON o.ProductID IN( p.ProductID))
                LEFT JOIN productvariantoptionvalue v  ON  v.OptionID IN (o.OptionID)) 
                LEFT JOIN productimage i  ON  i.OptionValueID IN (v.OptionValueID))
                LEFT JOIN imagegallery g  ON  g.ImageGalleryID IN (i.ImageGalleryID))
                LEFT JOIN productvariantcombination c  ON  c.OptionValueID IN (v.OptionValueID))
                JOIN shoppingcart s ON s.ProductID IN(c.ProductID))
                WHERE s.UserID='${UserID}' AND c.ProductVariantCombinationID IN ${ProductVariantCombinationDetail}
                GROUP BY c.OptionValueID
              
               `,
          {
            type: QueryTypes.SELECT,
          }
        );
        // console.log("productCombinationPriceproductCombinationPriceproductCombinationPrice", productCombinationPrice)
        productCombinationPriceDetail.push(productCombinationPrice);
        let variantsLength = productCombinationPriceDetail[i].length;

        let productCombinationPriceDetailArr;
        // if (Region == "Bangladesh") {
        for (let j = 0; j < variantsLength; j++) {

          const fromCurrency = productCombinationPriceDetail[i][j].Currency;
          const selectCurrency = getCurrencyRates.filter(item => item.FromCurrency === fromCurrency);
          currencyRate = selectCurrency.length ? selectCurrency[0].Rate : null;

          if (selectCurrency.length > 0) {
            console.log("currencyRate-------------------", currencyRate);
            productCombinationPriceDetailArr = getCurrencyRates.filter(item => item.FromCurrency === fromCurrency)
            console.log(productCombinationPriceDetailArr, "productCombinationPriceDetailArr")
            const convertedCurrency = productCombinationPriceDetailArr[0].ToCurrency;
            console.log(convertedCurrency, "at index", i)

            let Price =
              productCombinationPriceDetail[i][j].ProductCombinationPrice;

            console.log("Price", Price)
            productCombinationPriceDetail[i][j]["Currency"] = convertedCurrency;
            productCombinationPriceDetail[i][j]["ProductCombinationPrice"] = parseFloat(
              currencyRate * Price
            ).toFixed(2);

          }

          // if (productCombinationPriceDetail[i][j].Currency == "USD") {
          //   productCombinationPriceDetail[i][j]["Currency"] = "BDT";
          //   productCombinationPriceDetail[i][j]["ProductCombinationPrice"] =
          //     parseFloat(currencyRate * Price).toFixed(2);
          // }
        }
        // } else if (Region == "USA" || Region == "United States") {
        //   for (let j = 0; j < variantsLength; j++) {
        //     let Price =
        //       productCombinationPriceDetail[i][j].ProductCombinationPrice;
        //     if (productCombinationPriceDetail[i][j].Currency == "BDT") {
        //       productCombinationPriceDetail[i][j]["Currency"] = "USD";
        //       productCombinationPriceDetail[i][j]["ProductCombinationPrice"] =
        //         parseFloat(currencyRate * Price).toFixed(2);
        //     }
        //   }
        // } else {
        //   for (let j = 0; j < variantsLength; j++) {
        //     let Price =
        //       productCombinationPriceDetail[i][j].ProductCombinationPrice;
        //     productCombinationPriceDetail[i][j]["Currency"] = "USD";
        //     productCombinationPriceDetail[i][j]["ProductCombinationPrice"] =
        //       parseFloat(currencyRate * Price).toFixed(2);
        //   }
        // }
      }
      for (let i = 0; i < productCartList.length; i++) {
        let VATTaxRate = productCartList[i].VATTaxRate
          ? productCartList[i].VATTaxRate
          : 0;
        //console.log(VATTaxRate, "VATTaxRate")
        let State = productCartList[i].StoreState;
        let Tax = productCartList[i].TaxVATApply;
        let CountryID = productCartList[i].StoreCountry;
        if (Tax == "Y") {
          if (CountryID == "16" || CountryID == "226") {
            productCartList[i].TaxRate = VATTaxRate;
          } else {
            productCartList[i].TaxRate = 0;
          }
        } else {
          productCartList[i].TaxRate = 0;
        }
        //!cuurency conversion
        // if (Region == "Bangladesh") {

        let productCartListArr;

        const fromCurrency = productCartList[i].Currency;
        const selectCurrency = getCurrencyRates.filter(item => item.FromCurrency === fromCurrency);
        currencyRate = selectCurrency.length ? selectCurrency[0].Rate : null;

        if (selectCurrency.length > 0) {
          console.log("currencyRate-------------------", currencyRate);
          productCartListArr = getCurrencyRates.filter(item => item.FromCurrency === fromCurrency)
          console.log(productCartListArr, "productCartListArr")
          const convertedCurrency = productCartListArr[0].ToCurrency;
          console.log(convertedCurrency, "at index", i)

          let Price = productCartList[i].Price;

          console.log("Price", Price)
          productCartList[i]["Currency"] = convertedCurrency;
          productCartList[i]["Price"] = parseFloat(
            currencyRate * Price
          ).toFixed(2);

        }




        // if (productCartList[i].Currency == "USD") {
        //   productCartList[i]["Currency"] = "BDT";
        //   productCartList[i]["Price"] = parseFloat(
        //     currencyRate * Price
        //   ).toFixed(2);
        // }
        // } else {
        //   let Price = productCartList[i].Price;
        //   if (productCartList[i].Currency == "BDT") {
        //     productCartList[i]["Currency"] = "USD";
        //     productCartList[i]["Price"] = parseFloat(
        //       currencyRate * Price
        //     ).toFixed(2);
        //   }
        // }

        //old commented not mine
        // else {
        //     let Price = productCartList[i].Price
        //     productCartList[i]["Currency"] = "USD"
        //     productCartList[i]["Price"] = parseFloat(currencyRate * Price).toFixed(2)
        //     console.log( productCartList[i]["Price"] )
        // }
      }
      if (productCombinationPrice && productCombinationPrice.length > 0) {
        res.status(200).json({
          status: true,
          productCartList,
          productCombinationPriceDetail: productCombinationPriceDetail,
        });
      } else {
        res.status(200).json({
          status: false,
          productCartList,
          productCombinationPriceDetail: [],
        });
      }
    } else {
      res.status(200).json({
        status: true,
        productCartList: [],
        productCombinationPriceDetail: [],
      });
    }
  } catch (err) {
    console.log(err);
    res.status(200).json({
      status: false,
      message: err.message,
      productCartList: [],
      productCombinationPriceDetail: [],
    });
  }
};






exports.viewCartListMobile = async (req, res, next) => {
  try {
    let Region = req.region;
    const currencyRate = req.currency_rate;

    let UserID = req.UserID;
    let productCombinationPriceDetail = [];
    let getProductComibnationDetail = await connection.query(
      `SELECT * from shoppingcart
        WHERE UserID='${UserID}'
        ORDER BY ID DESC

       `,
      {
        type: QueryTypes.SELECT,
      }
    );
    let viewCartListQuery = `SELECT p.*,k.City,k.Native,y.CityID AS ProductCityID,u.CountryID AS ProductCountry,r.CompanyName,r.VendorID,s.UserID,g.Small,g.Medium,g.Large,i.MainImage,s.AllowStorePickup,s.Quantity AS Total_Quantity,e.ZipCode AS VendorStoreZip,e.City AS StoreCity,e.CountryID AS StoreCountry,e.State AS StoreState,IF(k.VATTaxRate="0.00" OR k.VATTaxRate IS NULL, cy.VATTaxRate, k.VATTaxRate) AS VATTaxRate1,
        (SELECT COUNT(t.ProductID)
        from productreviewrating t WHERE t.ProductID = p.ProductID) AS REVIEW_COUNT,
        (SELECT AVG(t.Rating) from productreviewrating t WHERE t.ProductID = p.ProductID) AS  AVG_Rating
            FROM (((((((((((( product p
            LEFT JOIN productcity y ON y.ProductID IN( p.ProductID))
            LEFT JOIN city k ON k.CityID IN( y.CityID))
            LEFT JOIN productcountry u ON u.ProductID IN( p.ProductID))
            LEFT JOIN vendor r ON r.VendorID IN( p.VendorID))
            LEFT JOIN productvariantoption o ON o.ProductID IN( p.ProductID))
            LEFT JOIN productvariantoptionvalue v  ON  v.OptionID IN (o.OptionID))
            LEFT JOIN productimage i  ON  i.OptionValueID IN (v.OptionValueID))
            LEFT JOIN imagegallery g  ON  g.ImageGalleryID IN (i.ImageGalleryID))
            LEFT JOIN productvariantcombination c  ON  c.OptionValueID IN (v.OptionValueID))
            LEFT JOIN vendorstore e ON e.VendorStoreID IN( c.VendorStoreID))
            LEFT JOIN shoppingcart s ON s.ProductID IN(c.ProductID))
            LEFT JOIN country cy ON cy.CountryID IN(u.CountryID))
            WHERE s.UserID='${UserID}' AND i.MainImage='Y'
            GROUP BY s.ID
            ORDER BY s.ID DESC
         `;
    let productCartList = await connection.query(viewCartListQuery, {
      type: QueryTypes.SELECT,
    });

    let productCombinationPrice;
    if (productCartList && productCartList.length > 0) {
      for (let i = 0; i < getProductComibnationDetail.length; i++) {
        let ProductVariantCombinationDetail = [];
        ProductVariantCombinationDetail.push(
          getProductComibnationDetail[i].ProductVariantCombinationDetail
        );
        ProductVariantCombinationDetail = `(${ProductVariantCombinationDetail.join(
          ","
        )})`;
        // `SELECT p.ProductID,p.Currency,c.ProductVariantCombinationID,c.VendorStoreID,c.Price AS ProductCombinationPrice,c.AvailableInventory,o.OptionID,o.OptionName,v.OptionValue,v.OptionValueID
        //         FROM ((((product p
        //         LEFT JOIN productvariantoption o ON o.ProductID IN( p.ProductID))
        //         LEFT JOIN productvariantoptionvalue v  ON  v.OptionID IN (o.OptionID))
        //         LEFT JOIN productvariantcombination c  ON  c.OptionValueID IN (v.OptionValueID))
        //         JOIN shoppingcart s ON s.ProductID IN(c.ProductID))
        //         WHERE s.UserID='${UserID}' AND c.ProductVariantCombinationID IN ${ProductVariantCombinationDetail}
        //         GROUP BY c.OptionValueID
        //        `
        productCombinationPrice = await connection.query(
          `SELECT p.ProductID,p.Currency,c.ProductVariantCombinationID,c.VendorStoreID,c.Price AS ProductCombinationPrice,c.AvailableInventory,o.OptionID,o.OptionName,v.OptionValue,v.OptionValueID
                FROM ((((product p
                LEFT JOIN productvariantoption o ON o.ProductID IN( p.ProductID))
                LEFT JOIN productvariantoptionvalue v  ON  v.OptionID IN (o.OptionID))
                LEFT JOIN productvariantcombination c  ON  c.OptionValueID IN (v.OptionValueID))
                JOIN shoppingcart s ON s.ProductID IN(c.ProductID))
                WHERE s.UserID='${UserID}' AND c.ProductVariantCombinationID IN ${ProductVariantCombinationDetail}
                GROUP BY c.OptionValueID
               `,
          {
            type: QueryTypes.SELECT,
          }
        );
        productCombinationPriceDetail.push(productCombinationPrice);
      }
      let tempPC = productCombinationPriceDetail;

      // let tempPC = productCombinationPriceDetail.reverse()
      let tempProd = productCartList;
      let tempArray = [];

      for (let i = 0; i < tempProd.length; i++) {
        //let City = tempProd[i].StoreCity
        //let State = tempProd[i].StoreState
        let VATTaxRate = tempProd[i].VATTaxRate1;
        let Tax = tempProd[i].TaxVATApply;
        let CountryID = tempProd[i].StoreCountry;
        if (Tax === "Y") {
          if (CountryID == "16" || CountryID == "226") {
            tempProd[i].TaxRate = VATTaxRate;
          } else {
            tempProd[i].TaxRate = null;
          }
        } else {
          tempProd[i].TaxRate = null;
        }
        //!cuurency conversion
        if (Region == "Bangladesh") {
          let Price = tempProd[i].Price;
          if (tempProd[i].Currency == "USD") {
            tempProd[i]["Currency"] = "BDT";
            tempProd[i]["Price"] = parseFloat(currencyRate * Price).toFixed(2);
          }
        } else if (Region == "USA" || Region == "United States") {
          let Price = tempProd[i].Price;
          if (tempProd[i].Currency == "BDT") {
            tempProd[i]["Currency"] = "USD";
            tempProd[i]["Price"] = parseFloat(currencyRate * Price).toFixed(2);
          }
        } else {
          let Price = tempProd[i].Price;
          tempProd[i]["Currency"] = "USD";
          tempProd[i]["Price"] = parseFloat(currencyRate * Price).toFixed(2);
        }

        var obj = {
          ...tempProd[i],
        };
        let variantsLength = tempPC[i].length;
        if (Region == "Bangladesh") {
          for (let j = 0; j < variantsLength; j++) {
            let Price = tempPC[i][j].ProductCombinationPrice;
            if (tempPC[i][j].Currency == "USD") {
              tempPC[i][j]["Currency"] = "BDT";
              tempPC[i][j]["ProductCombinationPrice"] = parseFloat(
                currencyRate * Price
              ).toFixed(2);
            }
          }
        } else if (Region == "USA" || Region == "United States") {
          for (let j = 0; j < variantsLength; j++) {
            let Price = tempPC[i][j].ProductCombinationPrice;
            if (tempPC[i][j].Currency == "BDT") {
              tempPC[i][j]["Currency"] = "USD";
              tempPC[i][j]["ProductCombinationPrice"] = parseFloat(
                currencyRate * Price
              ).toFixed(2);
            }
          }
        } else {
          for (let j = 0; j < variantsLength; j++) {
            let Price = tempPC[i][j].ProductCombinationPrice;
            tempPC[i][j]["Currency"] = "USD";
            tempPC[i][j]["ProductCombinationPrice"] = parseFloat(
              currencyRate * Price
            ).toFixed(2);
          }
        }

        obj["ProductCombinations"] = tempPC[i];
        tempArray.push(obj);
      }
      if (productCombinationPrice && productCombinationPrice.length > 0) {
        res.status(200).json({
          status: true,
          productCartList: tempArray,
        });
      } else {
        res.status(200).json({
          status: true,
          productCartList: [],
        });
      }

    } else {
      res.status(200).json({
        status: true,
        productCartList: [],
      });
    }
  } catch (err) {
    // next(err);
    console.log(err);
    res.status(200).json({
      status: false,
      message: err.message,
      productCartList: [],
    });
  }
};







exports.oldviewCartListMobile = async (req, res, next) => {
  try {
    let Region = req.region;
    const currencyRate = req.currency_rate;

    let UserID = req.UserID;
    let productCombinationPriceDetail = [];
    let getProductComibnationDetail = await connection.query(
      `SELECT * from shoppingcart
        WHERE UserID='${UserID}'
        ORDER BY ID DESC
     
       `,
      {
        type: QueryTypes.SELECT,
      }
    );
    let viewCartListQuery = `SELECT p.*,k.City,k.Native,y.CityID AS ProductCityID,u.CountryID AS ProductCountry,r.CompanyName,r.VendorID,s.UserID,g.Small,g.Medium,g.Large,i.MainImage,s.AllowStorePickup,s.Quantity AS Total_Quantity,e.ZipCode AS VendorStoreZip,e.City AS StoreCity,e.CountryID AS StoreCountry,e.State AS StoreState,IF(k.VATTaxRate="0.00" OR k.VATTaxRate IS NULL, cy.VATTaxRate, k.VATTaxRate) AS VATTaxRate1,
        (SELECT COUNT(t.ProductID)
        from productreviewrating t WHERE t.ProductID = p.ProductID) AS REVIEW_COUNT,
        (SELECT AVG(t.Rating) from productreviewrating t WHERE t.ProductID = p.ProductID) AS  AVG_Rating
            FROM (((((((((((( product p
            LEFT JOIN productcity y ON y.ProductID IN( p.ProductID))
            LEFT JOIN city k ON k.CityID IN( y.CityID))
            LEFT JOIN productcountry u ON u.ProductID IN( p.ProductID)) 
            LEFT JOIN vendor r ON r.VendorID IN( p.VendorID))      
            LEFT JOIN productvariantoption o ON o.ProductID IN( p.ProductID))
            LEFT JOIN productvariantoptionvalue v  ON  v.OptionID IN (o.OptionID))  
            LEFT JOIN productimage i  ON  i.OptionValueID IN (v.OptionValueID))
            LEFT JOIN imagegallery g  ON  g.ImageGalleryID IN (i.ImageGalleryID))
            LEFT JOIN productvariantcombination c  ON  c.OptionValueID IN (v.OptionValueID))
            LEFT JOIN vendorstore e ON e.VendorStoreID IN( c.VendorStoreID))  
            LEFT JOIN shoppingcart s ON s.ProductID IN(c.ProductID))
            LEFT JOIN country cy ON cy.CountryID IN(u.CountryID))
            WHERE s.UserID='${UserID}' AND i.MainImage='Y'
            GROUP BY s.ID
            ORDER BY s.ID DESC
         `;
    let productCartList = await connection.query(viewCartListQuery, {
      type: QueryTypes.SELECT,
    });

    let productCombinationPrice;
    if (productCartList && productCartList.length > 0) {
      for (let i = 0; i < getProductComibnationDetail.length; i++) {
        let ProductVariantCombinationDetail = [];
        ProductVariantCombinationDetail.push(
          getProductComibnationDetail[i].ProductVariantCombinationDetail
        );
        ProductVariantCombinationDetail = `(${ProductVariantCombinationDetail.join(
          ","
        )})`;
        productCombinationPrice = await connection.query(
          `SELECT p.ProductID,p.Currency,c.ProductVariantCombinationID,c.VendorStoreID,c.Price AS ProductCombinationPrice,c.AvailableInventory,o.OptionID,o.OptionName,v.OptionValue,v.OptionValueID
                FROM ((((product p
                LEFT JOIN productvariantoption o ON o.ProductID IN( p.ProductID))
                LEFT JOIN productvariantoptionvalue v  ON  v.OptionID IN (o.OptionID)) 
                LEFT JOIN productvariantcombination c  ON  c.OptionValueID IN (v.OptionValueID))
                JOIN shoppingcart s ON s.ProductID IN(c.ProductID))
                WHERE s.UserID='${UserID}' AND c.ProductVariantCombinationID IN ${ProductVariantCombinationDetail}
                GROUP BY c.OptionValueID
               `,
          {
            type: QueryTypes.SELECT,
          }
        );
        productCombinationPriceDetail.push(productCombinationPrice);
      }
      let hhdh = 10
      let tempPC = productCombinationPriceDetail;

      // let tempPC = productCombinationPriceDetail.reverse()
      let tempProd = productCartList;
      let tempArray = [];

      for (let i = 0; i < tempProd.length; i++) {
        //let City = tempProd[i].StoreCity
        //let State = tempProd[i].StoreState
        let VATTaxRate = tempProd[i].VATTaxRate1;
        let Tax = tempProd[i].TaxVATApply;
        let CountryID = tempProd[i].StoreCountry;
        if (Tax === "Y") {
          if (CountryID == "16" || CountryID == "226") {
            tempProd[i].TaxRate = VATTaxRate;
          } else {
            tempProd[i].TaxRate = null;
          }
        } else {
          tempProd[i].TaxRate = null;
        }
        //!cuurency conversion
        if (Region == "Bangladesh") {
          let Price = tempProd[i].Price;
          if (tempProd[i].Currency == "USD") {
            tempProd[i]["Currency"] = "BDT";
            tempProd[i]["Price"] = parseFloat(currencyRate * Price).toFixed(2);
          }
        } else if (Region == "USA" || Region == "United States") {
          let Price = tempProd[i].Price;
          if (tempProd[i].Currency == "BDT") {
            tempProd[i]["Currency"] = "USD";
            tempProd[i]["Price"] = parseFloat(currencyRate * Price).toFixed(2);
          }
        } else {
          let Price = tempProd[i].Price;
          tempProd[i]["Currency"] = "USD";
          tempProd[i]["Price"] = parseFloat(currencyRate * Price).toFixed(2);
        }

        var obj = {
          ...tempProd[i],
        };
        let variantsLength = tempPC[i].length;
        if (Region == "Bangladesh") {
          for (let j = 0; j < variantsLength; j++) {
            let Price = tempPC[i][j].ProductCombinationPrice;
            if (tempPC[i][j].Currency == "USD") {
              tempPC[i][j]["Currency"] = "BDT";
              tempPC[i][j]["ProductCombinationPrice"] = parseFloat(
                currencyRate * Price
              ).toFixed(2);
            }
          }
        } else if (Region == "USA" || Region == "United States") {
          for (let j = 0; j < variantsLength; j++) {
            let Price = tempPC[i][j].ProductCombinationPrice;
            if (tempPC[i][j].Currency == "BDT") {
              tempPC[i][j]["Currency"] = "USD";
              tempPC[i][j]["ProductCombinationPrice"] = parseFloat(
                currencyRate * Price
              ).toFixed(2);
            }
          }
        } else {
          for (let j = 0; j < variantsLength; j++) {
            let Price = tempPC[i][j].ProductCombinationPrice;
            tempPC[i][j]["Currency"] = "USD";
            tempPC[i][j]["ProductCombinationPrice"] = parseFloat(
              currencyRate * Price
            ).toFixed(2);
          }
        }

        obj["ProductCombinations"] = tempPC[i];
        tempArray.push(obj);
      }
      if (productCombinationPrice && productCombinationPrice.length > 0) {
        res.status(200).json({
          status: true,
          productCartList: tempArray,
        });
      } else {
        res.status(200).json({
          status: true,
          productCartList: [],
        });
      }
    } else {
      res.status(200).json({
        status: true,
        productCartList: [],
      });
    }
  } catch (err) {
    //   next(err);
    console.log(err);
    res.status(200).json({
      status: false,
      message: err.message,
      productCartList: [],
    });
  }
};
exports.updateCart = async (req, res, next) => {
  try {
    let UserID = req.UserID;
    let ProductID;
    let ProductVariantCombinationID = [];
    let Quantity;
    var { ProductDetail } = req.body;
    Quantity = ProductDetail[0].Quantity;
    ProductID = ProductDetail[0].ProductID;
    let saveCombinationIDLength =
      ProductDetail[0].ProductVariantCombinationDetail.length;

    for (i = 0; i < saveCombinationIDLength; i++) {
      ProductVariantCombinationID.push(
        ProductDetail[0].ProductVariantCombinationDetail[i]
          .ProductVariantCombinationID
      );
    }
    ProductVariantCombinationID = `"${ProductVariantCombinationID.join(",")}"`;
    let checkIFProductExistsQuery = `SELECT * FROM shoppingcart WHERE  ProductID=${ProductID} AND UserID=${UserID} AND ProductVariantCombinationDetail = ${ProductVariantCombinationID}`;
    let checkIFProductExists = await connection.query(
      checkIFProductExistsQuery,
      {
        type: QueryTypes.SELECT,
      }
    );
    if (checkIFProductExists && checkIFProductExists.length > 0) {
      let LastUpdate = new Date().toISOString().slice(0, 19).replace("T", " ");
      let updateCartQuery = `UPDATE shoppingcart SET Quantity=Quantity+${Quantity} WHERE ProductID=${ProductID} AND UserID=${UserID} AND ProductVariantCombinationDetail = ${ProductVariantCombinationID}`;
      let updateCart = await connection.query(updateCartQuery);
      if (updateCart) {
        res.status(200).json({
          status: true,
          message: "Product Count in Shopping Cart updated successfully",
        });
      } else {
        res.status(200).json({
          status: false,
          message:
            "Error while updating Product Count in Shopping Cart updated",
        });
      }
    } else {
      res.status(200).json({
        status: false,
        message: "Product does not exist in shopping cart",
      });
    }
  } catch (err) {
    next(err);
    res.status(200).json({
      status: false,
      message: err.message,
    });
  }
};
exports.deleteFromCart = async (req, res, next) => {
  try {
    let ProductID = req.params.id;
    let UserID = req.UserID;
    const { ProductVariantCombinationDetail } = req.body;
    let ProductVariantCombinationID = [];
    for (let i = 0; i < ProductVariantCombinationDetail.length; i++) {
      ProductVariantCombinationID.push(
        ProductVariantCombinationDetail[i].ProductVariantCombinationID
      );
    }
    ProductVariantCombinationID = `"${ProductVariantCombinationID.join(",")}"`;
    let q_ = `
        select * from shoppingcart where ProductID = "${ProductID}" AND ProductVariantCombinationDetail = ${ProductVariantCombinationID} AND UserID = "${UserID}"`;
    let checkIfProductExists = await connection.query(q_, {
      type: QueryTypes.SELECT,
    });

    if (checkIfProductExists && checkIfProductExists.length > 0) {
      let deleteShoppingCartList = await connection.query(
        ` DELETE FROM shoppingcart WHERE ProductID = "${ProductID}" AND ProductVariantCombinationDetail = ${ProductVariantCombinationID} AND UserID = "${UserID}"`
      );
      if (deleteShoppingCartList) {
        res.status(200).json({
          status: true,
          message: `Product removed from Shopping Cart List successfully `,
        });
      } else {
        res.status(200).json({
          status: false,
          message: `Error while removing Product from Shopping Cart `,
        });
      }
    } else {
      res.status(200).json({
        status: false,
        message: `Product does not exist in Shopping Cart `,
      });
    }
  } catch (err) {
    next(err);
    res.status(200).json({
      status: false,
      message: err.message,
    });
    console.log(err.message);
  }
};
exports.temporaryCart = async (req, res, next) => {
  try {
    let { ProductDetail } = req.body;
    let getProductID = [];
    for (let i = 0; i < ProductDetail.length; i++) {
      getProductID.push(ProductDetail[i].ProductID);
    }
    getProductID = `(${getProductID.join(",")})`;
    let productCombinationPriceDetail = [];

    let viewCartListQuery = `SELECT p.ProductID,p.Title,r.CompanyName,r.VendorID,p.Price AS BasePrice,p.Currency,s.UserID,SUM(s.Quantity) AS Total_Quantity,g.Small,g.Medium,g.Large,i.MainImage,
        (SELECT COUNT(t.ProductID)
        from productreviewrating t WHERE t.ProductID = p.ProductID) AS REVIEW_COUNT,
        (SELECT AVG(t.Rating) from productreviewrating t WHERE t.ProductID = p.ProductID) AS  AVG_Rating
            FROM ((((((( product p
            LEFT JOIN vendor r ON r.VendorID IN( p.VendorID))       
            LEFT JOIN productvariantoption o ON o.ProductID IN( p.ProductID))
            LEFT JOIN productvariantoptionvalue v  ON  v.OptionID IN (o.OptionID))  
            LEFT JOIN productimage i  ON  i.OptionValueID IN (v.OptionValueID))
            LEFT JOIN imagegallery g  ON  g.ImageGalleryID IN (i.ImageGalleryID))
            LEFT JOIN productvariantcombination c  ON  c.OptionValueID IN (v.OptionValueID))
            LEFT JOIN shoppingcart s ON s.ProductID IN(c.ProductID))
            WHERE p.ProductID IN ${getProductID} AND i.MainImage='Y'
            GROUP BY p.ProductID
         `;
    let productCartList = await connection.query(viewCartListQuery, {
      type: QueryTypes.SELECT,
    });
    if (productCartList && productCartList.length > 0) {
      for (let i = 0; i < ProductDetail.length; i++) {
        let getProductVariantCombinationID = [];
        let saveProductID = [];
        saveProductID.push(ProductDetail[i].ProductID);
        saveProductID = `(${saveProductID.join(",")})`;
        let variantsLength =
          ProductDetail[i].ProductVariantCombinationDetail.length;
        let variants = ProductDetail[i].ProductVariantCombinationDetail;
        for (j = 0; j < variantsLength; j++) {
          getProductVariantCombinationID.push(
            variants[j].ProductVariantCombinationID
          );
        }
        getProductVariantCombinationID = `(${getProductVariantCombinationID.join(
          ","
        )})`;
        productCombinationPrice = await connection.query(
          `SELECT p.ProductID,c.ProductVariantCombinationID,c.Price AS ProductCombinationPrice,o.OptionID,o.OptionName,v.OptionValue,v.OptionValueID
                FROM ((((product p
                LEFT JOIN productvariantoption o ON o.ProductID IN( p.ProductID))
                LEFT JOIN productvariantoptionvalue v  ON  v.OptionID IN (o.OptionID)) 
                LEFT JOIN productvariantcombination c  ON  c.OptionValueID IN (v.OptionValueID))
                LEFT JOIN shoppingcart s ON s.ProductID IN(c.ProductID))
                WHERE p.ProductID IN ${saveProductID} AND c.ProductVariantCombinationID IN ${getProductVariantCombinationID}
                GROUP BY c.OptionValueID
               `,
          {
            type: QueryTypes.SELECT,
          }
        );
        productCombinationPriceDetail.push(productCombinationPrice);
      }
      if (productCombinationPrice && productCombinationPrice.length > 0) {
        res.status(200).json({
          status: true,
          productCartList,
          productCombinationPriceDetail,
        });
      } else {
        res.status(200).json({
          status: true,
          productCartList,
          productCombinationPriceDetail: [],
        });
      }
    } else {
      res.status(200).json({
        status: true,
        productCartList: [],
        productCombinationPriceDetail: [],
      });
    }
  } catch (err) {
    next(err);
    res.status(200).json({
      status: false,
      message: err.message,
      productCartList: [],
      productCombinationPriceDetail: [],
    });
  }
};




exports.getInventoryCount = async (req, res, next) => {
  try {
    const { productCartList } = req.body;
    let getInventoryCountQuery;
    let getInventoryCountResult = [];
    const storeActiveStatus = []
    const productActiveStatus = []

    for (let i = 0; i < productCartList.length; i++) {
      let tempArray = [];
      let saveProductCombinationID;
      let saveResult = productCartList[i].ProductCombinations;
      for (let j = 0; j < saveResult.length; j++) {
        tempArray.push(saveResult[j].ProductVariantCombinationID);
        saveProductCombinationID = `(${tempArray.join(",")})`;
      }
      // getInventoryCountQuery = await connection.query(
      //   ` select p.ProductID,p.Title,v.OptionValue,v.OptionValueID,i.*
      //           from product p
      //           LEFT JOIN productvariantoption o ON o.ProductID=p.ProductID
      //           LEFT JOIN productvariantoptionvalue v ON v.OptionID=o.OptionID
      //           LEFT JOIN productvariantcombination c ON c.OptionValueID=v.OptionValueID
      //           LEFT JOIN productinventory i ON i.ProductVariantCombinationID=c.ProductVariantCombinationID
      //            where i.ProductVariantCombinationID IN ${saveProductCombinationID}
      //           `,
      //   {
      //     type: QueryTypes.SELECT,
      //   }
      // );

      getInventoryCountQuery = await connection.query(
        `SELECT p.ProductID, p.Active AS productActiveStatus, p.Title, v.OptionValue, v.OptionValueID, i.*, vs.Active AS storeActiveStatus
  FROM product p
  LEFT JOIN productvariantoption o ON o.ProductID = p.ProductID
  LEFT JOIN productvariantoptionvalue v ON v.OptionID = o.OptionID
  LEFT JOIN productvariantcombination c ON c.OptionValueID = v.OptionValueID
  LEFT JOIN productinventory i ON i.ProductVariantCombinationID = c.ProductVariantCombinationID
  LEFT JOIN vendorstore vs ON p.StoreName = vs.StoreName
  WHERE i.ProductVariantCombinationID IN ${saveProductCombinationID}`,
        {
          type: QueryTypes.SELECT,
        }
      );

      getInventoryCountResult.push(getInventoryCountQuery);




    }



    // getInventoryCountResult[0].map((item) => {
    //   if (item['productActiveStatus'] == 'N') {

    //     console.log("=====================");
    //     productActiveStatus.push(item['Title'])
    //   }
    //   if (item['storeActiveStatus'] == 'N') {
    //     console.log("_____________________");
    //     storeActiveStatus.push(item['Title'])
    //   }
    // })

    for (let i = 0; i < getInventoryCountResult[0].length; i++) {
      const item = getInventoryCountResult[0][i];
      if (item['productActiveStatus'] == 'N') {
        productActiveStatus.push(item['Title'])
        break
      }
      if (item['storeActiveStatus'] == 'N') {
        storeActiveStatus.push(item['Title'])
        break
      }
    }


    console.log(storeActiveStatus, productActiveStatus);



    // let outOfStockProducts = [];
    // let getLength;
    // for (let i = 0; i < getInventoryCountResult.length; i++) {
    //   let productID = [];
    //   getLength = getInventoryCountResult[i];
    //   productID.push(getInventoryCountResult[i][0].ProductID);
    //   for (let j = 0; j < getLength.length; j++) {
    //     if (getInventoryCountResult[i][j].Inventory == 0) {
    //       outOfStockProducts.push(getInventoryCountResult[i]); //first met index is enough as whole that object will be of same product
    //       break; // so it will remove repetition of data where 2 variants are empty in same product it will show only once
    //     }
    //   }
    // }
    // let tempArray = [];

    // for (let i = 0; i <= outOfStockProducts.length - 1; i++) {
    //   var obj = {
    //     ProductDetail: outOfStockProducts[i],
    //   };
    //   tempArray.push(obj);
    // }




    let outOfStockProducts = [];
    let getLength;

    for (let i = 0; i < getInventoryCountResult.length; i++) {
      getLength = getInventoryCountResult[i].length;
      let isProductOutOfStock = false;

      for (let j = 0; j < getLength; j++) {
        if (getInventoryCountResult[i][j].Inventory === 0) {
          console.log("======================>", getInventoryCountResult[i], getInventoryCountResult[i][j])
          isProductOutOfStock = true;
          break;
        }
      }

      if (isProductOutOfStock) {
        outOfStockProducts.push(getInventoryCountResult[i]);
      }
    }

    let tempArray = [];

    for (let i = 0; i < outOfStockProducts.length; i++) {
      var obj = {
        ProductDetail: outOfStockProducts[i],
      };
      tempArray.push(obj);
    }


    if (getInventoryCountQuery && getInventoryCountQuery.length > 0) {
      if (tempArray && tempArray.length > 0) {
        res.status(200).json({
          status: true,
          outOfStockProducts: tempArray,
          storeActiveStatus, productActiveStatus
        });
      } else {
        res.status(200).json({
          status: true,
          outOfStockProducts: [],
          storeActiveStatus, productActiveStatus
        });
      }
    } else {
      res.status(200).json({
        status: false,
        outOfStockProducts: [],
        storeActiveStatus, productActiveStatus
      });
    }
  } catch (err) {
    console.log(err);
    // next(err);
    res.status(200).json({
      status: false,
      message: err.message,
      outOfStockProducts: [],
    });
    console.log(err.message);
  }
};






exports.oldgetInventoryCount = async (req, res, next) => {
  try {
    const { productCartList } = req.body;
    let getInventoryCountQuery;
    let getInventoryCountResult = [];
    for (let i = 0; i < productCartList.length; i++) {
      let tempArray = [];
      let saveProductCombinationID;
      let saveResult = productCartList[i].ProductCombinations;
      for (let j = 0; j < saveResult.length; j++) {
        tempArray.push(saveResult[j].ProductVariantCombinationID);
        saveProductCombinationID = `(${tempArray.join(",")})`;
      }
      getInventoryCountQuery = await connection.query(
        ` select p.ProductID,p.Title,v.OptionValue,v.OptionValueID,i.*
                from product p
                LEFT JOIN productvariantoption o ON o.ProductID=p.ProductID
                LEFT JOIN productvariantoptionvalue v ON v.OptionID=o.OptionID
                LEFT JOIN productvariantcombination c ON c.OptionValueID=v.OptionValueID
                LEFT JOIN productinventory i ON i.ProductVariantCombinationID=c.ProductVariantCombinationID
                 where i.ProductVariantCombinationID IN ${saveProductCombinationID}
                `,
        {
          type: QueryTypes.SELECT,
        }
      );
      getInventoryCountResult.push(getInventoryCountQuery);
    }

    let outOfStockProducts = [];
    let getLength;

    for (let i = 0; i < getInventoryCountResult.length; i++) {
      getLength = getInventoryCountResult[i].length
      let isProductOutOfStock = false;
      console.log("find-----", getInventoryCountResult[i].length, getInventoryCountResult[i])
      for (let j = 0; j < getLength; j++) {
        console.log("======================>", getInventoryCountResult[i][j].Inventory, getInventoryCountResult[i][j])

        if (getInventoryCountResult[i][j].Inventory === 0) {
          console.log("NOT FOUNT-----------------------", getInventoryCountResult[i][j])
          isProductOutOfStock = true;
          break;
        }
      }

      if (isProductOutOfStock) {
        outOfStockProducts.push(getInventoryCountResult[i]);
      }
    }

    let tempArray = [];

    for (let i = 0; i < outOfStockProducts.length; i++) {
      var obj = {
        ProductDetail: outOfStockProducts[i],
      };
      tempArray.push(obj);
    }
    console.log(getInventoryCountQuery, tempArray, "<===============================================")
    if (getInventoryCountQuery && getInventoryCountQuery.length > 0) {
      if (tempArray && tempArray.length > 0) {
        res.status(200).json({
          status: true,
          outOfStockProducts: tempArray,
        });
      } else {
        console.log("ENTERD HERE==========================")
        res.status(200).json({
          status: true,
          outOfStockProducts: [],
        });
      }
    } else {
      res.status(200).json({
        status: false,
        outOfStockProducts: [],
      });
    }
  } catch (err) {
    next(err);
    res.status(200).json({
      status: false,
      message: err.message,
      outOfStockProducts: [],
    });
    console.log(err.message);
  }
};
exports.viewCartListBackup = async (req, res, next) => {
  try {
    let Region = req.region;
    const currencyRate = req.currency_rate;
    let productCombinationPriceDetail = [];
    let UserID = req.UserID;
    let getProductComibnationDetail = await connection.query(
      `SELECT * from shoppingcart WHERE UserID='${UserID}' ORDER BY ID DESC
     `,
      {
        type: QueryTypes.SELECT,
      }
    );
    let viewCartListQuery = `SELECT p.*,k.City,k.Native,y.CityID AS ProductCityID,u.CountryID AS ProductCountry,r.CompanyName,r.VendorID,s.UserID,g.Small,g.Medium,g.Large,i.MainImage,s.AllowStorePickup,s.Quantity AS Total_Quantity,e.ZipCode AS VendorStoreZip,e.City AS StoreCity,e.CountryID AS StoreCountry,e.State AS StoreState,
        (SELECT COUNT(t.ProductID)
        from productreviewrating t WHERE t.ProductID = p.ProductID) AS REVIEW_COUNT,
        (SELECT AVG(t.Rating) from productreviewrating t WHERE t.ProductID = p.ProductID) AS  AVG_Rating
            FROM ((((((((((( product p
            LEFT JOIN productcity y ON y.ProductID IN( p.ProductID))
            LEFT JOIN city k ON k.CityID IN( y.CityID))
            LEFT JOIN productcountry u ON u.ProductID IN( p.ProductID))  
            LEFT JOIN vendor r ON r.VendorID IN( p.VendorID))      
            LEFT JOIN productvariantoption o ON o.ProductID IN( p.ProductID))
            LEFT JOIN productvariantoptionvalue v  ON  v.OptionID IN (o.OptionID))  
            LEFT JOIN productimage i  ON  i.OptionValueID IN (v.OptionValueID))
            LEFT JOIN imagegallery g  ON  g.ImageGalleryID IN (i.ImageGalleryID))
            LEFT JOIN productvariantcombination c  ON  c.OptionValueID IN (v.OptionValueID))
            LEFT JOIN vendorstore e ON e.VendorStoreID IN( c.VendorStoreID))
            LEFT JOIN shoppingcart s ON s.ProductID IN(c.ProductID))
            WHERE s.UserID='${UserID}' AND i.MainImage='Y' 
            GROUP BY s.ID
            ORDER BY s.ID DESC
         `;
    let productCartList = await connection.query(viewCartListQuery, {
      type: QueryTypes.SELECT,
    });
    let productCombinationPrice;
    if (productCartList && productCartList.length > 0) {
      for (let i = 0; i < getProductComibnationDetail.length; i++) {
        let ProductVariantCombinationDetail = [];
        ProductVariantCombinationDetail.push(
          getProductComibnationDetail[i].ProductVariantCombinationDetail
        );
        ProductVariantCombinationDetail = `(${ProductVariantCombinationDetail.join(
          ","
        )})`;
        productCombinationPrice = await connection.query(
          `SELECT p.ProductID,p.Currency,c.ProductVariantCombinationID,c.VendorStoreID,c.Price AS ProductCombinationPrice,c.AvailableInventory,o.OptionID,o.OptionName,v.OptionValue,v.OptionValueID
                FROM ((((product p
                LEFT JOIN productvariantoption o ON o.ProductID IN( p.ProductID))
                LEFT JOIN productvariantoptionvalue v  ON  v.OptionID IN (o.OptionID)) 
                LEFT JOIN productvariantcombination c  ON  c.OptionValueID IN (v.OptionValueID))
                JOIN shoppingcart s ON s.ProductID IN(c.ProductID))
                WHERE s.UserID='${UserID}' AND c.ProductVariantCombinationID IN ${ProductVariantCombinationDetail}
                GROUP BY c.OptionValueID
               `,
          {
            type: QueryTypes.SELECT,
          }
        );

        productCombinationPriceDetail.push(productCombinationPrice);

        let variantsLength = productCombinationPriceDetail[i].length;
        if (Region == "Bangladesh") {
          for (let j = 0; j < variantsLength; j++) {
            let Price =
              productCombinationPriceDetail[i][j].ProductCombinationPrice;
            if (productCombinationPriceDetail[i][j].Currency == "USD") {
              productCombinationPriceDetail[i][j]["Currency"] = "BDT";
              productCombinationPriceDetail[i][j]["ProductCombinationPrice"] =
                parseFloat(currencyRate * Price).toFixed(2);
            }
          }
        } else if (Region == "USA") {
          for (let j = 0; j < variantsLength; j++) {
            let Price =
              productCombinationPriceDetail[i][j].ProductCombinationPrice;
            if (productCombinationPriceDetail[i][j].Currency == "BDT") {
              productCombinationPriceDetail[i][j]["Currency"] = "USD";
              productCombinationPriceDetail[i][j]["ProductCombinationPrice"] =
                parseFloat(currencyRate * Price).toFixed(2);
            }
          }
        } else {
          for (let j = 0; j < variantsLength; j++) {
            let Price =
              productCombinationPriceDetail[i][j].ProductCombinationPrice;
            productCombinationPriceDetail[i][j]["Currency"] = "USD";
            productCombinationPriceDetail[i][j]["ProductCombinationPrice"] =
              parseFloat(currencyRate * Price).toFixed(2);
          }
        }
      }
      for (let i = 0; i < productCartList.length; i++) {
        let City = productCartList[i].StoreCity;
        let State = productCartList[i].StoreState;
        let Tax = productCartList[i].TaxVATApply;
        let CountryID = productCartList[i].StoreCountry;
        if (Tax == "Y") {
          if (CountryID == "16") {
            productCartList[i].TaxRate = "5.00";
          } else if (CountryID == "226" && State == "Georgia") {
            productCartList[i].TaxRate = "8.00";
          }
        } else {
          productCartList[i].TaxRate = null;
        }
        //!cuurency conversion
        if (Region == "Bangladesh") {
          let Price = productCartList[i].Price;
          if (productCartList[i].Currency == "USD") {
            productCartList[i]["Currency"] = "BDT";
            productCartList[i]["Price"] = parseFloat(
              currencyRate * Price
            ).toFixed(2);
          }
        } else if (Region == "USA") {
          let Price = productCartList[i].Price;
          if (productCartList[i].Currency == "BDT") {
            productCartList[i]["Currency"] = "USD";
            productCartList[i]["Price"] = parseFloat(
              currencyRate * Price
            ).toFixed(2);
          }
        } else {
          let Price = productCartList[i].Price;
          productCartList[i]["Currency"] = "USD";
          productCartList[i]["Price"] = parseFloat(
            currencyRate * Price
          ).toFixed(2);
        }
      }
      if (productCombinationPrice && productCombinationPrice.length > 0) {
        res.status(200).json({
          status: true,
          productCartList,
          productCombinationPriceDetail: productCombinationPriceDetail,
        });
      } else {
        res.status(200).json({
          status: false,
          productCartList,
          productCombinationPriceDetail: [],
        });
      }
    } else {
      res.status(200).json({
        status: true,
        productCartList: [],
        productCombinationPriceDetail: [],
      });
    }
  } catch (err) {
    next(err);
    res.status(200).json({
      status: false,
      message: err.message,
      productCartList: [],
      productCombinationPriceDetail: [],
    });
  }
};
