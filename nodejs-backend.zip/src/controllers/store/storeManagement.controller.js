const connection = require("../../db/db.connection");
const {
  QueryTypes
} = require("sequelize");
const {
  sendMail
} = require("../../utils/email");
const {
  sendEmail
} = require("../../utils/notificationsMail");
const {
  Notification,
} = require("../../controllers/usersControllers/users.controller");
const {
  createStore,
  issueToken
} = require("../pathao/pathao.controller");
//! Vendor Buisness CRUD
exports.registerVendorBuisness = async (req, res, next) => {
  let transaction;
  console.log(req.files);
  let TaxIDPic;
  try {
    if (req.file && Object.keys(req.file).length > 0) {
      if (req.file.path && req.file.path.length > 0) {
        TaxIDPic = req.file.TaxIDPic[0].path;
      } else {
        TaxIDPic = null;
      }
    } else {
      TaxIDPic = null;
    }
    const GovernmentIDPic = req.files.GovernmentIDPic[0].path;
    const CompanyLogo = req.files.CompanyLogo[0].path;
    const BannerImage = req.files.BannerImage[0].path;
    const GovernmentIDPicBackSide = req.files.GovernmentIDPicBackSide[0].path;

    console.log(TaxIDPic);
    console.log(GovernmentIDPic);
    console.log(CompanyLogo);
    console.log(BannerImage);
    console.log(GovernmentIDPicBackSide, "GovernmentIDPicBackSide");

    let {
      VendorID,
      CompanyName,
      TaxID,
      GovernmentID,
      Address1,
      Address2,
      CityID,
      City,
      State,
      ZipCode,
      GoogleMapID,
      CountryID,
      PaymentAccount,
      PaymentRouting,
      BusinessEmail,
      BusinessPhone,
      BusinessURL,
      PageURL,
      AllowDelivery,
      GatewayID,
      AllowStorePickup,
      ProductApproval,
      CreatedDate,
      LastUpdate,
      AdminNote,
    } = req.body;
    let ReceiverID = VendorID;
    transaction = await connection.transaction();
    console.log(req.body);
    let checkIfVendorExists = await vendorIDCheck(VendorID, transaction);
    console.log(checkIfVendorExists);
    let checkIfStoreNameExists = await CompanyNameCheck(
      CompanyName,
      transaction
    );
    console.log(checkIfStoreNameExists);
    if (checkIfVendorExists && checkIfVendorExists == "0") {
      if (checkIfStoreNameExists && checkIfStoreNameExists == "0") {
        if (
          GatewayID === "null" ||
          GatewayID === null ||
          GatewayID === undefined
        ) {
          GatewayID = 0;
        }
        let queryString = `insert into vendor (VendorID, CompanyName, 
            TaxID,TaxIDPic,GovernmentID,GovernmentIDPic,GovernmentIDPicBackSide,CompanyLogo,BannerImage,Address1, 
            Address2, CityID, City, State, ZipCode,GoogleMapID, CountryID,
            PaymentAccount,PaymentRouting,BusinessEmail,
            BusinessPhone,BusinessURL,PageURL,AllowDelivery,
            GatewayID,AllowStorePickup,ProductApproval,AdminNote ) 
            values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) `;
        let registerVendorQuery = await connection.query(queryString, {
          replacements: [
            VendorID,
            CompanyName,
            TaxID,
            TaxIDPic,
            GovernmentID,
            GovernmentIDPic,
            GovernmentIDPicBackSide,
            CompanyLogo,
            BannerImage,
            Address1,
            Address2,
            CityID,
            City,
            State,
            ZipCode,
            GoogleMapID,
            CountryID,
            PaymentAccount,
            PaymentRouting,
            BusinessEmail,
            BusinessPhone,
            BusinessURL,
            PageURL,
            AllowDelivery,
            GatewayID,
            AllowStorePickup,
            ProductApproval,
            CreatedDate,
            LastUpdate,
            AdminNote,
          ],
          transaction,
        });
        if (registerVendorQuery) {
          let LastUpdate = new Date()
            .toISOString()
            .slice(0, 19)
            .replace("T", " ");
          let addNewUserNotificationQuery;
          let addNewUserNotification;
          addNewUserNotificationQuery = `insert into notification (TypeID,Body,CreaterID,ReceiverID,LastUpdate) `;
          addNewUserNotificationQuery += ` values ("4","Your role has been changed to Vendor","1","${VendorID}","${LastUpdate}") `;
          addNewUserNotification = await connection.query(
            addNewUserNotificationQuery, {
            transaction,
          }
          );
          console.log(addNewUserNotification, "addNewUserNotification");
          if (addNewUserNotification) {
            let TypeID = "5";
            let CreaterID = "1";
            let Body = {
              body: "Your Buisness Registration request is sent to Admin for approval ",
            };
            let getDeviceIDQuery = ` SELECT DeviceID,EmailAddress
            FROM profile 
            WHERE UserID=${ReceiverID}`;
            let getDeviceID = await connection.query(getDeviceIDQuery, {
              type: QueryTypes.SELECT,
              transaction,
            });
            if (getDeviceID && getDeviceID.length > 0) {
              let Message = Body.body;
              let EmailAddress = getDeviceID[0].EmailAddress;
              sendEmail(EmailAddress, Message, TypeID);

              let sendNotification = await Notification(
                TypeID,
                Body,
                CreaterID,
                ReceiverID,
                transaction
              );
              console.log(sendNotification, "sendNotification");
              if (sendNotification) {
                if (transaction) await transaction.commit();
                res.status(200).json({
                  status: true,
                  message: `Vendor register successfully`,
                });
              } else {
                if (transaction) await transaction.rollback();
                res.status(200).json({
                  status: false,
                  message: "Error while sending Notification to User ",
                });
              }
            } else {
              if (transaction) await transaction.rollback();
              res.status(200).json({
                status: false,
                message: `Error while adding user data from database`,
              });
            }
          } else {
            if (transaction) await transaction.rollback();
            res.status(200).json({
              status: false,
              message: `Error while adding user notification into database`,
            });
          }
        } else {
          if (transaction) await transaction.rollback();
          res.status(200).json({
            status: false,
            message: `Error while registering vendor`,
          });
        }
      } else if (checkIfStoreNameExists && checkIfStoreNameExists == "1") {
        if (transaction) await transaction.rollback();
        res.status(200).json({
          status: false,
          message: "Company Name already exists,Please choose unique CompanyName",
        });
      }
    } else if (checkIfVendorExists && checkIfVendorExists == "1") {
      if (transaction) await transaction.rollback();
      res.status(200).json({
        status: false,
        message: "Vendor already register against this UserID",
      });
    }
  } catch (err) {
    console.log(err, "------------");
    if (transaction) await transaction.rollback();
    res.status(200).json({
      status: false,
      error: err.message,
    });
  }
};
let CompanyNameCheck = async (CompanyName, transaction) => {
  try {
    let user = await connection.query(
      `select * from vendor where CompanyName = '${CompanyName}'`, {
      type: QueryTypes.SELECT,
      transaction,
    }
    );
    if (user && user.length > 0) {
      return "1";
    } else {
      return "0";
    }
  } catch (err) {
    if (transaction) await transaction.rollback();
    console.log(err.message);
    return null;
  }
};
let vendorIDCheck = async (VendorID, transaction) => {
  try {
    let user = await connection.query(
      `select * from vendor where VendorID = '${VendorID}'`, {
      type: QueryTypes.SELECT,
      transaction,
    }
    );
    if (user && user.length > 0) {
      return "1";
    } else {
      return "0";
    }
  } catch (err) {
    if (transaction) await transaction.rollback();
    console.log(err.message);
    return null;
  }
};
exports.checkBusinessEmail = async (req, res, next) => {
  try {
    let {
      BusinessEmail
    } = req.body;
    let user = await connection.query(
      `select * from vendor where BusinessEmail = "${BusinessEmail}" `, {
      type: QueryTypes.SELECT,
    }
    );
    if (user && user.length > 0) {
      res.status(200).json({
        status: false,
        message: `BusinessEmail already exists`,
      });
    } else {
      res.status(200).json({
        status: true,
        message: `BusinessEmail does not exist `,
      });
    }
  } catch (error) {
    next(err);
    res.status(200).json({
      status: false,
      data: {},
      error: err.message,
    });
    console.log(err.message);
  }
};
exports.checkBusinessPhone = async (req, res, next) => {
  try {
    let {
      BusinessPhone
    } = req.body;

    let user = await connection.query(
      `select * from vendor where BusinessPhone = "${BusinessPhone}" `, {
      type: QueryTypes.SELECT,
    }
    );
    if (user && user.length > 0) {
      res.status(200).json({
        status: false,
        message: `BusinessPhone already exists`,
      });
    } else {
      res.status(200).json({
        status: true,
        message: `BusinessPhone does not exist `,
      });
    }
  } catch (error) {
    next(err);
    res.status(200).json({
      status: false,
      data: {},
      error: err.message,
    });
    console.log(err.message);
  }
};
exports.viewVendorStoreByName = async (req, res, next) => {
  try {
    console.log(req.params.name);
    let checkvendor = await connection.query(
      `select * from vendorstore WHERE StoreName='${req.params.name}' `, {
      type: QueryTypes.SELECT,
    }
    );
    console.log("------" + checkvendor);
    if (checkvendor && checkvendor.length > 0) {
      res.status(200).json({
        status: true,
        Store: checkvendor[0],
      });
    } else {
      res.status(200).json({
        status: false,
        message: "Store does not exist",
        Store: [],
      });
    }
  } catch (err) {
    next(err);
    res.status(200).json({
      status: false,
      profiles: [],
      error: err.message,
    });
    console.log(err.message);
  }
};
exports.viewVendorBusinessByName = async (req, res, next) => {
  try {
    var {
      limit,
      offset,
      search,
      sort
    } = req.body;
    limit = parseInt(limit);
    offset = parseInt(offset);
    offset = limit * offset;
    let viewVendorBuisness = await connection.query(
      `select * from vendor WHERE CompanyName='${req.params.name}' `, {
      type: QueryTypes.SELECT,
    }
    );
    console.log(viewVendorBuisness, "viewVendorBuisness");
    if (viewVendorBuisness && viewVendorBuisness.length > 0) {
      let VendorID = viewVendorBuisness[0].VendorID;
      let ProductsCount = await connection.query(
        `SELECT COUNT(ProductID ) as total_records FROM product WHERE VendorID ='${VendorID}' `, {
        type: QueryTypes.SELECT,
      }
      );
      if (ProductsCount && ProductsCount.length > 0) {
        let viewProductDetailsQuery =
          `SELECT p.ProductID,p.Title,p.Price,p.Currency,g.Small,g.Medium,g.Large
          FROM ((((product p 
          LEFT JOIN productvariantoption o ON o.ProductID IN (p.ProductID))
          LEFT JOIN productvariantoptionvalue v ON v.OptionID IN(o.OptionID))
          LEFT JOIN productimage i ON i.OptionValueID IN(v.OptionValueID))
          LEFT JOIN imagegallery g ON g.ImageGalleryID IN(i.ImageGalleryID))
          WHERE p.VendorID ="${VendorID}" AND i.MainImage = 'Y' AND p.Active = 'Y' AND p. Title LIKE "%${search}%" order by ProductID ${sort} limit ` +
          limit +
          " offset " +
          offset;
        let viewProductDetails = await connection.query(
          viewProductDetailsQuery, {
          type: QueryTypes.SELECT,
        }
        );
        if (viewVendorBuisness && viewVendorBuisness.length > 0) {
          let getProductReviewRatingCount = await connection.query(
            `
           SELECT AVG(r.Rating) AS StoreAverageRating,
         (SELECT COUNT(r.Review) 
          FROM product  p
          INNER JOIN productreviewrating r ON r.ProductID IN (p.ProductID)
          WHERE p.VendorID="${VendorID}") TotalVendorReview 
          FROM product  p
           INNER JOIN productreviewrating r ON r.ProductID IN (p.ProductID)
           WHERE p.VendorID="${VendorID} AND p.Active = 'Y'
           GROUP BY p.VendorID"
           `, {
            type: QueryTypes.SELECT,
          }
          );
          if (
            getProductReviewRatingCount &&
            getProductReviewRatingCount.length > 0
          ) {
            res.status(200).json({
              status: true,
              total_Products: ProductsCount[0].total_records,
              business: viewVendorBuisness[0],
              Products: viewProductDetails,
              ProductReviewCount: getProductReviewRatingCount[0],
            });
          } else {
            res.status(200).json({
              status: false,
              total_Products: ProductsCount[0].total_records,
              business: [],
              Products: [],
              ProductReviewCount: [],
            });
          }
        } else {
          res.status(200).json({
            status: false,
            total_Products: ProductsCount[0].total_records,
            business: [],
            Products: [],
          });
        }
      }
    } else {
      res.status(200).json({
        status: false,
        profiles: [],
        message: "Error while getting buisness records from DB",
      });
    }
  } catch (err) {
    next(err);
    res.status(200).json({
      status: false,
      profiles: [],
      error: err.message,
    });
    console.log(err.message);
  }
};
exports.viewVendorBuisnessById = async (req, res, next) => {
  try {
    let vendorDetails = await connection.query(
      `
          select v.*, s.StateID
          FROM vendor v
          LEFT JOIN state s ON s.State = v.State
          WHERE v.VendorID = '${req.params.id}'
          `, {
      type: QueryTypes.SELECT,
    }
    );
    // console.log(user)
    if (vendorDetails && vendorDetails.length > 0) {
      let vendorCommissionRate = await connection.query(
        `
            select * from vendorcommissionrate 
            WHERE VendorID = '${req.params.id}'
            ORDER BY ID DESC
            `, {
        type: QueryTypes.SELECT,
      }
      );
      console.log(vendorCommissionRate);
      if (vendorCommissionRate && vendorCommissionRate.length > 0) {
        res.status(200).json({
          status: true,
          business: vendorDetails[0],
          vendorCommissionRate: vendorCommissionRate[0],
        });
      } else {
        res.status(200).json({
          status: true,
          message: "Business Already exists",
          business: vendorDetails[0],
          vendorCommissionRate: null,
        });
      }
    } else {
      res.status(200).json({
        status: false,
        message: "Business does not exist",
        business: null,
        vendorCommissionRate: null,
      });
    }
  } catch (err) {
    next(err);
    res.status(200).json({
      status: false,
      business: null,
      vendorCommissionRate: null,
      error: err.message,
    });
    console.log(err.message);
  }
};
exports.viewVendorBuisnessPaginated = async (req, res, next) => {
  try {
    let {
      limit,
      offset
    } = req.body;
    limit = parseInt(limit);
    offset = parseInt(offset);
    offset = limit * offset;
    let vendorsCount = await connection.query(
      `
          SELECT COUNT(VendorID) as total_records FROM vendor `, {
      type: QueryTypes.SELECT,
    }
    );
    if (vendorsCount && vendorsCount.length > 0) {
      let viewVendorBusinessQuery =
        "SELECT *  FROM vendor order by VendorID desc limit " +
        limit +
        " offset " +
        offset;
      let viewVendorBusiness = await connection.query(viewVendorBusinessQuery, {
        type: QueryTypes.SELECT,
      });
      if (viewVendorBusiness && viewVendorBusiness.length > 0) {
        res.status(200).json({
          status: true,
          total_records: vendorsCount[0].total_records,
          VendorBuisness: viewVendorBusiness,
        });
      } else {
        res.status(200).json({
          status: true,
          total_records: vendorsCount[0].total_records,
          VendorBuisness: [],
        });
      }
    }
  } catch (err) {
    console.log(err.message);
    res.status(200).json({
      status: false,
      VendorBuisness: [],
      error: err.message,
    });
  }
};
exports.viewVendorBuisnessByPhoneFilter = async (req, res, next) => {
  try {
    let {
      limit,
      offset,
      search,
      sort
    } = req.body;
    limit = parseInt(limit);
    offset = parseInt(offset);
    offset = limit * offset;
    console.log(req.body);
    search = search.trim();

    let vendorsCount = await connection.query(
      `
          SELECT COUNT(VendorID) as total_records FROM vendor WHERE BusinessPhone LIKE "%${search}%"`, {
      type: QueryTypes.SELECT,
    }
    );
    if (vendorsCount && vendorsCount.length > 0) {
      let viewVendorBuisnessQuery =
        `
          SELECT * FROM vendor WHERE BusinessPhone LIKE "%${search}%"
          order by VendorID ${sort}
          limit ` +
        limit +
        " offset " +
        offset;
      let viewVendorBuisness = await connection.query(viewVendorBuisnessQuery, {
        type: QueryTypes.SELECT,
      });
      if (viewVendorBuisness && viewVendorBuisness.length > 0) {
        res.status(200).json({
          status: true,
          total_records: vendorsCount[0].total_records,
          VendorBuisness: viewVendorBuisness,
        });
      } else {
        res.status(200).json({
          status: true,
          total_records: vendorsCount[0].total_records,
          VendorBuisness: [],
        });
      }
    }
  } catch (err) {
    next(err);
    res.status(200).json({
      status: false,
      VendorBuisness: {},
      error: err.message,
    });
    console.log(err.message);
  }
};
exports.viewVendorBuisnessByEmailFilter = async (req, res, next) => {
  try {
    let {
      limit,
      offset,
      search,
      sort
    } = req.body;
    limit = parseInt(limit);
    offset = parseInt(offset);
    offset = limit * offset;
    console.log(req.body);
    search = search.trim();

    let vendorsCount = await connection.query(
      `
          SELECT COUNT(VendorID) as total_records FROM vendor WHERE BusinessEmail LIKE "%${search}%" `, {
      type: QueryTypes.SELECT,
    }
    );
    if (vendorsCount && vendorsCount.length > 0) {
      let viewVendorBuisnessQuery =
        `
          SELECT * FROM vendor WHERE BusinessEmail LIKE "%${search}%"
          order by VendorID ${sort} limit ` +
        limit +
        " offset " +
        offset;
      let viewVendorBuisness = await connection.query(viewVendorBuisnessQuery, {
        type: QueryTypes.SELECT,
      });
      if (viewVendorBuisness && viewVendorBuisness.length > 0) {
        res.status(200).json({
          status: true,
          total_records: vendorsCount[0].total_records,
          VendorBuisness: viewVendorBuisness,
        });
      } else {
        res.status(200).json({
          status: true,
          total_records: vendorsCount[0].total_records,
          VendorBuisness: [],
        });
      }
    }
  } catch (err) {
    next(err);
    res.status(200).json({
      status: false,
      VendorBuisness: {},
      error: err.message,
    });
    console.log(err.message);
  }
};
exports.viewVendorBuisnessByNameFilter = async (req, res, next) => {
  try {
    let {
      limit,
      offset,
      search,
      sort
    } = req.body;
    limit = parseInt(limit);
    offset = parseInt(offset);
    offset = limit * offset;
    console.log(req.body);
    search = search.trim();

    let vendorsCount = await connection.query(
      `
          SELECT COUNT(VendorID) as total_records FROM vendor WHERE CompanyName LIKE "%${search}%" `, {
      type: QueryTypes.SELECT,
    }
    );
    if (vendorsCount && vendorsCount.length > 0) {
      let viewVendorBuisnessQuery =
        `
          SELECT * FROM vendor WHERE CompanyName LIKE "%${search}%"
          order by VendorID ${sort}
          limit ` +
        limit +
        " offset " +
        offset;
      let viewVendorBuisness = await connection.query(viewVendorBuisnessQuery, {
        type: QueryTypes.SELECT,
      });
      if (viewVendorBuisness && viewVendorBuisness.length > 0) {
        res.status(200).json({
          status: true,
          total_records: vendorsCount[0].total_records,
          VendorBuisness: viewVendorBuisness,
        });
      } else {
        res.status(200).json({
          status: true,
          total_records: vendorsCount[0].total_records,
          VendorBuisness: [],
        });
      }
    }
  } catch (err) {
    console.log(err);
    res.status(200).json({
      status: false,
      VendorBuisness: [],
      error: err.message,
    });
    console.log(err.message);
  }
};
exports.updateVendorBuisnessById = async (req, res, next) => {
  try {
    const id = req.params.id;
    var checkBusinessUser = await connection.query(
      `
          select * from vendor where VendorID = '${id}'
          `, {
      type: QueryTypes.SELECT,
    }
    );
    if (checkBusinessUser && checkBusinessUser.length > 0) {
      let TaxIDPic;
      let GovernmentIDPic;
      let CompanyLogo;
      let BannerImage;
      let GovernmentIDPicBackSide;
      console.log(req.files);

      if (Object.keys(req.files).length > 0) {
        if (req.files.TaxIDPic && req.files.TaxIDPic.length > 0) {
          TaxIDPic = req.files.TaxIDPic[0].path;
        } else {
          TaxIDPic = checkBusinessUser[0].TaxIDPic;
        }
        if (req.files.GovernmentIDPic && req.files.GovernmentIDPic.length > 0) {
          GovernmentIDPic = req.files.GovernmentIDPic[0].path;
        } else {
          GovernmentIDPic = checkBusinessUser[0].GovernmentIDPic;
        }
        if (req.files.CompanyLogo && req.files.CompanyLogo.length > 0) {
          CompanyLogo = req.files.CompanyLogo[0].path;
        } else {
          CompanyLogo = checkBusinessUser[0].CompanyLogo;
        }
        if (req.files.BannerImage && req.files.BannerImage.length > 0) {
          BannerImage = req.files.BannerImage[0].path;
        } else {
          BannerImage = checkBusinessUser[0].BannerImage;
        }
        if (req.files.GovernmentIDPicBackSide && req.files.GovernmentIDPicBackSide.length > 0) {
          GovernmentIDPicBackSide = req.files.GovernmentIDPicBackSide[0].path;
        } else {
          GovernmentIDPicBackSide = checkBusinessUser[0].GovernmentIDPicBackSide;
        }
      } else {
        CompanyLogo = checkBusinessUser[0].CompanyLogo;
        GovernmentIDPic = checkBusinessUser[0].GovernmentIDPic;
        TaxIDPic = checkBusinessUser[0].TaxIDPic;
        BannerImage = checkBusinessUser[0].BannerImage;
        GovernmentIDPicBackSide = checkBusinessUser[0].GovernmentIDPicBackSide;

      }

      let {
        CompanyName,
        TaxID,
        GovernmentID,
        Address1,
        Address2,
        CityID,
        City,
        State,
        ZipCode,
        GoogleMapID,
        CountryID,
        PaymentAccount,
        PaymentRouting,
        BusinessEmail,
        BusinessPhone,
        BusinessURL,
        PageURL,
        ReviewedByAdmin,
        AllowDelivery,
        GatewayID,
        AllowStorePickup,
        ProductApproval,
        AdminNote,
        EmailVerified,
        PhoneVerified,
        About,
        Policies,
        bankBranch,
        bankName
      } = req.body;
      console.log(req.body, "body")

      // return
      let LastUpdate = new Date().toISOString().slice(0, 19).replace("T", " ");


      if (CompanyName == checkBusinessUser[0].CompanyName) {
        console.log("inside if ")
        let updateQueryString = `
          UPDATE vendor SET CompanyName = ? , TaxID = ? , TaxIDPic = ? ,
            GovernmentID = ? , GovernmentIDPic = ? , GovernmentIDPicBackSide=?, CompanyLogo = ? , BannerImage = ? , Address1 = ? , Address2 = ? , CityID = ? ,City = ? , State = ? , ZipCode = ? , GoogleMapID = ? , CountryID = ? ,
            PaymentAccount = ? , PaymentRouting = ? , BusinessEmail = ? , BusinessPhone = ? , EmailVerified = ? , PhoneVerified = ? , BusinessURL = ? , PageURL = ?  , AllowDelivery = ? ,GatewayID = ? , AllowStorePickup = ? , ProductApproval = ? , LastUpdate = ? , About = ? , Policies = ? , AdminNote = ? , bankName = ? , bankBranch = ?
            WHERE VendorID = "${id}"
          `;
        var updateBusinessQuery = await connection.query(updateQueryString, {
          replacements: [
            CompanyName,
            TaxID,
            TaxIDPic,
            GovernmentID,
            GovernmentIDPic,
            GovernmentIDPicBackSide,
            CompanyLogo,
            BannerImage,
            Address1,
            Address2,
            CityID,
            City,
            State,
            ZipCode,
            GoogleMapID,
            CountryID,
            PaymentAccount,
            PaymentRouting,
            BusinessEmail,
            BusinessPhone,
            EmailVerified,
            PhoneVerified,
            BusinessURL,
            PageURL,
            AllowDelivery,
            GatewayID,
            AllowStorePickup,
            ProductApproval,
            LastUpdate,
            About,
            Policies,
            AdminNote,
            bankName,
            bankBranch
          ],
        });
        if (updateBusinessQuery && updateBusinessQuery.length > 0) {
          res.status(200).json({
            status: true,
            message: `
          Vendor Store updated successfully `,
          });
        } else {
          res.status(200).json({
            status: false,
            message: `
          Error
          while updating vendor store `,
          });
        }
      } else {
        console.log(console.log("inside else "))
        let checkIFCompanyNameAlreadyExists = await connection.query(
          `
          select * from vendor where CompanyName = '${CompanyName}'
          `, {
          type: QueryTypes.SELECT,
        }
        );
        console.log(checkIFCompanyNameAlreadyExists);
        if (
          checkIFCompanyNameAlreadyExists &&
          checkIFCompanyNameAlreadyExists.length > 0
        ) {
          res.status(200).json({
            status: false,
            profile: {},
            message: `
          Company Name already taken, please select another one `,
          });
        } else {
          let updateQueryString = `
          UPDATE vendor SET CompanyName = ? , TaxID = ? , TaxIDPic = ? ,
            GovernmentID = ? , GovernmentIDPic = ? ,GovernmentIDPicBackSide=?, CompanyLogo = ? , BannerImage = ? , Address1 = ? , Address2 = ? , CityID = ? ,
            City = ? , State = ? , ZipCode = ? , GoogleMapID = ? , CountryID = ? ,
            PaymentAccount = ? , PaymentRouting = ? , BusinessEmail = ? , BusinessPhone = ? , EmailVerified = ? , PhoneVerified = ? ,
            BusinessURL = ? , PageURL = ? , AllowDelivery = ? ,
            GatewayID = ? , AllowStorePickup = ? , ProductApproval = ? , LastUpdate = ? , About = ? , Policies = ? , AdminNote = ?
            WHERE VendorID = "${id}"
          `;
          let updateBusinessQuery = await connection.query(updateQueryString, {
            replacements: [
              CompanyName,
              TaxID,
              TaxIDPic,
              GovernmentID,
              GovernmentIDPic,
              GovernmentIDPicBackSide,
              CompanyLogo,
              BannerImage,
              Address1,
              Address2,
              CityID,
              City,
              State,
              ZipCode,
              GoogleMapID,
              CountryID,
              PaymentAccount,
              PaymentRouting,
              BusinessEmail,
              BusinessPhone,
              EmailVerified,
              PhoneVerified,
              BusinessURL,
              PageURL,
              AllowDelivery,
              GatewayID,
              AllowStorePickup,
              ProductApproval,
              LastUpdate,
              About,
              Policies,
              AdminNote,
            ],
          });

          if (updateBusinessQuery && updateBusinessQuery.length > 0) {
            res.status(200).json({
              status: true,
              message: `
          Vendor Business updated successfully `,
            });
          } else {
            res.status(200).json({
              status: false,
              message: `
          Error
          while updating vendor Business `,
            });
          }
        }
      }
    } else {
      res.status(200).json({
        status: false,
        message: `
          VendorID does not exist `,
      });
    }
  } catch (err) {
    console.log(err);
    res.status(200).json({
      status: false,
      error: err.message,
    });
  }
};
//! Vendor Store CRUD
exports.RegistervendorStore = async (req, res, next) => {
  let transaction;
  try {
    let {
      VendorID,
      StoreName,
      Address1,
      Address2,
      CityID,
      City,
      State,
      ZipCode,
      CountryID,
      StoreEmail,
      StorePhone,
      EmailVerified,
      PhoneVerified,
      StoreFAX,
      StoreURL,
      GoogleMapID,
      ExceptDropOff,
      AdminNote,
      zone_id,
      area_id,
      pathaoToken,
      city_id,
    } = req.body;
    let Active = "Y";
    transaction = await connection.transaction();
    CityID = CountryID == "16" ? CityID : CityID ? CityID : null
    city_id = CountryID == "16" ? city_id : city_id ? city_id : null
    zone_id = CountryID == "16" ? zone_id : null
    area_id = CountryID == "16" ? area_id : null


    console.log(city_id, "city_id")
    console.log(CityID, "CityID") ///new changes

    LastUpdate = new Date().toISOString().slice(0, 19).replace("T", " ");

    let checkIfStoreExists = await vendorStoreIDCheck(VendorID, transaction);
    console.log(checkIfStoreExists);

    let checkIfStoreNameExists = await StoreNameCheck(StoreName, transaction);
    console.log(checkIfStoreNameExists);

    if (checkIfStoreExists && checkIfStoreExists === "1") {
      if (checkIfStoreNameExists && checkIfStoreNameExists === "0") {
        if (StorePhone && StorePhone.length == 13 && CountryID === "16") {
          StorePhone = StorePhone.slice(2);
        }
        let queryString = `
          insert into vendorstore(VendorID, StoreName,
            Address1, Address2, CityID, City, State,
            ZipCode, CountryID, StoreEmail, StorePhone, EmailVerified, PhoneVerified, StoreFAX, StoreURL, GoogleMapID, ExceptDropOff, Active, LastUpdate, AdminNote,city_id,zone_id,area_id)
          values( ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? ,?,?,?)
          `;
        let vendorStoreQuery = await connection.query(queryString, {
          replacements: [
            VendorID,
            StoreName,
            Address1,
            Address2,
            CityID,
            City,
            State,
            ZipCode,
            CountryID,
            StoreEmail,
            StorePhone,
            EmailVerified,
            PhoneVerified,
            StoreFAX,
            StoreURL,
            GoogleMapID,
            ExceptDropOff,
            Active,
            LastUpdate,
            AdminNote,
            city_id,
            zone_id,
            area_id,
          ],
          transaction,
        });
        let ReceiverID = VendorID;
        let response;

        if (vendorStoreQuery) {
          if (CountryID == "16") {
            try {
              response = await createStore(
                StoreName,
                StorePhone,
                Address1,
                city_id,
                zone_id,
                area_id,
                pathaoToken
              );
              console.log(
                response,
                "response in --------------------------------------------"
              );
            } catch (error) {
              if (transaction) await transaction.rollback();
              res.status(200).json({
                status: false,
                message: error.response.data,
              });
            }
            if (response) {
              if (
                response.data.message ===
                "You already have a almost same pending store request."
              ) {
                let updatePthaoStoreRequest;
                updatePthaoStoreRequest = await connection.query(
                  `UPDATE vendorstore SET PthaoStoreRequest="In Queue" WHERE StoreName="${StoreName}" `, {
                  transaction,
                }
                );
                if (updatePthaoStoreRequest) {
                  if (transaction) await transaction.commit(); //!final commit
                  res.status(200).json({
                    status: true,
                    message: ` Successfully Added Store in Queue Request `,
                    pathaoResponse: response.data,
                  });
                } else {
                  if (transaction) await transaction.rollback();
                  res.status(200).json({
                    status: false,
                    message: "Error while updating Pathao Strore Queue Status ",
                    error: {
                      name: ["Error while updating Pathao Strore Queue Status "],
                    },
                  });
                }
              } else if (
                response.data.message ===
                "Store created successfully, Please wait one hour for approval."
              ) {
                console.log(response.data);
                let TypeID = "5";
                let CreaterID = "1";
                let Body = {
                  body: "Your Store is Registered Successfully !! PLease wait 24 to 48 hours for approval ",
                };
                let getDeviceIDQuery = ` SELECT DeviceID,EmailAddress
                 FROM profile
                WHERE UserID=${ReceiverID}`;
                let getDeviceID = await connection.query(getDeviceIDQuery, {
                  type: QueryTypes.SELECT,
                  transaction,
                });
                let Message = Body.body;
                if (getDeviceID && getDeviceID.length > 0) {
                  let EmailAddress = getDeviceID[0].EmailAddress;
                  sendEmail(EmailAddress, Message, TypeID);
                  let sendNotification = await Notification(
                    TypeID,
                    Body,
                    CreaterID,
                    ReceiverID,
                    transaction
                  );
                  console.log(sendNotification, "sendNotification");
                  if (sendNotification) {
                    if (transaction) await transaction.commit(); //!final commit
                    res.status(200).json({
                      status: true,
                      message: ` Vendor Store added successfully `,
                      pathaoResponse: response.data,
                    });
                  } else {
                    if (transaction) await transaction.rollback();
                    res.status(200).json({
                      status: false,
                      message: "Please fix the given errors",
                      error: {
                        name: ["Error while sending Notification to User"],
                      },
                    });

                  }
                } else {
                  if (transaction) await transaction.rollback();
                  res.status(200).json({
                    status: false,
                    message: "Please fix the given errors",
                    error: {
                      name: ["Error while getting record from DB"],
                    },
                  });

                }
              } else {
                if (transaction) await transaction.rollback();
                res.status(200).json({
                  status: false,
                  message: response.data.message,
                  error: response.data.errors,
                });
              }
            } else {
              if (transaction) await transaction.rollback();
              res.status(200).json({
                status: false,
                message: ` Error while getting pathao store register api response `,
                error: {
                  name: [" Error while getting pathao store register api response "],
                },
              });
            }
          }
	//	else {
          //  if (transaction) await transaction.commit(); //!final commit
           // res.status(200).json({
         //     status: true,
          //    message: ` Successfully registered `,
         //   });
         // }

		else {
            let updateQuery = await connection.query(
              `UPDATE vendorstore SET PthaoStoreResponse="USA CASE" WHERE StoreName = "${StoreName}" `,//test this as wel
              {
                transaction,
              }
            );
            if (updateQuery) {
              if (transaction) await transaction.commit(); //!final commit
              res.status(200).json({
                status: true,
                message: ` Successfully registered `,
              });
            } else {
              if (transaction) await transaction.rollback();
              res.status(200).json({
                status: false,
                message: "Please fix the given errors",
                error: {
                  name: ["Registeration Failed"],//please change messages here accrodingly
                },
              });
            }
          }

        } else {
          if (transaction) await transaction.rollback();
          res.status(200).json({
            status: false,
            message: "Please fix the given errors",
            error: {
              name: ["Error while registering vendor store"],
            },
          });
        }
      } else if (checkIfStoreNameExists && checkIfStoreNameExists == "1") {
        if (transaction) await transaction.rollback();
        res.status(200).json({
          status: false,
          message: "Please fix the given errors",
          error: {
            name: ["StoreName already exists, Please choose a unique Storename"],
          },
        });
      }
    } else if (checkIfStoreExists && checkIfStoreExists == "0") {
      if (transaction) await transaction.rollback();
      res.status(200).json({
        status: false,
        message: "Please fix the given errors",
        error: {
          name: [" Vendor Business does not exist"],
        },
      });
    }
  } catch (err) {
    console.log(err.message, "*******");
    if (transaction) await transaction.rollback();
    res.status(200).json({
      status: false,
      message: "Please fix the given errors",
      error: {
        name: [err.message],
      },
    });
  }
};
let StoreNameCheck = async (StoreName, transaction) => {
  try {
    let user = await connection.query(
      `
          select * from vendorstore where StoreName = '${StoreName}'
          `, {
      type: QueryTypes.SELECT,
      transaction,
    }
    );
    if (user && user.length > 0) {
      return "1";
    } else {
      return "0";
    }
  } catch (err) {
    if (transaction) await transaction.rollback();
    console.log(err.message);
    return null;
  }
};
let vendorStoreIDCheck = async (VendorID, transaction) => {
  try {
    let user = await connection.query(
      `
          select * from vendor where VendorID = '${VendorID}'
          `, {
      type: QueryTypes.SELECT,
      transaction,
    }
    );
    if (user && user.length > 0) {
      return "1";
    } else {
      return "0";
    }
  } catch (err) {
    if (transaction) await transaction.rollback();
    console.log(err.message);
    return null;
  }
};
exports.checkStoreEmail = async (req, res, next) => {
  try {
    let {
      StoreEmail
    } = req.body;
    let user = await connection.query(
      `
          select * from vendorstore where StoreEmail = "${StoreEmail}"
          `, {
      type: QueryTypes.SELECT,
    }
    );
    if (user && user.length > 0) {
      res.status(200).json({
        status: false,
        message: `
          StoreEmail already exists `,
      });
    } else {
      res.status(200).json({
        status: true,
        message: `
          StoreEmail does not exist `,
      });
    }
  } catch (error) {
    next(err);
    res.status(200).json({
      status: false,
      data: {},
      error: err.message,
    });
    console.log(err.message);
  }
};
exports.viewVendorStoreByVendorId = async (req, res, next) => {
  try {
    let user = await connection.query(
      `
          SELECT * FROM vendorstore WHERE VendorID = '${req.params.id}' 
          `, {
      type: QueryTypes.SELECT,
    }
    );
    if (user && user.length > 0) {
      res.status(200).json({
        status: true,
        Store: user,
      });
    } else {
      res.status(200).json({
        status: true,
        Store: [],
      });
    }
  } catch (err) {
    next(err);
    res.status(200).json({
      status: false,
      Store: [],
      error: err.message,
    });
    console.log(err.message);
  }
};
exports.viewVendorStoreByVendorStoreId = async (req, res, next) => {
  try {
    let user = await connection.query(
      `
          SELECT * FROM vendorstore WHERE VendorStoreID = '${req.params.id}'
          `, {
      type: QueryTypes.SELECT,
    }
    );
    if (user && user.length > 0) {
      res.status(200).json({
        status: true,
        Store: user,
      });
    } else {
      res.status(200).json({
        status: true,
        Store: [],
      });
    }
  } catch (err) {
    next(err);
    res.status(200).json({
      status: false,
      Store: [],
      error: err.message,
    });
    console.log(err.message);
  }
};
exports.viewAllVendorStore = async (req, res, next) => {
  try {
    let {
      limit,
      offset
    } = req.body;
    limit = parseInt(limit);
    offset = parseInt(offset);
    offset = limit * offset;
    let vendorsCount = await connection.query(
      `
          SELECT COUNT(VendorStoreID) as total_records FROM vendorstore `, {
      type: QueryTypes.SELECT,
    }
    );
    if (vendorsCount && vendorsCount.length > 0) {
      let allVendorStoreDetailsQuery =
        "SELECT *  FROM vendorstore order by VendorStoreID desc limit " +
        limit +
        " offset " +
        offset;
      let allVendorStoreDetails = await connection.query(
        allVendorStoreDetailsQuery, {
        type: QueryTypes.SELECT,
      }
      );
      if (allVendorStoreDetails && allVendorStoreDetails.length > 0) {
        res.status(200).json({
          status: true,
          total_records: vendorsCount[0].total_records,
          Stores: allVendorStoreDetails,
        });
      } else {
        res.status(200).json({
          status: true,
          total_records: vendorsCount[0].total_records,
          Stores: [],
        });
      }
    }
  } catch (err) {
    next(err);
    res.status(200).json({
      status: false,
      Stores: {},
      error: err.message,
    });
    console.log(err.message);
  }
};
exports.viewVendorStoreByPhoneFilter = async (req, res, next) => {
  try {
    let {
      limit,
      offset,
      search,
      sort
    } = req.body;
    limit = parseInt(limit);
    offset = parseInt(offset);
    offset = limit * offset;
    console.log(req.body);
    search = search.trim();

    let usersCount = await connection.query(
      `
          SELECT COUNT(VendorID) as total_records FROM vendorstore WHERE StorePhone LIKE "%${search}%" `, {
      type: QueryTypes.SELECT,
    }
    );
    if (usersCount && usersCount.length > 0) {
      let data =
        `
          SELECT * FROM vendorstore WHERE StorePhone LIKE "%${search}%"
          order by VendorID ${sort}
          limit ` +
        limit +
        " offset " +
        offset;
      let allUsers = await connection.query(data, {
        type: QueryTypes.SELECT,
      });
      if (allUsers && allUsers.length > 0) {
        res.status(200).json({
          status: true,
          total_records: usersCount[0].total_records,
          Stores: allUsers,
        });
      } else {
        res.status(200).json({
          status: true,
          total_records: usersCount[0].total_records,
          Stores: [],
        });
      }
    }
  } catch (err) {
    next(err);
    res.status(200).json({
      status: false,
      profile: {},
      error: err.message,
    });
    console.log(err.message);
  }
};
exports.viewVendorStoreByEmailFilter = async (req, res, next) => {
  try {
    let {
      limit,
      offset,
      search,
      sort
    } = req.body;
    limit = parseInt(limit);
    offset = parseInt(offset);
    offset = limit * offset;
    console.log(req.body);
    search = search.trim();

    let usersCount = await connection.query(
      `
          SELECT COUNT(VendorID) as total_records FROM vendorstore WHERE StoreEmail LIKE "%${search}%" `, {
      type: QueryTypes.SELECT,
    }
    );
    if (usersCount && usersCount.length > 0) {
      let data =
        `
          SELECT * FROM vendorstore WHERE StoreEmail LIKE "%${search}%"
          order by VendorID ${sort}
          limit ` +
        limit +
        " offset " +
        offset;
      let allUsers = await connection.query(data, {
        type: QueryTypes.SELECT,
      });
      if (allUsers && allUsers.length > 0) {
        res.status(200).json({
          status: true,
          total_records: usersCount[0].total_records,
          Stores: allUsers,
        });
      } else {
        res.status(200).json({
          status: true,
          total_records: usersCount[0].total_records,
          Stores: [],
        });
      }
    }
  } catch (err) {
    next(err);
    res.status(200).json({
      status: false,
      profile: {},
      error: err.message,
    });
    console.log(err.message);
  }
};
exports.viewVendorStoreByNameFilter = async (req, res, next) => {
  try {
    let {
      limit,
      offset,
      search,
      sort
    } = req.body;
    limit = parseInt(limit);
    offset = parseInt(offset);
    offset = limit * offset;
    console.log(req.body);
    search = search.trim();

    let usersCount = await connection.query(
      `
          SELECT COUNT(VendorID) as total_records FROM vendorstore WHERE StoreName LIKE "%${search}%" `, {
      type: QueryTypes.SELECT,
    }
    );
    if (usersCount && usersCount.length > 0) {
      let data =
        `
          SELECT * FROM vendorstore WHERE StoreName LIKE "%${search}%"
          order by VendorID ${sort}
          limit ` +
        limit +
        " offset " +
        offset;
      let allUsers = await connection.query(data, {
        type: QueryTypes.SELECT,
      });
      if (allUsers && allUsers.length > 0) {
        res.status(200).json({
          status: true,
          total_records: usersCount[0].total_records,
          Stores: allUsers,
        });
      } else {
        res.status(200).json({
          status: true,
          total_records: usersCount[0].total_records,
          Stores: [],
        });
      }
    }
  } catch (err) {
    next(err);
    res.status(200).json({
      status: false,
      profile: {},
      error: err.message,
    });
    console.log(err.message);
  }
};
exports.updateVendorStoreById = async (req, res, next) => {
  try {
    const id = req.params.id;
    console.log(id);
    let {
      VendorStoreID,
      StoreName,
      Address1,
      Address2,
      CityID,
      City,
      State,
      ZipCode,
      CountryID,
      StoreEmail,
      StorePhone,
      StoreFAX,
      StoreURL,
      GoogleMapID,
      ExceptDropOff,
      Active,
      AdminNote,
      EmailVerified,
      PhoneVerified,
      city_id,
      zone_id,
      area_id
    } = req.body;
    let LastUpdate = new Date().toISOString().slice(0, 19).replace("T", " ");

    let user = await connection.query(
      `
          select * from vendorstore where VendorID = '${id}'
          `, {
      type: QueryTypes.SELECT,
    }
    );
    if (user && user.length > 0) {
      let vednorIDChecking = await connection.query(
        `
          select * from vendorstore where VendorStoreID = '${VendorStoreID}'
          `, {
        type: QueryTypes.SELECT,
      }
      );
      if (vednorIDChecking && vednorIDChecking.length > 0) {
        let checkStoreProducts = await connection.query(`SELECT * from product WHERE StoreName = "${StoreName}"`, {
          type: QueryTypes.SELECT
        })
        if (checkStoreProducts && checkStoreProducts.length > 0) {
          let updateProductStatus = await connection.query(`UPDATE product SET Active = "${Active}" WHERE StoreName = "${StoreName}"`)

          if (!updateProductStatus) {
            res.status(200).json({
              status: false,
              message: "Error while updating product active status",
              Store: [],
            });
          }
        }


        console.log(StoreName);
        console.log(vednorIDChecking[0].StoreName);
        if (StoreName == vednorIDChecking[0].StoreName) {
          let queryString = `
          UPDATE vendorstore SET StoreName = "${StoreName}", Address1 = "${Address1}", Address2 = "${Address2}", CityID = "${CityID}", City = "${City}", State = "${State}", ZipCode = "${ZipCode}", CountryID = "${CountryID}", StoreEmail = "${StoreEmail}", StorePhone = "${StorePhone}", EmailVerified = "${EmailVerified}", PhoneVerified = "${PhoneVerified}", StoreFAX = "${StoreFAX}", StoreURL = "${StoreURL}", GoogleMapID = "${GoogleMapID}", ExceptDropOff = "${ExceptDropOff}", Active = "${Active}", LastUpdate = "${LastUpdate}", AdminNote = "${AdminNote}",city_id="${city_id}",zone_id="${zone_id}",area_id="${area_id}"
          WHERE VendorStoreID = "${VendorStoreID}"
          `;
          let updateStoreQuery = await connection.query(queryString);
          if (updateStoreQuery && updateStoreQuery.length > 0) {
            res.status(200).json({
              status: true,
              message: `
          Vendor Store updated successfully `,
            });
          } else {
            res.status(200).json({
              status: false,
              message: `
          Error
          while updating vendor store `,
            });
          }
        } else {
          let checkIFStoreNameAlreadyExists = await connection.query(
            `
          select * from vendorstore where StoreName = '${StoreName}'
          `, {
            type: QueryTypes.SELECT,
          }
          );
          console.log(checkIFStoreNameAlreadyExists);
          if (
            checkIFStoreNameAlreadyExists &&
            checkIFStoreNameAlreadyExists.length > 0
          ) {
            res.status(200).json({
              status: false,
              profile: {},
              message: `
          Store Name already taken, please select another one `,
            });
          } else {
            let queryString = `
          UPDATE vendorstore SET StoreName = "${StoreName}", Address1 = "${Address1}", Address2 = "${Address2}", CityID = "${CityID}", City = "${City}", State = "${State}", ZipCode = "${ZipCode}", CountryID = "${CountryID}", StoreEmail = "${StoreEmail}", StorePhone = "${StorePhone}", EmailVerified = "${EmailVerified}", PhoneVerified = "${PhoneVerified}", StoreFAX = "${StoreFAX}", StoreURL = "${StoreURL}", GoogleMapID = "${GoogleMapID}", ExceptDropOff = "${ExceptDropOff}", Active = "${Active}", LastUpdate = "${LastUpdate}", AdminNote = "${AdminNote}",city_id="${city_id}",zone_id="${zone_id}",area_id="${area_id}"
          WHERE VendorStoreID = "${VendorStoreID}"
          `;
            let updateStoreQuery = await connection.query(queryString);
            if (updateStoreQuery && updateStoreQuery.length > 0) {
              res.status(200).json({
                status: true,
                message: `
          Vendor Store updated successfully `,
              });
            } else {
              res.status(200).json({
                status: false,
                message: `
          Error
          while updating vendor store `,
              });
            }
          }
        }

      } else {
        res.status(200).json({
          status: false,
          message: "Please enter Vlaid StoreID",
          Store: [],
        });
      }
    } else {
      res.status(200).json({
        status: false,
        message: `
          VendorID does not exist `,
      });
    }
  } catch (err) {
    console.log(err.message);
    res.status(200).json({
      status: false,
      profile: {},
      error: err.message,
    });
  }
};
//! Vendor SUbCategory CRUD
exports.insertVendorSubcategory = async (req, res, next) => {
  try {
    let {
      VendorID,
      SubCategoryID
    } = req.body;

    console.log(req.body);
    //! bulk insert
    let queryToBulkInsertSubCategories = `
          INSERT INTO vendorsubcategory(VendorID, SubCategoryID) VALUES `;
    for (let i = 0; i < SubCategoryID.length; i++) {
      if (i == SubCategoryID.length - 1) {
        //!this is here just to remove (comma) that is handled in else part here
        queryToBulkInsertSubCategories += `(${VendorID}, ${SubCategoryID[i]})`;
      } else {
        queryToBulkInsertSubCategories += `(${VendorID}, ${SubCategoryID[i]}), `;
      }
    }
    console.log(queryToBulkInsertSubCategories);
    let insertData = await connection.query(queryToBulkInsertSubCategories);
    console.log(insertData);
    if (insertData) {
      res.status(200).json({
        status: true,
        message: "Vendor SubCategory added Successfully",
      });
    } else {
      res.status(200).json({
        status: false,
        message: "Cannot add Vendor SubCategory",
      });
    }
  } catch (err) {
    next(err);
    console.log(err.message);
    res.status(200).json({
      status: false,
      profile: {},
      error: err.message,
    });
  }
};
exports.getVendorSubcategory = async (req, res, next) => {
  try {
    let VendorID = req.params.id;
    let viewVendorSubCategory = await connection.query(
      `
          SELECT c.*, s.SubCategory, s.SubCategoryPic
          FROM vendorsubcategory c 
          INNER JOIN subcategory s ON s.SubCategoryID = c.SubCategoryID
          WHERE c.VendorID = "${VendorID}" `, {
      type: QueryTypes.SELECT,
    }
    );
    if (viewVendorSubCategory && viewVendorSubCategory.length > 0) {
      res.status(200).json({
        status: true,
        VendorSubCategory: viewVendorSubCategory,
      });
    } else {
      res.status(200).json({
        status: false,
        message: "Vendor SubCategory does not exist for this Vendor",
        VendorSubCategory: [],
      });
    }
  } catch (err) {
    console.log(err.message);
    res.status(200).json({
      status: false,
      VendorSubCategory: [],
      error: err.message,
    });
    console.log(err.message);
  }
};
exports.deleteVendorSubcategory = async (req, res, next) => {
  try {
    const id = req.params.id;
    console.log(id);
    let checkvendorsubcategory = await connection.query(
      `
          select * from vendorsubcategory where ID = "${id}"
          `, {
      type: QueryTypes.SELECT,
    }
    );
    if (checkvendorsubcategory && checkvendorsubcategory.length > 0) {
      let deleteVendorSubCategory = await connection.query(
        `
          DELETE FROM vendorsubcategory WHERE ID = "${id}"
          `, {
        type: QueryTypes.DELETE,
      }
      );
      res.status(200).json({
        status: true,
        message: `
          Vendor SubCategory deleted successfully `,
      });
    } else {
      console.log("*********");
      res.status(200).json({
        status: false,
        message: `
          Vendor SubCategory does not exist `,
      });
    }
  } catch (err) {
    next(err);
    res.status(200).json({
      status: false,
      data: {},
      error: err.message,
    });
    console.log(err.message);
  }
};

//! Email Verification Api's
exports.emailVerification = async (req, res, next) => {
  try {
    let {
      EmailAddress
    } = req.body;
    let UserID = req.UserID;

    if (EmailAddress && EmailAddress.length > 0) {


      let checkEmail = await connection.query(
        `
          select * from emailverification where EmailAddress = "${EmailAddress}" AND UserID !="${UserID}" AND EmailVerified="Y"
          `, {
        type: QueryTypes.SELECT,
      }
      );
      console.log(checkEmail, "checkEmail")

      if (checkEmail && checkEmail.length > 0) {
        res.status(200).json({
          status: false,
          message: `EmailAddress already owned by another user `,
        });
      } else {

        let checkEmailForCurrentUser = await connection.query(
          `
          select * from emailverification where EmailAddress = "${EmailAddress}" AND UserID ="${UserID}" AND EmailVerified="Y"
          `, {
          type: QueryTypes.SELECT,
        }
        );

        if (checkEmailForCurrentUser && checkEmailForCurrentUser.length > 0) {
          res.status(200).json({
            status: true,
            EmailVerified: checkEmailForCurrentUser[0].EmailVerified,
            message: `Email already verified `,
          });

        } else {
          var otp = Math.floor(Math.random() * 90000) + 10000;
          otp.toString();
          let insertEmailVerification = `
          insert into emailverification(EmailAddress, OTP,UserID)
          `;
          insertEmailVerification += `
          values("${EmailAddress}", "${otp.toString()}","${UserID}")
          `;
          insertEmailVerification += ` ON DUPLICATE KEY UPDATE OTP=VALUES(OTP)`;

          let insertValues = await connection.query(insertEmailVerification);
          console.log(insertValues);
          if (insertValues && insertValues.length > 0) {
            sendMail(EmailAddress, otp);
            res.status(200).json({
              status: true,
              EmailVerified: "N",
              message: `OTP send and EmailAddress added successfully `,
            });
          } else {
            res.status(200).json({
              status: false,
              message: `Something went wrong, please try again later `,
              error: err.message,
            });
          }
        }
      }
    } else {
      res.status(200).json({
        status: false,
        message: `
          Please provide an email address `,
      });
    }
  } catch (err) {
    console.log(err)
    res.status(200).json({
      status: false,
      error: err.message,
    });
  }
};
exports.verifyOTPforEmailVerification = async (req, res, next) => {
  try {
    const {
      EmailAddress,
      OTP
    } = req.body;
    let UserID = req.UserID;

    let queryString = `
          select * from emailverification where EmailAddress = '${EmailAddress}'
          and OTP = '${OTP}' AND UserID ="${UserID}"
          `;
    let user = await connection.query(queryString, {
      type: QueryTypes.SELECT,
    });
    if (user && user.length > 0) {
      let updateEmailVerificationQuery = `
          update emailverification Set EmailVerified = 'Y'
          where EmailVerificationID = '${user[0].EmailVerificationID}'
          `;
      let updateUser = await connection.query(updateEmailVerificationQuery);
      if (updateUser) {
        res.status(200).json({
          status: true,
          message: `
          Email verification successful `,
        });
      } else {
        res.status(200).json({
          status: false,
          message: `
          Error
          while verifying Email Address `,
        });
      }
    } else {
      res.status(200).json({
        status: false,
        message: `
          Invalid EmailAddress or OTP `,
      });
    }
  } catch (err) {
    next(err);
    res.status(200).json({
      status: false,
      profile: {},
      error: err.message,
    });
  }
};
exports.resendOTPforEmailVerification = async (req, res, next) => {
  try {
    let {
      EmailAddress
    } = req.body;
    if (EmailAddress) {
      console.log(EmailAddress);
      let queryString = `
          select * from emailverification where EmailAddress = "${EmailAddress}"
          `;
      let user = await connection.query(queryString, {
        type: QueryTypes.SELECT,
      });
      if (user && user.length > 0) {
        var otp = Math.floor(Math.random() * 90000) + 10000;
        otp.toString();
        let queryString = `
          UPDATE emailverification SET OTP = '${otp}'
          WHERE EmailAddress = "${EmailAddress}"
          `;
        let resendOTP_ = await connection.query(queryString);
        if (resendOTP_) {
          sendMail(EmailAddress, otp);
          res.status(200).json({
            status: true,
            message: `
          OTP is resend to the EmailAddress `,
          });
        } else {
          res.status(200).json({
            status: false,
            message: `
          Error
          while sending OTP `,
          });
        }
      } else {
        res.status(200).json({
          status: false,
          message: `
          Please enter an email to get OTP `,
        });
      }
    } else {
      res.status(200).json({
        status: false,
        message: `
          Please provide an email address `,
      });
    }
  } catch (err) {
    next(err);
    res.status(200).json({
      status: false,
      profile: {},
      error: err.message,
    });
  }
};
//! Vendor Dashboard
exports.VendorDashBoardApi = async (req, res, next) => {
  try {
    const VendorID = req.UserID;
    let getVendorOrderDetail = await connection.query(
      `SELECT  
          COUNT(DISTINCT( CASE WHEN p.ProcessStatus = "Delivered" THEN OrderNumber END)) as DeliveredOrders,
          COUNT(DISTINCT( CASE WHEN p.ProcessStatus = "Assigned" THEN OrderNumber END)) as AssignedOrders,
          COUNT(DISTINCT( CASE WHEN p.ProcessStatus = "Returned" THEN OrderNumber END)) as ReturnedOrders,
          COUNT(DISTINCT( CASE WHEN p.ProcessStatus = "Picked" THEN OrderNumber END)) as PickedOrders,
          COUNT(DISTINCT( CASE WHEN p.ProcessStatus = "Cancelled" THEN OrderNumber END)) as CancelledOrders,
          COUNT(DISTINCT( CASE WHEN p.ProcessStatus = "To be Returned" THEN OrderNumber END )) as TobeReturnedOrders,
          COUNT(DISTINCT( CASE WHEN p.ProcessStatus = "On the Way" THEN OrderNumber END))  as OntheWayOrders  
          FROM processorder p
          INNER JOIN vendorstore v ON v.VendorStoreID=p.VendorStoreID
          WHERE  v.VendorID="${VendorID}"
           `, {
      type: QueryTypes.SELECT,
    }
    );
    if (getVendorOrderDetail && getVendorOrderDetail.length > 0) {
      res.status(200).json({
        status: true,
        VendorOrderStatusCount: getVendorOrderDetail[0],
      });
    } else {
      res.status(200).json({
        status: false,
        VendorOrderStatusCount: [],
      });
    }
  } catch (err) {
    next(err);
    res.status(200).json({
      status: false,
      VendorOrderStatusCount: [],
      error: err.message,
    });
  }
};
//! Vendor ReturnOrder
exports.getRefundOrdersByVendorIDOld = async (req, res, next) => {
  try {
    // let Region = req.region;
    // const currencyRate = req.currency_rate;
    const VendorID = req.UserID;
    let {
      limit,
      offset,
      search,
      sort
    } = req.body;
    let productCombinationPriceDetail = [];
    limit = parseInt(limit);
    offset = parseInt(offset);
    offset = limit * offset;
    let getCount = await connection.query(
      `SELECT COUNT(DISTINCT OrderNumber) AS total_records
         FROM processorder o
         LEFT JOIN product p ON o.ProductID= p.ProductID
         LEFT JOIN vendor v ON v.VendorID= p.VendorID
         WHERE (ReturnOrderStatus="Assigned" || ReturnOrderStatus="Delivered" || ReturnOrderStatus="Picked") AND p.VendorID="${VendorID}"
         AND o.RefundStatus != "Refunded"
     `, {
      type: QueryTypes.SELECT,
    }
      // `SELECT COUNT(*) as total_records  from (SELECT COUNT(OrderNumber) as total_records from processorder WHERE UserID="${UserID}" AND ReturnReason NOT IN ('NULL','null','undefined','Cancelled') GROUP BY OrderNumber )OrderNumber`,
      // {
      //   type: QueryTypes.SELECT,
      // }
    );
    if (getCount[0].total_records && getCount[0].total_records > 0) {
      let viewOrderListQuery = `SELECT p.ProductID,p.Title,m.TransactionID,s.OrderNumber,s.AllowStorePickup,s.AllowAdminPickup,s.ReadyPickupForUser,s.ReadyPickupForAdmin,s.OrderDate,m.PaymentStatus,p.Price AS BasePrice,s.Quantity,p.Currency,s.UserID,g.Small,g.Medium,g.Large,i.MainImage,s.StatusHistory,s.ProcessStatus,s.DeliveryDriverID,s.ConsignmentId,s.*,r.CountryID AS VendorCountry,pr.*,s.RefundStatus,s.RefundStatusHistory
          FROM ((((((((( product p      
          LEFT JOIN productvariantoption o ON o.ProductID IN( p.ProductID))
          LEFT JOIN productvariantoptionvalue v  ON  v.OptionID IN (o.OptionID))  
          LEFT JOIN productimage i  ON  i.OptionValueID IN (v.OptionValueID))
          LEFT JOIN imagegallery g  ON  g.ImageGalleryID IN (i.ImageGalleryID))
          LEFT JOIN productvariantcombination c  ON  c.OptionValueID IN (v.OptionValueID))
          LEFT JOIN processorder s ON s.ProductID IN(c.ProductID))
          INNER JOIN processrefand pr ON pr.ProcessOrderID IN (s.ProcessOrderID))
          LEFT JOIN vendor r ON (r.VendorID= p.VendorID))
          LEFT JOIN processpayment m ON m.OrderNumber IN(s.OrderNumber))
          WHERE i.MainImage='Y' AND p.VendorID="${VendorID}" AND s.RefundStatus != "Refunded" AND ( s.ReturnOrderStatus="Assigned" || s.ReturnOrderStatus="Delivered" || ReturnOrderStatus="Picked" )   AND s.OrderNumber IN (select * from (SELECT OrderNumber from processorder WHERE ( ReturnOrderStatus="Assigned" ||ReturnOrderStatus="Delivered" || ReturnOrderStatus="Picked" )  AND OrderNumber LIKE "%${search}%" AND RefundStatus != "Refunded" GROUP BY OrderNumber ORDER BY ProcessOrderID ${sort} LIMIT ${limit} OFFSET ${offset} ) OrderNumber)
          GROUP BY s.ProcessOrderID
          ORDER BY s.ProcessOrderID ${sort}`;
      let viewOrderList = await connection.query(viewOrderListQuery, {
        type: QueryTypes.SELECT,
      });
      let productCombinationDetail;
      if (viewOrderList && viewOrderList.length > 0) {
        for (let i = 0; i < viewOrderList.length; i++) {
          let ProductVariantCombinationDetail = [];
          ProductVariantCombinationDetail.push(
            viewOrderList[i].ProductVariantCombinationDetail
          );
          ProductVariantCombinationDetail = `(${ProductVariantCombinationDetail.join(
            ","
          )})`;
          productCombinationDetail = await connection.query(
            `SELECT p.ProductID,c.ProductVariantCombinationID,c.VendorStoreID,c.Price AS ProductCombinationPrice,c.AvailableInventory,o.OptionID,o.OptionName,v.OptionValue,v.OptionValueID,p.Currency
              FROM ((((product p
              LEFT JOIN productvariantoption o ON o.ProductID IN( p.ProductID))
              LEFT JOIN productvariantoptionvalue v  ON  v.OptionID IN (o.OptionID)) 
              LEFT JOIN productvariantcombination c  ON  c.OptionValueID IN (v.OptionValueID))
              LEFT JOIN processorder s ON s.ProductID IN(c.ProductID))
              WHERE  c.ProductVariantCombinationID IN ${ProductVariantCombinationDetail} 
              GROUP BY c.OptionValueID
              ORDER BY s.ProcessOrderID ASC
             `, {
            type: QueryTypes.SELECT,
          }
          );
          productCombinationPriceDetail.push(productCombinationDetail);
        }

        let getCurrencyRates = await connection.query(
          "SELECT * FROM currencyrate", {
          type: QueryTypes.SELECT,
        }
        );
        let VendorCountry = viewOrderList[0].VendorCountry;
        let currencyRate;
        if (VendorCountry == "16") {
          currencyRate = getCurrencyRates[1].Rate;
        } else {
          currencyRate = getCurrencyRates[0].Rate;
        }
        let orderName = [];
        let orderDate = [];
        let paymentStatus = [];
        let transactionID = [];
        let tempPC = productCombinationPriceDetail;
        let tempProd = viewOrderList;
        let tempArray = [];
        let allowStorePickup = [];
        let readyPickupForUser = [];
        let readyPickupForAdmin = [];
        let allowAdminPickup = [];
        let statusHistory = [];
        let processStatus = [];
        let tempAOrderDetails = [];

        for (let i = 0; i < tempProd.length; i++) {
          //!cuurency conversion
          if (VendorCountry == "16") {
            let Price = tempProd[i].BasePrice;
            if (tempProd[i].Currency == "USD") {
              tempProd[i]["Currency"] = "BDT";
              tempProd[i]["BasePrice"] = parseFloat(
                currencyRate * Price
              ).toFixed(2);
            }
          } else if (VendorCountry == "226") {
            let Price = tempProd[i].BasePrice;
            if (tempProd[i].Currency == "BDT") {
              tempProd[i]["Currency"] = "USD";
              tempProd[i]["BasePrice"] = parseFloat(
                currencyRate * Price
              ).toFixed(2);
            }
          } else {
            let Price = tempProd[i].BasePrice;
            tempProd[i]["Currency"] = "USD";
            tempProd[i]["BasePrice"] = parseFloat(currencyRate * Price).toFixed(
              2
            );
          }
          var obj = {
            ...tempProd[i],
          };
          let variantsLength = tempPC[i].length;
          if (VendorCountry == "16") {
            for (let j = 0; j < variantsLength; j++) {
              let Price = tempPC[i][j].ProductCombinationPrice;
              if (tempPC[i][j].Currency == "USD") {
                tempPC[i][j]["Currency"] = "BDT";
                tempPC[i][j]["ProductCombinationPrice"] = parseFloat(
                  currencyRate * Price
                ).toFixed(2);
              }
            }
          } else if (VendorCountry == "226") {
            for (let j = 0; j < variantsLength; j++) {
              let Price = tempPC[i][j].ProductCombinationPrice;
              if (tempPC[i][j].Currency == "BDT") {
                tempPC[i][j]["Currency"] = "USD";
                tempPC[i][j]["ProductCombinationPrice"] = parseFloat(
                  currencyRate * Price
                ).toFixed(2);
              }
            }
          } else {
            for (let j = 0; j < variantsLength; j++) {
              let Price = tempPC[i][j].ProductCombinationPrice;
              tempPC[i][j]["Currency"] = "USD";
              tempPC[i][j]["ProductCombinationPrice"] = parseFloat(
                currencyRate * Price
              ).toFixed(2);
            }
          }
          obj["ProductCombinations"] = tempPC[i];
          tempArray.push(obj);
        }
        for (let i = 0; i < tempArray.length; i++) {
          if (!orderName.includes(tempArray[i].OrderNumber)) {
            orderName.push(tempArray[i].OrderNumber);
            orderDate.push(tempArray[i].OrderDate);
            paymentStatus.push(tempArray[i].PaymentStatus);
            transactionID.push(tempArray[i].TransactionID);
            allowStorePickup.push(tempArray[i].AllowStorePickup);
            readyPickupForUser.push(tempArray[i].ReadyPickupForUser);
            readyPickupForAdmin.push(tempArray[i].ReadyPickupForAdmin);
            allowAdminPickup.push(tempArray[i].AllowAdminPickup);
            statusHistory.push(tempArray[i].StatusHistory);
            processStatus.push(tempArray[i].ProcessStatus);
          }
        }
        for (let i = 0; i < orderName.length; i++) {
          var obj = {
            OrderNumber: orderName[i],
            OrderDate: orderDate[i],
            PaymentStatus: paymentStatus[i],
            TransactionID: transactionID[i],
            AllowStorePickup: allowStorePickup[i],
            ReadyPickupForUser: readyPickupForUser[i],
            ReadyPickupForAdmin: readyPickupForAdmin[i],
            AllowAdminPickup: allowAdminPickup[i],
            StatusHistory: statusHistory[i],
            ProcessStatus: processStatus[i],
            ProductDetail: [],
          };
          for (let j = 0; j < tempArray.length; j++) {
            if (orderName[i] === tempArray[j].OrderNumber) {
              obj.ProductDetail.push(tempArray[j]);
            }
          }
          tempAOrderDetails.push(obj);
        }
        if (productCombinationDetail && productCombinationDetail.length > 0) {
          res.status(200).json({
            status: true,
            total_records: getCount[0].total_records,
            orderDetails: tempAOrderDetails,
          });
        } else {
          res.status(200).json({
            status: false,
            orderDetails: [],
          });
        }
      } else {
        res.status(200).json({
          status: true,
          total_records: getCount[0].total_records,
          orderDetails: [],
        });
      }
    } else {
      res.status(200).json({
        status: true,
        total_records: getCount[0].total_records,
        orderDetails: [],
      });
    }
  } catch (err) {
    console.log(err.message);
    next(err);
    res.status(200).json({
      status: false,
      orderDetails: [],
    });
  }
};
exports.getFreeRefundOrdersByVendorID = async (req, res, next) => {
  try {
    // let Region = req.region;
    // const currencyRate = req.currency_rate;
    const VendorID = req.UserID;
    let {
      limit,
      offset,
      search,
      sort
    } = req.body;
    let productCombinationPriceDetail = [];
    limit = parseInt(limit);
    offset = parseInt(offset);
    offset = limit * offset;
    let getCount = await connection.query(
      `SELECT COUNT(DISTINCT OrderNumber) AS total_records
         FROM processorder o
         LEFT JOIN product p ON o.ProductID= p.ProductID
         LEFT JOIN vendor v ON v.VendorID= p.VendorID
         WHERE p.FreeProductReturn="Y" AND (ReturnOrderStatus="Assigned" || ReturnOrderStatus="Delivered" || ReturnOrderStatus="Picked") AND p.VendorID="${VendorID}"
         AND o.RefundStatus != "Refunded"
     `, {
      type: QueryTypes.SELECT,
    }
      // `SELECT COUNT(*) as total_records  from (SELECT COUNT(OrderNumber) as total_records from processorder WHERE UserID="${UserID}" AND ReturnReason NOT IN ('NULL','null','undefined','Cancelled') GROUP BY OrderNumber )OrderNumber`,
      // {
      //   type: QueryTypes.SELECT,
      // }
    );
    if (getCount[0].total_records && getCount[0].total_records > 0) {
      let viewOrderListQuery = `SELECT p.ProductID,p.Title,m.TransactionID,s.OrderNumber,s.AllowStorePickup,s.AllowAdminPickup,s.ReadyPickupForUser,s.ReadyPickupForAdmin,s.OrderDate,m.PaymentStatus,p.Price AS BasePrice,s.Quantity,p.Currency,s.UserID,g.Small,g.Medium,g.Large,i.MainImage,s.StatusHistory,s.ProcessStatus,s.DeliveryDriverID,s.ConsignmentId,s.*,r.CountryID AS VendorCountry,pr.*,s.RefundStatus,s.RefundStatusHistory
          FROM ((((((((( product p      
          LEFT JOIN productvariantoption o ON o.ProductID IN( p.ProductID))
          LEFT JOIN productvariantoptionvalue v  ON  v.OptionID IN (o.OptionID))  
          LEFT JOIN productimage i  ON  i.OptionValueID IN (v.OptionValueID))
          LEFT JOIN imagegallery g  ON  g.ImageGalleryID IN (i.ImageGalleryID))
          LEFT JOIN productvariantcombination c  ON  c.OptionValueID IN (v.OptionValueID))
          LEFT JOIN processorder s ON s.ProductID IN(c.ProductID))
          INNER JOIN processrefand pr ON pr.ProcessOrderID IN (s.ProcessOrderID))
          LEFT JOIN vendor r ON (r.VendorID= p.VendorID))
          LEFT JOIN processpayment m ON m.OrderNumber IN(s.OrderNumber))
          WHERE i.MainImage='Y' AND p.FreeProductReturn="Y" AND p.VendorID="${VendorID}" AND s.RefundStatus != "Refunded" AND ( s.ReturnOrderStatus="Assigned" || s.ReturnOrderStatus="Delivered" || ReturnOrderStatus="Picked" )   AND s.OrderNumber IN (select * from (SELECT po.OrderNumber from processorder po
            INNER JOIN product p ON p.ProductID=po.ProductID
             WHERE p.FreeProductReturn="Y"  AND ( po.ReturnOrderStatus="Assigned" || po.ReturnOrderStatus="Delivered" || po.ReturnOrderStatus="Picked" )  AND po.OrderNumber LIKE "%${search}%" AND po.RefundStatus != "Refunded" GROUP BY po.OrderNumber ORDER BY po.ProcessOrderID ${sort} LIMIT ${limit} OFFSET ${offset} ) OrderNumber)
          GROUP BY s.ProcessOrderID
          ORDER BY s.ProcessOrderID ${sort}`;
      let viewOrderList = await connection.query(viewOrderListQuery, {
        type: QueryTypes.SELECT,
      });
      let productCombinationDetail;
      if (viewOrderList && viewOrderList.length > 0) {
        for (let i = 0; i < viewOrderList.length; i++) {
          let ProductVariantCombinationDetail = [];
          ProductVariantCombinationDetail.push(
            viewOrderList[i].ProductVariantCombinationDetail
          );
          ProductVariantCombinationDetail = `(${ProductVariantCombinationDetail.join(
            ","
          )})`;
          productCombinationDetail = await connection.query(
            `SELECT p.ProductID,c.ProductVariantCombinationID,c.VendorStoreID,c.Price AS ProductCombinationPrice,c.AvailableInventory,o.OptionID,o.OptionName,v.OptionValue,v.OptionValueID,p.Currency
              FROM ((((product p
              LEFT JOIN productvariantoption o ON o.ProductID IN( p.ProductID))
              LEFT JOIN productvariantoptionvalue v  ON  v.OptionID IN (o.OptionID)) 
              LEFT JOIN productvariantcombination c  ON  c.OptionValueID IN (v.OptionValueID))
              LEFT JOIN processorder s ON s.ProductID IN(c.ProductID))
              WHERE  c.ProductVariantCombinationID IN ${ProductVariantCombinationDetail} 
              GROUP BY c.OptionValueID
              ORDER BY s.ProcessOrderID ASC
             `, {
            type: QueryTypes.SELECT,
          }
          );
          productCombinationPriceDetail.push(productCombinationDetail);
        }

        let getCurrencyRates = await connection.query(
          "SELECT * FROM currencyrate", {
          type: QueryTypes.SELECT,
        }
        );
        let VendorCountry = viewOrderList[0].VendorCountry;
        let currencyRate;
        if (VendorCountry == "16") {
          currencyRate = getCurrencyRates[1].Rate;
        } else {
          currencyRate = getCurrencyRates[0].Rate;
        }
        let orderName = [];
        let orderDate = [];
        let paymentStatus = [];
        let transactionID = [];
        let tempPC = productCombinationPriceDetail;
        let tempProd = viewOrderList;
        let tempArray = [];
        let allowStorePickup = [];
        let readyPickupForUser = [];
        let readyPickupForAdmin = [];
        let allowAdminPickup = [];
        let statusHistory = [];
        let processStatus = [];
        let tempAOrderDetails = [];

        for (let i = 0; i < tempProd.length; i++) {
          //!cuurency conversion
          if (VendorCountry == "16") {
            let Price = tempProd[i].BasePrice;
            if (tempProd[i].Currency == "USD") {
              tempProd[i]["Currency"] = "BDT";
              tempProd[i]["BasePrice"] = parseFloat(
                currencyRate * Price
              ).toFixed(2);
            }
          } else if (VendorCountry == "226") {
            let Price = tempProd[i].BasePrice;
            if (tempProd[i].Currency == "BDT") {
              tempProd[i]["Currency"] = "USD";
              tempProd[i]["BasePrice"] = parseFloat(
                currencyRate * Price
              ).toFixed(2);
            }
          } else {
            let Price = tempProd[i].BasePrice;
            tempProd[i]["Currency"] = "USD";
            tempProd[i]["BasePrice"] = parseFloat(currencyRate * Price).toFixed(
              2
            );
          }
          var obj = {
            ...tempProd[i],
          };
          let variantsLength = tempPC[i].length;
          if (VendorCountry == "16") {
            for (let j = 0; j < variantsLength; j++) {
              let Price = tempPC[i][j].ProductCombinationPrice;
              if (tempPC[i][j].Currency == "USD") {
                tempPC[i][j]["Currency"] = "BDT";
                tempPC[i][j]["ProductCombinationPrice"] = parseFloat(
                  currencyRate * Price
                ).toFixed(2);
              }
            }
          } else if (VendorCountry == "226") {
            for (let j = 0; j < variantsLength; j++) {
              let Price = tempPC[i][j].ProductCombinationPrice;
              if (tempPC[i][j].Currency == "BDT") {
                tempPC[i][j]["Currency"] = "USD";
                tempPC[i][j]["ProductCombinationPrice"] = parseFloat(
                  currencyRate * Price
                ).toFixed(2);
              }
            }
          } else {
            for (let j = 0; j < variantsLength; j++) {
              let Price = tempPC[i][j].ProductCombinationPrice;
              tempPC[i][j]["Currency"] = "USD";
              tempPC[i][j]["ProductCombinationPrice"] = parseFloat(
                currencyRate * Price
              ).toFixed(2);
            }
          }
          obj["ProductCombinations"] = tempPC[i];
          tempArray.push(obj);
        }
        for (let i = 0; i < tempArray.length; i++) {
          if (!orderName.includes(tempArray[i].OrderNumber)) {
            orderName.push(tempArray[i].OrderNumber);
            orderDate.push(tempArray[i].OrderDate);
            paymentStatus.push(tempArray[i].PaymentStatus);
            transactionID.push(tempArray[i].TransactionID);
            allowStorePickup.push(tempArray[i].AllowStorePickup);
            readyPickupForUser.push(tempArray[i].ReadyPickupForUser);
            readyPickupForAdmin.push(tempArray[i].ReadyPickupForAdmin);
            allowAdminPickup.push(tempArray[i].AllowAdminPickup);
            statusHistory.push(tempArray[i].StatusHistory);
            processStatus.push(tempArray[i].ProcessStatus);
          }
        }
        for (let i = 0; i < orderName.length; i++) {
          var obj = {
            OrderNumber: orderName[i],
            OrderDate: orderDate[i],
            PaymentStatus: paymentStatus[i],
            TransactionID: transactionID[i],
            AllowStorePickup: allowStorePickup[i],
            ReadyPickupForUser: readyPickupForUser[i],
            ReadyPickupForAdmin: readyPickupForAdmin[i],
            AllowAdminPickup: allowAdminPickup[i],
            StatusHistory: statusHistory[i],
            ProcessStatus: processStatus[i],
            ProductDetail: [],
          };
          for (let j = 0; j < tempArray.length; j++) {
            if (orderName[i] === tempArray[j].OrderNumber) {
              obj.ProductDetail.push(tempArray[j]);
            }
          }
          tempAOrderDetails.push(obj);
        }
        if (productCombinationDetail && productCombinationDetail.length > 0) {
          res.status(200).json({
            status: true,
            total_records: getCount[0].total_records,
            orderDetails: tempAOrderDetails,
          });
        } else {
          res.status(200).json({
            status: false,
            orderDetails: [],
          });
        }
      } else {
        res.status(200).json({
          status: true,
          total_records: getCount[0].total_records,
          orderDetails: [],
        });
      }
    } else {
      res.status(200).json({
        status: true,
        total_records: getCount[0].total_records,
        orderDetails: [],
      });
    }
  } catch (err) {
    console.log(err.message);
    next(err);
    res.status(200).json({
      status: false,
      orderDetails: [],
    });
  }
};
exports.getPaidRefundOrdersByVendorID = async (req, res, next) => {
  try {
    // let Region = req.region;
    // const currencyRate = req.currency_rate;
    const VendorID = req.UserID;
    let {
      limit,
      offset,
      search,
      sort
    } = req.body;
    let productCombinationPriceDetail = [];
    limit = parseInt(limit);
    offset = parseInt(offset);
    offset = limit * offset;
    let getCount = await connection.query(
      `SELECT COUNT(DISTINCT OrderNumber) AS total_records
         FROM processorder o
         LEFT JOIN product p ON o.ProductID= p.ProductID
         LEFT JOIN vendor v ON v.VendorID= p.VendorID
         WHERE p.FreeProductReturn="N" AND (ReturnOrderStatus="Assigned" || ReturnOrderStatus="Delivered" || ReturnOrderStatus="Picked") AND p.VendorID="${VendorID}"
         AND o.RefundStatus != "Refunded"
     `, {
      type: QueryTypes.SELECT,
    }
      // `SELECT COUNT(*) as total_records  from (SELECT COUNT(OrderNumber) as total_records from processorder WHERE UserID="${UserID}" AND ReturnReason NOT IN ('NULL','null','undefined','Cancelled') GROUP BY OrderNumber )OrderNumber`,
      // {
      //   type: QueryTypes.SELECT,
      // }
    );
    if (getCount[0].total_records && getCount[0].total_records > 0) {
      let viewOrderListQuery = `SELECT p.ProductID,p.Title,m.TransactionID,s.OrderNumber,s.AllowStorePickup,s.AllowAdminPickup,s.ReadyPickupForUser,s.ReadyPickupForAdmin,s.OrderDate,m.PaymentStatus,p.Price AS BasePrice,s.Quantity,p.Currency,s.UserID,g.Small,g.Medium,g.Large,i.MainImage,s.StatusHistory,s.ProcessStatus,s.DeliveryDriverID,s.ConsignmentId,s.*,r.CountryID AS VendorCountry,pr.*,s.RefundStatus,s.RefundStatusHistory
          FROM ((((((((( product p      
          LEFT JOIN productvariantoption o ON o.ProductID IN( p.ProductID))
          LEFT JOIN productvariantoptionvalue v  ON  v.OptionID IN (o.OptionID))  
          LEFT JOIN productimage i  ON  i.OptionValueID IN (v.OptionValueID))
          LEFT JOIN imagegallery g  ON  g.ImageGalleryID IN (i.ImageGalleryID))
          LEFT JOIN productvariantcombination c  ON  c.OptionValueID IN (v.OptionValueID))
          LEFT JOIN processorder s ON s.ProductID IN(c.ProductID))
          INNER JOIN processrefand pr ON pr.ProcessOrderID IN (s.ProcessOrderID))
          LEFT JOIN vendor r ON (r.VendorID= p.VendorID))
          LEFT JOIN processpayment m ON m.OrderNumber IN(s.OrderNumber))
          WHERE i.MainImage='Y' AND p.FreeProductReturn="N" AND p.VendorID="${VendorID}" AND s.RefundStatus != "Refunded" AND ( s.ReturnOrderStatus="Assigned" || s.ReturnOrderStatus="Delivered" || ReturnOrderStatus="Picked" )   AND s.OrderNumber IN (select * from (SELECT po.OrderNumber from processorder po
            INNER JOIN product p ON p.ProductID=po.ProductID
             WHERE p.FreeProductReturn="N"  AND ( po.ReturnOrderStatus="Assigned" || po.ReturnOrderStatus="Delivered" || po.ReturnOrderStatus="Picked" )  AND po.OrderNumber LIKE "%${search}%" AND po.RefundStatus != "Refunded" GROUP BY po.OrderNumber ORDER BY po.ProcessOrderID ${sort} LIMIT ${limit} OFFSET ${offset} ) OrderNumber)
          GROUP BY s.ProcessOrderID
          ORDER BY s.ProcessOrderID ${sort}`;
      let viewOrderList = await connection.query(viewOrderListQuery, {
        type: QueryTypes.SELECT,
      });
      let productCombinationDetail;
      if (viewOrderList && viewOrderList.length > 0) {
        for (let i = 0; i < viewOrderList.length; i++) {
          let ProductVariantCombinationDetail = [];
          ProductVariantCombinationDetail.push(
            viewOrderList[i].ProductVariantCombinationDetail
          );
          ProductVariantCombinationDetail = `(${ProductVariantCombinationDetail.join(
            ","
          )})`;
          productCombinationDetail = await connection.query(
            `SELECT p.ProductID,c.ProductVariantCombinationID,c.VendorStoreID,c.Price AS ProductCombinationPrice,c.AvailableInventory,o.OptionID,o.OptionName,v.OptionValue,v.OptionValueID,p.Currency
              FROM ((((product p
              LEFT JOIN productvariantoption o ON o.ProductID IN( p.ProductID))
              LEFT JOIN productvariantoptionvalue v  ON  v.OptionID IN (o.OptionID)) 
              LEFT JOIN productvariantcombination c  ON  c.OptionValueID IN (v.OptionValueID))
              LEFT JOIN processorder s ON s.ProductID IN(c.ProductID))
              WHERE  c.ProductVariantCombinationID IN ${ProductVariantCombinationDetail} 
              GROUP BY c.OptionValueID
              ORDER BY s.ProcessOrderID ASC
             `, {
            type: QueryTypes.SELECT,
          }
          );
          productCombinationPriceDetail.push(productCombinationDetail);
        }

        let getCurrencyRates = await connection.query(
          "SELECT * FROM currencyrate", {
          type: QueryTypes.SELECT,
        }
        );
        let VendorCountry = viewOrderList[0].VendorCountry;
        let currencyRate;
        if (VendorCountry == "16") {
          currencyRate = getCurrencyRates[1].Rate;
        } else {
          currencyRate = getCurrencyRates[0].Rate;
        }
        let orderName = [];
        let orderDate = [];
        let paymentStatus = [];
        let transactionID = [];
        let tempPC = productCombinationPriceDetail;
        let tempProd = viewOrderList;
        let tempArray = [];
        let allowStorePickup = [];
        let readyPickupForUser = [];
        let readyPickupForAdmin = [];
        let allowAdminPickup = [];
        let statusHistory = [];
        let processStatus = [];
        let tempAOrderDetails = [];

        for (let i = 0; i < tempProd.length; i++) {
          //!cuurency conversion
          if (VendorCountry == "16") {
            let Price = tempProd[i].BasePrice;
            if (tempProd[i].Currency == "USD") {
              tempProd[i]["Currency"] = "BDT";
              tempProd[i]["BasePrice"] = parseFloat(
                currencyRate * Price
              ).toFixed(2);
            }
          } else if (VendorCountry == "226") {
            let Price = tempProd[i].BasePrice;
            if (tempProd[i].Currency == "BDT") {
              tempProd[i]["Currency"] = "USD";
              tempProd[i]["BasePrice"] = parseFloat(
                currencyRate * Price
              ).toFixed(2);
            }
          } else {
            let Price = tempProd[i].BasePrice;
            tempProd[i]["Currency"] = "USD";
            tempProd[i]["BasePrice"] = parseFloat(currencyRate * Price).toFixed(
              2
            );
          }
          var obj = {
            ...tempProd[i],
          };
          let variantsLength = tempPC[i].length;
          if (VendorCountry == "16") {
            for (let j = 0; j < variantsLength; j++) {
              let Price = tempPC[i][j].ProductCombinationPrice;
              if (tempPC[i][j].Currency == "USD") {
                tempPC[i][j]["Currency"] = "BDT";
                tempPC[i][j]["ProductCombinationPrice"] = parseFloat(
                  currencyRate * Price
                ).toFixed(2);
              }
            }
          } else if (VendorCountry == "226") {
            for (let j = 0; j < variantsLength; j++) {
              let Price = tempPC[i][j].ProductCombinationPrice;
              if (tempPC[i][j].Currency == "BDT") {
                tempPC[i][j]["Currency"] = "USD";
                tempPC[i][j]["ProductCombinationPrice"] = parseFloat(
                  currencyRate * Price
                ).toFixed(2);
              }
            }
          } else {
            for (let j = 0; j < variantsLength; j++) {
              let Price = tempPC[i][j].ProductCombinationPrice;
              tempPC[i][j]["Currency"] = "USD";
              tempPC[i][j]["ProductCombinationPrice"] = parseFloat(
                currencyRate * Price
              ).toFixed(2);
            }
          }
          obj["ProductCombinations"] = tempPC[i];
          tempArray.push(obj);
        }
        for (let i = 0; i < tempArray.length; i++) {
          if (!orderName.includes(tempArray[i].OrderNumber)) {
            orderName.push(tempArray[i].OrderNumber);
            orderDate.push(tempArray[i].OrderDate);
            paymentStatus.push(tempArray[i].PaymentStatus);
            transactionID.push(tempArray[i].TransactionID);
            allowStorePickup.push(tempArray[i].AllowStorePickup);
            readyPickupForUser.push(tempArray[i].ReadyPickupForUser);
            readyPickupForAdmin.push(tempArray[i].ReadyPickupForAdmin);
            allowAdminPickup.push(tempArray[i].AllowAdminPickup);
            statusHistory.push(tempArray[i].StatusHistory);
            processStatus.push(tempArray[i].ProcessStatus);
          }
        }
        for (let i = 0; i < orderName.length; i++) {
          var obj = {
            OrderNumber: orderName[i],
            OrderDate: orderDate[i],
            PaymentStatus: paymentStatus[i],
            TransactionID: transactionID[i],
            AllowStorePickup: allowStorePickup[i],
            ReadyPickupForUser: readyPickupForUser[i],
            ReadyPickupForAdmin: readyPickupForAdmin[i],
            AllowAdminPickup: allowAdminPickup[i],
            StatusHistory: statusHistory[i],
            ProcessStatus: processStatus[i],
            ProductDetail: [],
          };
          for (let j = 0; j < tempArray.length; j++) {
            if (orderName[i] === tempArray[j].OrderNumber) {
              obj.ProductDetail.push(tempArray[j]);
            }
          }
          tempAOrderDetails.push(obj);
        }
        if (productCombinationDetail && productCombinationDetail.length > 0) {
          res.status(200).json({
            status: true,
            total_records: getCount[0].total_records,
            orderDetails: tempAOrderDetails,
          });
        } else {
          res.status(200).json({
            status: false,
            orderDetails: [],
          });
        }
      } else {
        res.status(200).json({
          status: true,
          total_records: getCount[0].total_records,
          orderDetails: [],
        });
      }
    } else {
      res.status(200).json({
        status: true,
        total_records: getCount[0].total_records,
        orderDetails: [],
      });
    }
  } catch (err) {
    console.log(err.message);
    next(err);
    res.status(200).json({
      status: false,
      orderDetails: [],
    });
  }
};
//! Vendor Retur Order
exports.updateReturnOrderStatusByVendor = async (req, res, next) => {
  let transaction;
  try {
    transaction = await connection.transaction();
    //!above this
    const {
      ProcessOrderIDs,
      OrderNumber
    } = req.body;
    let RefandDeliveryPic = req.file.path;
    const idsWrappedInQuotes = ProcessOrderIDs.map(
      (ProcessOrderIDs) => `'${ProcessOrderIDs}'`
    );
    let ProcessOrderID = `(${idsWrappedInQuotes.join(",")})`;
    let LastUpdate = new Date().toISOString().slice(0, 19).replace("T", " ");

    let updateRefundOrderStatusQuery = `UPDATE processrefand SET RefandProductReceiveDate="${LastUpdate}",RefandDeliveryPic=? WHERE ProcessOrderID IN ${ProcessOrderID} `;
    let updateRefundOrderStatus = await connection.query(
      updateRefundOrderStatusQuery, {
      replacements: [RefandDeliveryPic],
      transaction,
    }
    );
    console.log(updateRefundOrderStatus, "updateRefundOrderStatus");
    if (updateRefundOrderStatus) {
      //add join of product here and type in notification ?
      let getProductRecieveDateQuery = ` SELECT pr.ProcessRefandID,po.ProcessOrderID,pr.RefandProductReceiveDate
    FROM processorder po
    INNER JOIN processrefand pr ON pr.ProcessOrderID=po.ProcessOrderID
    WHERE po.ProcessOrderID IN ${ProcessOrderID} AND po.RefundStatus="Processing" AND pr.RefandProductReceiveDate IS NULL OR pr.RefandProductReceiveDate = ''`;
      let getProductRecieveDate = await connection.query(
        getProductRecieveDateQuery, {
        type: QueryTypes.SELECT,
        transaction,
      }
      );
      if (getProductRecieveDate && getProductRecieveDate.length > 0) {
        if (transaction) await transaction.commit();
        res.status(200).json({
          status: true,
          message: " Successfully updated product receive status ",
        });
      } else {
        let getProductType = await connection.query(
          `SELECT po.OrderNumber,p.FreeProductReturn
          FROM processorder po
          INNER JOIN product p ON p.ProductID = po.ProductID
          WHERE po.ProcessOrderID IN ${ProcessOrderID} `, {
          type: QueryTypes.SELECT,
          transaction,
        }
        );
        let FreeProductReturn = getProductType[0].FreeProductReturn;
        let TypeID = "7";
        let Body = {
          OrderNumber: OrderNumber,
          body: `All products of OrderNumber ${OrderNumber} are delivered to related vendors you can initiate refund payment process `,
          status: "Processing",
          type: FreeProductReturn,
        };
        const senderID = "1";
        const receiverID = "1";
        let sendNotification = await Notification(
          TypeID,
          Body,
          senderID,
          receiverID,
          transaction
        );
        if (sendNotification) {
          let Message = `All products of OrderNumber ${OrderNumber} are delivered to related vendors you can initiate refund payment process `;
          let getEmailAddress = await connection.query(
            ` SELECT UserID,EmailAddress FROM profile    
           WHERE SuperAdmin="Y"  `, {
            type: QueryTypes.SELECT,
            transaction,
          }
          );
          let EmailAddress = getEmailAddress[0].EmailAddress;
          let sendMail = sendEmail(EmailAddress, Message, TypeID);
          if (sendMail) {
            if (transaction) await transaction.commit();
            res.status(200).json({
              status: true,
              message: " Successfully updated product receive status and notify super admin for initiating payment process",
            });
          } else {
            if (transaction) await transaction.rollback();
            res.status(200).json({
              status: false,
              message: "Error while sending Email to Super Admin ",
            });
          }
        } else {
          if (transaction) await transaction.rollback();
          res.status(200).json({
            status: false,
            message: "Error while sending Notification to Super Admin ",
          });
        }
      }
    } else {
      if (transaction) await transaction.rollback();
      res.status(200).json({
        status: false,
        message: "Error while updating refund status in DB",
      });
    }
  } catch (err) {
    if (transaction) await transaction.rollback();
    next(err);
    res.status(200).json({
      status: false,
      error: err.message,
    });
    console.log(err.message);
  }
};
exports.markDeliveredPathaoReturnOrderStatus = async (req, res, next) => {
  let transaction;
  try {
    transaction = await connection.transaction();
    const {
      status,
      OrderNumber,
      ProcessOrderIDs
    } = req.body;
    let body;
    let changeOrderStatus;
    let LastUpdate = new Date().toISOString().slice(0, 19).replace("T", " ");
    let orderStatus;
    let parsePreviousStatusHistory = [];
    const idsWrappedInQuotes = ProcessOrderIDs.map(
      (ProcessOrderIDs) => `'${ProcessOrderIDs}'`
    );
    let ProcessOrderID = `(${idsWrappedInQuotes.join(",")})`;
    let getOrderDetail = await connection.query(
      `SELECT * from processorder  WHERE ProcessOrderID IN ${ProcessOrderID}  `, {
      type: QueryTypes.SELECT,
      transaction,
    }
    );
    if (getOrderDetail && getOrderDetail.length > 0) {
      let ReceiverID = getOrderDetail[0].UserID;
      if (status == "Delivered") {
        body = `Your return order ${OrderNumber} is Delivered`;
        orderStatus = "Delivered";
        parsePreviousStatusHistory = JSON.parse(
          getOrderDetail[0].ReturnOrderStatusHistory
        );
        parsePreviousStatusHistory.push(LastUpdate);
        parsePreviousStatusHistory.push(LastUpdate);
        (changeOrderStatusQuery = `UPDATE processorder
           SET ReturnOrderStatus="${status}",ReturnOrderStatusHistory='${JSON.stringify(
          parsePreviousStatusHistory
        )}',LastUpdate="${LastUpdate}"
          WHERE ProcessOrderID IN ${ProcessOrderID}  `), {
          transaction,
        };
        changeOrderStatus = await connection.query(changeOrderStatusQuery, {
          transaction,
        });
        if (changeOrderStatus) {
          let TypeID = "7";
          let CreaterID = "1";
          let Body = {
            OrderNumber: OrderNumber,
            body,
          };
          let Message = `You Return Order # ${Body.OrderNumber} is ${orderStatus} `;
          let getDeviceIDQuery = ` SELECT EmailAddress,UserID
                  FROM profile 
                  WHERE UserID=${ReceiverID}`;
          let getDeviceID = await connection.query(getDeviceIDQuery, {
            type: QueryTypes.SELECT,
            transaction,
          });
          if (getDeviceID && getDeviceID.length > 0) {
            let EmailAddress = getDeviceID[0].EmailAddress;
            let ReceiverID = getDeviceID[0].UserID;
            sendEmail(EmailAddress, Message, TypeID);
            let sendNotification = await Notification(
              TypeID,
              Body,
              CreaterID,
              ReceiverID,
              transaction
            );
            console.log(sendNotification, "sendNotification");
            if (sendNotification) {
              if (transaction) await transaction.commit(); //!final commit
              res.status(200).json({
                status: true,
                message: "Order Status Updated Sucessfully ",
              });
            } else {
              if (transaction) await transaction.rollback();
              res.status(200).json({
                status: false,
                message: "Error while sending Notification to User ",
              });
            }
          } else {
            if (transaction) await transaction.rollback();
            res.status(200).json({
              status: false,
              message: "Error while getting user data from Database ",
            });
          }
        } else {
          if (transaction) await transaction.rollback();
          res.status(200).json({
            status: false,
            message: "Error while updating status ",
          });
        }
      } else {
        if (transaction) await transaction.rollback();
        res.status(200).json({
          status: false,
          message: "Inavlied Status from frontend ",
        });
      }
    } else {
      if (transaction) await transaction.rollback();
      res.status(200).json({
        status: false,
        message: "No record found to update against this data ",
      });
    }
  } catch (err) {
    console.log(err.message, "------------------------------");
    if (transaction) await transaction.rollback();
    next(err);
    res.status(200).json({
      status: false,
      error: err.message,
    });
  }
};
exports.markDeliveredVendorReturnOrderStatus = async (req, res, next) => {
  let transaction;
  try {
    transaction = await connection.transaction();
    const {
      status,
      OrderNumber,
      ProcessOrderIDs
    } = req.body;
    let body;
    let changeOrderStatus;
    let LastUpdate = new Date().toISOString().slice(0, 19).replace("T", " ");
    let orderStatus;
    let parsePreviousStatusHistory = [];
    const idsWrappedInQuotes = ProcessOrderIDs.map(
      (ProcessOrderIDs) => `'${ProcessOrderIDs}'`
    );
    let ProcessOrderID = `(${idsWrappedInQuotes.join(",")})`;
    let getOrderDetail = await connection.query(
      `SELECT * from processorder  WHERE ProcessOrderID IN ${ProcessOrderID}  `, {
      type: QueryTypes.SELECT,
      transaction,
    }
    );
    if (getOrderDetail && getOrderDetail.length > 0) {
      let ReceiverID = getOrderDetail[0].UserID;
      if (status == "Delivered") {
        body = `Your return order ${OrderNumber} is Delivered`;
        orderStatus = "Delivered";
        parsePreviousStatusHistory = JSON.parse(
          getOrderDetail[0].ReturnOrderStatusHistory
        );
        parsePreviousStatusHistory.push(LastUpdate);
        parsePreviousStatusHistory.push(LastUpdate);
        (changeOrderStatusQuery = `UPDATE processorder
           SET ReturnOrderStatus="${status}",ReturnOrderStatusHistory='${JSON.stringify(
          parsePreviousStatusHistory
        )}',LastUpdate="${LastUpdate}"
          WHERE ProcessOrderID IN ${ProcessOrderID}  `), {
          transaction,
        };
        changeOrderStatus = await connection.query(changeOrderStatusQuery, {
          transaction,
        });
        if (changeOrderStatus) {
          let TypeID = "7";
          let CreaterID = "1";
          let Body = {
            OrderNumber: OrderNumber,
            body,
          };
          let Message = `You Return Order # ${Body.OrderNumber} is ${orderStatus} `;
          let getDeviceIDQuery = ` SELECT EmailAddress,UserID
                  FROM profile 
                  WHERE UserID=${ReceiverID}`;
          let getDeviceID = await connection.query(getDeviceIDQuery, {
            type: QueryTypes.SELECT,
            transaction,
          });
          if (getDeviceID && getDeviceID.length > 0) {
            let EmailAddress = getDeviceID[0].EmailAddress;
            let ReceiverID = getDeviceID[0].UserID;
            sendEmail(EmailAddress, Message, TypeID);
            let sendNotification = await Notification(
              TypeID,
              Body,
              CreaterID,
              ReceiverID,
              transaction
            );
            console.log(sendNotification, "sendNotification");
            if (sendNotification) {
              if (transaction) await transaction.commit(); //!final commit
              res.status(200).json({
                status: true,
                message: "Order Status Updated Sucessfully ",
              });
            } else {
              if (transaction) await transaction.rollback();
              res.status(200).json({
                status: false,
                message: "Error while sending Notification to User ",
              });
            }
          } else {
            if (transaction) await transaction.rollback();
            res.status(200).json({
              status: false,
              message: "Error while getting user data from Database ",
            });
          }
        } else {
          if (transaction) await transaction.rollback();
          res.status(200).json({
            status: false,
            message: "Error while updating status ",
          });
        }
      } else {
        if (transaction) await transaction.rollback();
        res.status(200).json({
          status: false,
          message: "Inavlied Status from frontend ",
        });
      }
    } else {
      if (transaction) await transaction.rollback();
      res.status(200).json({
        status: false,
        message: "No record found to update against this data ",
      });
    }
  } catch (err) {
    console.log(err.message, "------------------------------");
    if (transaction) await transaction.rollback();
    next(err);
    res.status(200).json({
      status: false,
      error: err.message,
    });
  }
};

//new vendor and store registration api
exports.registerVendorBuisnessAndStore = async (req, res, next) => {
  let transaction;
  try {
    const GovernmentIDPic = req.files.GovernmentIDPic[0].path;
    const CompanyLogo = req.files.CompanyLogo[0].path;
    const BannerImage = req.files.BannerImage[0].path;
    const GovernmentIDPicBackSide = req.files.GovernmentIDPicBackSide[0].path;
    let TaxIDPic;
    if (req.file && Object.keys(req.file).length > 0) {
      if (req.file.path && req.file.path.length > 0) {
        TaxIDPic = req.file.TaxIDPic[0].path;
      } else {
        TaxIDPic = null;
      }
    } else {
      TaxIDPic = null;
    }
    let {
      VendorID,
      CompanyName,
      TaxID,
      GovernmentID,
      Address1,
      Address2,
      CityID,
      City,
      State,
      ZipCode,
      GoogleMapID,
      CountryID,
      PaymentAccount,
      PaymentRouting,
      BusinessEmail,
      BusinessPhone,
      BusinessURL,
      PageURL,
      AllowDelivery,
      GatewayID,
      AllowStorePickup,
      ProductApproval,
      CreatedDate,
      AdminNote,
      StoreName,
      StoreAddress1,
      StoreAddress2,
      StoreCityID,
      StoreCity,
      StoreState,
      StoreZipCode,
      StoreCountryID,
      StoreEmail,
      StorePhone,
      EmailVerified,
      PhoneVerified,
      StoreFAX,
      StoreURL,
      ExceptDropOff,
      Active,
      zone_id,
      area_id,
      pathaoToken,
      city_id,
    } = req.body;
    console.log(req.body, "----------body");

    CityID = CountryID == "16" ? CityID : CityID ? CityID : null
    StoreCityID = CountryID == "16" ? StoreCityID : StoreCityID ? StoreCityID : null
    city_id = CountryID == "16" ? city_id : null
    zone_id = CountryID == "16" ? zone_id : null
    area_id = CountryID == "16" ? area_id : null


    let ReceiverID = VendorID;
    let LastUpdate = new Date().toISOString().slice(0, 19).replace("T", " ");
    transaction = await connection.transaction();

    let checkIfVendorExists = await vendorIDCheck(VendorID, transaction);
    let checkIfStoreNameExists = await CompanyNameCheck(
      CompanyName,
      transaction
    );

    if (checkIfVendorExists && checkIfVendorExists == "0") {
      if (checkIfStoreNameExists && checkIfStoreNameExists == "0") {
        if (
          GatewayID === "null" ||
          GatewayID === null ||
          GatewayID === undefined
        ) {
          GatewayID = 0;
        }
        let queryString = `insert into vendor (VendorID, CompanyName, 
            TaxID,TaxIDPic,GovernmentID,GovernmentIDPic,GovernmentIDPicBackSide,CompanyLogo,BannerImage,Address1, 
            Address2, CityID, City, State, ZipCode,GoogleMapID, CountryID,
            PaymentAccount,PaymentRouting,BusinessEmail,
            BusinessPhone,BusinessURL,PageURL,AllowDelivery,
            GatewayID,AllowStorePickup,ProductApproval,CreatedDate,AdminNote ) 
            values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`;
        let registerVendorQuery = await connection.query(queryString, {
          replacements: [
            VendorID,
            CompanyName,
            TaxID,
            TaxIDPic,
            GovernmentID,
            GovernmentIDPic,
            GovernmentIDPicBackSide,
            CompanyLogo,
            BannerImage,
            Address1,
            Address2,
            CityID,
            City,
            State,
            ZipCode,
            GoogleMapID,
            CountryID,
            PaymentAccount,
            PaymentRouting,
            BusinessEmail,
            BusinessPhone,
            BusinessURL,
            PageURL,
            AllowDelivery,
            GatewayID,
            AllowStorePickup,
            ProductApproval,
            LastUpdate,
            AdminNote,
          ],
          transaction,
        });

        if (registerVendorQuery) {
          let checkIfStoreNameExists = await StoreNameCheck(
            StoreName,
            transaction
          );
          console.log(checkIfStoreNameExists);

          if (checkIfStoreNameExists && checkIfStoreNameExists === "0") {
            if (StorePhone && StorePhone.length == 13 && CountryID === "16") {
              StorePhone = StorePhone.slice(2);
            }
            let queryString = `
          insert into vendorstore(VendorID, StoreName,
            Address1, Address2, CityID, City, State,
            ZipCode, CountryID, StoreEmail, StorePhone, EmailVerified, PhoneVerified, StoreFAX, StoreURL, GoogleMapID, ExceptDropOff, Active, LastUpdate, AdminNote,city_id,zone_id,area_id)
          values( ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ?,?,?,?)
          `;
            let vendorStoreQuery = await connection.query(queryString, {
              replacements: [
                VendorID,
                StoreName,
                StoreAddress1,
                StoreAddress2,
                StoreCityID,
                StoreCity,
                StoreState,
                StoreZipCode,
                StoreCountryID,
                StoreEmail,
                StorePhone,
                EmailVerified,
                PhoneVerified,
                StoreFAX,
                StoreURL,
                GoogleMapID,
                ExceptDropOff,
                Active,
                LastUpdate,
                AdminNote,
                city_id, zone_id, area_id
              ],
              transaction,
            });
            let response;

            if (vendorStoreQuery) {
              console.log(CountryID, "CountryID--------------------------------")
              if (CountryID == "16") {
                try {
                  response = await createStore(
                    StoreName,
                    StorePhone,
                    Address1,
                    city_id,
                    zone_id,
                    area_id,
                    pathaoToken
                  );
                  console.log(
                    response,
                    "response in --------------------------------------------"
                  );
                } catch (error) {
                  if (transaction) await transaction.rollback();
                  res.status(200).json({
                    status: false,
                    message: error.response.data,
                  });
                }
                if (response) {
                  let getDeviceIDQuery = ` SELECT DeviceID,EmailAddress
                    FROM profile 
                    WHERE UserID=${ReceiverID}`;
                  let getDeviceID = await connection.query(getDeviceIDQuery, {
                    type: QueryTypes.SELECT,
                    transaction,
                  });

                  let TypeID = "5";
                  let CreaterID = "1";
                  let Body = {
                    body: "Your Buisness Registration request is sent to Admin for approval ",
                  };
                  let sendNotification = await Notification(
                    TypeID,
                    Body,
                    CreaterID,
                    ReceiverID,
                    transaction
                  );
                  let Message = Body.body;
                  let EmailAddress = getDeviceID[0].EmailAddress;
                  sendEmail(EmailAddress, Message, TypeID);

                  let typeID = "4";
                  let MessageBody = {
                    body: "Your role has been changed to Vendor ",
                  };
                  let notification = await Notification(
                    typeID,
                    MessageBody,
                    CreaterID,
                    ReceiverID,
                    transaction
                  );
                  if (
                    response.data.message ===
                    "You already have a almost same pending store request."
                  ) {
                    let updatePthaoStoreRequest;
                    updatePthaoStoreRequest = await connection.query(
                      `UPDATE vendorstore SET PthaoStoreRequest="In Queue" WHERE StoreName="${StoreName}" `, {
                      transaction,
                    }
                    );
                    if (updatePthaoStoreRequest) {
                      if (transaction) await transaction.commit(); //!final commit
                      res.status(200).json({
                        status: true,
                        message: ` Successfully Added Store in Queue Request `,
                        pathaoResponse: response.data,
                      });
                    } else {
                      if (transaction) await transaction.rollback();
                      res.status(200).json({
                        status: false,
                        message: "Error while updating Pathao Strore Queue Status ",
                        pathaoResponse: response.data,
                      });
                    }
                  } else if (
                    response.data.message ===
                    "Store created successfully, Please wait one hour for approval."
                  ) {
                    console.log(response.data);
                    let TypeID = "5";
                    let CreaterID = "1";
                    let Body = {
                      body: "Your Store is Registered Successfully !! PLease wait 24 to 48 hours for approval ",
                    };

                    let Message = Body.body;
                    sendEmail(EmailAddress, Message, TypeID);
                    let sendNotification = await Notification(
                      TypeID,
                      Body,
                      CreaterID,
                      ReceiverID,
                      transaction
                    );
                    console.log(sendNotification, "sendNotification");
                    if (sendNotification) {
                      if (transaction) await transaction.commit(); //!final commit
                      res.status(200).json({
                        status: true,
                        message: ` Vendor Store added successfully `,
                        pathaoResponse: response.data,
                      });
                    } else {
                      if (transaction) await transaction.rollback();
                      res.status(200).json({
                        status: false,
                        message: "Error while sending Notification to User ",
                      });
                    }
                  } else {
                    if (transaction) await transaction.rollback();
                    res.status(200).json({
                      status: false,
                      message: response.data.message,
                      error: response.data.errors,
                    });
                  }
                } else {
                  if (transaction) await transaction.rollback();
                  res.status(200).json({
                    status: false,
                    message: ` Error while getting pathao store register api response `,
                  });
                }
              } else {
                let getDeviceIDQuery = ` SELECT DeviceID,EmailAddress
                    FROM profile 
                    WHERE UserID=${ReceiverID}`;
                let getDeviceID = await connection.query(getDeviceIDQuery, {
                  type: QueryTypes.SELECT,
                  transaction,
                });

                let TypeID = "5";
                let CreaterID = "1";
                let Body = {
                  body: "Your Buisness Registration request is sent to Admin for approval ",
                };
                let sendNotification = await Notification(
                  TypeID,
                  Body,
                  CreaterID,
                  ReceiverID,
                  transaction
                );
                let Message = Body.body;
                let EmailAddress = getDeviceID[0].EmailAddress;
                sendEmail(EmailAddress, Message, TypeID);

                let typeID = "4";
                let MessageBody = {
                  body: "Your role has been changed to Vendor ",
                };
                let notification = await Notification(
                  typeID,
                  MessageBody,
                  CreaterID,
                  ReceiverID,
                  transaction
                );
                if (transaction) await transaction.commit(); //!final commit
                res.status(200).json({
                  status: true,
                  message: ` Successfully registered `,
                });
              }
            } else {
              if (transaction) await transaction.rollback();
              res.status(200).json({
                status: false,
                message: ` Error while registering vendor store `,
              });
            }
          } else if (checkIfStoreNameExists && checkIfStoreNameExists == "1") {
            if (transaction) await transaction.rollback();
            res.status(200).json({
              status: false,
              message: "StoreName already exists,Please choose unique Storename",
            });
          }

          //above this -------------------------------------------------
        } else {
          if (transaction) await transaction.rollback();
          res.status(200).json({
            status: false,
            message: `Error while registering vendor`,
          });
        }
      } else if (checkIfStoreNameExists && checkIfStoreNameExists == "1") {
        if (transaction) await transaction.rollback();
        res.status(200).json({
          status: false,
          message: "Company Name already exists,Please choose unique CompanyName",
        });
      }
    } else if (checkIfVendorExists && checkIfVendorExists == "1") {
      if (transaction) await transaction.rollback();
      res.status(200).json({
        status: false,
        message: "Vendor already register against this UserID",
        error: "null",
      });
    }
  } catch (err) {
    console.log(err, "------------");
    if (transaction) await transaction.rollback();
    res.status(200).json({
      status: false,
      message: err.message,
      error: "null",
    });
  }
};
exports.checkStoreStatus = async (req, res, next) => {
  try {
    const {
      VendorStoreID
    } = req.body;

    let getStoreStatusQuery = ` SELECT vs.VendorStoreID,vs.PthaoStoreResponse
            FROM vendorstore vs
            WHERE vs.VendorStoreID="${VendorStoreID}" AND vs.PthaoStoreResponse IS NULL`;
    let getStoreStatus = await connection.query(getStoreStatusQuery, {
      type: QueryTypes.SELECT,
    });
    console.log(getStoreStatus, "getStoreStatus");

    if (getStoreStatus && getStoreStatus.length) {
      res.status(200).json({
        status: true,
        value: true,
      });
    } else {
      res.status(200).json({
        status: true,
        value: false,
      });
    }
  } catch (error) {
    res.status(200).json({
      status: false,
      message: error.message,
    });
  }
};
exports.resendStoreRequest = async (req, res, next) => {
  try {
    const {
      VendorStoreID
    } = req.body;

    let getStoreStatusQuery = `SELECT vs.VendorStoreID,vs.StorePhone,vs.Address1,vs.StoreName,vs.zone_id,vs.area_id,vs.city_id,vs.PthaoStoreResponse
            FROM vendorstore vs
            WHERE vs.VendorStoreID="${VendorStoreID}" AND vs.PthaoStoreResponse IS NULL`;
    let getStoreStatus = await connection.query(getStoreStatusQuery, {
      type: QueryTypes.SELECT,
    });
    console.log(getStoreStatus, "getStoreStatus");

    if (getStoreStatus && getStoreStatus.length > 0) {
      let pathaoToken = await issueToken();
      console.log(pathaoToken, "pathaoToken");

      const store = getStoreStatus[0];
      let response;
      try {
        response = await createStore(
          store.StoreName,
          store.StorePhone,
          store.Address1,
          store.city_id,
          store.zone_id,
          store.area_id,
          pathaoToken
        );

        let updatePthaoStoreRequest;
        let PthaoStoreResponse = JSON.stringify(response.data);

        console.log(response.data.message);
        if (
          response.data.message ===
          "Store created successfully, Please wait one hour for approval."
        ) {
          updatePthaoStoreRequest = await connection.query(
            `UPDATE vendorstore SET  PthaoStoreResponse='${PthaoStoreResponse}' WHERE StoreName="${store.StoreName}" `
          );
          res.status(200).json({
            status: true,
            message: `Vendor store request send successfully`,
            pathaoResponse: response.data,
          });
        } else {
          updatePthaoStoreRequest = await connection.query(
            `UPDATE vendorstore SET PthaoStoreFailureResponse='${PthaoStoreResponse}' WHERE StoreName="${store.StoreName}" `
          );
          res.status(200).json({
            status: false,
            pathaoResponse: response.data,
          });
        }

      } catch (error) {
        updatePthaoStoreRequest = await connection.query(
          `UPDATE vendorstore SET PthaoStoreFailureResponse='${PthaoStoreResponse}' WHERE StoreName="${store.StoreName}" `
        );

        res.status(200).json({
          status: false,
          message: `Failed to create store`,
          pathaoResponse: response.data,
        });
      }
    } else {
      res.status(200).json({
        status: true,
        message: "No request found ",
      });
    }
  } catch (error) {
    res.status(200).json({
      status: false,
      message: error.message,
    });
  }
};
