var admin = require("firebase-admin");

var serviceAccount = require("../../src/utils/private-file.json");


admin.initializeApp({
  credential: admin.credential.cert(serviceAccount),
  databaseURL: "https://sample-project-e1a84.firebaseio.com"
})

/* var token=[''];


const payload = {
    notification: {
       title: "This is notification",
       body: "This is the body "
           }
    };
    var options ={
      priority :"high",
      timeToLive : 60*60*24
    }; */

module.exports.admin = admin