var nodemailer = require("nodemailer");
/* var transporter = nodemailer.createTransport({
  service: 'smtp.gmail.com',
  host: "smtp.gmail.com",
  port: "587",
  auth: {
    user: 'banglabazaremail@gmail.com',			//email ID
    pass: 'Bazar@2021'				//Password 
  }
}); */
var transporter = nodemailer.createTransport({
  host: "smtp.zeptomail.com",
  port: 587,
  auth: {
    user: "emailapikey",
    pass: "wSsVR61xrBf5C68unmCvL7tsnVVdU1yiHUV5jVSjunKuHP7C98dtlxabBlTxTfIXEWBrETdGoOh7n0sGhjUIh9glnAoDDyiF9mqRe1U4J3x17qnvhDzPX2VYlhuKLYMLxQ1um2dhFstu", //application specific password
  },
});
exports.sendEmail = async (EmailAddress, Message, TypeID) => {
  try {
    let Subject;
    // console.log(EmailAddress, Message, TypeID);
    if (TypeID == "5") {
      Subject = "Registration Status";
    }
    if (TypeID == "6") {
      Subject = "Order Status";
    }
    if (TypeID == "7") {
      Subject = "Refund Request";
    }

    var details = {
      from: "BanglaBazar <no-reply@banglabazar.com>",
      to: EmailAddress,
      subject: Subject,
      html: Message,
      //html: `Your verification code is: <em>${otp}</em>`, // Sending OTP
      // $username: process.env.SMTP_USER,
      // $password: process.env.SMTP_PASSWORD,
    };
    transporter.sendMail(details, function (error, data) {
      if (error) {
        console.log(error);
        return null;
      } else console.log(data);
    });
  } catch (err) {
    console.log(err);
  }
};
