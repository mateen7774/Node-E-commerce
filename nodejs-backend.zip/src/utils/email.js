var nodemailer = require("nodemailer");
var transporter = nodemailer.createTransport({
  host: "smtp.zeptomail.com",
  port: 587,
  auth: {
    user: "emailapikey",
    pass: "wSsVR61xrBf5C68unmCvL7tsnVVdU1yiHUV5jVSjunKuHP7C98dtlxabBlTxTfIXEWBrETdGoOh7n0sGhjUIh9glnAoDDyiF9mqRe1U4J3x17qnvhDzPX2VYlhuKLYMLxQ1um2dhFstu", //application specific password
  },
});
exports.sendMail = async (email, otp) => {
  try {
    var details = {
      from: "BanglaBazar <no-reply@banglabazar.com>",
      to: email,
      subject: " OTP For BanglaBazar",
      html: `Your verification code is: <em>${otp}</em>`,
    };
    transporter.sendMail(details, function (error, data) {
      if (error) console.log(error);
      else console.log(data);
    });
  } catch (err) {
    console.log(err);
  }
};
