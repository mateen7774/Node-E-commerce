var nodemailer = require("nodemailer");
/* var transporter = nodemailer.createTransport({
	service: 'smtp.gmail.com',
	host: "smtp.gmail.com",
	port: "587",
	auth: {
		user: 'banglabazaremail@gmail.com',			//email ID
		pass: 'Bazar@2021'				//Password 
	}
}); */
var transporter = nodemailer.createTransport({
  service: process.env.SMTP_SERVICE,
  host: process.env.SMTP_HOST,
  port: process.env.SMTP_PORT,
  auth: {
    user: process.env.SMTP_USER, //email ID
    pass: process.env.SMTP_PASSWORD, //Password
  },
});
exports.sendMessage = async (EmailAddress) => {
  try {
    var details = {
      from: "BanglaBazar <no-reply@banglabazar.com>", // sender address same as above
      to: EmailAddress, // Receiver's email id
      subject: "Banglabazar Notify",
      text: "Thank you for browsing our site, We will notify you when our site is up and running.", //email's body
      $username: "banglabazaremail@gmail.com",
      $password: "Bazar@2021",
    };
    transporter.sendMail(details, function (error, data) {
      if (error) console.log(error);
      else console.log(data);
    });
  } catch (err) {
    console.log(err);
  }
};



exports.sendContactUsEmail = async (EmailAddress, subject, name, message) => {
 console.log(EmailAddress, subject, name, message,"____________________________")
	try {
    var details = {
      from: EmailAddress, // sender address same as above
      to: "customercare@banglabazar.com", // Receiver's email id
      subject: subject,

      html: `<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Contact Us Email</title>
</head>
<body>
  <h1>Contact Us Email</h1>
  <p><strong>Name:</strong> ${name}</p>
  <p><strong>Message:</strong> ${message}</p>
</body>
</html>`, //email's body
      $username: "banglabazaremail@gmail.com",
      $password: "Bazar@2021",
    };
    transporter.sendMail(details, function (error, data) {
      if (error) console.log(error);
      else console.log(data);
    });
  } catch (err) {
    console.log(err);
  }
};



