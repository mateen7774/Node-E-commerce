var nodemailer = require("nodemailer");
var transporter = nodemailer.createTransport({
    host: "smtp.zeptomail.com",
    port: 587,
    auth: {
        user: "emailapikey",
        pass: "wSsVR61xrBf5C68unmCvL7tsnVVdU1yiHUV5jVSjunKuHP7C98dtlxabBlTxTfIXEWBrETdGoOh7n0sGhjUIh9glnAoDDyiF9mqRe1U4J3x17qnvhDzPX2VYlhuKLYMLxQ1um2dhFstu", //application specific password
    },
});
exports.sendContactAdminMail = async (EmailAddress, subject, name, message) => {
    console.log("____________", EmailAddress, subject, name, message);
    try {
        var details = {
            from:`BanglaBazar <notify@banglabazar.com>`,
            to: 'customercare@banglabazar.com',
            subject: subject,
        	cc: EmailAddress,
            replyTo: EmailAddress,
            html:`
                <html>
                <head>
                    <meta charset="UTF-8">
                    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
                    <meta name="viewport" content="width=device-width, initial-scale=1.0">
                    <title>Contact Admin Email</title>
                </head>
                <body>
                    <h1>Contact Admin Email</h1>
                    <p><strong>Email Address:</strong> ${EmailAddress}</p>
                    <p><strong>Name:</strong> ${name}</p>
                    <p><strong>Message:</strong> ${message}</p>
                </body>
                </html>
            `,

        };
        transporter.sendMail(details, function (error, data) {
            if (error) console.log(error);
            else console.log(data);
        });
    } catch (err) {
        console.log(err);
    }
};












