const jwt = require('jsonwebtoken');
const getAccessToken = async (user) => {
    return await jwt.sign({ UserID: user.UserID, EmailAddress: user.EmailAddress }, process.env.JWT_SECRET, {
        expiresIn: process.env.JWT_EXPIRE,
    });
}

module.exports = getAccessToken