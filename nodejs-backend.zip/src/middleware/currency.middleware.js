

const connection = require("../db/db.connection");

const {
  QueryTypes
} = require("sequelize");
// get Region from Routes
exports.region = async (req, res, next) => {
  try {
    let currencyCode;
    const headers = req.headers;
    const region = headers.region;
     currencyCode = headers.currencycode;
    if (( region && region != undefined) && (currencyCode && currencyCode != undefined)) {
  
      let getCurrencyRates = await connection.query(
        `select * from currencyrate where ToCurrency = '${currencyCode}'`,
        {      type: QueryTypes.SELECT,
        }
      );
      
      if (getCurrencyRates && getCurrencyRates.length > 0) {
        req.region=region;
        req.getCurrencyRates = getCurrencyRates;    
        next();
      } else {
        res.status(401).json({
          status: false,
          message: "Unable to process currency conversion",
        });
      }
    } else {
      return res.status(200).json({
        status: false,
        message: "Invalid region in headers",
      });
    }
  } catch (err) {
    console.log(err.message);
    return res.status(200).json({
      status: false,
      message: err.message,
    });
  }
};
