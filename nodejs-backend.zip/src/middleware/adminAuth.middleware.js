const jwt = require("jsonwebtoken");
const {
    QueryTypes
} = require("sequelize");
const connection = require("../db/db.connection");

// Protect Routes
exports.admin_protect = async (req, res, next) => {
    let token;
    if (
        req.headers.authorization &&
        req.headers.authorization.startsWith("Bearer")
    ) {
        token = req.headers.authorization.split(" ")[1];
    }
    if (!token) {
        return res.status(401).json({
            status: false,
            message: "Inavlid Token , Not authorized to access this route"
        });
    }
    try {
        const decoded = jwt.verify(token, process.env.JWT_SECRET);
        let {
            UserID,
        } = decoded
        let user = await connection.query(`select * from profile where UserID = '${UserID}' AND Admin="Y" OR SuperAdmin="Y"`, {
            type: QueryTypes.SELECT
        })
        if (user && user.length > 0) {
            //console.log('Admin ID --------------', UserID)
            req.UserID = UserID;
            next();
        } else {
            res.status(401).json({
                status: false,
                message: "Not authorize to access this admin route"
            });
        }
    } catch (err) {
        return res.status(401).json({
            status: false,
            message: "Not authorized to access this route"
        });
    }
}