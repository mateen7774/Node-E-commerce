const express = require("express");
const {
  deletedVideo,
  addProductDetailsForm1,
  addProductDetailsForm2,
  getProductVariantOptionDropDownByProductID,
  getProductAllVariantDetailsByProductId,
  getSubCategoryVariantsById,
  updateProductDetailsForm1,
  getProductDetailsPaginated,
  getProductDetailsPaginatedByVendorId,
  viewProductDetailsByNameFilter,
  getProductVariantsDetailsByProductId,
  updateProductDetailsForm2,
  viewProductDetailsByCityFilter,
  viewProductDetailsByCountryFilter,
  getProductDetailsByProductId,
  addNewProductVariantOption,
  deleteProductVariantOptionById,
  getProductVariantsDetailsByOptionId,
  getProductAllDetailsByProductId,
  deleteProductVariantOptionValueById,
  addProductClicks,
  addProductRating,
  MostPouplarProductsByCategoryAndSubCategoryId,
  GlobalSearchProductDetailsByCategory,
  viewProductDetailsBySubCategory,
  viewProductDetailsByCategory,
  getSubCategoryByVendorId,
  getProductDetailsByProductIdOld,
  getProductVariantOptionDropDownByProductIDNew,
  deletedImage

} = require("../../controllers/product/productManagement.controller");
const router = express.Router();
const multer = require("multer");
// const { SmallDateTime } = require("mssql");
var storage1 = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, "./public/imageGallery");
  },
  filename: function (req, file, cb) {
    cb(null, Date.now() + file.originalname);
  },
});
var upload = multer({
  storage: storage1,
});
var uploadMultipleImages = upload.fields([
  {

    name: "Small",
  },
  {
    name: "Medium",
  },
  {
    name: "Large",
  },

]);

const { protect } = require("../../middleware/auth.middleware");
const {
  region
} = require("../../middleware/currency.middleware");
//! Product Form 1 CRUD Routes
router.post("/addProduct-Form1", addProductDetailsForm1);
router.post("/get-productDetailsPaginated", region, getProductDetailsPaginated);
router.post("/get-productDetailsPaginated/:id", region, getProductDetailsPaginatedByVendorId);
router.get("/get-productDetails/:id", region, getProductDetailsByProductIdOld); //this one is with the currency conversion
router.get("/get-product-details/:id", region, getProductDetailsByProductId);
router.post("/get-productDetailsBySubCategory/:id", region, viewProductDetailsBySubCategory);
router.post("/get-productDetailsByCategory/:id", region, viewProductDetailsByCategory);
router.route('/add-productVariant/:id').post(addNewProductVariantOption);
router.route('/delete-productVariant/:id').delete(deleteProductVariantOptionById);
router.route('/updateProduct-Form1/:id').put(updateProductDetailsForm1);
//! Product Form 2 CRUD Routes
router.post("/addProduct-Form2", uploadMultipleImages, addProductDetailsForm2);
router.route("/get-productVariantsDetails/:id").get(getProductVariantsDetailsByProductId);
router.route("/get-productVariantDetail/:id").get(getProductVariantsDetailsByOptionId);
router.put("/updateProduct-Form2/:id", protect, upload.any('video'), updateProductDetailsForm2);
router.route('/delete-productVariantValue').post(deleteProductVariantOptionValueById);
router.route("/get-productVariantOption/:id").get(getProductVariantOptionDropDownByProductID);
router.route("/get-productVariantOptionWithValues/:id").get(getProductVariantOptionDropDownByProductIDNew);
router.route("/get-subCategoryVariants/:id").get(getSubCategoryVariantsById);
//! Product All Details Api Route
router.get("/get-productAllDetails/:id/:UserID", region, getProductAllDetailsByProductId);


// new added route for variant changes

router.post("/get-productAllVariantDetails/:id", getProductAllVariantDetailsByProductId)



//! Most Popular And Top-Rated Products BY Category And SubCategory Api's Routes
router.post("/get-mostPopluarAndTopRatedProducts/:id", region, MostPouplarProductsByCategoryAndSubCategoryId);
//router.route("/get-topRatedProducts/:id").post(TopRatedProductsByCategoryAndSubCategoryId);
//! Global Search Most Popular And Top-Rated Products Api's Routes
router.post("/get-gloabalProductsSearchByCategory", region, GlobalSearchProductDetailsByCategory);
/* router.route("/get-gloabalMostPopularProducts").post(MostPouplarProductsByCategoryGlobalSearch);
router.route("/get-gloabalTopRatedProducts").post(TopRatedProductsByCategoryGlobalSearch); */
//! Product Serach Filter Api's Routes
router.post("/get-productDetailsByName", region, viewProductDetailsByNameFilter);
router.post("/get-productDetailsByCity", region, viewProductDetailsByCityFilter);
router.delete("/image/:ImageGalleryID", deletedImage);
router.delete("/video/:ProductVariantCombinationID",deletedVideo)

router.post("/get-productDetailsByCountry", region, viewProductDetailsByCountryFilter);
//! Product Clicks CRUD Routes
router.route('/addProductClicks').post(addProductClicks);
//! Product Review Rating CRUD Routes
router.route('/addProductRating').post(addProductRating);
module.exports = router;