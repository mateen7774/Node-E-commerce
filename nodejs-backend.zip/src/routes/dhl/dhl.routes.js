const express = require("express");
const {
  onePieceShipmentRates,
  multiplePiecesShipmentRates,
  createShippment,
  trackSingleShipment,
  trackMultipleShipment,
  addressValidation,
  dhlStatusUpdateWebhook,
} = require("../../controllers/dhl/dhl.controller");
const router = express.Router();
const { protect } = require("../../middleware/auth.middleware");
const { region } = require("../../middleware/currency.middleware");

router.post("/rates", region, onePieceShipmentRates);
router.post("/rates-multiple", region, multiplePiecesShipmentRates);
router.post("/create", createShippment);
router.get("/track-single/:id", trackSingleShipment);
router.get("/track-multiple/:id", trackMultipleShipment);
router.post("/address-validate", addressValidation);
router.get("/update-status/:id/:status", dhlStatusUpdateWebhook);

dhlStatusUpdateWebhook;

module.exports = router;
