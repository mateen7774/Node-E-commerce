const express = require("express");
const {
  getAuditCurrency,
} = require("../../controllers/currency/currency.controller");
const router = express.Router();
//!Country routes
router.route("/get-auditCurrency").post(getAuditCurrency);

module.exports = router;
