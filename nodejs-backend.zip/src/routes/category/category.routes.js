const express = require("express");
const {
  addCategory,
  viewCategoryById,
  deleteCategoryById,
  updateCategoryById,
  addSubCategory,
  viewSubCategoryById,
  deleteSubCategoryById,
  updateSubCategoryById,
  insertSubCategoryVariant,
  viewSubCategoryVariantById,
  insertSubCategoryVariantValue,
  viewSubCategoryVariantValueById,
  viewAllCategory,
  deleteSubCategoryVariantById,
  deleteSubCategoryVariantValueById,
  updateSubCategoryVariantById,
  updateSubCategoryVariantValueById,
  viewAllCategories,
  viewAllSubCategoryById,
  viewAllSubCategory,
  insertCategoriesListByCSV,
  insertSubCategoriesListByCSV,
  viewAllCategoriesANDSubcategories,
  testAllCategoriesANDSubcategories,
  getVendorSubcategoryUpdated,
	viewDepartmentsAllCategoriesANDSubcategories
} = require("../../controllers/category/category.controller");
const router = express.Router();
const multer = require("multer");
//const { protect } = require('../../middleware/auth.middleware');
var storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, "./public/categoryImages/");
  },
  filename: function (req, file, cb) {
    cb(null, Date.now() + file.originalname);
  },
});
var upload = multer({
  storage,
});
//! Category CRUD Api's Routes
router.post("/add-category", upload.single("CategoryPic"), addCategory);
router.route("/get-category").post(viewCategoryById);
router.route("/get-allcategory").post(viewAllCategory);
router.route("/get-allcategories").get(viewAllCategories);
router.route("/delete-category/:id").delete(deleteCategoryById);
router.put(
  "/update-category/:id",
  upload.single("CategoryPic"),
  updateCategoryById
);
//! SubCategory CRUD Api's Routes
router.post(
  "/add-subcategory",
  upload.single("SubCategoryPic"),
  addSubCategory
);
router.route("/get-subcategory").post(viewSubCategoryById);
router.route("/get-subCategory/:id").get(viewAllSubCategoryById);
router.route("/get-allSubCategory").get(viewAllSubCategory);
router.route("/get-subCategoriesByCategories").get(getVendorSubcategoryUpdated);

router.route("/delete-subcategory/:id").delete(deleteSubCategoryById);
router.put(
  "/update-subcategory/:id",
  upload.single("SubCategoryPic"),
  updateSubCategoryById
);
//!GET All Categories And SubCategories Api Route
router
  .route("/get-allCategoriesAndSubCategories")
  .get(viewAllCategoriesANDSubcategories);
//! SubCategory Variant CRUD Api's Routes
router.route("/insert-subcategoryvariant").post(insertSubCategoryVariant);
router.route("/get-subcategoryvariant/:id").get(viewSubCategoryVariantById);
router
  .route("/get-viewDepartmentsAllCategoriesANDSubcategories")
  .get(viewDepartmentsAllCategoriesANDSubcategories);
router
  .route("/delete-subcategoryvariant/:id")
  .delete(deleteSubCategoryVariantById);
router
  .route("/update-subcategoryvariant/:id")
  .put(updateSubCategoryVariantById);
//! SubCategory Variant Value CRUD Api's Routes
router
  .route("/insert-subcategoryvariantvalue")
  .post(insertSubCategoryVariantValue);
router
  .route("/get-subcategoryvariantvalue/:id")
  .get(viewSubCategoryVariantValueById);
router
  .route("/delete-subcategoryvariantValue/:id")
  .delete(deleteSubCategoryVariantValueById);
router
  .route("/update-subcategoryvariantvalue/:id")
  .put(updateSubCategoryVariantValueById);
//! INSERT Categories And SubCategories list by CSV file APi's Routes
router.route("/insert-categoryList").post(insertCategoriesListByCSV);
router.route("/insert-subCategoryList").post(insertSubCategoriesListByCSV);

module.exports = router;
