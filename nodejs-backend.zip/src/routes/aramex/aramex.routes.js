const express = require("express");
const {
    aramexShipment,
} = require("../../controllers/aramex/aramex.controller");
const router = express.Router();
module.exports = router;

router.post("/init", aramexShipment);