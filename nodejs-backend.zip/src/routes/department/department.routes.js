const express = require('express');
const {
  addDepartment,
  viewDepartment,
  deleteDepartmentById,
  updateDepartmentById,
  viewAllDepartment,
  insertDepartmentsListByCsv
} = require("../../controllers/department/department.controller");
const router = express.Router();
const multer = require('multer');
//const { protect } = require('../../middleware/auth.middleware');
var storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, './public/departmentImages/')
  },
  filename: function (req, file, cb) {
    cb(null, Date.now() + file.originalname)
  }
});

var upload = multer({
  storage
});
//!Department CRUD Api's Routes
 router.post('/add-department', upload.single('DepartmentPic'), addDepartment);
 router.route('/get-department').post(viewDepartment);
 router.route("/get-alldepartment").get(viewAllDepartment);
 router.route('/delete-department/:id').delete(deleteDepartmentById);
 router.put('/update-department/:id', upload.single('DepartmentPic'), updateDepartmentById);
 //!INSERT Department list By CSV File Route
 router.route('/insert-departmentList').post(insertDepartmentsListByCsv);
module.exports = router;