const express = require("express");
const {
  adduserEmailToNewsLetter,
} = require("../../controllers/news/newsLetter.controller");
const router = express.Router();

router.route("/add").post(adduserEmailToNewsLetter);
module.exports = router;
