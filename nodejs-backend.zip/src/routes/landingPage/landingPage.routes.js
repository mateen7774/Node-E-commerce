const express = require("express");
const {
  createLandingPageProductsView,
  viewLandingPageProductsView,
  getRecentlyViewedProducts,
  trendingForyouProducts,
  topRatedProducts,
  deleteRecentlyViewedProducts,
  getCountryCurrencyData,
  test,
} = require("../../controllers/landingPage/landingPage.controller");
const { region } = require("../../middleware/currency.middleware");
const router = express.Router();
router.route("/createProductsViews").post(createLandingPageProductsView);
router.post("/showProductsViews", region, viewLandingPageProductsView);
router.post("/recenltyViewedProducts", region, getRecentlyViewedProducts);
router.post("/trendingForyouProducts", region, trendingForyouProducts);
router.post("/topRatedProducts", region, topRatedProducts);
router.route("/updateRecentlyViewed").post(deleteRecentlyViewedProducts);
router.route("/test").get(test);
router.get("/countryCurrencyList",getCountryCurrencyData)

module.exports = router;
