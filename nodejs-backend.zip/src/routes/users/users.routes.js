const express = require("express");
const {
	checkedliveryguystatus,
  registerUser,
  login,
  updateUserById,
  verifyOTP,
  resendOTP,
  uploadImage,
  forgotPassword,
  verifyOTPResetPassword,
  updatePassword,
  updatePhoneNumber,
  updateEmail,
  viewUserDetailsByEmailFilter,
  viewUserDetailsByPhoneFilter,
  viewUserDetailsByNameFilter,
  getUserCatdDetails,
  getUserReviewStatus,
  logout,
} = require("../../controllers/usersControllers/users.controller");
const router = express.Router();
const multer = require("multer");
const { protect } = require("../../middleware/auth.middleware");
const { admin_protect } = require("../../middleware/adminAuth.middleware");

var storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, "./public/profileImages/");
  },
  filename: function (req, file, cb) {
    cb(null, Date.now() + file.originalname);
  },
});
var upload = multer({
  storage,
});
//api
router.get("/check-delivery-status", protect, checkedliveryguystatus);

router.post("/login", login);
router.route("/register").post(registerUser);
router.put("/update/:id", protect, updateUserById);
router.route("/verify").post(verifyOTP);
router.route("/resend").post(resendOTP);
router.put("/uploadForm", protect, upload.single("myimg"), uploadImage);
router.route("/forgot").post(forgotPassword);
router.route("/verify-otp").post(verifyOTPResetPassword);
router.route("/update-password").post(updatePassword);
router.put("/update-number", protect, updatePhoneNumber)
router.put("/update-number/:id", protect, updatePhoneNumber);

router.put("/update-email", updateEmail);
router.post(
  "/userDetails-phoneFilter",
  admin_protect,
  viewUserDetailsByPhoneFilter
);
router.post(
  "/userDetails-emailFilter",
  admin_protect,
  viewUserDetailsByEmailFilter
);
router.post(
  "/userDetails-nameFilter",
  admin_protect,
  viewUserDetailsByNameFilter
);
router.get("/user-cardDetails", protect, getUserCatdDetails);
router.post("/user-review-status", protect, getUserReviewStatus);
router.post("/logout", protect, logout);

module.exports = router;
//users controller
