const express = require("express");
const {
  getCountry,
  getCity,
  getState,
  addCountry,
  updateCountryById,
  deleteCountryById,
  addCity,
  updateCityById,
  insertCountresListByCsv,
  addNewStateByUser,
  addNewCityByUser,
  addState,
  updateStateById,
  getAllCountry,
  getAllCity,
  getAllState,
  getVendorAllowedCountries,
  getVednorAllowedStates,
  getVednorAllowedCities,
  insertStatesListByCsv,
  insertCitiesListByCsv,
  getAllCityByState,
  getDeliveryAllowedCountries,
  getAllCityByCountry,
  getCountryByName,
  getStateByName,
  getUserAllowedCountries,
} = require("../../controllers/location/location.controller");
const router = express.Router();
//!Country routes
router.route("/add-country").post(addCountry);
router.route("/get-country").post(getCountry);
router.route("/get-country").get(getAllCountry);
router.route("/get-countryByName").post(getCountryByName);
router.route("/get-vendorAllowedCountries").get(getVendorAllowedCountries);
router.route("/get-deliveryAllowedCountries").get(getDeliveryAllowedCountries);
router.route("/get-userAllowedCountries").get(getUserAllowedCountries);
router.route("/update-country/:id").put(updateCountryById);
router.route("/delete-country/:id").delete(deleteCountryById);
//!State routes
router.route("/add-state").post(addState);
router.route("/get-state").post(getState);
router.route("/get-stateByName").post(getStateByName);
router.route("/get-state").get(getAllState);
router.route("/get-vendorAllowedStates").post(getVednorAllowedStates);
router.route("/update-state/:id").put(updateStateById);
//!City routes api's
router.route("/add-city").post(addCity);
router.route("/get-city").post(getCity);
router.route("/get-city").get(getAllCity);
router.route("/get-cities/:id").get(getAllCityByState);
router.route("/get-citiesByCountry/:id").get(getAllCityByCountry);
router.route("/get-vendorAllowedCities").post(getVednorAllowedCities);
router.route("/update-city/:id").put(updateCityById);
//! State and City enter by user explicitly APi's
router.route("/add-newState").post(addNewStateByUser);
router.route("/add-newCity").post(addNewCityByUser);
//!Insert Countries List by CSV
router.route("/insert-countries").post(insertCountresListByCsv);
router.route("/insert-states").post(insertStatesListByCsv);
router.route("/insert-cities").post(insertCitiesListByCsv);

module.exports = router;
