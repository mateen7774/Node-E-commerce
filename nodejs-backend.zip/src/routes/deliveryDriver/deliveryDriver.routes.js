const express = require("express");
const {
  registerDeliveryDriver,
  updateDeliveryDriverDetails,
  deleteDeliveryDriverById,
  getDeliveryDriverByCity,
  assignDeliveryDriver,
  getDriverOrdersByStatus,
  changeDriverOrderStatus,
  markReturnedStatus,
  driverDashBoardApi,
  checkDriverAvailability,
  changePathaoOrderStatus,
  getDeliveryDriverDetails,
  ShippingCostVendor,
  shippingCostVendorCountry,
  shippingCostVendorCity,
  updatePathaoOrderStatus,
  pathaoStatusUpdateWebhook,
  deliveryDriverCodOrders,
  updateDriverDepositProof,
  changeDriverReturnOrderStatus,
} = require("../../controllers/deliveryDriver/deliveryDriver.controller");
const router = express.Router();
const multer = require("multer");
const { protect } = require("../../middleware/auth.middleware");
const { admin_protect } = require("../../middleware/adminAuth.middleware");
var storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, "./public/profileImages/");
  },
  filename: function (req, file, cb) {
    cb(null, Date.now() + file.originalname);
  },
});
var upload = multer({
  storage,
});
const { region } = require("../../middleware/currency.middleware");
var uploadMultiple = upload.fields([
  {
    name: "GovernmentIDPic",
  },
  { name: "GovernmentIDPicBackSide" },

]);
router.post(
  "/register-driver",
  // upload.single("GovernmentIDPic"),
  uploadMultiple,
  protect,
  registerDeliveryDriver
);
router.put(
  "/update-driverDetails",
  upload.single("GovernmentIDPic"),
  protect,
  updateDeliveryDriverDetails
);
router.delete("/delete-driver", protect, deleteDeliveryDriverById);
router.get("/get-driver/:name", protect, getDeliveryDriverByCity);
router.post("/assign-driver", admin_protect, assignDeliveryDriver);
router.post("/getDriverOrders", protect, getDriverOrdersByStatus);
router.post(
  "/changeDriverStatus",
  protect,
  upload.single("DeliveryConfirmationPic"),
  changeDriverOrderStatus
);
//router.post("/update-deliveryStatus", changePathaoOrderStatus);
router.post("/markReturnStatus", protect, markReturnedStatus);
router.post("/driver-dashboard", protect, driverDashBoardApi);
router.post("/check-availability", protect, checkDriverAvailability);
router.get("/get-driverDetails/:id", protect, getDeliveryDriverDetails);
router.post("/shipping-cost", protect, region, ShippingCostVendor);
router.post("/city-cost", admin_protect, shippingCostVendorCity);
router.post("/country-cost", admin_protect, shippingCostVendorCountry);
router.post("/update-pathaoStatus", admin_protect, updatePathaoOrderStatus);
// router.get("/update-pathaoStatus/:id", pathaoStatusUpdateWebhook);
router.post("/update-pathaoStatus-hook", pathaoStatusUpdateWebhook);
router.post("/get-codOrders", deliveryDriverCodOrders);
router.post(
  "/add-depositProof",
  upload.single("DriverDepositProof"),
  updateDriverDepositProof
);
router.post(
  "/changeStatus-ro",
  upload.single("DeliveryConfirmationPic"),
  changeDriverReturnOrderStatus
);

module.exports = router;
