const express = require("express");
const {
  addCourierService,
  getCourierService,
  deleteCourierService,
  updateCourierService,
  updateOrderDetailByOrderId,
  sendUserVendorContactNo,
  changeVendorShippingOrderStatus,
  updatePickupOrderStatus,
  deliveredPickupOrderStatus
} = require("../../controllers/courier/courier.controller");
const { admin_protect } = require("../../middleware/adminAuth.middleware");
const router = express.Router();
const multer = require("multer");
var storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, "./public/profileImages/");
  },
  filename: function (req, file, cb) {
    cb(null, Date.now() + file.originalname);
  },
});
var upload = multer({
  storage,
});
//!Country routes 
router.post("/add-courier", admin_protect, addCourierService);
router.get("/get-courier", admin_protect, getCourierService);
router.post("/delete-courier", admin_protect, deleteCourierService);
router.post("/update-courier", admin_protect, updateCourierService);
router.post("/update-order", admin_protect, updateOrderDetailByOrderId);
router.post("/send-contact", admin_protect, sendUserVendorContactNo);
router.post("/update-orderStatus", admin_protect, upload.single("DeliveryConfirmationPic"), changeVendorShippingOrderStatus);
router.post("/change-pickupStatus", admin_protect, updatePickupOrderStatus);
router.post("/delivered-pickupStatus", admin_protect, upload.single("DeliveryConfirmationPic"), deliveredPickupOrderStatus);
module.exports = router;
