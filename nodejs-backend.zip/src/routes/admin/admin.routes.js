const express = require("express");

const {
  sendContactEmail,
  sendContactAdminEmail,
  viewUsers,
  updateUsersDetailsByID,
  deleteUserById,
  viewUserById,
  addUser,
  updateRoles,
  showNote,
  createNote,
  updateNote,
  checkEmail,
  checkNumber,
  updateIP,
  setStatus,
  showType,
  viewRecordsReviewByAdmin,
  updateVendorAdminStatusById,
  viewRecordsReviewBySuperAdmin,
  updateVendorSuperAdminStatusById,
  getVendorCount,
  getProfileCount,
  getProductsReviewedByAdmin,
  updateProductsReviewedByAdminStatus,
  getProductsActiveStatus,
  updateProductsActiveStatusById,
  getProductsReviewedBySuperAdmin,
  getOrdersDetailsForAdmin,
  changePickupStatuses,
  getOrdersDetailsForSuperAdmin,
  getOrdersDetailsByOrderID,
  viewDeliveryDriverPendingRequestsByAdmin,
  updateDeliveryDriverStatusByAdmin,
  getOrdersForAdmin,
  getOrdersByStatusFilters,
  changeOrderStatuses,
  notifyUser,
  getOrderDetailsByVendorID,
  getRefundOrderDetail,
  getInAppNotifications,
  updateInAppNotifications,
  getRefundOrderDetailByOrderID,
  shippingByVendorOrders,
  getOrderByVendorPaymentStatus,
  updateVendorCommission,
  getVendorDetails,
  getOrderByVendorIDPaymentStatus,
  addVendorPaymentProcess,
  getVendorPaymentDetails,
  getCodPaymentOrders,
  updateDriverPaymentStatus,
  getSubCategoryByVendorId,
  deleteVendorSubCategoryById,
  updateVendorSubCategoryById,
  getDriverDetails,
  getDriverDetailsBySearchFilter,
  getDriverPaymentOrderByDriverID,
  addDriverPaymentProcess,
  getDriverPaymentDetails,
  setVendorCodStatus,
  updateReturnOrderStatusByVendor,
  assignReturnOrder,
  assignReturnOrderUSA,
  codRefundApis,
  getProductConfirmRefundOrders,
  getAllRefundOrders,
  getRefundOrderDetailFree,
  getRefundOrderDetailPaid,
  getProductConfirmRefundOrdersFree,
  getProductConfirmRefundOrdersPaid,
  getVendorSubcategoryUpdated,
  getOrderDetailsForInvoice,
  getStatiticContent
} = require("../../controllers/admin/admin.controller");

const {
  admin_protect
} = require("../../middleware/adminAuth.middleware");

const {
  protect
} = require("../../middleware/auth.middleware");

const {
  region
} = require("../../middleware/currency.middleware");

const router = express.Router();

const multer = require("multer");

var storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, "./public/profileImages/");
  },
  filename: function (req, file, cb) {
    cb(null, Date.now() + file.originalname);
  },
});

var upload = multer({
  storage,
});

router.post("/users", admin_protect, addUser);
router.post("/get", admin_protect, viewUsers);
router.get("/get/:id", admin_protect, viewUserById);
router.put("/update/:id", admin_protect, updateUsersDetailsByID);
router.delete("/delete/:id", admin_protect, deleteUserById);
router.put("/setRoles", admin_protect, updateRoles);
router.post("/create-notes", admin_protect, createNote);
router.get("/show-notes/:id", admin_protect, showNote);
router.put("/update-notes", admin_protect, updateNote);
router.post("/check-email", admin_protect, checkEmail);
router.post("/check-number", admin_protect, checkNumber);
router.put("/update-ip", updateIP);
router.get("/notifications", admin_protect, getInAppNotifications);
router.get("/update-notifications/:id", protect, updateInAppNotifications);
router.put("/status", admin_protect, setStatus);
router.get("/type", admin_protect, showType);
router.get("/get-businessRecords", admin_protect, viewRecordsReviewByAdmin);
router.post("/contact-email", sendContactAdminEmail);
router.post("/contact", sendContactEmail);
router.put(
  "/update-vendorAdminStatus/:id",
  admin_protect,
  updateVendorAdminStatusById
);
router.get(
  "/get-vendorBusinessRecord",
  admin_protect,
  viewRecordsReviewBySuperAdmin
);
router.post(
  "/update-vendorSuperAdminStatus/:id",
  admin_protect,
  updateVendorSuperAdminStatusById
);
router.get("/get-productByStatus", admin_protect, getProductsReviewedByAdmin);
router.get(
  "/get-productBySuperAdminStatus",
  admin_protect,
  getProductsReviewedBySuperAdmin
);
router.put(
  "/update-productStatus/:id",
  admin_protect,
  updateProductsReviewedByAdminStatus
);
router.get(
  "/get-productByActiveStatus",
  admin_protect,
  getProductsActiveStatus
);
router.put(
  "/update-productByActiveStatus/:id",
  admin_protect,
  updateProductsActiveStatusById
);
router.get("/get-vendorCount", admin_protect, getVendorCount);
router.get("/get-profileCount", admin_protect, getProfileCount);
router.post("/get-orders", admin_protect, getOrdersDetailsForAdmin);
router.post("/get-all-orders", admin_protect, getOrdersForAdmin);
router.post("/getStaticTable", getStatiticContent);
router.post("/update-status/:id", admin_protect, changePickupStatuses);
router.post("/order-details", admin_protect, getOrdersDetailsForSuperAdmin);
router.get("/orderDetails/:id", protect, getOrdersDetailsByOrderID);
router.get("/getOrder/:id", protect, region, getOrderDetailsForInvoice);
router.post("/getVendorOrder/:id", admin_protect, getOrderDetailsByVendorID);
router.get(
  "/pending-requests",
  admin_protect,
  viewDeliveryDriverPendingRequestsByAdmin
);
router.get(
  "/update-driverStatus/:id",
  admin_protect,
  updateDeliveryDriverStatusByAdmin
);
router.post("/getOrdersByStatus", admin_protect, getOrdersByStatusFilters);
router.post("/changeOrderStatuses", admin_protect, changeOrderStatuses);
router.post("/refund-details-free", admin_protect, getRefundOrderDetailFree);
router.post("/refund-details-paid", admin_protect, getRefundOrderDetailPaid);
router.get(
  "/refund-details/:id/:type",
  admin_protect,
  getRefundOrderDetailByOrderID
);
router.post("/notify-user", admin_protect, notifyUser);
router.post("/vendor-shipping", admin_protect, shippingByVendorOrders);
//! PayToVendor Api's route
router.post(
  "/vendorPaymentOrders",
  admin_protect,
  getOrderByVendorPaymentStatus
);
router.post("/update-commissionRate", admin_protect, updateVendorCommission);
router.post("/vendor-details", admin_protect, getVendorDetails);
router.get(
  "/vendorPaymentOrders/:id",
  admin_protect,
  getOrderByVendorIDPaymentStatus
);
router.post(
  "/add-vendorPayment",
  admin_protect,
  upload.single("PaymentConfirmation"),
  addVendorPaymentProcess
);
router.get("/get-paymentDetails/:id", admin_protect, getVendorPaymentDetails);
router.post("/get-codPaymentOrders", admin_protect, getCodPaymentOrders);
router.post("/update-paymentStatus", admin_protect, updateDriverPaymentStatus);
router.route("/get-vendorSubCategory/:id").get(getSubCategoryByVendorId);

router.route("/delete-vendorSubCategory").post(deleteVendorSubCategoryById);
router.route("/update-vendorSubCategory").post(updateVendorSubCategoryById);
router.post(
  "/driver-detailsFilter",
  admin_protect,
  getDriverDetailsBySearchFilter
);
router.post("/driver-details", admin_protect, getDriverDetails);
router.get(
  "/driverPaymentOrders/:id",
  admin_protect,
  getDriverPaymentOrderByDriverID
);
router.post(
  "/add-driverPayment",
  admin_protect,
  upload.single("PaymentConfirmation"),
  addDriverPaymentProcess
);
router.get(
  "/get-driverPaymentDetails/:id",
  admin_protect,
  getDriverPaymentDetails
);
router.post("/update-vendorCodStatus", admin_protect, setVendorCodStatus);
router.post("/assign-ro", admin_protect, assignReturnOrder);
router.post(
  "/cod-refund",
  admin_protect,
  upload.single("RefundCodDepositProof"),
  codRefundApis
); //api//
router.post(
  "/getConfirm-ro-free",
  admin_protect,
  getProductConfirmRefundOrdersFree
);
router.post(
  "/getConfirm-ro-paid",
  admin_protect,
  getProductConfirmRefundOrdersPaid
);
router.post("/getAll-ro", admin_protect, getAllRefundOrders);
router.post(
  "/assign-ro-usa",
  admin_protect,
  upload.single("RefundDocument"),
  assignReturnOrderUSA
);
router.route("/get-vendorSubCategories/:id").get(getVendorSubcategoryUpdated);

module.exports = router;
