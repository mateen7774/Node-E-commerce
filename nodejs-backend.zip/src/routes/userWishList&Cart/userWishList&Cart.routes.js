const express = require("express");
const {
  addUserWishList,
  deleteUserWishList,
  viewUserWishList,
  addToCart,
  deleteFromCart,
  updateCart,
  viewCartList,
  viewCartListMobile,
  temporaryCart,
  getInventoryCount,
  viewCartListwithTax,
} = require("../../controllers/userWishList&Cart/userWishList&Cart.controller");
const router = express.Router();
const { protect } = require("../../middleware/auth.middleware");
const { region } = require("../../middleware/currency.middleware");
router.post("/addUserWishList", protect, addUserWishList);
router.get("/viewUserWishList", protect, viewUserWishList);
router.delete("/deleteUserWishList/:id", protect, deleteUserWishList);
//router.post('/addCart', protect, addToCart);
router.post("/addCart", protect, addToCart);
router.get("/viewCart", region, protect, viewCartList);
router.get("/viewCart-m", protect, region, viewCartListMobile);
router.put("/updateCart", protect, updateCart);
router.post("/removeCart/:id", protect, deleteFromCart);
router.route("/temporaryCart").post(temporaryCart);
router.post("/get-inventory", getInventoryCount);
module.exports = router;
